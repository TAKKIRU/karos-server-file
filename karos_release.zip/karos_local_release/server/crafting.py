"""Крафт (у NPC и своими силами) и разборка предметов — данные data/craft.json (tools/craft.py; имя модуля не craft — tools/ в sys.path).

Пакеты (AMo; в записях оригинала крафта нет — разобрано по клиенту):
  Счётчик запросов (0x0041f753) сборщик пишет первым, но он уходит в заголовок кадра
  (cat, sub, u32 счётчик) — данные начинаются с eid (сверено с C 06/5a в записи оригинала).
  C 06/16 крафт у NPC (сборщик 0x0050bb63, окно CGuiComposite 0x0050c9b0):
      +0 eid, +4 eid NPC, +8 рецепт, +12 u16 0x6f.
  S 06/16 (обработчик 0x00654df6, CItemCombinationPacket, кадр >= 20):
      +0 eid, +4 eid NPC, +8 рецепт, +12 u16 код:
      0x6f «Успешная комбинация [%s]», 0x70 «Недостаточно каратов», 0x71 «Нет места в рюкзаке»,
      0x72 «Нет материалов», 0x73 «Неизвестная ошибка», 0x85 «Неудача».
  C 06/3f крафт своими силами (сборщик 0x0050bafd): +0 eid, +4, +8, +12 рецепт,
      +16 u16: 0x177 — начать, 0x176 — прервать (0x0050cc4d).
  S 06/3f (обработчик 0x0065503b, кадр >= 24): +0 eid, +4, +8, +12 рецепт, +16 u16 код:
      0x177 — полоса изготовления на время рецепта (+0x14), 0x178 «успешно скомбинировал»,
      0x85 «Неудача», 0x176 «прервано», 0x70–0x73 как у 06/16. Пока нет ответа, клиент
      не шлёт следующий запрос (флаг игрока +0x75e), «сделать N раз» — N запросов подряд.
  C 06/56 разборка (сборщик 0x00452a2c, подтверждение 0x0061f22e): +0 eid,
      +4 u8 сумка, +5 u8 ячейка (сквозная), +6 предмет, +10 0, +14 0, +18 u16 0x5a.
  S 06/56 (обработчик 0x0065b77a, CItemDismantlePacket, кадр >= 26): та же раскладка,
      +10 полученный предмет, +14 количество, +18 u16 код:
      0x5a «Получен предмет [%s] X %d», 0x230 «Невозможно разобрать», 0x231 «Недостаточно
      денег», 0x232 «Не удалось разобрать предмет».
  C 06/47 переработка в «Дух воина» (окно CGuiRecycleComposite, отправка 0x0050cfc3, сборщик
      0x0050bbbf): +0 eid, +4 u32 сумка, +8 u32 ячейка, +12 предмет, +16 u16 0x69, +18 0, +22 0.
  S 06/47 (обработчик 0x0065b09d, CItemCombiReinforcingPacket, разбор 0x00659821) — та же
      раскладка, +18 полученный предмет, +22 количество, +16 код: 0x1dd «Успешное
      преобразование: %s», 0x1d9 «Нет необходимого материала», 0x1da «Нужно больше
      дополнительных материалов», 0x1db «Недостаточно каратов», 0x1dc «Рюкзак заполнен».
Числа в пакетах — big-endian.
"""
import json, os, random, struct

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')

try:
    _d = json.load(open(os.path.join(DATA, 'craft.json'), encoding='utf-8'))
except (OSError, ValueError):
    _d = {}
RECIPES = {int(k): v for k, v in _d.get('recipes', {}).items()}
NPC = {int(k): v for k, v in _d.get('npc', {}).items()}
PC = {int(k): v for k, v in _d.get('pc', {}).items()}
DISMANTLE = _d.get('dismantle', [])
GRADE = {int(k): v for k, v in _d.get('grade', {}).items()}
RECYCLE = {int(k): v for k, v in _d.get('recycle', {}).items()}

OK, NO_MONEY, BAG_FULL, NO_MATS, ERROR, FAIL = 0x6f, 0x70, 0x71, 0x72, 0x73, 0x85
PC_CANCEL, PC_START, PC_OK = 0x176, 0x177, 0x178
DIS_OK, DIS_CANT, DIS_MONEY, DIS_FAIL = 0x5a, 0x230, 0x231, 0x232
RC_NO_MAT, RC_NO_EXTRA, RC_MONEY, RC_FULL, RC_OK = 0x1d9, 0x1da, 0x1db, 0x1dc, 0x1dd


def find_recipe(pl, offsets):
    """Номер рецепта из запроса: первое из смещений, где лежит известный рецепт."""
    for o in offsets:
        if len(pl) >= o + 4:
            v = struct.unpack_from('>I', pl, o)[0]
            if v in RECIPES:
                return v
    return None


def missing(inv, rec):
    """-> [(материал, нужно, есть)] того, чего не хватает."""
    out = []
    for item, n in rec['mats']:
        have = inv.count_item(item)
        if have < n:
            out.append((item, n, have))
    return out


BATCH_MAX = 1000          # попыток за одно «Изготовить всё»
# рецепты, которые где-то можно изготовить (у ремесленника или своими силами) и с материалами
LISTED = frozenset(r for r in ({x for v in NPC.values() for x in v} | set(PC))
                   if r in RECIPES and RECIPES[r]['mats'])


def affordable(inv, rec, gold_item, keep=None):
    """Сколько попыток рецепта хватает по материалам и каратам (не больше BATCH_MAX)."""
    need = {}
    for item, n in rec['mats']:
        need[item] = need.get(item, 0) + n
    if rec['cost']:
        need[gold_item] = need.get(gold_item, 0) + rec['cost']
    n = BATCH_MAX
    for item, per in need.items():
        have = inv.gold() if item == gold_item else inv.count_item(item, keep)
        n = min(n, have // per)
    return n


def roll(rec):
    return random.randrange(10000) < rec['chance']


def build_npc(eid, npc_eid, rid, code):
    return struct.pack('>IIIH', eid, npc_eid, rid, code)


def build_pc(eid, a, b, rid, code):
    return struct.pack('>IIIIH', eid, a, b, rid, code)


# ---- разборка ----
def dismantle_rule(item, kind, level):
    """Правило разборки для предмета (вид, грейд, ярус по уровню) или None."""
    g = GRADE.get(item)
    if not g:
        return None
    tier = max(1, min(12, (int(level or 1) + 9) // 10))
    same = [r for r in DISMANTLE if r['kind'] == kind and r['grade'] == g]
    if not same:
        return None
    return next((r for r in same if r['tier'] == tier),
                min(same, key=lambda r: abs(r['tier'] - tier)))


DISMANTLE_ALWAYS = True   # по просьбе: разборка всегда успешна (как на Genesis). False — как в таблице клиента:
                          # доли материалов из 100, остаток — неудача (у обычных вещей успех 25%)


def dismantle_roll(rule):
    """-> (материал, количество) или None — неудача. Материал выбирается по долям правила; при
    DISMANTLE_ALWAYS неудачи нет (доли нормируются на их сумму). Количество — множитель правила
    (дробная часть — шанс на ещё одну штуку)."""
    shares = [(item, ch * 100.0 / (of or 100)) for item, ch, of in rule['out']]
    total = sum(s for _i, s in shares)
    if total <= 0:
        return None
    x = random.random() * (total if DISMANTLE_ALWAYS else 100)
    acc = 0.0
    for item, s in shares:
        acc += s
        if x < acc:
            m = rule['mult']
            n = int(m) + (1 if random.random() < m - int(m) else 0)
            return item, max(1, n)
    return None


def build_dismantle(eid, cont, cell, item, got, count, code):
    return struct.pack('>IBBIIIH', eid, cont & 0xff, cell & 0xff, item, got, count, code)


# ---- переработка в «Дух воина» ----
def parse_recycle(pl):
    pl = bytes(pl) + bytes(max(0, 26 - len(pl)))
    return struct.unpack_from('>IIII', pl, 0)          # eid, сумка, ячейка, предмет


def build_recycle(eid, cont, cell, item, code, got=0, n=0):
    return struct.pack('>IIIIHII', eid, cont, cell, item, code, got, n)
