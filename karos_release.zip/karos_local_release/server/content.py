"""Загрузка разобранного контента в единую игровую базу для сервера.

Источники (всё получено реверсом, §75-99):
  content.sqlite       — предметы, навыки, NPC, квесты
  spawns.json          — 10 535 точек спавна мобов по картам
  warps.json           — 644 портала между локациями
  maplist.json         — реестр карт (ID <-> имя)
  item_attrs.json      — урон оружия по уровням заточки
  npcInfo (typed)      — уровень, радиус агро, дальность атаки мобов
"""
import os, json, sqlite3

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))


def _j(name):
    p = os.path.join(ROOT, name)
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else None


NPCINFO = os.path.join(os.path.dirname(ROOT), 'ResUnpak', 'Interface', 'IE_Lod', 'npcInfo.lod_rus')
NPC_REC = 234     # npcInfo: u32 число записей, далее записи по 234 байта


def _npcinfo_lod():
    """npcInfo.lod_rus (режим 1): +0 id, +68 уровень (id = вид×100 + уровень; +60/+64 — не он),
    +132 имя (cp1251, до \\0). HP/опыта/урона в клиентских таблицах нет."""
    import struct, sys
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(ROOT), 'tools'))
        from lod_decode import decode
        d = decode(open(NPCINFO, 'rb').read(), 1)
    except (OSError, ImportError):
        return {}
    out = {}
    for k in range(struct.unpack_from('<I', d, 0)[0]):
        o = 4 + k * NPC_REC
        if o + NPC_REC > len(d):
            break
        nid = struct.unpack_from('<I', d, o)[0]
        lvl = struct.unpack_from('<i', d, o + 68)[0]   # +68 уровень (Малый паук 1001801 -> 1)
        name = d[o + 132:o + NPC_REC].split(b'\0')[0].decode('cp1251', 'replace')
        grade = struct.unpack_from('<i', d, o + 20)[0]  # +20 класс: 90–97 полевые боссы, 1013/1014/1016 — боссы подземелий
        out[nid] = {'name': name, 'level': max(1, lvl), 'grade': grade}
    return out


class Content:
    def __init__(self):
        self.db = sqlite3.connect(os.path.join(ROOT, 'content.sqlite'))
        self.dbt = sqlite3.connect(os.path.join(ROOT, 'content_typed.sqlite'))
        self.maps = self._load_maps()
        self.spawns = _j('spawns.json') or {}
        # имена папок карт и maplist различаются регистром («peltrok» / «Peltrok»):
        # без этого в Пельтроке сервер не знал своих NPC (некликабельны)
        # подземелья: в файлах клиента расстановки нет — берём из записей оригинала
        # (tools/cap_spawns.py -> data/spawns_capture.json, ключ — номер карты: у
        # подземелий разных уровней общие файлы карты — 29014/29614, 29016/29516)
        self.spawns_by_id = {int(k): v for k, v in (_j('spawns_capture.json') or {}).items()
                             if str(k).isdigit()}
        # полная расстановка интерьерных карт — из объектов карты .mo (tools/mo_spawns.py):
        # точки с номерами, которые клиент ждёт в 04/02 +0x44 (сверено с записями 29014/29614/29516)
        for k, v in (_j('spawns_mo.json') or {}).items():
            if str(k).isdigit() and v:
                self.spawns_by_id[int(k)] = v
        for m in self.maps.values():
            if m['name'] not in self.spawns:
                for k in list(self.spawns):
                    if k.lower() == m['name'].lower():
                        self.spawns[m['name']] = self.spawns[k]
        # размер тайла: у почти всех карт 5120, у Центри-Хейла (караульная башня) и Mine_Dungeon — 10240:
        # локальные координаты точек .npc доходят до 10236. С 5120 мобы караульной башни стояли на ряд ниже:
        # в подвалах, саду и на этажах их не было, в катакомбах МакТроя — чужие
        self.tile = {}
        for name, sp in self.spawns.items():
            loc = [max(s['x'], s['z']) for s in sp if max(s['x'], s['z']) <= 10300]
            self.tile[name] = 10240.0 if loc and max(loc) > 5200 else 5120.0
        try:
            import terrain                  # рельеф .ter у таких карт другого формата — не читать
            terrain.BIG_TILE.update(n for n, t in self.tile.items() if t != 5120.0)
        except ImportError:
            pass
        self.warps = _j('warps.json') or {}
        self.weapon_dmg = _j('item_attrs.json') or {}
        self.npc = self._load_npc()
        self.filters = _j('filters.json') or {}

    def _load_maps(self):
        out = {}
        for m in (_j('maplist.json') or []):
            mid = m['head'][1] if m.get('head') else None
            if mid:
                out[mid] = {'id': mid, 'name': m['name'], 'bgm': m.get('bgm', '')}
        return out

    def _load_npc(self):
        """npcId -> {name, level, aggro, atk_range}. Основа — content_typed
        (дальность/агро), имя и уровень — из клиентского npcInfo.lod_rus."""
        out = self._load_npc_sqlite()
        for nid, info in _npcinfo_lod().items():
            out.setdefault(nid, {'id': nid, 'atk_range': 30.0, 'aggro': 200.0}).update(info)
        return out

    def _load_npc_sqlite(self):
        out = {}
        try:
            q = ('SELECT o0_i, o60_i, o96_f64, o104_f64, strings '
                 'FROM npcInfo WHERE strings != ""')
            for nid, lvl, atk, aggro, name in self.dbt.execute(q):
                out[nid] = {'id': nid, 'name': name.split('|')[0],
                            'level': lvl, 'atk_range': atk, 'aggro': aggro}
        except sqlite3.Error:
            pass
        return out

    def tile_size(self, map_name):
        return self.tile.get(map_name, 5120.0)

    def map_spawns(self, map_name, map_id=None):
        """точки спавна на карте -> [{model, npcId, x, y, z, npc}]. Карта без своей
        расстановки (подземелье) — из записей оригинала по номеру карты."""
        out = []
        src = self.spawns.get(map_name, [])
        try:
            import dungeon                       # подземелье со сценарием: полный список .mo со скрытыми волнами
            src = dungeon.spawns(map_id) or src
        except ImportError:
            pass
        if not src and map_id in self.spawns_by_id:
            src = self.spawns_by_id[map_id]
        for s in src:
            info = self.npc.get(s['id'])
            out.append({**s, 'npc': info})
        return out

    def stats(self):
        return {
            'maps': len(self.maps),
            'npc_types': len(self.npc),
            'spawn_maps': len(self.spawns),
            'total_spawns': sum(len(v) for v in self.spawns.values()),
            'warps': sum(len(v) for v in self.warps.values()),
            'weapons': len(self.weapon_dmg),
        }


if __name__ == '__main__':
    c = Content()
    print("Игровая база загружена:")
    for k, v in c.stats().items():
        print(f"  {k:16} {v}")
    # пример: мобы одной карты со статами
    for mname in ('berneo', 'Antcave'):
        sp = c.map_spawns(mname)
        named = [s for s in sp if s.get('npc')]
        print(f"\n{mname}: {len(sp)} спавнов, {len(named)} со статами NPC")
        for s in named[:4]:
            n = s['npc']
            print(f"   {n['name'][:20]:22} ур.{n['level']:>3} агро={n['aggro']:.0f} "
                  f"@({s['x']:.0f},{s['z']:.0f})")
