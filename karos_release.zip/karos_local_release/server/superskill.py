"""Супер-навыки: вложение очков флетты (данные data/super_skills.json, tools/super_table.py).

У группы классов (класс // 100 * 100: 100 … 800) 12 супер-навыков в три ряда (skillTreeSuper).
Уровень навыка покупается очками флетты (08/01 +59): цена уровня — skillLevel [2]
(ур.1 — 1, ур.2 — 865, ур.3 — 5530, ур.4 — 7350, ур.5 — 8650). Очки копятся к следующему
уровню; набралось — уровень растёт, остаток идёт дальше.

S 05/0c (CAttackSkillSuperListPacket, обработчик 0x0065d05c): BE eid, BE u16 15, затем 15 ячеек
  по 13 байт (LE): u32 навык, u8 уровень, u32 опция (камень супер-навыка, skillEnchant 600xxx),
  u32 очков вложено в следующий уровень. Пустая ячейка — нули.
C 05/0e (окно вложения очков, 0x004cca14, сборщик 0x004cc248): +0 eid, +4 навык, +8 очков,
  +12 u8 0x20, +13 u16 0x2a6, +15 u8 0.
S 05/0e (CAttackSkillSuperLevelUPPacket, 0x0065d132): та же раскладка, +12 u8 уровень,
  +13 u16 код (0x2a6 — успех, 0x2a7 «Возможно только применение супер-навыка», 0x2a8
  «Неудачное повышение уровня»), +15 u8: 0 «Навык %s был усилен до ур. %d»,
  1 «Изучено: %s» (+ «усилен»), 2 «Потрачено очков: %d».
Запись оригинала (remain3): 6801 ур.2, вложено 14; вложили 14 -> ответ (ур.2, режим 2),
  список с 28, очки флетты 14 -> 0.

Камни супер-навыка (опция; окно CGuiSkillEnchant 0x004cb489): предметы 600101…631105, номер
камня = опция в 05/0c. Вид 5 «(Пассивный)» — на пассивные навыки (skill_effects 'k' = 0),
вид 6 «(Атака)», «(Усиление)» — на остальные. Цена (проверка окна): вставить 10 000 карат,
заменить 20 000 (старый камень — в рюкзак), вынуть 10 000 (камень — в рюкзак).
C 05/0d (сборщик 0x00623d96, отправка 0x00624464): +0 eid, +4 навык, +8 камень, +12 u8 сумка,
  +13 u8 ячейка (сквозная), +14 u16 0x2a1. S 05/0d (CAttackSkillOptionEquipPacket,
  0x0065d602) — та же раскладка, код: 0x2a1 «Применена опция к навыку %s», 0x2a2 «Заменена
  опция», 0x2a3 «Возможно только применение камня», 0x2a4 «Неправильный тип камня»,
  0x2a5 «Ошибка супер-навыка», 0x0b «нет места в инвентаре».
C 05/0f (0x006245b1): +0 eid, +4 навык, +8 u16 0x2a9. S 05/0f (…PutOutPacket, 0x0065d3e2):
  та же раскладка, 0x2a9 «Удалена опция навыка %s», 0x2aa «Неудачное удаление», 0x0b нет места.
"""
import json, os, struct

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    _d = json.load(open(os.path.join(DATA, 'super_skills.json'), encoding='utf-8'))
except (OSError, ValueError):
    _d = {}
TREE = {int(k): v for k, v in _d.get('tree', {}).items()}
COST = {int(k): {int(a): b for a, b in v.items()} for k, v in _d.get('cost', {}).items()}
STONES = {int(k): v for k, v in _d.get('stones', {}).items()}
SLOTS = 15
OK, ONLY_SUPER, FAIL = 0x2a6, 0x2a7, 0x2a8
LEVELED, LEARNED, SPENT = 0, 1, 2
APPLIED, REPLACED, ONLY_STONE, WRONG_STONE, ERROR, BAG_FULL = 0x2a1, 0x2a2, 0x2a3, 0x2a4, 0x2a5, 0x0b
REMOVED, REMOVE_FAIL = 0x2a9, 0x2aa
PRICE_APPLY, PRICE_REPLACE, PRICE_REMOVE = 10000, 20000, 10000


def group_skills(cls):
    return {sid for _r, sid, _k in TREE.get(int(cls) // 100 * 100, [])}


def parse_list(body):
    """S 05/0c -> [[навык, уровень, опция, очки]] (только занятые ячейки)."""
    out = []
    if not body or len(body) < 6:
        return out
    n = struct.unpack_from('>H', body, 4)[0]
    for i in range(min(n, SLOTS)):
        o = 6 + 13 * i
        if o + 13 > len(body):
            break
        sid, lv, opt, pts = struct.unpack_from('<IBII', body, o)
        if sid:
            out.append([sid, lv, opt, pts])
    return out


def build_list(eid, entries):
    out = struct.pack('>IH', eid, SLOTS)
    for i in range(SLOTS):
        e = entries[i] if i < len(entries) else (0, 0, 0, 0)
        out += struct.pack('<IBII', *e)
    return out


def invest(entries, sid, pts):
    """Вложить очки. -> (уровень, режим ответа) или None — нельзя (уровень на пределе)."""
    e = next((x for x in entries if x[0] == sid), None)
    if e is None:
        if len(entries) >= SLOTS:
            return None
        e = [sid, 0, 0, 0]
        entries.append(e)
    costs = COST.get(sid, {})
    if e[1] + 1 not in costs:
        return None
    start = e[1]
    e[3] += pts
    while e[1] + 1 in costs and e[3] >= costs[e[1] + 1]:
        e[3] -= costs[e[1] + 1]
        e[1] += 1
    if e[1] == start:
        return e[1], SPENT
    return e[1], LEARNED if start == 0 else LEVELED


def parse_req(pl):
    pl = bytes(pl) + bytes(max(0, 16 - len(pl)))
    eid, sid, pts = struct.unpack_from('>III', pl, 0)
    return eid, sid, pts, pl[12]


def build_reply(eid, sid, pts, level, code, mode):
    return struct.pack('>IIIBHB', eid, sid, pts, level & 0xff, code, mode)


# ---- камни (опции) ----
def stone_fits(stone, skill_is_passive):
    st = STONES.get(stone)
    if not st:
        return None
    return (st['kind'] == 5) == bool(skill_is_passive)


def parse_equip(pl):
    pl = bytes(pl) + bytes(max(0, 16 - len(pl)))
    eid, sid, stone, cont, cell = struct.unpack_from('>IIIBB', pl, 0)
    return sid, stone, cont, cell


def build_equip(eid, sid, stone, cont, cell, code):
    return struct.pack('>IIIBBH', eid, sid, stone, cont & 0xff, cell & 0xff, code)


def build_putout(eid, sid, code):
    return struct.pack('>IIH', eid, sid, code)


# ---- камни «Атака» в бою: дебаф цели при ударе супер-навыком ----
# Группа камня (камень // 100): 6301 полный шок (n с — моб не ходит и не бьёт), 6302 частичный
# шок (n с — не бьёт), 6303 приостановка движения, 6304 приостановка атаки, 6305 молчание
# (запрет предметов — мобам не нужно), 6306 скорость атаки −n%, 6307 скорость движения −n%,
# 6308 защита −n% (урон по мобу +n%), 6309 атака −n%, 6310 «сильный шок» — этот удар +n%,
# 6311 перезарядка навыка −n с (считает клиент). Длительность процентных дебафов в данных нет —
# DEBUFF_SECS (допущение).
DEBUFF_SECS = 5.0


def entry(entries, sid):
    return next((e for e in entries if e[0] == sid), None)


def on_hit(mob, stone, now):
    """Наложить дебаф камня на моба. -> множитель урона этого удара."""
    st = STONES.get(stone)
    if not st or stone // 10000 != 63:
        return 1.0
    g, n = stone // 100, float(st.get('n', 0))
    db = getattr(mob, 'debuffs', None)
    if db is None:
        db = mob.debuffs = {}
    if g == 6301:
        db['stun'] = (1, now + n)
    elif g == 6302:
        db['noatk'] = (1, now + n)
    elif g == 6303:
        db['root'] = (1, now + n)
    elif g == 6304:
        db['noatk'] = (1, now + n)
    elif g == 6306:
        db['aspd'] = (max(0.1, 1 - n / 100), now + DEBUFF_SECS)
    elif g == 6307:
        db['move'] = (max(0.1, 1 - n / 100), now + DEBUFF_SECS)
    elif g == 6308:
        db['def'] = (1 + n / 100, now + DEBUFF_SECS)
    elif g == 6309:
        db['atk'] = (max(0.0, 1 - n / 100), now + DEBUFF_SECS)
    elif g == 6310:
        return 1 + n / 100
    return 1.0


def mob_mod(mob, key, now, default=None):
    """Значение действующего дебафа моба или default."""
    db = getattr(mob, 'debuffs', None)
    if not db or key not in db:
        return default
    v, until = db[key]
    if now >= until:
        del db[key]
        return default
    return v


# ---- смена супер-навыка (купон, 06/5d) ----
# Навыки дерева идут парами в порядке skillTreeSuper: (0,1), (2,3) … — в каждом ряду две пары
# (окно CGuiSkillChange 0x004cc857 берёт выбранный навык и его соседа по паре). Окно открывает
# использование предмета категории 79 «Купон смены супер-навыка» (0x00622a7c) с его сумкой и ячейкой.
# C 06/5d (сборщик 0x004cc2b8, отправка 0x004ccd4e): +0 навык, +4 навык-пара, +8 u8 сумка купона,
#   +9 u8 ячейка купона, +10 u16 0. S 06/5d (CSuperSkillChange, 0x0065d7e5): та же раскладка,
#   +10 код: 0x2ac «Ошибка супер-навыка», 0x2ad «Невозможно сменить супер-навык, пока используется
#   камень», иное — «Супер-навык сменен».
COUPON_CAT = 79
CH_ERROR, CH_STONE, CH_OK = 0x2ac, 0x2ad, 0x2ab


def pair_of(cls, sid):
    lst = [x[1] for x in TREE.get(int(cls) // 100 * 100, [])]
    if sid not in lst:
        return None
    i = lst.index(sid)
    j = i ^ 1
    return lst[j] if j < len(lst) else None


def parse_change(pl):
    pl = bytes(pl) + bytes(max(0, 12 - len(pl)))
    a, b, cont, cell = struct.unpack_from('>IIBB', pl, 0)
    return a, b, cont, cell


def build_change(a, b, cont, cell, code):
    return struct.pack('>IIBBH', a, b, cont & 0xff, cell & 0xff, code)


def change(entries, cls, a, b):
    """Перевести навык a в пару b (уровень и очки сохраняются). -> код ответа."""
    e = entry(entries, a)
    if e is None or e[1] < 1 or pair_of(cls, a) != b:
        return CH_ERROR
    other = entry(entries, b)
    if other is not None and other[1] > 0:
        return CH_ERROR
    if e[2]:
        return CH_STONE
    if other is not None:
        entries.remove(other)
    e[0] = b
    return CH_OK


# ---- срабатывание навыка от вещи (itemInvokeSkill, tools/proc_table.py) ----
import random as _rnd
try:
    PROCS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'item_procs.json'))).items()}
except (OSError, ValueError):
    PROCS = {}
PROC_BUFF_SECS = 10.0          # длительность бафа от срабатывания (в данных нет — допущение)


def procs_for(equipped_items):
    """[(навык, когда, шанс)] надетых вещей."""
    return [tuple(PROCS[i]) for i in equipped_items if i in PROCS]


def roll_procs(procs, when, rng=_rnd):
    return [p[0] for p in procs if p[1] in when and rng.random() < p[2] / 10000.0]
