"""Гача-автоматы (окно «гача слоты», категория 15).

Протокол — запись оригинала (docs/capture_orig_1.md, 23:08):
  C 15/02 (BE u16 1, u16 1, u32 0) -> S 15/02 список автоматов:
     BE u16 1, u16 1, u16 автоматов, u16 записей; записи по 16 байт (LE):
     u16 автомат, u16 ячейка, u16 0, u16 2, u16 цена (жетонов), u16 призов, u32 жетон.
  C 15/03 (BE u16 автомат, u16 ячейка, u16 1, u16 0) -> S 15/03 призы:
     BE u16 автомат, u16 ячейка, u16 число, u16 2; записи по 12 байт (LE):
     u16 номер, u32 предмет, u16 кол-во, u16 вес, u16 флаг.
  C 15/04 прокрутка (запись orig_hl 23:38): BE u16 автомат, 0, u16 ячейка, 0, u32 контейнер
  монеты, u32 ячейка монеты, 6 нулей, u16 0x025E -> S 06/06 приз, S 15/04 (build_spin),
  S 06/06 монета (остаток).

Автомат 1 — призы автомата 1 оригинала; 2-4 — пулы Karos Genesis (overlay/ui/items.js,
KAROS_GACHA, редкость SS..E -> вес). Жетон — «Лотерейный билет» (99998): в клиенте нет
монеты автоматов оригинала (999994084).
"""
import json, os, random, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOKEN = 99998                      # «Лотерейный билет»
TOKEN_PRICE = 10000                # караты за билет (комиссионка/магазин)
GRADE_W = {'SS': 1, 'S': 3, 'A': 10, 'B': 30, 'C': 60, 'D': 80, 'E': 100}
SLOTS = 4

# Автомат 1 оригинала (запись 23:08): предмет, кол-во, вес
ORIG_1 = [(999995108, 1, 1), (48030, 1, 1), (1000002685, 1, 2), (500130007, 1, 10),
          (400153003, 1, 20), (320014, 1, 20), (400140003, 1, 20), (320029, 1, 20),
          (400140024, 1, 20), (320030, 1, 20), (400140020, 1, 20), (1000002205, 1, 20),
          (1000002631, 1, 20), (1000002634, 1, 60), (99996, 3, 60), (400099991, 1, 80),
          (400140010, 1, 80), (310000, 1, 80), (500200075, 1, 80), (90074, 2, 80),
          (400140017, 2, 80), (500200066, 2, 80), (100140025, 3, 80), (400140106, 35, 80),
          (400060927, 4, 89), (400140008, 7, 90), (400153001, 1, 100), (400153002, 1, 100),
          (100141101, 1, 100), (60901, 12, 100), (60902, 12, 100), (141301, 1, 140)]


def _genesis_pools():
    p = os.path.join(os.path.dirname(ROOT), 'Karos Genesis', 'overlay', 'ui', 'items.js')
    try:
        s = open(p, encoding='utf-8').read()
        i = s.index('window.KAROS_GACHA')
        return json.loads(s[s.index('=', i) + 1:].strip().rstrip(';'))
    except (OSError, ValueError):
        return {}


class Gacha:
    def __init__(self, items):
        self.items = items
        self.machines = []          # [{'cost', 'prizes': [(item, count, weight, flag)]}]
        self._add([(i, n, w) for i, n, w in ORIG_1], cost=2)
        pools = _genesis_pools()
        for key, cost in (('1', 1), ('3', 4), ('4', 6)):
            pool = sorted(((int(i), 1, GRADE_W.get(g, 50)) for i, g in pools.get(key, {}).items()),
                          key=lambda x: x[2])
            self._add(pool, cost)

    def _add(self, pool, cost):
        prizes = [(i, n, w, 1 if w <= 3 else 0) for i, n, w in pool if i in self.items][:35]
        if prizes:
            self.machines.append({'cost': cost, 'prizes': prizes})

    def build_machines(self):
        n = len(self.machines)
        out = bytearray(struct.pack('>HHHH', 1, 1, n, n * SLOTS))
        for m, mach in enumerate(self.machines, 1):
            for slot in range(1, SLOTS + 1):
                out += struct.pack('<HHHHHHI', m, slot, 0, 2, mach['cost'],
                                   len(mach['prizes']), TOKEN)
        return bytes(out)

    def build_prizes(self, m, slot):
        mach = self.machines[m - 1] if 1 <= m <= len(self.machines) else self.machines[0]
        out = bytearray(struct.pack('>HHHH', m, slot, len(mach['prizes']), 2))
        for k, (item, cnt, w, fl) in enumerate(mach['prizes'], 1):
            out += struct.pack('<HIHHH', k, item, cnt, w, fl)
        return bytes(out)

    def spin(self, m, rng=random):
        """-> (предмет, кол-во, цена в жетонах, номер приза с 1)."""
        mach = self.machines[m - 1] if 1 <= m <= len(self.machines) else self.machines[0]
        total = sum(w for _, _, w, _ in mach['prizes'])
        r = rng.uniform(0, total)
        for k, (item, cnt, w, _) in enumerate(mach['prizes'], 1):
            r -= w
            if r <= 0:
                return item, cnt, mach['cost'], k
        item, cnt, _, _ = mach['prizes'][-1]
        return item, cnt, mach['cost'], len(mach['prizes'])


def build_spin(m, slot, item, idx, code=0x025E):
    """S 15/04 (запись оригинала 23:38): BE u16 автомат, 0, u16 ячейка, 0, 6 нулей,
    u32 предмет, u32 номер приза, u16 код 0x025E."""
    return struct.pack('>HHHH', m, 0, slot, 0) + bytes(6) + struct.pack('>IIH', item, idx, code)
