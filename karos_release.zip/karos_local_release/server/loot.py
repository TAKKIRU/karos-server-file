"""Добыча с мобов. Таблиц дропа в клиенте нет. Частоты — по записям ОРИГИНАЛА (orig_1, orig_hl_Pers4x,
remain3_persons: 159 своих убийств ур.2–68, разбор — docs/drop_original.md): 0,43 предмета на убийство
(61% убийств — только караты), части монстра 80xxx — 0,154, материалы 90xxx — 0,074, Божественное
перо — 0,037, зелья здоровья — 0,025, свиток чарования и Цветок удачи — по 0,006, снаряжение — 0,031.
Раньше было по Genesis (≈1,1 предмета + 33% снаряжения на убийство — втрое-вдесятеро щедрее).
  * караты — всегда, сколько — progression.mob_gold (свои, ×15 по просьбе);
  * моб из официальной базы GameXP (WIKI_DROPS, ~90% точек спавна): состав — список базы, частота — на
    категорию по записям оригинала (WIKI_RATES), снаряжение — тоже из списка базы;
  * моб с таблицей Genesis (≥ 20 убийств, data/genesis_drops.json), если его нет в базе: состав — его, доли
    × ORIG_SCALE (0,37 = 0,39 / 1,06 — объём оригинала к объёму Genesis);
  * моб без таблицы: общий набор оригинала (GENERIC) + 3 «части монстра» вида по 5%;
  * снаряжение (правило Genesis, частота оригинала): 3% — одна вещь любого класса, оружие или
    броня, грейд 1–4, уровень — ближайшая ступень выше уровня моба (60%) и две ниже (по 20%).
Предметы, которых нет в нашем itemBase (99987–99990 — в оригинале 6% убийств), не выпадают.
Гиганты («Гигантский …»): всё, кроме карат, бросается дважды — вдвое больше предметов (по просьбе).
Боссы (npcInfo +20: 90–97, 1013/1014/1016) — «крутая» добыча (BOSS_*): караты ×10, 3 вещи грейда 3–4
ступени выше уровня босса, 25% — вещь грейда 5–6 рядом с уровнем, по 3–6 свитков чарования каждого
вида, Божественное перо, Цветок удачи, Счастливый куб, Кристалл флетты, 50% — камень супер-навыка,
плюс 5 бросков обычной таблицы.
"""
import functools, json, os, random

from inventory import GOLD

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    ITEMS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'items.json'),
                                                    encoding='utf-8')).items()}
except OSError:
    ITEMS = {}
# Стопки в сумке по 999 (по просьбе; в оригинале 3–100): всё стопочное с лимитом меньше — до 999, 1000 и
# больше как есть, нестопочное как есть. Клиенту то же в itemBase ставит tools/patch_stacks.py.
STACK_MIN = 999
for _v in ITEMS.values():
    if 1 < _v.get('stack', 1) < STACK_MIN:
        _v['stack'] = STACK_MIN

HP_POTION, MP_POTION = 54005, 54205
GEAR_CHANCE = 0.031                    # оригинал: 5 вещей на 159 убийств (Genesis — 0,33)
GEAR_TIER_W = (0.6, 0.2, 0.2)          # ступень выше уровня моба, ниже, ещё ниже
MIN_KILLS = 20
ORIG_SCALE = 0.37                      # доли таблиц Genesis -> объём оригинала
# общий набор оригинала (доля убийств; 159 убийств): перо, свиток, Цветок удачи
GENERIC = ((70295, 0.037), (60902, 0.006), (99992, 0.006))
FEATHER = 70295
# материалы 90xxx — одна штука на 7,4% убийств, из тех, что падали в записях оригинала
MATERIALS = (90003, 90004, 90006, 90008, 90013, 90015, 90047)
MATERIAL_RATE = 0.074
POTION_RATE = 0.025                    # зелье здоровья по уровню моба (оригинал: Большое x3, Маленькое x1)
BOSS_GOLD_MULT = 10
BOSS_ROLLS = 5
BOSS_STACKS = ((60900, 3, 6), (60901, 3, 6), (60902, 3, 6), (70295, 2, 4), (99992, 1, 3),
               (64008, 2, 5), (90002, 1, 3))
BOSS_STONE_CHANCE = 0.5
PART_RATE = 0.05                       # 3 части по 5% = 0,15 (оригинал 0,154; у Genesis по 8–14%)
try:
    _GD = json.load(open(os.path.join(DATA, 'genesis_drops.json'), encoding='utf-8'))
except (OSError, ValueError):
    _GD = {}
try:
    _GRADE = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'craft.json'),
                                                   encoding='utf-8'))['grade'].items()}
except (OSError, ValueError, KeyError):
    _GRADE = {}
# Состав дропа — официальная база GameXP (data/gamexp_wiki_mobs.json, «Из этого монстра выпадает», без шансов;
# docs/data_sources.md). Шансов нигде нет, поэтому частота — на категорию за убийство, по записям оригинала
# (docs/drop_original.md, 159 убийств); предмет внутри категории — любой из списка моба:
#   части монстра 0,157; материалы 90xxx 0,075; снаряжение 0,031; зелья 0,025; свитки чарования 0,012
#   (доспехов 0,006 + оружия); Цветок удачи 0,006. Не выпадали ни разу за 159 убийств (оценка < 1/159):
#   руда, уголь, ванисийские детали, рецепты — 0,006; Счастливый куб, азмаранская монета, свитки возврата,
#   коробки, пропуска — 0,003. Квестовые предметы (вид 4, кроме монеты) — только через задания.
# Божественное перо (0,037) в списках базы нет — общий дроп всех мобов, как раньше.
WIKI_RATES = {'part': 0.157, 'material': 0.075, 'gear': 0.031, 'potion': 0.025, 'scroll': 0.012,
              'flower': 0.006, 'ore': 0.006, 'other': 0.003}
SILVER_COIN = 'Азмаранская серебряная монета'


def drop_cat(i):
    it = ITEMS[i]
    if it['kind'] == 1:
        return 'gear'
    if 80001 <= i < 81000:
        return 'part'
    if 90000 <= i < 91000:
        return 'material'
    if 54000 <= i < 55000:
        return 'potion'
    if it['kind'] == 2 and it['cat'] in (9, 10):
        return 'scroll'
    if it['kind'] == 8 and it['cat'] == 38:
        return 'flower'
    if it['kind'] == 3 and it['cat'] == 11:
        return 'ore'
    if it['kind'] == 4 and it['name'] != SILVER_COIN:
        return None                         # квестовый предмет
    return 'other'


def _wiki_drops():
    try:
        mobs = json.load(open(os.path.join(DATA, 'gamexp_wiki_mobs.json'), encoding='utf-8'))['mobs']
    except (OSError, ValueError, KeyError):
        return {}
    out = {}
    for k, v in mobs.items():
        cats = {}
        for i, n in v.get('drops') or ():
            if i in ITEMS and i != GOLD:
                c = drop_cat(i)
                if c:
                    cats.setdefault(c, []).append((i, max(1, int(n or 1))))
        if cats:
            out[int(k)] = {c: tuple(x) for c, x in cats.items()}
    return out


WIKI_DROPS = _wiki_drops()       # вид моба -> {категория: ((предмет, кол-во), …)}
# вид моба -> ((предмет, доля, ср. кол-во), …) — без карат и снаряжения (снаряжение — правилом);
# только для мобов, которых нет в официальной базе
TABLES = {}
for _npc, _v in _GD.items():
    if _v['kills'] < MIN_KILLS:
        continue
    TABLES[int(_npc)] = tuple(
        (int(i), t / _v['kills'] * ORIG_SCALE, max(1, round(n / t)))
        for i, (t, n) in _v['items'].items()
        if int(i) in ITEMS and int(i) != 999999 and ITEMS[int(i)]['kind'] != 1)


def item_name(item):
    if item == GOLD:
        return 'золото'
    return ITEMS.get(item, {}).get('name') or str(item)


@functools.lru_cache(maxsize=1)
def _graded_gear():
    """{уровень: (вещи)} — оружие/броня грейда 1–4 любого класса (как у Genesis)."""
    out = {}
    for iid, it in ITEMS.items():
        if it['kind'] == 1 and it['cat'] in (1, 2) and 1 <= _GRADE.get(iid, 0) <= 4 and it['lvl']:
            out.setdefault(it['lvl'], []).append(iid)
    return {k: tuple(v) for k, v in out.items()}


def gear_tiers(mob_level):
    """Три ступени уровня вещей для моба: ближайшая выше (не дальше +5) и две ниже."""
    lv = sorted(_graded_gear())
    if not lv:
        return ()
    up = [x for x in lv if mob_level < x <= mob_level + 5]
    top = up[0] if up else max([x for x in lv if x <= mob_level] or lv[:1])
    i = lv.index(top)
    return tuple(lv[j] for j in (i, i - 1, i - 2) if j >= 0)


def roll_gear(mob_level, rng=random):
    tiers = gear_tiers(mob_level)
    if not tiers:
        return None
    w = GEAR_TIER_W[:len(tiers)]
    lvl = rng.choices(tiers, weights=w)[0]
    return rng.choice(_graded_gear()[lvl])


PARTS = tuple(sorted(k for k, v in ITEMS.items()
                     if v['kind'] == 3 and v['cat'] == 0 and 80001 <= k < 81000))


def mob_parts(npc_id):
    """Три «части монстра» (80001…) на вид моба — постоянные, по id."""
    if not PARTS:
        return ()
    r = random.Random(npc_id)
    return tuple(r.sample(PARTS, min(3, len(PARTS))))


def hp_potion(level):
    """Зелье здоровья по уровню моба: маленькое / среднее / большое."""
    return 54005 if level < 20 else (54003 if level < 45 else 54002)


def _items(npc, rng, mult=1.0, level=1):
    """Один бросок предметов моба (без карат и снаряжения). mult — множитель шанса
    (шанс выпадения персонажа, 08/02 +240, %: навыки питомца-счастливчика и пр.)."""
    out = []
    wl = WIKI_DROPS.get(npc)
    if wl:
        for item, rate in GENERIC:
            if item == FEATHER and item in ITEMS and rng.random() < rate * mult:
                out.append((item, 1))
        for c, items in wl.items():
            if rng.random() < WIKI_RATES[c] * mult:
                out.append(rng.choice(items))
        return out
    table = TABLES.get(npc)
    if table:
        for item, rate, n in table:
            if rng.random() < rate * mult:
                out.append((item, n))
    else:
        for item, rate in GENERIC:
            if item in ITEMS and rng.random() < rate * mult:
                out.append((item, 1))
        for part in mob_parts(npc):
            if rng.random() < PART_RATE * mult:
                out.append((part, 1))
        mats = [m for m in MATERIALS if m in ITEMS]
        if mats and rng.random() < MATERIAL_RATE * mult:
            out.append((rng.choice(mats), 1))
        pot = hp_potion(level)
        if pot in ITEMS and rng.random() < POTION_RATE * mult:
            out.append((pot, 1))
    return out


@functools.lru_cache(maxsize=256)
def _rare_gear(level):
    """Вещи грейда 5–6 (сквайра/рыцаря/«Властелина»…) в пределах ±10 уровней."""
    return tuple(i for i, it in ITEMS.items()
                 if it['kind'] == 1 and it['cat'] in (1, 2) and _GRADE.get(i, 0) in (5, 6)
                 and it['lvl'] and abs(it['lvl'] - level) <= 10)


@functools.lru_cache(maxsize=1)
def _stones():
    try:
        st = json.load(open(os.path.join(DATA, 'super_skills.json'), encoding='utf-8'))['stones']
    except (OSError, ValueError, KeyError):
        return ()
    return tuple((int(k), v['tier']) for k, v in st.items() if int(k) in ITEMS)


def boss_extra(lvl, rng):
    out = []
    tiers = gear_tiers(lvl)
    top = [i for i in _graded_gear().get(tiers[0], ()) if _GRADE.get(i) in (3, 4)] if tiers else []
    for _ in range(3):
        g = rng.choice(top) if top else roll_gear(lvl, rng)
        if g:
            out.append((g, 1))
    rare = _rare_gear(lvl)
    if rare and rng.random() < 0.25:
        out.append((rng.choice(rare), 1))
    for item, a, b in BOSS_STACKS:
        if item in ITEMS:
            out.append((item, rng.randint(a, b)))
    st = _stones()
    if st and rng.random() < BOSS_STONE_CHANCE:
        pool = [k for k, t in st if t <= (5 if rng.random() < 0.1 else 3)]
        if pool:
            out.append((rng.choice(pool), 1))
    return out


def roll(mob, player, rng=random):
    """-> [(item, count)]"""
    lvl = max(1, getattr(mob, 'level', 1))
    npc = getattr(mob, 'npc_id', 0)
    boss, giant = getattr(mob, 'is_boss', False), getattr(mob, 'is_giant', False)
    import progression
    gold = progression.mob_gold(lvl, npc) * (BOSS_GOLD_MULT if boss else 1)
    out = [(GOLD, gold)]
    rolls = BOSS_ROLLS if boss else (progression.GIANT_LOOT_ROLLS if giant else 1)
    mult = 1 + max(0.0, float(getattr(player, 'drop_pct', 0.0) or 0.0)) / 100
    own_gear = 'gear' in WIKI_DROPS.get(npc, {})      # снаряжение из списка базы уже в _items
    for _ in range(rolls):
        out += _items(npc, rng, mult, lvl)
        if not own_gear and rng.random() < GEAR_CHANCE * mult:
            g = roll_gear(lvl, rng)
            if g:
                out.append((g, 1))
    if boss:
        out += boss_extra(lvl, rng)
    return out
