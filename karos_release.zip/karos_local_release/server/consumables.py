"""Расходники по описаниям клиента (itemBase_Name) — зелья, восстановление по времени, свитки возврата.

Раньше сервер знал только 4 стартовых зелья (и с неверными числами); остальные зелья здоровья/маны,
свитки возврата в другие города не действовали. Числа — из описаний предметов:
  «Восстанавливает 240 здоровья» (54001), «Восстанавливает 140 здоровья и 40 маны» (999900035),
  «Быстро восстанавливает 160 здоровья и 120 маны» (140106) — сразу;
  «В течение 20 минут каждые 5 секунд восстанавливает 6% здоровья» (54218) / «… 240 маны» (54221) —
  по времени; в записи Genesis такой предмет висит значком 05/09 с номером самого предмета;
  «Телепортирует в город Люпинель» (57106) / «на остров Зерон» (57110) — точка «Город …»
  (mapWarpTargetPos), свиток тратится.
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HEAL, HOT, TOWN, BOXN = {}, {}, {}, {}   # BOXN: коробка -> (предмет, число)
# Коробки, содержимое которых видно только в записях (06/02 -> 06/06):
#   «Коробка на День рождения» 999995134 — Pers4x: Большое/Среднее зелье здоровья ×100, remain3: Огромное
#   зелье здоровья ×100, Доспехи из флеттоцветов (7 дней); шансы неизвестны — поровну;
#   «Коробка костюмов» 1000008850 — всегда «Коробка с костюмом» 1000004076 (genesis_1, huge_genesis_pack).
RANDOM_BOX = {999995134: [(999000157, 100), (999000155, 100), (999000159, 100), (999995011, 1)],
              1000008850: [(1000004076, 1)]}        # предмет -> (hp, mp); -> (что, число, %?, шаг с, срок с); -> имя
_DONE = []

_NUM = r'(\d[\d\s]*)'


def _int(s):
    return int(re.sub(r'\s', '', s))


def init():
    if _DONE:
        return
    _DONE.append(1)
    try:
        sys.path.insert(0, os.path.join(ROOT, 'tools'))
        from boxes import records, decode as _dec, SRC as _src
        recs = list(records(_dec(open(_src, 'rb').read(), 0)))
    except (OSError, ImportError):
        return
    names = {iid: name for iid, name, _d in recs}
    for iid, name, desc in recs:
        d = ' '.join(desc.lower().split())
        m = re.match(r'содержит (\d+) ([а-яё ]+?)\.?$', d)
        if m:
            it = _by_stems(m.group(2), names, iid)
            if it:
                BOXN[iid] = (it, int(m.group(1)))
            continue
        m = re.search(r'в течение (\d+) (минут|мин|час|секунд)[а-я]* каждые (\d+) секунд[а-я]* '
                      r'восстанавливает ' + _NUM + r'\s*(%?)\s*(здоровья|маны)', d)
        if m:
            dur = int(m.group(1)) * {'м': 60, 'ч': 3600, 'с': 1}[m.group(2)[0]]
            HOT[iid] = ('hp' if m.group(6).startswith('здор') else 'mp', _int(m.group(4)),
                        bool(m.group(5)), int(m.group(3)), dur)
            continue
        m = re.search(r'(?:^|[.\]] *|быстро )восстанавливает ' + _NUM + r'\s*(здоровья|маны)'
                      r'(?:\s*и\s*' + _NUM + r'\s*(здоровья|маны))?', d)
        if m and 'каждые' not in d and '%' not in d[m.start():m.end() + 2]:
            hp = mp = 0
            for num, what in ((m.group(1), m.group(2)), (m.group(3), m.group(4))):
                if num and what:
                    if what.startswith('здор'):
                        hp = _int(num)
                    else:
                        mp = _int(num)
            HEAL[iid] = (hp, mp)
            continue
        m = re.search(r'телепортирует (?:в город|на остров) ([а-яё\- ]+?)[.]?$', d)
        if m:
            TOWN[iid] = m.group(1).strip()


def _stems(text):
    return {w[:3] for w in re.findall(r'[а-яё]+', text.lower()) if len(w) > 2}


def _by_stems(phrase, names, near):
    """«маленьких зелий восстановления» -> «Малое зелье восстановления»: те же основы (3 буквы);
    из одноимённых — ближайший по номеру к коробке."""
    want = _stems(phrase)
    hits = [i for i, n in names.items() if i != near and _stems(n) == want]
    return min(hits, key=lambda i: abs(i - near)) if hits else None


def town_target(item, targets):
    """Номер точки «Город X» (или «X»/«Док острова X») для свитка возврата; None — нет."""
    t = TOWN.get(item)
    if not t:
        return None
    t = t.lower()
    best = None
    for k, v in sorted(targets.items(), key=lambda kv: (len(kv[0]) != 6, int(kv[0]))):   # точки 1900xx
        n = (v.get('name') or '').lower()
        if n in ('город ' + t, 'город ' + t.rstrip('а')):
            return int(k)
        if best is None and t[:5] in n and ('город' in n or n == t):
            best = int(k)
    return best
