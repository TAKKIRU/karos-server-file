"""Боевая система эмулятора — по раскладкам из дампа play1 (§107-109).

Сборка/разбор боевых пакетов:
  05/00  C→S  замах по цели
  05/01  C→S  удар
  05/02  S→C  результат: атакующий, цель, тип атаки, УРОН   (+0x14 тип, +0x15 урон)
  08/06  S→C  новое HP цели
  08/02  S→C  статы персонажа (атака на +96 float)

Формула урона (§109) — калибрована по замерам с оригинального сервера:
  при атаке ~55 урон 5..12 по мобам ур.10-21, и 3..9 по мобу ур.24.
  Значит: урон = бросок(мин..макс) с поправкой на защиту цели.
Точный коэффициент атаки требует дампа со сменой оружия — до тех пор
используется калибровка по наблюдениям.
"""
import struct, random

ATK_NORMAL = 1        # тип атаки: обычный удар
ATK_CRIT = 2          # критический удар (записи оригинала: 05/02 вид 2, урон ×1.2–1.25)
ATK_SKILL = 5         # навык


class Combat:
    """Расчёт урона. Калибровка по §109."""

    # наблюдения: атака 55 -> средний урон ~9 по мобам ур.10-21
    BASE_RATIO = 9.0 / 55.0        # доля атаки, уходящая в урон
    SPREAD = 0.35                  # разброс броска, +-35%

    @staticmethod
    def mob_defense(level):
        """Защита цели по уровню. Из замеров: ур.24 режет урон почти вдвое
        против ур.10-21 (§109). Защиты в клиентских таблицах НЕТ (§77),
        поэтому выводим из наблюдений."""
        if level >= 24:
            return 0.62        # Swampy Sprinter: 9.4 -> 5.7
        return 1.0

    @classmethod
    def roll_damage(cls, attack, target_level, attack_type=ATK_NORMAL):
        base = attack * cls.BASE_RATIO * cls.mob_defense(target_level)
        if attack_type == ATK_SKILL:
            base *= 0.6                       # навыки в замерах били слабее
        lo = base * (1 - cls.SPREAD)
        hi = base * (1 + cls.SPREAD)
        return max(1, min(255, int(round(random.uniform(lo, hi)))))


ENT_PLAYER = 0        # тип сущности в боевых пакетах (docs/protocol.md)
ENT_MOB = 1
RESULT_OK = 0x0024    # код результата «успех» в 05/00 и 05/03


def build_damage(tpl, attacker, target, damage, atype=ATK_NORMAL, pos=None,
                 attacker_type=ENT_PLAYER, target_type=ENT_MOB):
    """05/02 — результат удара. Раскладка из обработчика клиента 0x006608b3:
      +0  тип атакующего (0 игрок, 1 моб)   +1 id атакующего BE32
      +10 число целей                        +15.. записи по 30 байт:
          +0 тип цели, +1 id цели LE32, +5 вид удара, +6 урон i32 LE,
          +14 позиция цели 3×f32.
    Раньше тип атакующего всегда был 0 (игрок), а тип цели 1 (моб) —
    удар моба по игроку клиент не мог сопоставить и не анимировал."""
    pl = bytearray(tpl)
    pl[0] = attacker_type
    struct.pack_into('>I', pl, 1, attacker)
    pl[10] = 1                                   # одна цель
    pl[15] = target_type
    struct.pack_into('<I', pl, 16, target)
    pl[20] = atype
    struct.pack_into('<i', pl, 21, int(damage))  # полный урон, не только байт
    if pos and len(pl) >= 41:
        struct.pack_into('<3f', pl, 29, *pos)
    return bytes(pl)


ATK_MISS = 4          # промах (записи оригинала: урон 0)
ATK_BLOCK = 5         # блок: урон ×~0.6 (оригинал: 234 при обычном 391)
ATK_BLOCK_FULL = 6    # полный блок, урон 0


def build_damage_multi(tpl, attacker, hits, attacker_type=ENT_PLAYER, target_type=ENT_MOB):
    """05/02 с несколькими целями (массовый навык; запись оригинала remain3: число целей +10,
    записи по 30 байт с +15). hits — [(id, урон, вид, (x, y, z))]."""
    if len(hits) == 1:
        t, d, k, p = hits[0]
        return build_damage(tpl, attacker, t, d, k, p, attacker_type, target_type)
    base = bytearray(build_damage(tpl, attacker, hits[0][0], hits[0][1], hits[0][2], hits[0][3],
                                  attacker_type, target_type))
    head, rec0 = base[:15], bytes(tpl[15:45])
    head[10] = len(hits)
    out = bytearray(head)
    for t, d, k, p in hits:
        r = bytearray(rec0.ljust(30, bytes(1)))
        r[0] = target_type
        struct.pack_into('<I', r, 1, t)
        r[5] = k
        struct.pack_into('<i', r, 6, int(d))
        if p:
            struct.pack_into('<3f', r, 14, *p)
        out += r
    return bytes(out)


def build_attack_start(tpl, attacker_type, attacker, target_type, target,
                       apos, tpos=None, mode=0):
    """05/00 — начало атаки (обработчик клиента 0x00660ca3), payload 49 байт:
      +0 тип атакующего, +1 id BE32, +5 режим (0 обычная), +10 позиция 3×f32,
      +22 угол, +26 тип цели, +27 id цели BE32, +31 позиция цели 3×f32,
      +47 код результата BE16 (0x0024 = успех).
    Для моба (тип 1) клиент проигрывает анимацию замаха по цели."""
    pl = bytearray(tpl)
    pl[0] = attacker_type
    struct.pack_into('>I', pl, 1, attacker)
    pl[5] = mode
    struct.pack_into('<3f', pl, 10, *apos)
    pl[26] = target_type
    struct.pack_into('>I', pl, 27, target)
    if tpos:
        struct.pack_into('<3f', pl, 31, *tpos)
    struct.pack_into('>H', pl, 47, RESULT_OK)
    return bytes(pl)


def ack_attack_start(payload):
    """Ответ на 05/00 игрока: тот же пакет с кодом результата 0x0024.
    Без него (просто эхо) клиент считает атаку отклонённой и отменяет её."""
    pl = bytearray(payload)
    if len(pl) >= 49:
        struct.pack_into('>H', pl, 47, RESULT_OK)
    return bytes(pl)


def build_hp(tpl, entity, hp):
    """08/06 — новое HP сущности (entity BE32 @+1, hp BE32 @+9)."""
    pl = bytearray(tpl)
    struct.pack_into('>I', pl, 1, entity)
    struct.pack_into('>I', pl, 9, max(0, hp))
    return bytes(pl)


def parse_attack(payload, sub=0x01):
    """Извлечь eid ЦЕЛИ (моба) из удара клиента. Сверено с дампом:
    05/01 (удар) — цель BE32 @+28; 05/00 (замах) — @+27.
    На +1 лежит АТАКУЮЩИЙ (игрок), а не цель — прежний разбор (+5) был неверен,
    из-за чего урон по мобам не проходил."""
    off = 28 if sub == 0x01 else 27
    if len(payload) < off + 4:
        return None
    return struct.unpack_from('>I', payload, off)[0]


if __name__ == '__main__':
    print("Проверка формулы против ЗАМЕРОВ с оригинала (§109):\n")
    print(f"{'моб':20} {'ур':>3} {'замер':>12} {'наша модель':>16}")
    obs = [('Spiderling', 10, '5..11 (8.6)'), ('Owlbear Cub', 19, '6..12 (9.4)'),
           ('Prairie Dog', 21, '6..12 (9.0)'), ('Swampy Sprinter', 24, '3..9 (5.7)')]
    for nm, lvl, o in obs:
        rolls = [Combat.roll_damage(55, lvl) for _ in range(400)]
        print(f"{nm:20} {lvl:>3} {o:>12} {min(rolls):>6}..{max(rolls):<3} "
              f"({sum(rolls)/len(rolls):.1f})")
