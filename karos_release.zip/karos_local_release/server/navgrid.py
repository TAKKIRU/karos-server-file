"""Проходимость открытых карт по навигационной сетке клиента (Map/<карта>/<карта>.nav).

Формат (загрузчик AMo 0x006ba585; путь «%s\\%s\\Map\\%s\\Map\\%s.nav»): u32 размер клетки (10),
u32 n, n × 24 байта — прямоугольник проходимой области в клетках: i32 z_max, z_min, x_max, x_min,
u32 0, u32 номер группы; дальше — списки соседей (u32 число, u32 номера) для поиска пути клиентом.
Проверено по точкам спавна (data/spawns.json, глобальные координаты = тайл × 5120 + локальные):
прямоугольники покрывают 17–50% площади карты, а внутри — 84–98% точек спавна (2 клетки допуска —
92–99%). Файлы .sat — свойства поверхности, не стены (под точками, где ходил игрок, встречаются любые
значения).

walkable(карта, x, z) -> True / False, или None, если у карты нет .nav и о ней ещё мало известно.

Интерьеры и подземелья (.nav нет): проходимость «изучается» — клетки 40×40, по которым прошёл игрок
(отрезки между его 04/01; телепорты > 600 не считаются), и окрестность точек спавна мобов. Когда
изученных клеток не меньше LEARN_MIN, walkable() отвечает по ним (с допуском в 1 клетку — коридор
≈120), иначе None (как раньше — без ограничений). Моб вне изученной области ходит свободно (blocked()),
так что не застревает; заблокированный моб в погоне идёт по следу игрока (trail_next). Изученное
хранится в server/nav_learned.json (только координаты клеток).
"""
import collections, glob, json, os, struct, threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAPS = os.path.join(ROOT, 'ResUnpak', 'Map')
_cache = {}
LEARN_CELL, LEARN_MIN = 40.0, 30
LEARN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nav_learned.json')
_learned = {}                      # карта -> set((cx, cz))
_trail = {}                        # карта -> deque((x, z)) — след игрока
_lock = threading.Lock()
_dirty = [False]


def _load(name):
    if name in _cache:
        return _cache[name]
    grid = None
    p = os.path.join(MAPS, name, name + '.nav')
    if not os.path.exists(p):
        alt = glob.glob(os.path.join(MAPS, name, '**', name + '.nav'), recursive=True)
        p = alt[0] if alt else None
    if p:
        try:
            d = open(p, 'rb').read()
            cell, n = struct.unpack_from('<2I', d, 0)
            rects = [struct.unpack_from('<4i', d, 8 + 24 * i) for i in range(n)
                     if 8 + 24 * (i + 1) <= len(d)]
            if rects and cell > 0:
                w = max(r[2] for r in rects) + 1
                h = max(r[0] for r in rects) + 1
                g = bytearray(w * h)
                for z2, z1, x2, x1 in rects:
                    if x1 < 0 or z1 < 0 or x2 < x1 or z2 < z1:
                        continue
                    row = b'\1' * (x2 - x1 + 1)
                    for z in range(z1, z2 + 1):
                        g[z * w + x1:z * w + x2 + 1] = row
                grid = (float(cell), w, h, g)
        except (OSError, struct.error):
            grid = None
    _cache[name] = grid
    return grid


def has_nav(name):
    return _load(name) is not None


def _learned_set(name):
    if not _learned and os.path.exists(LEARN_FILE):
        try:
            for k, v in json.load(open(LEARN_FILE, encoding='utf-8')).items():
                _learned[k] = {tuple(c) for c in v}
        except (OSError, ValueError):
            pass
        _learned.setdefault('', set())
    return _learned.setdefault(name, set())


def learn(name, x0, z0, x1, z1):
    """Игрок прошёл отрезок (x0, z0) -> (x1, z1): клетки по пути проходимы (карты без .nav)."""
    if not name or has_nav(name):
        return
    d = ((x1 - x0) ** 2 + (z1 - z0) ** 2) ** 0.5
    if d > 600:
        return
    st = _learned_set(name)
    n = max(1, int(d / (LEARN_CELL / 2)))
    with _lock:
        for i in range(n + 1):
            x, z = x0 + (x1 - x0) * i / n, z0 + (z1 - z0) * i / n
            c = (int(x // LEARN_CELL), int(z // LEARN_CELL))
            if c not in st:
                st.add(c)
                _dirty[0] = True
        tr = _trail.setdefault(name, collections.deque(maxlen=400))
        if not tr or abs(tr[-1][0] - x1) + abs(tr[-1][1] - z1) > 20:
            tr.append((x1, z1))


def learn_point(name, x, z, r=2):
    """Точка спавна: клетки в радиусе r проходимы."""
    if not name or has_nav(name):
        return
    st = _learned_set(name)
    cx, cz = int(x // LEARN_CELL), int(z // LEARN_CELL)
    with _lock:
        for dz in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dz * dz <= r * r and (cx + dx, cz + dz) not in st:
                    st.add((cx + dx, cz + dz))
                    _dirty[0] = True


def save():
    if not _dirty[0]:
        return
    with _lock:
        data = {k: sorted(v) for k, v in _learned.items() if k and v}
        _dirty[0] = False
    try:
        json.dump(data, open(LEARN_FILE, 'w', encoding='utf-8'))
    except OSError:
        pass


def trail_next(name, x, z, ahead=4):
    """Точка следа игрока «впереди» ближайшей к (x, z) — по ней моб обходит стену. None — нет следа."""
    tr = _trail.get(name)
    if not tr:
        return None
    best, bi = None, -1
    for i, (tx, tz) in enumerate(tr):
        d = (tx - x) ** 2 + (tz - z) ** 2
        if best is None or d < best:
            best, bi = d, i
    if best is None or best > 400 ** 2:
        return None
    return tr[min(len(tr) - 1, bi + ahead)]


def walkable(name, x, z, tol=0):
    """Проходима ли точка (глобальные координаты карты). tol — допуск в клетках."""
    g = _load(name) if name else None
    if g is None:
        st = _learned_set(name) if name else None
        if not st or len(st) < LEARN_MIN:
            return None
        cx, cz = int(x // LEARN_CELL), int(z // LEARN_CELL)
        t = tol + 1
        return any((cx + dx, cz + dz) in st for dz in range(-t, t + 1) for dx in range(-t, t + 1))
    cell, w, h, grid = g
    cx, cz = int(x // cell), int(z // cell)
    for dz in range(-tol, tol + 1):
        for dx in range(-tol, tol + 1):
            i, j = cx + dx, cz + dz
            if 0 <= i < w and 0 <= j < h and grid[j * w + i]:
                return True
    return False


def blocked(name, fx, fz, tx, tz):
    """Шаг из (fx, fz) в (tx, tz) запрещён: цель непроходима, а стоим на проходимом
    (кто стоит вне сетки — например, моб с точки у края — может идти куда угодно)."""
    w = walkable(name, tx, tz)
    if w is None or w:
        return False
    return bool(walkable(name, fx, fz, 1))
