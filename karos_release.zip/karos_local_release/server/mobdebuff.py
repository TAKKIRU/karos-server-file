"""Дебафы навыков игрока на мобов (навыки вида 13 skillBase и вторые эффекты ударов вида 11 —
кровотечение, замедление, оглушение…; data/skill_effects.json).

Эффекты навыка на его уровне (statcalc.skill_fx) -> записи mob.debuffs — те же ключи, что у камней
«Атака» супер-навыков (superskill.on_hit) и срабатываний вещей; их уже читают ai.py (move, root,
stun, aspd, noatk), урон моба по игроку (atk) и урон по мобу (def):
  27 скорость движения −n% -> 'move' (−100% — обездвиживание 'root'); 85 обездвиживание -> 'root';
  13 скорость атаки −n% -> 'aspd' (−100% — «связывание рук», 8305 -> 'noatk'; у ударов — оглушение);
  17 / 18 / 19 физ., текущая физ. и маг. защита: −n% -> урон по мобу +n%; число X -> +X / K,
     K = max(120, 0.8·ур.²) — та же шкала защиты, что у урона мобов по игроку (progression.mob_damage);
     прибавка не больше ×2;
  71 / 73 / 74 / 6 / 8 сила атаки −n% -> 'atk' (урон моба по игроку);
  28 здоровье −X — урон X в секунду всё время действия (описания 7902, 8306: «каждую секунду»).
Не применяются (мобам не нужно или шкалы нет): 10 / 11 / 16 / 21 рейтинги, крит, уклонение,
14 скорость навыков, 25 злость, 29 / 33 мана, 34.
Длительность — skillLevel +140 (buffs.info): 6806 — 6 с, 6811 — 30 с, 16002 — 3 с, как в 05/09
записей оригинала (remain3_persons, orig_hl_Pers4x); нет — DEFAULT_SECS.
Иконка на мобе — S 05/09: +0 тип 1 (моб), eid, 1/0 (наложен / снят), записи: навык, ур.,
уровень заклинателя, 0, секунды, 0 (снятие — отдельным 05/09 с 0, как в оригинале).
"""
DEFAULT_SECS = 5.0
DEF_TYPES = (17, 18, 19)
ATK_TYPES = (6, 8, 71, 73, 74)


def def_scale(level):
    return max(120.0, 0.8 * max(1, level) ** 2)


def _put(db, key, val, until, stronger, now):
    """Действующий дебаф того же вида: сильнейшее значение, позднейший срок."""
    old = db.get(key)
    if old and old[1] > now:
        val = stronger(old[0], val)
        until = max(old[1], until)
    db[key] = (val, until)


DEBUFF_TYPES = (6, 8, 13, 17, 18, 19, 27, 28, 71, 73, 74, 85)


def has_debuff(fx):
    """Есть ли у навыка-удара (вид 11) действие на цель: кровотечение, замедление, оглушение…"""
    return any(t in DEBUFF_TYPES and (v < 0 or p < 0 or t == 85) for t, v, p in fx)


def apply(mob, fx, secs, now, stun=False):
    """Наложить эффекты [(тип, число, %)] на моба. -> (что наложено {ключ: значение}, урон/с).
    stun — у ударов (вид 11) «скорость атаки −100%» на 1–2,5 с — оглушение («Мощный выстрел,
    оглушающий противника», 9101, 9902, 10505): моб не ходит и не бьёт."""
    db = getattr(mob, 'debuffs', None)
    if db is None:
        db = mob.debuffs = {}
    until = now + secs
    out, dot, dmul = {}, 0.0, 1.0
    for t, v, pct in fx:
        if t == 27 and pct < 0:
            if pct <= -100:
                _put(db, 'root', 1, until, max, now); out['root'] = 1
            else:
                m = max(0.05, 1 + pct / 100.0)
                _put(db, 'move', m, until, min, now); out['move'] = m
        elif t == 85:
            _put(db, 'root', 1, until, max, now); out['root'] = 1
        elif t == 13 and pct < 0:
            if pct <= -100:
                k = 'stun' if stun else 'noatk'
                _put(db, k, 1, until, max, now); out[k] = 1
            else:
                m = max(0.1, 1 + pct / 100.0)
                _put(db, 'aspd', m, until, min, now); out['aspd'] = m
        elif t in DEF_TYPES and (pct < 0 or v < 0):
            dmul += (-pct / 100.0) if pct < 0 else (-v / def_scale(getattr(mob, 'level', 1)))
        elif t in ATK_TYPES and pct < 0:
            m = max(0.0, 1 + pct / 100.0)
            _put(db, 'atk', m, until, min, now); out['atk'] = m
        elif t == 28 and v < 0:
            dot += -v
    if dmul > 1.0:
        m = min(2.0, dmul)
        _put(db, 'def', m, until, max, now); out['def'] = round(m, 3)
    return out, dot


def build_icon(mob_eid, sid, lv, caster_lv, secs, add=True):
    """S 05/09 для моба (тип 1)."""
    import struct
    return struct.pack('>BIBH', 1, mob_eid, 1 if add else 0, 1) + \
        struct.pack('>IBBIII', sid, lv & 0xff, caster_lv & 0xff, 0, int(secs) if add else 0, 0)
