"""«Камень души» в часть костюма (06/4d, CItemMixedReinforcePacket) — по записи Genesis лучницы и описаниям.

Запись huge_genesis_pack_2: C 06/4d +0 eid, +4 сумка камня, +8 ячейка, +12 камень, +16 сумка костюма,
+20 ячейка, +24 костюм, +28 0, +32 u16 0x1e5; ответ — эхо (код 0x1e5). Камень тратится, у записи
костюма: +80 u32 номер камня, +92 u32 время окончания (30 дней), байт +7 — 1/2 (смысл не ясен, не трогаем).
Эффекты и ограничения — из описания камня (itemBase_Name):
  500200060 «…увеличивает силу физической атаки на 5%. Можно совместить только с постоянными поножами
  или кирасой… Эффект длится 30 дней»; 500200062 «…здоровье на 1000, физ. защиту на 3% и маг. защиту
  на 3%… только с постоянными ботинками или перчатками» …
Слоты костюма (itemBase): 26 торс, 27 ноги, 28 кисти рук, 29 ступни.
"""
import os, re, struct, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STONE_OFF, UNTIL_OFF = 80, 92
CODE = 0x1e5
STONES = {}        # камень -> {'fx': [(тип, число, %)], 'slots': {…}, 'days': n}
_DONE = []
_ATTR = {'сил': 1, 'ловк': 3, 'живуч': 2, 'интел': 5, 'мудр': 4}


def _fx(desc):
    d = ' '.join(desc.lower().split())
    m = re.search(r'увеличивает (.+?)(?:можно совмест|щ[её]лкните|эффект длится|$)', d)
    body = m.group(1) if m else ''
    out = []
    for part, num, pc in re.findall(r'([а-яё .,()pk-]+?)\s+на\s+(\d+)\s*(%?)', body):
        pct = bool(pc)
        n = int(num)
        names = [x.strip() for x in re.split(r',| и ', part) if x.strip()]
        for nm in names:
            if 'pk' in nm:
                continue
            if 'физ' in nm and 'атак' in nm:
                out.append((6, 0.0, float(n)) if pct else (6, float(n), 0.0))
            elif 'маг' in nm and 'атак' in nm:
                out.append((8, 0.0, float(n)) if pct else (8, float(n), 0.0))
            elif 'физ' in nm and 'защит' in nm:
                out.append((17, 0.0, float(n)) if pct else (17, float(n), 0.0))
            elif 'маг' in nm and 'защит' in nm:
                out.append((19, 0.0, float(n)) if pct else (19, float(n), 0.0))
            elif 'здоров' in nm:
                out.append((46, float(n), 0.0) if not pct else (46, 0.0, float(n)))
            else:
                for k, t in _ATTR.items():
                    if nm.startswith(k) or nm.endswith(k) or k in nm.split()[-1]:
                        out.append((t, float(n), 0.0))
                        break
    return out


def init():
    if _DONE:
        return
    _DONE.append(1)
    try:
        sys.path.insert(0, os.path.join(ROOT, 'tools'))
        from boxes import records, decode as _dec, SRC as _src
        recs = list(records(_dec(open(_src, 'rb').read(), 0)))
    except (OSError, ImportError):
        return
    for iid, name, desc in recs:
        if not name.lower().startswith('камень души'):
            continue
        d = desc.lower()
        slots = set()
        if 'поножам' in d or 'кирас' in d:
            slots |= {26, 27}
        if 'ботинк' in d or 'перчатк' in d:
            slots |= {28, 29}
        days = re.search(r'длится (\d+) дн', d)
        STONES[iid] = {'fx': _fx(desc), 'slots': slots or {26, 27, 28, 29},
                       'days': int(days.group(1)) if days else 30}


def effects(rec, now=None):
    """Эффекты камня в записи костюма (пока не истёк срок)."""
    if len(rec) < UNTIL_OFF + 4:
        return []
    st = struct.unpack_from('<I', rec, STONE_OFF)[0]
    if not st:
        return []
    init()
    s = STONES.get(st)
    until = struct.unpack_from('<I', rec, UNTIL_OFF)[0]
    if not s or (until and until < (now or time.time())):
        return []
    return [list(e) for e in s['fx']]
