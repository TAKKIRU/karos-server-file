"""Высота рельефа открытых карт по файлам клиента .ter (формат — tools/terrain_check.py).

height(карта, x, z) -> высота земли (билинейно по сетке 129×129 тайла) или None, если у карты
нет .ter (интерьеры — меш, см. server.mesh_floor). Тайлы читаются лениво и кэшируются.
"""
import os, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAPS = os.path.join(ROOT, 'ResUnpak', 'Map')
TILE, N = 5120.0, 129
STEP = TILE / (N - 1)
_cache = {}
# карты с тайлом 10240 (content.Content.tile: Центри-Хейл, Mine_Dungeon): их .ter другого формата (1,4–3 МБ
# вместо 66 КБ) — сетку 129×129 под 5120 из них читать нельзя; высота — по точкам спавна и пройденному
BIG_TILE = set()


def _tile(name, t):
    key = (name, t)
    if key not in _cache:
        g = None
        p = os.path.join(MAPS, name, 'Map', f'{name}{t}.ter')
        try:
            d = open(p, 'rb').read(8 + 4 * N * N)
            if d[:4] == b'CEST' and len(d) == 8 + 4 * N * N:
                g = struct.unpack_from(f'<{N * N}f', d, 8)
        except OSError:
            pass
        _cache[key] = g
    return _cache[key]


def has_terrain(name):
    d = os.path.join(MAPS, name, 'Map')
    try:
        return any(f.lower().endswith('.ter') for f in os.listdir(d))
    except OSError:
        return False


def height(name, x, z):
    if name in BIG_TILE:
        return None
    tx, tz = int(x // TILE), int(z // TILE)
    if tx < 0 or tz < 0:
        return None
    g = _tile(name, tz * 64 + tx)
    if g is None:
        return None
    lx, lz = (x - tx * TILE) / STEP, (z - tz * TILE) / STEP
    i, j = min(int(lx), N - 2), min(int(lz), N - 2)
    fx, fz = lx - i, lz - j
    h00, h10 = g[j * N + i], g[j * N + i + 1]
    h01, h11 = g[(j + 1) * N + i], g[(j + 1) * N + i + 1]
    h = (h00 * (1 - fx) + h10 * fx) * (1 - fz) + (h01 * (1 - fx) + h11 * fx) * fz
    return h if h == h else None                # NaN — дыра в рельефе
