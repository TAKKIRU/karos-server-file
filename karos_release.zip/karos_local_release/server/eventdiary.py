"""Дневник событий: календарь посещений и задания (окно CGuiEventMain/…ATTD/…Guide).

По записям оригинала (orig_1, orig_hl_Pers4x) и клиенту AMo (категория 0a, обработчики 0x0065b9be…):
  C 0a/0a (12 нулей; клиент шлёт сам после входа, 0x0044562c) -> S 0a/0a (CEventDiaryOpenPacket):
      u32 время сервера (unix), u32 сегодня уже отмечен (0/1), u32 n, n × u8 отмеченные дни месяца.
      Оригинал: 6aef917b 00000000 00000001 05 — отмечен 5-го, сегодня ещё нет.
  C 0a/0b (12 нулей; кнопка «Вы хотите войти?») -> S 0a/0b (CEventDiaryAttendPacket):
      u32 1, u32 отмечено дней в месяце, u32 сегодняшнее число (оригинал: 1, 2, 8),
      затем награда приходит письмом (10/04). Уже отмечен — ответа нет.
  S 0a/0c (CEventDiaryMissionListPacket, разбор 0x0065a09b): u32 n1, u32 n2, n1 × 7 байт
      (u8 0 — в процессе / 1 — выполнено, u16 LE задание, u32 LE прогресс), n2 × u16 LE —
      задания с полученной наградой.
  C 0a/0d (сборщик 0x0059336d): u16 задание, u8 1 — условие выполнено (клиент сам замечает
      действие, 0x00696dce) / 2 — забрать награду (0x005933c9), u32 0, u16 0x175.
  S 0a/0d (CEventDiaryProgressPacket, 0x0065baeb) — та же раскладка (оригинал: 03eb 01 00000001 0175).
Задания (eventDiary): 1001…1030 «по одному разу», награда eventDiary_reward с тем же номером.
Состояние — в персонаже: ch['diary'] = {'done': [...], 'claimed': [...]}, дни посещения —
ch['attend']['days'] (postbox.attend считает награды за посещение).
"""
import struct, time

MISSIONS = list(range(1001, 1031))
DONE, CLAIM = 1, 2
OK_CODE = 0x175


def build_open(attend, now=None):
    now = now or time.time()
    t = time.localtime(now)
    month = time.strftime('%Y-%m', t)
    days = attend.get('days', []) if attend.get('days_month') == month else []
    today = 1 if attend.get('last') == time.strftime('%Y-%m-%d', t) else 0
    return struct.pack('>III', int(now), today, len(days)) + bytes(d & 0xff for d in days)


def build_attend(attend, now=None):
    t = time.localtime(now or time.time())
    return struct.pack('>III', 1, attend.get('count', 0), t.tm_mday)


def mark_day(attend, now=None):
    """Добавить сегодняшнее число в отмеченные дни месяца (после postbox.attend)."""
    t = time.localtime(now or time.time())
    month = time.strftime('%Y-%m', t)
    if attend.get('days_month') != month:
        attend['days'], attend['days_month'] = [], month
    if t.tm_mday not in attend['days']:
        attend['days'].append(t.tm_mday)


def build_list(diary):
    done, claimed = set(diary.get('done', [])), diary.get('claimed', [])
    active = [m for m in MISSIONS if m not in claimed]
    out = struct.pack('>II', len(active), len(claimed))
    for m in active:
        out += struct.pack('<BHI', 1 if m in done else 0, m, 1 if m in done else 0)
    for m in claimed:
        out += struct.pack('<H', m)
    return out


def parse_progress(pl):
    pl = bytes(pl) + bytes(max(0, 9 - len(pl)))
    mid, state = struct.unpack_from('>HB', pl, 0)
    return mid, state


def build_progress(mid, state, value=1):
    return struct.pack('>HBIH', mid, state, value, OK_CODE)
