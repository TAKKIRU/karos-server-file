"""Состояние игрового мира сервера-эмулятора.

Источник истины для всех исходящих пакетов. Пакеты СОБИРАЮТСЯ из состояния,
а не воспроизводятся (§76). Где раскладка поля неизвестна — используется
шаблон-несущая из дампа с переписанными известными полями.
"""
import math, random
import progression
import struct
import terrain
import navgrid


MOB_EID_BASE = 20000


class Entity:
    _next = MOB_EID_BASE

    def __init__(self, eid, x, y, z, angle=0.0):
        self.eid = eid
        self.x, self.y, self.z = x, y, z
        self.angle = angle

    @classmethod
    def new_id(cls):
        cls._next += 1
        return cls._next


class Player(Entity):
    def __init__(self, eid, x, y, z, name='', hp=150, maxhp=150, mp=90, maxmp=90):
        super().__init__(eid, x, y, z)
        self.name = name
        self.hp, self.maxhp = hp, maxhp
        self.mp, self.maxmp = mp, maxmp
        self.level = 1
        self.exp = 0            # очки опыта (верхние 16 бит поля уровень+опыт)
        self.target = None      # eid цели из 05/00 (замах)


class Mob(Entity):
    """Моб из точки спавна карты. Статы — из npcInfo (§75,77)."""
    def __init__(self, eid, npc_id, x, y, z, info=None):
        super().__init__(eid, x, y, z)
        self.npc_id = npc_id
        self.spawn_x, self.spawn_y, self.spawn_z = x, y, z   # для респауна
        info = info or {}
        self.name = info.get('name', '')
        self.level = info.get('level', 1)
        self.grade = info.get('grade')          # npcInfo +20: боссы 90–97, 1013/1014/1016 (progression)

        # --- ФИКС АГРО (заменили 3 строки) ---
        self.aggro = info.get('aggro', 250.0)
        if self.aggro <= 0:
            self.aggro = 250.0
        # -------------------------------------
        
        self.atk_range = info.get('atk_range', 20)
        # HP в клиентских таблицах нет. Опорная точка — дамп оригинала: малый паук
        # (ур. 10 по npcInfo) = 50 HP; рост ~7% за уровень.
        # запись оригинала -> оценка по квестам -> таблица по уровню × приставка (Гигантский ×9 …)
        self.hp = self.maxhp = progression.mob_max_hp(npc_id, info)
        self.alive = True
        self.state = 'idle'          # idle | chase | attack | dead
        self.target = None


class World:
    """Один игровой мир (карта). Держит игроков и мобов."""

    def __init__(self, map_name='', content=None):
        self.map_name = map_name
        self.content = content
        self.players = {}
        self.mobs = {}
        self.npcs = {}           # NPC/объекты карты (без AI), шлются как мобы

    def add_player(self, player):
        self.players[player.eid] = player

    def load_mobs(self, limit=None):
        """заселить мир мобами из точек спавна карты"""
        if not self.content:
            return 0
        spawns = self.content.map_spawns(self.map_name, getattr(self, 'map_id', None))
        TS = self.content.tile_size(self.map_name)       # 5120, у караульной башни — 10240 (content.py)
        n = 0
        # СБРОС ID при каждом заходе в мир. Мобы — с 20000: id NPC = номер их
        # точки спавна (до ~1400), а id персонажей — 0x2892+.
        Entity._next = MOB_EID_BASE
        try:
            import dungeon                       # стартеры и ключи событий EID: бьются, но не ходят и не бьют
            attackable = set(dungeon.rule(getattr(self, 'map_id', None)).get('attackable') or [])
        except ImportError:
            attackable = set()

        for s in spawns:
            if limit and n >= limit:
                break
                
            # <-- ФИКС: отсекаем городских NPC и объекты (они не должны быть мобами)
            model = str(s.get('model', ''))
            _inf = s.get('npc') or {}
            # объекты (Камень памяти, реликвии, стены, катапульты, врата): в npcInfo агро 0 и дальность 0 —
            # не мобы. Раньше им ставилось агро 250: Камень памяти в городе нападал, рядом — его копия
            _obj = bool(_inf) and not _inf.get('aggro') and not _inf.get('atk_range')
            if s.get('sidx') is not None and s.get('uidx') in attackable:
                _obj = False                      # «1-й стартер», «Монстр с ключом», «Ключевой предмет»
            if model.startswith(('N_', 'NPC_', 'Map\\', 'O_')) or _obj:
                # NPC/объекты: без AI и боя, но клиенту их надо прислать (04/02
                # с номером точки) — иначе по ним нельзя кликнуть
                # id NPC = номер точки спавна: клиент сам создаёт NPC из файла карты
                # с этим id (статичная модель без имени). Пакет 04/02 с ТЕМ ЖЕ id
                # оживляет его (обработчик 0x00667a45 находит сущность по id и
                # обновляет), а с другим id — клонирует вторую модель (были двойники).
                if s.get('uidx') and not model.startswith('Map\\'):
                    tile = s.get('tile', 0)
                    npc = Mob(s['uidx'], s['id'],
                              s['x'] + (tile % 64) * TS, s['z'] + (tile // 64) * TS,
                              s['y'], s.get('npc'))
                    npc.uidx = s['uidx']
                    npc.is_npc = True
                    npc.service = model.startswith(('N_', 'NPC_'))      # торговцы и т.п. — «белая зона»
                    npc.name = npc.name or model
                    self.npcs[npc.eid] = npc
                continue
                
            tile = s.get('tile', 0)
            col, row = tile % 64, tile // 64
            low = model.lower()
            ore = low.startswith('m_object') or (not low.startswith('m_')
                                                 and ('stone' in low or 'mine' in low))
            # в точке .npc задано число мобов и радиус разброса (tools/spawn_counts.py):
            # в пустыне Эристума 245 точек по 2 моба, 57 — по 5; раньше ставили по одному
            cnt = 1 if ore else max(1, min(10, int(s.get('count', 1) or 1)))
            if not ore and not model.startswith('N_'):
                cnt *= progression.MOB_MULT            # обычных — вдвое больше оригинала
            rad = float(s.get('radius', 0) or 0)
            info = s.get('npc') or {}
            boss, giant = progression.is_boss(info), progression.is_giant(info)
            if giant:
                cnt = max(1, min(10, int(s.get('count', 1) or 1))) * progression.GIANT_MULT   # втрое
                rad = max(rad, 150.0)
            if boss:
                cnt = progression.BOSS_COUNT           # боссов по 5 на точке
                rad = max(rad, 200.0)
            if s.get('sidx') is not None:               # подземелье со сценарием (dungeon.py): как в .mo —
                cnt, rad, boss, giant = 1, 0.0, False, False  # по одному, без умножения: этапы считают убитых
            rnd = random.Random(s.get('uidx', 0) * 7919 + s['id'])
            for i in range(cnt):
                dx = dz = 0.0
                if i and rad > 0:
                    for _try in range(8):              # разброс — только на проходимое (.nav)
                        a, d = rnd.uniform(0, 2 * math.pi), rad * math.sqrt(rnd.random())
                        dx, dz = d * math.cos(a), d * math.sin(a)
                        if navgrid.walkable(self.map_name, s['x'] + col * TS + dx,
                                            s['z'] + row * TS + dz) is not False:
                            break
                    else:
                        dx = dz = 0.0
                wx = s['x'] + col * TS + dx
                wz = s['z'] + row * TS + dz
                eid = Entity.new_id()
                if s.get('uidx') in attackable and not low.startswith('m_'):
                    eid = s['uidx']                    # стартер/кристалл — объект карты: клиент создаёт его
                                                       # сам с этим номером, 04/02 с тем же — оживляет (не клон)
                h = s['y']
                if i and TS == 5120.0:                 # разброс по рельефу (.ter: тайлы 5120), а не высота точки
                    t = terrain.height(self.map_name, wx, wz)
                    if t is not None and abs(t - h) < 300:
                        h = t
                self.mobs[eid] = Mob(eid, s['id'], wx, wz, h, s.get('npc'))
                self.mobs[eid].map_name = self.map_name
                if i == 0:
                    navgrid.learn_point(self.map_name, wx, wz)   # интерьеры: спавн проходим
                self.mobs[eid].is_boss, self.mobs[eid].is_giant = boss, giant
                # время возрождения — progression.respawn_delay (база оригинала или 30 с по пульту F2)
                # номер точки спавна в карте клиента (tools/spawn_uidx.py): клиент
                # клонирует моба с этой точки, иначе не создаёт его вовсе
                self.mobs[eid].uidx = s.get('uidx', 0)
                if s.get('uidx') in attackable and s.get('sidx') is not None:
                    self.mobs[eid].static = True                 # стоит, не отвечает на удары
                if low.startswith('m_meteo'):
                    # «метеоры» Демонической башни (без имени в npcInfo, агрессия 200): ловушка на
                    # мостах — не ходят за игроком (раньше бегали и били игрока ещё на старте)
                    self.mobs[eid].anchored = True
                if s.get('sidx') is not None:
                    self.mobs[eid].sidx = s['sidx']              # номер для required_spawns
                    self.mobs[eid].dormant = bool(s.get('dormant'))   # волна — до события 0a/00 (вид 46)
                    self.mobs[eid].no_respawn = True
                # узлы добычи (камни/руда): бьются как моб, но не отвечают — дают руду
                if ore:
                    self.mobs[eid].gather = 'ore'
                    self.mobs[eid].hp = self.mobs[eid].maxhp = 30
                n += 1
        return n

    SAFE_R = 350.0      # приближение «белой зоны»: рядом с NPC-службой мобы не нападают

    def in_safe(self, x, y):
        cells = getattr(self, '_safe_cells', None)
        if cells is None:
            cells = self._safe_cells = {}
            for n in self.npcs.values():
                if getattr(n, 'service', False):
                    cells.setdefault((int(n.x // 500), int(n.y // 500)), []).append((n.x, n.y))
        cx, cy = int(x // 500), int(y // 500)
        r2 = self.SAFE_R ** 2
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for px, py in cells.get((cx + dx, cy + dy), ()):
                    if (px - x) ** 2 + (py - y) ** 2 <= r2:
                        return True
        return False

    def near(self, x, y, radius=3000):
        """мобы и NPC в радиусе от точки (для рассылки клиенту)"""
        out = []
        for m in list(self.mobs.values()) + list(self.npcs.values()):
            if abs(m.x - x) < radius and abs(m.y - y) < radius:
                out.append(m)
        return out


if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from content import Content
    c = Content()
    w = World('berneo', c)
    n = w.load_mobs()
    print(f"мир berneo: заселено мобов {n}")
    p = Player(0x2892, 6000, 7000, 600, name='Тест')
    w.add_player(p)
    near = w.near(p.x, p.y, radius=2000)
    print(f"игрок на ({p.x},{p.y}), мобов в радиусе 2000: {len(near)}")
    for m in near[:5]:
        print(f"   {m.name[:18]:20} ур.{m.level} hp={m.hp} @({m.x:.0f},{m.y:.0f})")
