"""Серверный инвентарь персонажа.

Запись предмета — 147 байт, одинаковая в 06/05 (список) и 06/06 (положить):
  +0  контейнер (0 = надето, 1 = сумка)
  +1  слот
  +2  item id LE32
  +6  слот экипировки (у надетых = слот, в сумке 0)
  +8  uid (8 байт)
  +16 количество u16 LE (зелья 100, золото 999999 — сумма)
  +0x38 u64 — время истечения (unix) для предметов со сроком действия (itemBase
        +124, «Малая сумка» 30 дней); 0 у такого предмета = «срок действия истёк»

06/05 (S->C): +0 eid BE32, +4 ?, +5 число записей, с +6 записи.
06/06 (S->C, обработчик клиента 0x0065332f): +0 eid BE32, +4 u8 (0), +5 запись.
  Клиент кладёт запись в ячейку [контейнер][слот] — так же обновляется и
  количество (запись с тем же слотом и новым числом).
"""
import random, struct, time

GOLD = 999999           # деньги — предмет в сумке, сумма в поле количества
REC = 147
BAG, EQUIP = 1, 0
BAG_SLOTS = 20          # «Особая сумка» (контейнер 1): 2 ряда по 10 — расходники
GEAR_BAG = 2            # контейнер первой надетой сумки
BAG_ITEM, BAG_EQUIP_SLOT, GEAR_BAG_SLOTS = 69010, 13, 48   # «Сумка на 48 слотов»
# Слоты сумок 13/14/15 -> контейнеры 2/3/4 (клиент: FUN_0062367a считает слоты
# 13..15 сумками, FUN_00621767 знает контейнеры 2..4). Вместимость — у самой
# сумки (itemBase [16]); задаётся из loot.ITEMS через set_bag_sizes().
BAG_EQUIP_SLOTS = (13, 14, 15)
BAG_CONT = {13: 2, 14: 3, 15: 4}
BAG_SIZES = {BAG_ITEM: GEAR_BAG_SLOTS}


DURABILITY = {}       # item -> макс. прочность (itemBase [35])
STACK_MAX = {}        # item -> лимит стопки (только стопочные; loot.STACK_MIN и itemBase [14])
DUR_OFF = 0x48        # текущая прочность в записи (подсказка клиента: предмет +0x48)
# что бывает у обычной вещи: адрес, id, uid, количество, срок, прочность, белые характеристики (+125..134)
PLAIN_BYTES = (frozenset(range(24)) - {7}) | frozenset(range(0x38, 0x40)) \
    | frozenset(range(DUR_OFF, DUR_OFF + 4)) | frozenset(range(125, 135))


def improved(r):
    """Вещь улучшена: в записи есть что-то сверх обычной (заточка +7, вставки, камень души, жёлтые
    характеристики). Незнакомое поле тоже считается улучшением: лучше не тронуть лишнюю вещь."""
    return any(b and i not in PLAIN_BYTES for i, b in enumerate(r))


def set_stack_sizes(items):
    STACK_MAX.clear()
    STACK_MAX.update({i: v['stack'] for i, v in items.items() if v.get('stack', 1) > 1 and v.get('kind') != 1})


def stack_key(r):
    """Записи одной стопки: всё, кроме адреса, uid и количества (срок и прочие поля должны совпасть)."""
    return bytes(r[2:6]) + bytes(r[7:8]) + bytes(r[20:])


def stamp(r):
    """Примета записи для массовых действий пульта: [контейнер, ячейка, предмет, uid, количество]."""
    return [r[0], r[1], struct.unpack_from('<I', r, 2)[0], bytes(r[8:16]).hex(),
            struct.unpack_from('<I', r, 16)[0]]


def set_bag_sizes(items):
    for iid, it in items.items():
        if it.get('dur'):
            DURABILITY[int(iid)] = it['dur']
        if it.get('cat') == 13 and it.get('slots'):
            BAG_SIZES[int(iid)] = it['slots']


class Inventory:
    def __init__(self, head, records):
        self.head = bytearray(head[:6])       # eid, ?, count (count пересчитаем)
        self.recs = [bytearray(r) for r in records]

    # ---- загрузка / сохранение ----
    @classmethod
    def from_payload(cls, pl):
        n = pl[5] if len(pl) > 5 else 0
        recs = [pl[6 + i * REC:6 + (i + 1) * REC] for i in range(n)
                if 6 + (i + 1) * REC <= len(pl)]
        return cls(pl[:6], recs)

    @classmethod
    def from_saved(cls, head, hex_list):
        return cls(head, [bytes.fromhex(h) for h in hex_list])

    def to_saved(self):
        return [r.hex() for r in self.recs]

    # 06/05: клиент (0x00657dfa) читает число записей +5 как ЗНАКОВЫЙ байт, а оригинал не слал больше
    # 53 записей (7.8 КБ). При 135 вещах (0x87 < 0) и пакете 19.8 КБ клиент рвал связь при входе.
    LIST_MAX = 50

    def payload(self, limit=None):
        """06/05: первые limit записей (надетое — первым: в нём сумки), остальные — self.rest
        (досылаются по одной 06/06, как подобранная добыча)."""
        recs = sorted(self.recs, key=lambda r: r[0] != 0)
        limit = limit or self.LIST_MAX
        first, self.rest = recs[:limit], recs[limit:]
        h = bytearray(self.head)
        h[5] = len(first)
        return bytes(h) + b''.join(bytes(r) for r in first)

    # ---- поиск ----
    @staticmethod
    def item(r):
        return struct.unpack_from('<I', r, 2)[0]

    @staticmethod
    def count(r):
        return struct.unpack_from('<H', r, 16)[0]

    def find(self, cont, slot):
        for r in self.recs:
            if r[0] == cont and r[1] == slot:
                return r
        return None

    def find_item(self, item, cont=BAG, prefer_slot=None):
        """cont=None — в любой сумке (не среди надетого)."""
        hits = [r for r in self.recs
                if (r[0] == cont if cont is not None else r[0] != EQUIP) and self.item(r) == item]
        for r in hits:
            if r[1] == prefer_slot:
                return r
        return hits[0] if hits else None

    def capacity(self, cont):
        """Ячеек в контейнере: 1 — 20; 2..4 — по сумке, надетой в слот 13..15."""
        if cont == BAG:
            return BAG_SLOTS
        for slot, c in BAG_CONT.items():
            if c == cont:
                b = self.find(EQUIP, slot)
                return BAG_SIZES.get(self.item(b), 0) if b is not None else 0
        return 0

    def containers(self):
        """Куда можно класть: 1 и контейнеры надетых сумок."""
        return [BAG] + [BAG_CONT[s] for s in BAG_EQUIP_SLOTS if self.find(EQUIP, s) is not None]

    def free_bag_slot(self, cont=BAG):
        used = {r[1] for r in self.recs if r[0] == cont}
        for s in range(self.capacity(cont)):
            if s not in used:
                return s
        return None

    def free_cell(self, prefer=BAG):
        """(контейнер, ячейка): сначала в prefer, потом в остальных сумках."""
        for c in [prefer] + [c for c in self.containers() if c != prefer]:
            s = self.free_bag_slot(c)
            if s is not None:
                return c, s
        return None

    def gear_container(self):
        """Куда класть снаряжение: в первую надетую сумку со свободным местом."""
        for c in self.containers()[1:]:
            if self.free_bag_slot(c) is not None:
                return c
        return BAG

    def free_bag_equip_slot(self):
        """Свободный слот под сумку (13..15) или None."""
        for s in BAG_EQUIP_SLOTS:
            if self.find(EQUIP, s) is None:
                return s
        return None

    def replace_items(self, mapping):
        """Заменить предметы (id -> новый id), срок действия снять. -> число замен."""
        n = 0
        for r in self.recs:
            new = mapping.get(self.item(r))
            if new:
                struct.pack_into('<I', r, 2, new)
                struct.pack_into('<Q', r, 0x38, 0)
                n += 1
        return n

    def split_gear_stacks(self, items):
        """Снаряжение с количеством > 1 (старая выдача магазина) -> отдельные вещи.
        Не влезшие копии пропадают. -> число разделённых записей."""
        n = 0
        for r in list(self.recs):
            iid, cnt = self.item(r), self.count32(r)
            if cnt > 1 and items.get(iid, {}).get('kind') == 1:
                struct.pack_into('<I', r, 16, 1)
                for _ in range(cnt - 1):
                    c = self.gear_container()
                    new = self.add(iid, 1, stack=False, cont=c)
                    if new is None:
                        break
                    rec = self.find(new[0], new[1])
                    if rec is not None:          # та же запись (срок, особые) в новой ячейке
                        uid = bytes(rec[8:16])
                        rec[2:] = r[2:]
                        rec[0], rec[1] = new[0], new[1]
                        rec[8:16] = uid
                        if rec[0] != 0:
                            rec[6] = 0
                n += 1
        return n

    def ensure_bag(self):
        """Надеть «Сумку на 48 слотов» в слот 13, если сумки нет. -> True, если надели."""
        if self.find(EQUIP, BAG_EQUIP_SLOT) is not None:
            return False
        base = next((x for x in self.recs if x[0] == EQUIP), None)
        r = bytearray(base) if base is not None else bytearray(REC)
        r[0], r[1], r[6] = EQUIP, BAG_EQUIP_SLOT, BAG_EQUIP_SLOT
        struct.pack_into('<I', r, 2, BAG_ITEM)
        struct.pack_into('<II', r, 8, random.getrandbits(32), random.getrandbits(32))
        struct.pack_into('<I', r, 16, 1)
        self.recs.append(r)
        return True

    def locate(self, cont, slot, item):
        """Где на самом деле лежит item: (контейнер, ячейка) или None."""
        r = self.find(cont, slot)
        if r is not None and self.item(r) == item:
            return cont, slot
        r = next((x for x in self.recs if x[0] != EQUIP and self.item(x) == item), None)
        return (r[0], r[1]) if r is not None else None

    def move(self, fc, fs, tc, ts):
        """06/08: переложить [fc][fs] -> [tc][ts]; если там что-то есть — обмен."""
        a = self.find(fc, fs)
        if a is None:
            return False
        b = self.find(tc, ts)
        a[0], a[1] = tc, ts
        a[6] = ts if tc == EQUIP else 0
        if b is not None and b is not a:
            b[0], b[1] = fc, fs
            b[6] = fs if fc == EQUIP else 0
        return True

    def merge_stacks(self):
        """Объединить стопки в сумках до лимита STACK_MAX (остаются первые по адресу, uid остающихся цел).
        -> ([записи с новым количеством], [(сумка, ячейка, предмет, сумка и ячейка, куда влилось)])."""
        groups = {}
        for r in sorted(self.recs, key=lambda r: (r[0], r[1])):
            it = self.item(r)
            if r[0] in self.containers() and it != GOLD and it in STACK_MAX and self.count32(r):
                groups.setdefault(stack_key(r), []).append(r)
        changed, removed = {}, []
        for g in groups.values():
            cap = STACK_MAX[self.item(g[0])]
            a, b = 0, len(g) - 1
            while a < b:
                have, more = self.count32(g[a]), self.count32(g[b])
                n = min(cap - have, more)
                if n <= 0:
                    a += 1
                    continue
                struct.pack_into('<I', g[a], 16, have + n)
                changed[id(g[a])] = g[a]
                if n == more:
                    removed.append((g[b][0], g[b][1], self.item(g[b]), g[a][0], g[a][1]))
                    changed.pop(id(g[b]), None)
                    self.recs = [r for r in self.recs if r is not g[b]]
                    b -= 1
                else:
                    struct.pack_into('<I', g[b], 16, more - n)
                    changed[id(g[b])] = g[b]
        return list(changed.values()), removed

    def purge_passes(self, items, now=None):
        """Убрать из сумок пропуска и билеты с истёкшим сроком (itemBase: вид 3 со сроком — их ровно 10:
        63057–63061, 64003/64004/64011–64013). -> [(сумка, ячейка, предмет)]."""
        now = now or time.time()
        out, keep = [], []
        for r in self.recs:
            it = items.get(self.item(r)) or {}
            end = struct.unpack_from('<Q', r, 0x38)[0]
            if r[0] != EQUIP and it.get('kind') == 3 and it.get('period') and 0 < end <= now:
                out.append((r[0], r[1], self.item(r)))
            else:
                keep.append(r)
        self.recs = keep
        return out

    def sort_all(self, items):
        """Порядок кнопки клиента (CItemAutoSortPacket, AMo 0x0061d21c): все сумки сквозь — 1, 2, 3, 4 по
        ячейкам; ключ — категория itemBase [5], затем номер предмета; равные — в прежнем порядке. Только
        обмены ячеек, записи целы. Количество 0 стоит на месте; сумку с двумя записями в ячейке или ячейкой
        за вместимостью не трогаем. -> ([(сумка, ячейка, в сумку, в ячейку, предмет, предмет цели)], [пропущено])."""
        at, cells, skipped = {}, [], []
        for c in sorted(self.containers()):
            cap = self.capacity(c)
            here = [r for r in self.recs if r[0] == c]
            pos = {r[1] for r in here}
            if len(pos) != len(here) or any(s >= cap for s in pos):
                skipped.append(c)
                continue
            at.update({(c, r[1]): r for r in here})
            cells += [(c, s) for s in range(cap)]
        fixed = {k for k, r in at.items() if not self.item(r) or not self.count32(r)}
        order = sorted((r for k, r in at.items() if k not in fixed),
                       key=lambda r: ((items.get(self.item(r)) or {}).get('cat') or 0, self.item(r), r[0], r[1]))
        swaps = []
        for to, a in zip([k for k in cells if k not in fixed], order):
            frm = (a[0], a[1])
            if frm == to:
                continue
            b = at.pop(to, None)
            self.move(frm[0], frm[1], to[0], to[1])
            at.pop(frm, None)
            at[to] = a
            if b is not None:
                at[frm] = b
            swaps.append(frm + to + (self.item(a), self.item(b) if b is not None else 0))
        return swaps, skipped

    def free_count(self):
        n = 0
        for c in self.containers():
            used = {r[1] for r in self.recs if r[0] == c}
            n += sum(1 for s in range(self.capacity(c)) if s not in used)
        return n

    def room_for(self, item):
        """Сколько штук стопочного предмета ещё влезет."""
        cap = STACK_MAX.get(item, 1)
        have = sum(max(0, cap - self.count32(r)) for r in self.recs if r[0] != EQUIP and self.item(r) == item)
        return have + cap * self.free_count()

    def add_stack(self, item, count, cont=BAG, period=0):
        """Положить стопочное: долить имеющиеся до лимита, остальное — новыми стопками.
        -> записи для 06/06 или None (всё не влезает — не меняется ничего)."""
        cap = STACK_MAX.get(item)
        if not cap:
            r = self.add(item, count, stack=True, cont=cont, period=period)
            return None if r is None else [r]
        if count > self.room_for(item):
            return None
        out, left = [], count
        for r in sorted((r for r in self.recs if r[0] != EQUIP and self.item(r) == item), key=lambda r: r[0] != cont):
            n = min(left, cap - self.count32(r))
            if n > 0:
                struct.pack_into('<I', r, 16, self.count32(r) + n)
                out.append(bytearray(r))
                left -= n
        while left > 0:
            n = min(left, cap)
            out.append(self.add(item, n, stack=False, cont=cont, period=period))
            left -= n
        return out

    def put_stack(self, rec, stackable=False, prefer=BAG):
        """put_rec с лимитом стопки (хранилище, выкуп, снятый лот). -> записи для 06/06 или None (места нет)."""
        item, left = self.item(rec), self.count32(rec) or 1
        cap = STACK_MAX.get(item)
        if not stackable or not cap:
            r = self.put_rec(rec, stackable, prefer)
            return None if r is None else [r]
        key = stack_key(rec)
        same = [r for r in self.recs if r[0] != EQUIP and self.count32(r) < cap and stack_key(r) == key]
        if left > sum(cap - self.count32(r) for r in same) + cap * self.free_count():
            return None
        out = []
        for r in same:
            n = min(left, cap - self.count32(r))
            if n > 0:
                struct.pack_into('<I', r, 16, self.count32(r) + n)
                out.append(bytearray(r))
                left -= n
        part, first = bytearray(rec), True
        while left > 0:
            n = min(left, cap)
            if not first:                    # лишние стопки — со своим uid
                struct.pack_into('<II', part, 8, random.getrandbits(32), random.getrandbits(32))
            struct.pack_into('<I', part, 16, n)
            out.append(self.put_rec(part, False, prefer))
            first = False
            left -= n
        return out

    def remove(self, cont, slot, count=None, item=None):
        """Убрать предмет (продажа/выброс). count=None — весь стак. Если ячейка
        не совпала (клиент перекладывал), ищем по id предмета.
        -> (запись с остатком или None если ячейка опустела, item, сколько убрано)."""
        r = self.find(cont, slot)
        if (r is None or (item and self.item(r) != item)) and item:
            r = next((x for x in self.recs if x[0] != EQUIP and self.item(x) == item), None)
        if r is None:
            return None, 0, 0
        have = self.count32(r) or 1
        n = have if count is None else min(have, max(1, count))
        item = self.item(r)
        if n >= have:
            self.recs.remove(r)
            return None, item, n
        struct.pack_into('<I', r, 16, have - n)
        return bytearray(r), item, n

    def refresh_durability(self):
        """Выданным раньше инструментам с нулевой прочностью — полная. -> число."""
        n = 0
        for r in self.recs:
            mx = DURABILITY.get(self.item(r))
            if mx and struct.unpack_from('<I', r, DUR_OFF)[0] == 0:
                struct.pack_into('<I', r, DUR_OFF, mx)
                n += 1
        return n

    def refresh_periods(self, periods):
        """Предметам со сроком действия без времени истечения (выданы до
        исправления) — поставить срок от текущего момента. -> число исправленных."""
        n = 0
        for r in self.recs:
            per = periods.get(self.item(r), 0)
            if per and struct.unpack_from('<Q', r, 0x38)[0] == 0:
                struct.pack_into('<Q', r, 0x38, int(time.time()) + per)
                n += 1
        return n

    def count_item(self, item, keep=None):
        """keep(запись) — эти записи не считать (и не забирать в take_item)."""
        return sum(self.count32(r) or 1 for r in self.recs
                   if r[0] != EQUIP and self.item(r) == item and not (keep and keep(r)))

    def take_item(self, item, count, keep=None):
        """Забрать count шт. предмета из сумок (квестовые предметы при сдаче).
        -> список (контейнер, ячейка, запись или None) изменённых ячеек."""
        out = []
        for r in [x for x in self.recs if x[0] != EQUIP and self.item(x) == item and not (keep and keep(x))]:
            if count <= 0:
                break
            have = self.count32(r) or 1
            n = min(have, count)
            count -= n
            if n >= have:
                self.recs.remove(r)
                out.append((r[0], r[1], None))
            else:
                struct.pack_into('<I', r, 16, have - n)
                out.append((r[0], r[1], bytearray(r)))
        return out

    def equipped(self):
        """{слот экипировки: item} для надетых вещей."""
        return {r[1]: self.item(r) for r in self.recs if r[0] == EQUIP}

    # ---- действия; возвращают запись для 06/06 (или None) ----
    def use(self, item, prefer_slot=None, cont=None):
        """Потратить 1 шт. предмета из сумки. -> (запись для 06/06, осталось)."""
        r = self.find(cont, prefer_slot) if cont is not None else None
        if r is None or self.item(r) != item:
            r = self.find_item(item, BAG, prefer_slot) or self.find_item(item, None, prefer_slot)
        if r is None:
            return None, 0
        left = max(0, self.count(r) - 1)
        struct.pack_into('<H', r, 16, left)
        out = bytearray(r)
        if left == 0:
            self.recs.remove(r)
            struct.pack_into('<I', out, 2, 0)     # пустая ячейка
        return out, left

    def add(self, item, count=1, stack=True, cont=BAG, period=0):
        """Положить предмет в сумку: в существующий стак (зелья, золото 999999)
        или в свободную ячейку. count может быть < 0 (списать золото).
        -> запись для 06/06 или None (сумка полна)."""
        if stack:
            r = self.find_item(item, cont)
            if r is None:            # караты у перенесённых персонажей бывают в любой сумке
                r = self.find_item(item, None)
            if r is not None:
                struct.pack_into('<I', r, 16, max(0, min(0x7fffffff, self.count32(r) + count)))
                return bytearray(r)
        if count <= 0:
            return None
        # полна эта сумка — кладём в следующую (раньше лут не шёл в сумку на 48)
        # караты — тоже в любую сумку с местом (у паладина особая сумка была полна — караты не появлялись)
        cell = self.free_cell(cont)
        if cell is None or cell[1] is None:
            return None
        cont, s = cell
        r = bytearray(REC)
        r[0], r[1], r[6] = cont, s, 0
        struct.pack_into('<I', r, 2, item)
        struct.pack_into('<II', r, 8, random.getrandbits(32), random.getrandbits(32))  # uid
        struct.pack_into('<I', r, 16, count)
        struct.pack_into('<Q', r, 0x38, int(time.time()) + period if period else 0)
        if DURABILITY.get(item):
            struct.pack_into('<I', r, DUR_OFF, DURABILITY[item])   # полная прочность
        self.recs.append(r)
        return bytearray(r)

    def put_rec(self, rec, stackable=False, prefer=BAG):
        """Положить готовую запись (из хранилища — с заточкой, вставками, uid) в сумку.
        Стакуемое — в существующую стопку. -> запись для 06/06 или None (места нет)."""
        item, n = self.item(rec), self.count32(rec) or 1
        if stackable or item == GOLD:
            r = self.find_item(item, BAG) or self.find_item(item, None)
            if r is not None:
                struct.pack_into('<I', r, 16, min(0x7fffffff, self.count32(r) + n))
                return bytearray(r)
        cell = self.free_cell(prefer)
        if cell is None:
            return None
        r = bytearray(bytes(rec)[:REC].ljust(REC, b'\0'))
        r[0], r[1], r[6] = cell[0], cell[1], 0
        struct.pack_into('<I', r, 16, n)
        self.recs.append(r)
        return bytearray(r)

    @staticmethod
    def count32(r):
        return struct.unpack_from('<I', r, 16)[0]

    def gold(self):
        r = self.find_item(GOLD, BAG) or self.find_item(GOLD, None)
        return self.count32(r) if r is not None else 0

    def putoff(self, equip_slot, item=None):
        """Снять вещь: надето -> свободная ячейка сумки. -> запись или None."""
        r = self.find(EQUIP, equip_slot)
        if r is None and item:
            r = next((x for x in self.recs if x[0] == EQUIP and self.item(x) == item), None)
        if r is None:
            return None
        own = BAG_CONT.get(r[1]) if r[0] == EQUIP else None
        if own is not None:
            # сумку: только пустую и не в саму себя (её контейнер исчезает вместе с ней —
            # сумка внутри себя и вещи без сумки роняли клиент при следующем надевании)
            if any(x[0] == own and self.item(x) for x in self.recs):
                return None
            cell = next((self.free_cell(c) for c in self.containers()[1:]
                         if c != own and self.free_bag_slot(c) is not None), None)
        else:
            cell = self.free_cell(self.gear_container())
        if cell is None or cell[1] is None:
            return None
        r[0], r[1], r[6] = cell[0], cell[1], 0
        return bytearray(r)

    def wear(self, item, equip_slot, bag_slot=None, bag_cont=None):
        """Надеть вещь из сумки. -> ((конт, ячейка) откуда, запись надетой,
        запись прежней вещи — она уже в ячейке-источнике — или None); None —
        вещи нет."""
        r = self.find(bag_cont, bag_slot) if bag_cont is not None else None
        if r is None or r[0] == EQUIP or self.item(r) != item:
            r = self.find_item(item, None, bag_slot)
        if r is None:
            return None
        src = (r[0], r[1])
        old = self.find(EQUIP, equip_slot)
        r[0], r[1], r[6] = EQUIP, equip_slot, equip_slot
        if old is not None and old is not r:
            old[0], old[1], old[6] = src[0], src[1], 0
        else:
            old = None
        return src, bytearray(r), (bytearray(old) if old is not None else None)


def build_putout(eid, cont, slot, item):
    """Убрать предмет из ячейки — ШЛЁТСЯ ОПКОДОМ 06/06, как в оригинале: запись с тем же предметом и
    количеством 0 по настоящему адресу. В записях оригинала S 06/07 нет ни разу; ячейку очищает 06/06 с
    количеством 0 (66 раз), и на запрос клиента «выбросить» (C 06/07) сервер отвечал тоже 06/06.
    Клиент сам переводит ячейки сумок 2–4 за основной сеткой в доп. сетку 0x1a–0x1c (AMo 0x00621767)
    и снимает быстрые слоты кончившегося предмета.
    Раньше слали S 06/07 с адресом, пересчитанным по угаданной сетке 12: у клиента очищалась не та клетка
    (израсходованный «Дух воина» из [3][19] оставался), и после сортировки он показывал одно, а
    использовал другое. Кроме того, S 06/07 стирает чужой быстрый слот с тем же номером ячейки."""
    r = bytearray(REC)
    r[0], r[1] = cont, slot
    struct.pack_into('<I', r, 2, item)
    return build_putin(eid, r)


def parse_slot_req(pl):
    """06/07 C->S: -> (контейнер, ячейка, item)."""
    if len(pl) < 10:
        return None
    return pl[4], pl[5], struct.unpack_from('>I', pl, 6)[0]


def empty_rec(cont, slot):
    """Пустая запись (item 0): 06/06 с ней очищает ячейку — проверено в игре
    на кончившихся зельях; так же снимается иконка надетой вещи."""
    r = bytearray(REC)
    r[0], r[1] = cont, slot
    return r


PICKUP_OK = 0x5B      # код «получен предмет» в 06/03 (обработчик 0x00652b1d)


def build_pickup_notice(eid, item, count):
    """06/03 S->C (CItemPickupPacket): +0 eid BE32, +4 количество BE32,
    +8 item BE32, +12 код BE16. С кодом 0x5B клиент пишет в чат
    «получено: <имя>» / «<имя> (N)», сам инвентарь не трогает."""
    return (struct.pack('>III', eid, count, item) + struct.pack('>H', PICKUP_OK)
            + bytes(18))


def build_putin(eid, rec):
    """06/06 S->C: положить запись предмета в ячейку инвентаря."""
    return struct.pack('>I', eid) + b'\x00' + bytes(rec)


def apply_equipped(payload, base, equipped, slots=(1, 2, 3, 4, 7, 8), enchants=None):
    """Записать надетые вещи в массив слотов пакета (карточка/02/05/04/02): 31 × u32 id,
    сразу за ним 31 × u8 заточка (оригинал Pers4x: 07 07 07 05 00 00 08 — по ней клиент
    считает атаку/защиту вещей в окне персонажа)."""
    pl = bytearray(payload)
    for s in slots:
        off = base + 4 * s
        if off + 4 <= len(pl):
            struct.pack_into('<I', pl, off, equipped.get(s, 0))
        if enchants is not None and base + 124 + s < len(pl):
            pl[base + 124 + s] = (enchants.get(s, 0) if equipped.get(s) else 0) & 0xff
    return bytes(pl)
