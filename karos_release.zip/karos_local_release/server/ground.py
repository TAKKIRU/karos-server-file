"""Предметы на земле (дроп с мобов, который надо подобрать).

06/04 CItemDropPacket S->C (обработчик клиента 0x00653167 -> 0x0063e99c), 181 байт:
  +0   ключ 1 BE32 = ВЛАДЕЛЕЦ трофея (eid игрока). Клиент (FUN_0063fce5) даёт
       поднять, только если он равен своему eid (или <1) — иначе «Нет права на
       захват трофеев» (строка 27006) и подбор даже не отправляется
  +4   ключ 2 BE32 (номер предмета на земле)
  +8   правило трофеев BE32: 0 личное (проверка владельца), 1 по группе;
       при других значениях клик по предмету ничего не делает
  +12, +16  BE32 — клиент лишь хранит
  +20  запись предмета 147 байт (как в 06/05; +22 = item id LE — по нему модель и имя)
  +167 x f32, +171 y f32 (горизонталь), +175 высота f32
  +179 код BE16 (0x93 — «вы выбросили предмет»: только сообщение; иначе — создать)
Убрать с земли: 06/03 с кодом 0xB7 и (+0 ключ1, +4 ключ2, +8 item) — клиент находит
объект (0x0063c691) и прячет его, без сообщения в чат.
"""
import itertools, math, random, struct, time

REC = 147
HIDE = 0xB7
DESPAWN = 180.0          # сек: предмет исчезает, если не подобран


class Ground:
    _ids = itertools.count(1)

    def __init__(self):
        self.items = {}      # gid -> dict

    def drop(self, dropper, item, count, x, y, z, base_rec=None, rng=random, period=0):
        """dropper — владелец трофея (eid игрока, см. +0 в 06/04)."""
        gid = next(Ground._ids)
        ang = rng.random() * 2 * math.pi
        r = 15 + rng.random() * 25
        rec = bytearray(base_rec) if base_rec else bytearray(REC)
        rec[0], rec[1], rec[6] = 1, 0, 0
        struct.pack_into('<I', rec, 2, item)
        struct.pack_into('<II', rec, 8, rng.getrandbits(32), rng.getrandbits(32))
        struct.pack_into('<I', rec, 16, count)
        if period:                                   # срок действия (+0x38, u64 время)
            struct.pack_into('<Q', rec, 0x38, int(time.time()) + period)
        g = {'gid': gid, 'dropper': dropper, 'item': item, 'count': count,
             'x': x + r * math.cos(ang), 'y': y + r * math.sin(ang), 'z': z,
             'rec': bytes(rec), 't': time.time()}
        self.items[gid] = g
        return g

    def find_in(self, payload):
        """Найти номер предмета на земле в запросе подбора (формат ещё не снят)."""
        for o in range(0, max(0, len(payload) - 3)):
            v = struct.unpack_from('>I', payload, o)[0]
            if v in self.items:
                return self.items[v]
        return None

    def take(self, gid):
        return self.items.pop(gid, None)

    def expired(self, now=None):
        now = now or time.time()
        old = [g for g in self.items.values() if now - g['t'] > DESPAWN]
        for g in old:
            self.items.pop(g['gid'], None)
        return old


def build_drop(owner_eid, g):
    return (struct.pack('>IIIII', g['dropper'], g['gid'], 0, 0, 0) + g['rec']
            + struct.pack('<3f', g['x'], g['y'], g['z']) + struct.pack('>H', 0))


def build_hide(g):
    return (struct.pack('>III', g['dropper'], g['gid'], g['item']) + struct.pack('>H', HIDE)
            + bytes(18))
