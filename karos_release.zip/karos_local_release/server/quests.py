"""УСТАРЕЛО: сервер этот модуль не подключает (квесты — questlog.py по quest.lod; таблица quest_seq
в content_full.sqlite пуста). Оставлен для истории.

Разговор с NPC и квесты.

Раскладки из дампа play1:
  09/00 C→S разговор с NPC: +0 игрок BE32, +5 id NPC (BE32 со смещения 4..7)
  09/01 C→S действие с квестом (взять/сдать): та же голова + ffffffff
  09/03 C→S прогресс квеста
Сервер в оригинале отвечает ЭХОМ того же пакета (подтверждено дампом),
а тексты диалогов и квестов клиент берёт из своих файлов — сервер шлёт
только идентификаторы. Поэтому эхо достаточно для работы окна NPC.

Содержимое (что предлагать) берётся из расшифрованных таблиц:
  npcDialogue — 1446 реплик, quest — 730 квестов.
"""
import struct, sqlite3, os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))


class Quests:
    def __init__(self):
        self.db = sqlite3.connect(os.path.join(ROOT, 'content.sqlite'))
        self.full = sqlite3.connect(os.path.join(ROOT, 'content_full.sqlite'))
        self.active = {}          # player_eid -> {quest_id: прогресс}

    def dialogue_for(self, npc_id):
        """реплики NPC из npcDialogue"""
        try:
            q = 'SELECT strings FROM npcDialogue WHERE f0=? LIMIT 3'
            return [r[0] for r in self.db.execute(q, (npc_id,)) if r[0]]
        except sqlite3.Error:
            return []

    def quests_of(self, npc_id):
        """квесты, которые даёт этот NPC"""
        try:
            q = 'SELECT v0 FROM quest_seq LIMIT 5'
            return [r[0] for r in self.full.execute(q)]
        except sqlite3.Error:
            return []

    def accept(self, player_eid, quest_id):
        self.active.setdefault(player_eid, {})[quest_id] = 0
        return True

    def progress(self, player_eid, quest_id, n=1):
        cur = self.active.setdefault(player_eid, {})
        cur[quest_id] = cur.get(quest_id, 0) + n
        return cur[quest_id]

    def complete(self, player_eid, quest_id):
        return self.active.get(player_eid, {}).pop(quest_id, None)

    def stats(self):
        try:
            nd = self.db.execute('SELECT COUNT(*) FROM npcDialogue').fetchone()[0]
        except sqlite3.Error:
            nd = 0
        try:
            nq = self.full.execute('SELECT COUNT(*) FROM quest_seq').fetchone()[0]
        except sqlite3.Error:
            nq = 0
        return {'dialogues': nd, 'quests': nq}


def parse_talk(payload):
    """09/00 -> (player_eid, npc_id)"""
    if len(payload) < 10:
        return None
    return (struct.unpack_from('>I', payload, 0)[0],
            struct.unpack_from('>I', payload, 4)[0])


def parse_quest(payload):
    """09/01 -> (player_eid, npc_id)"""
    if len(payload) < 12:
        return None
    return (struct.unpack_from('>I', payload, 0)[0],
            struct.unpack_from('>I', payload, 4)[0])


if __name__ == '__main__':
    q = Quests()
    print(f"загружено: {q.stats()}")
    print(f"\nпример квестов: {q.quests_of(0)[:5]}")
    q.accept(0x2892, 1001)
    print(f"взят квест 1001, прогресс: {q.progress(0x2892, 1001)}")
    print(f"активные квесты игрока: {q.active}")
