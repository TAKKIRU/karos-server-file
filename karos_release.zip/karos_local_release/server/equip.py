"""Экипировка — по раскладке из дампа play1 (§107).

  06/00 C→S надеть: +0 entity BE32, +4 =1, +5 слот ИНВЕНТАРЯ, +7 item BE32
  06/00 S→C ответ : +4 =0, +5 слот ЭКИПИРОВКИ
  06/01 C→S снять : +4 =0, +5 слот экипировки, +6 дубль, +7 item BE32

ВАЖНО: два разных пространства слотов. Клиент шлёт слот инвентаря при
надевании, слот экипировки при снятии — сервер обязан их различать.

Атака персонажа пересчитывается при смене экипировки: в дампе она
выросла 21 -> 55 после надевания комплекта (§109).
"""
import struct, json, os, sqlite3

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))


class Equipment:
    """Надетые предметы персонажа: слот экипировки -> item_id."""

    def __init__(self):
        self.slots = {}          # slot_equip -> item_id
        self.inventory = {}      # slot_inv -> item_id

    def wear(self, slot_inv, item_id):
        """надеть из инвентаря; возвращает слот экипировки"""
        slot_equip = self._equip_slot_for(item_id)
        self.slots[slot_equip] = item_id
        self.inventory.pop(slot_inv, None)
        return slot_equip

    def putoff(self, slot_equip):
        return self.slots.pop(slot_equip, None)

    @staticmethod
    def _equip_slot_for(item_id):
        """слот экипировки по ID предмета.
        В дампе: 42001->1, 42801->4 и т.п. Точная таблица — в itemBase;
        пока раскладываем по диапазону ID (группы по 400, §107)."""
        # оружие (1001..28999) -> 7, щиты 29001.. -> 8 (клиент сам шлёт слот 8
        # при снятии щита); броня — блоки по 2000 на класс (32001, 34001, …),
        # внутри блока +400 на часть: торс 1, ноги 2, перчатки 3, обувь 4.
        if 29000 < item_id < 30000:
            return 8
        if item_id < 29000:
            return 7
        if item_id < 50000:
            return ((item_id - 1) % 2000) // 400 + 1
        return 1


class Stats:
    """Статы персонажа. Раскладка 08/02: +32 maxHP, +44 maxMP, +96 атака."""

    def __init__(self, attack=21.0, max_hp=150.4, max_mp=90.0):
        self.attack = attack
        self.max_hp = max_hp
        self.max_mp = max_mp

    def recalc(self, equipment, content=None):
        """пересчёт атаки от надетого. Наблюдение §109: комплект дал 21->55."""
        bonus = 0.0
        for item_id in equipment.slots.values():
            bonus += self._item_attack(item_id, content)
        self.attack = 21.0 + bonus
        return self.attack

    @staticmethod
    def _item_attack(item_id, content):
        """урон предмета из itemAttr (§97), если известен"""
        if content and str(item_id) in getattr(content, 'weapon_dmg', {}):
            recs = content.weapon_dmg[str(item_id)]
            r0 = [r for r in recs if r['lvl'] == 0]
            if r0 and len(r0[0]['vals']) >= 2:
                return (r0[0]['vals'][0] + r0[0]['vals'][1]) / 2
        return 8.5      # средний вклад предмета по наблюдениям


def parse_wear(payload):
    """06/00 -> (entity, slot_inv, item_id)"""
    if len(payload) < 11:
        return None
    return (struct.unpack_from('>I', payload, 0)[0], payload[5],
            struct.unpack_from('>I', payload, 7)[0])


def parse_putoff(payload):
    """06/01 -> (entity, slot_equip, item_id)"""
    if len(payload) < 11:
        return None
    return (struct.unpack_from('>I', payload, 0)[0], payload[5],
            struct.unpack_from('>I', payload, 7)[0])


def build_wear_reply(tpl, entity, slot_equip, item_id, enchant=0):
    """06/00 S->C (клиент 0x00652787): +0 eid, +5/+6 слот, +7 item BE32, +11 заточка (u8) —
    по ней клиент считает атаку/защиту вещи в окне персонажа (оригинал: ружьё +8 -> 08)."""
    pl = bytearray(tpl) + bytes(max(0, 12 - len(tpl)))
    struct.pack_into('>I', pl, 0, entity)
    pl[4] = 0
    pl[5] = slot_equip
    pl[6] = slot_equip
    struct.pack_into('>I', pl, 7, item_id)
    pl[11] = enchant & 0xff
    return bytes(pl[:12])


def build_stats(tpl, stats):
    """08/02 — статы. Записываем известные поля (§109)."""
    pl = bytearray(tpl)
    for off, val in ((32, stats.max_hp), (44, stats.max_mp), (96, stats.attack),
                     (412, stats.max_hp), (424, stats.max_mp)):
        if off + 4 <= len(pl):
            struct.pack_into('<f', pl, off, float(val))
    return bytes(pl)


if __name__ == '__main__':
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    from content import Content
    c = Content()
    eq = Equipment()
    st = Stats()
    print(f"атака без экипировки: {st.attack}")
    # то, что надевал пользователь в дампе (§107)
    for slot_inv, item in ((14, 42001), (15, 42401), (16, 42801),
                           (17, 43201), (18, 16001)):
        se = eq.wear(slot_inv, item)
        print(f"  надет {item} (инв.{slot_inv}) -> слот экипировки {se}")
    print(f"атака после комплекта: {st.recalc(eq, c):.1f}   (в дампе было 54.9)")
