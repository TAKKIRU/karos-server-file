"""Почта (сюда приходят награды) и награды за посещение — по записям оригинала.

Отметка посещения — кнопкой в окне дневника (C 0a/0b, server/eventdiary.py), как в оригинале.
Письма хранятся у персонажа в accounts.json: ch['mail'] = [{id, sender, title, body, date: [г, м, д],
type, read, items: [[item, n]], gold, exp, sent}]. Посещение: ch['attend'] = {last, month, count, streak}.

S 10/04 (при входе): u32 непрочитанных.
C 10/02 (открыть почту, 16 байт) -> S 10/02: u32 0, u32 страниц, u32 писем, u32 0, затем письма:
  u32 id, u16 1, u16 1001, отправитель\\0, заголовок\\0, u32 год, u32 месяц, u32 день,
  u16 вид (6 — «Karos Online», 2 — подарок), u16 прочитано, u16 0, u16 дней хранения,
  u16 есть вложения.
C 10/01 (прочитать): u32 id, u16 1, u16 1001, u16 вид -> S 10/01: то же, отправитель\\0,
  заголовок\\0, текст\\0, u32 год, u32 месяц, u32 день, u32 0, u32 0, u16 число вложений,
  u32 караты, 8 × запись предмета (147 байт: ff ff, item, …, uid, кол-во; пустая — ff ff 0
  и номер слота на +6).
C 10/05 (забрать вложения): u32 id, u16 1, u16 1001, 8 байт 0, u16 вид -> S 10/08: u32 id,
  u16 1, u16 1001, u16 вид, затем 06/06 предметы и караты (так в записи orig_1).
Строки — UTF-8, числа BE (записи предметов — как в рюкзаке, LE).
Имя модуля не mailbox — так называется модуль стандартной библиотеки.
"""
import json, os, random, struct, time

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    _ev = json.load(open(os.path.join(DATA, 'events.json'), encoding='utf-8'))
except (OSError, ValueError):
    _ev = {}
ATTEND = _ev.get('attendance', [])
REWARDS = {int(k): v for k, v in _ev.get('rewards', {}).items()}
SENDER = 'Karos Online'
KEEP_DAYS = 30
SLOTS = 8
REC_LEN = 147
SYS = 6


def new_mail(title, body, items=(), gold=0, exp=0, sender=SENDER, kind=SYS):
    t = time.localtime()
    return {'id': (int(time.time()) + random.randrange(1 << 16)) & 0x7fffffff, 'sender': sender,
            'title': title, 'body': body, 'date': [t.tm_year, t.tm_mon, t.tm_mday], 'type': kind,
            'read': 0, 'items': [list(x) for x in items][:SLOTS], 'gold': int(gold),
            'exp': int(exp), 'sent': int(time.time())}


def unread(mails):
    return sum(1 for m in mails if not m.get('read'))


def _s(x):
    return x.encode('utf-8') + b'\0'


def _left(m):
    return max(0, KEEP_DAYS - int((time.time() - m.get('sent', time.time())) // 86400))


def build_count(mails):
    return struct.pack('>I', unread(mails))


def build_list(mails):
    shown = sorted(mails, key=lambda m: -m.get('sent', 0))
    out = struct.pack('>IIII', 0, max(1, (len(shown) + 9) // 10), len(shown), 0)
    for m in shown:
        y, mo, d = m['date']
        out += (struct.pack('>IHH', m['id'], 1, 1001) + _s(m['sender']) + _s(m['title'])
                + struct.pack('>IIIHHHHH', y, mo, d, m['type'], 1 if m.get('read') else 0, 0,
                              _left(m), 1 if (m['items'] or m['gold']) else 0))
    return out


def _slot(i, item=None, n=0):
    r = bytearray(REC_LEN)
    r[0] = r[1] = 0xff
    if item:
        struct.pack_into('<I', r, 2, item)
        struct.pack_into('<II', r, 8, random.getrandbits(32), random.getrandbits(32))
        struct.pack_into('<I', r, 16, n)
    else:
        r[6] = i
    return bytes(r)


def build_read(m):
    y, mo, d = m['date']
    out = (struct.pack('>IHHH', m['id'], 1, 1001, m['type']) + _s(m['sender']) + _s(m['title'])
           + _s(m['body']) + struct.pack('>IIIIIHI', y, mo, d, 0, 0, len(m['items']), m['gold']))
    for i in range(SLOTS):
        out += _slot(i, *m['items'][i]) if i < len(m['items']) else _slot(i)
    return out


def build_taken(m):
    return struct.pack('>IHHH', m['id'], 1, 1001, m['type'])


def parse_id(pl):
    return struct.unpack_from('>I', pl, 0)[0] if len(pl) >= 4 else 0


# ---- посещение ----
def attend(state, now=None):
    """Отметить вход сегодня. -> [записи посещения] с наградой за этот вход (пусто, если
    сегодня уже отмечен). Вид 1 — каждый день, 2 — N-й вход за месяц, 3 — N дней подряд."""
    now = now or time.time()
    t = time.localtime(now)
    day = time.strftime('%Y-%m-%d', t)
    if state.get('last') == day:
        return []
    month = time.strftime('%Y-%m', t)
    yesterday = time.strftime('%Y-%m-%d', time.localtime(now - 86400))
    state['streak'] = state.get('streak', 0) + 1 if state.get('last') == yesterday else 1
    state['count'] = state.get('count', 0) + 1 if state.get('month') == month else 1
    state['month'], state['last'] = month, day
    return [a for a in ATTEND
            if a['kind'] == 1 or (a['kind'] == 2 and state['count'] == a['n'])
            or (a['kind'] == 3 and state['streak'] == a['n'])]


def attend_mail(a):
    r = REWARDS.get(a['reward'], {})
    return new_mail('Награда за посещение',
                    a['text'] or 'Этот предмет является наградой за посещение.',
                    r.get('items', []), r.get('gold', 0), r.get('exp', 0))
