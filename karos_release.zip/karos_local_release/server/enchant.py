"""Заточка (06/17) и чарование характеристик (06/55) — по записям оригинала.

Запись предмета (147 байт): +7 уровень заточки; +28/+32/+36 вставки (руны, камни);
+40/+44/+48 «особые характеристики» (id 999999xxx).

06/17 C->S (43 байта, BE): +0 eid, +4/+8/+12 контейнер/ячейка/id свитка, +16/+20/+24
контейнер/ячейка/id предмета, +28 код u16, +30 12 байт ячеек защиты (ff — нет), +42 u8.
S->C — то же с кодом результата на +28 (обработчик клиента 0x0065595c):
  0x74 «Чарование удалось», 0x75 «не удалось», 0x76 «не удалось, предмет уничтожен»,
  0x96 «не удалось, но защита предотвратила уничтожение»; затем 06/06 свиток и предмет.
06/55 C->S (18 байт, BE): +0/+4 контейнер/ячейка материала («Камень древнего знания»,
3 шт. за попытку), +8/+12 контейнер/ячейка предмета, +16 код. S->C: 06/06 материал,
06/06 предмет, 06/55 с кодом 0x0175 (неудача, «Повторите попытку позднее»; удача — 0x0174).
Жёлтая характеристика пишется в запись +135.. (itemroll.add_yellow, лимит по заточке).
try_characteristic ниже — старый вариант (писал не туда), не используется.
"""
import collections, json, os, random, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OK, FAIL, BROKEN, SAVED = 0x74, 0x75, 0x76, 0x96
CHAR_OK, CHAR_FAIL = 0x0174, 0x0175
STONES_PER_TRY = 3
CHAR_CHANCE = 0.35
# шанс заточки на следующий уровень, если таблицы нет (свой: +1..+3 всегда, дальше реже)
CHANCE = {0: 1.0, 1: 1.0, 2: 1.0, 3: 0.9, 4: 0.8, 5: 0.7, 6: 0.6, 7: 0.5, 8: 0.4, 9: 0.3,
          10: 0.2, 11: 0.15, 12: 0.1}
# таблица клиента ItemEnchant (tools/enchant_table.py): {вид свитка: {тип предмета: {уровень:
# [успех %, неудача без потерь %, ?]}}}; остаток — уничтожение
try:
    TABLE = json.load(open(os.path.join(ROOT, 'data', 'enchant.json'), encoding='utf-8'))
except (OSError, ValueError):
    TABLE = {}
MAX_LEVEL = 13
ENCH_OFF = 7
OPT_OFF = (40, 44, 48)


def _option_pool():
    """Особые характеристики, какие бывают у предметов игроков (слепок комиссионки)."""
    try:
        lots = json.load(open(os.path.join(ROOT, 'data', 'commission_snapshot.json'), encoding='utf-8'))
    except (OSError, ValueError):
        return [(999999016, 1)]
    c = collections.Counter(o for g in lots for o in g.get('opts', [])[3:] if o)
    return list(c.items()) or [(999999016, 1)]


POOL = _option_pool()


def level(rec):
    return rec[ENCH_OFF]


def chances(lv_to, scroll_grade=0, item_cat=1):
    """-> (успех, без потерь) долями для заточки на уровень lv_to; None — таблицы нет."""
    g = TABLE.get(str(scroll_grade)) or TABLE.get('0')
    if not g:
        return None
    t = g.get(str(item_cat)) or g.get('2' if item_cat != 1 else '1')
    row = t.get(str(lv_to)) if t else None
    if not row:
        return None
    return row[0] / 100.0, row[1] / 100.0


def try_enchant(rec, safe=True, protected=False, rng=random, scroll_grade=0, item_cat=1):
    """-> код результата; меняет rec (уровень) при удаче. Шансы — таблица клиента
    ItemEnchant: успех / неудача без потерь / уничтожение (safe — без уничтожения,
    protected — защита спасает предмет)."""
    lv = rec[ENCH_OFF]
    if lv >= MAX_LEVEL:
        return FAIL
    ch = chances(lv + 1, scroll_grade, item_cat)
    x = rng.random()
    if ch is None:
        ok, keep = CHANCE.get(lv, 0.05), 1.0
        if lv >= 6:
            keep = 0.5
    else:
        ok, keep = ch
    if x < ok:
        rec[ENCH_OFF] = lv + 1
        return OK
    if safe or x < ok + keep:
        return FAIL
    if protected:
        return SAVED
    return BROKEN


def try_characteristic(rec, rng=random):
    """Добавить особую характеристику в свободное поле (+40/+44/+48; занято всё — заменить
    случайную). -> код 06/55."""
    if rng.random() >= CHAR_CHANCE:
        return CHAR_FAIL
    total = sum(w for _, w in POOL)
    r = rng.uniform(0, total)
    opt = POOL[-1][0]
    for o, w in POOL:
        r -= w
        if r <= 0:
            opt = o
            break
    free = [o for o in OPT_OFF if struct.unpack_from('<I', rec, o)[0] == 0]
    struct.pack_into('<I', rec, free[0] if free else rng.choice(OPT_OFF), opt)
    return CHAR_OK


# ---- чарование изделий из флеттоцветов (06/18, tools/fleta_enchant_table.py) ----
# C 06/18 (сборщик 0x0049de86, окно 0x0049ebde): +0 eid, +4 ступень, +8 вид (4 оружие, 5 доспехи),
#   +12 u16 0x74, +14 u8 режим кнопки (1..4; не используется). Вещи клиент не перечисляет —
#   сервер сам берёт их из сумки по таблице.
# S 06/18 (0x00655e73): +0 eid, +4 ступень, +8 вид, +12 u16 код: 0x79 «Чарование (%s) было
#   успешным» (клиент показывает изделие 53001/53501), 0x7a «…окончилось неудачей», 0x7b «Все
#   предметы … исчезли», 0x7c «Etc Error».
# Ступень изделия хранится в байте заточки записи (+7); только что сделанное изделие (0) — ступень 1.
import json as _json
try:
    _FL = _json.load(open(os.path.join(ROOT, 'data', 'fleta_enchant.json'), encoding='utf-8'))
except (OSError, ValueError):
    _FL = []
FLETA = {(r['grade'], r['kind']): r for r in _FL}
FLETA_ITEM = {4: 53001, 5: 53501}
F_OK, F_FAIL, F_LOST, F_ERR = 0x79, 0x7a, 0x7b, 0x7c


def fleta_grade(rec):
    return max(1, rec[ENCH_OFF])


def fleta_plan(inv, recipe):
    """Что забрать из сумки: [('rec', сумка, ячейка, предмет)] для изделий нужной ступени и
    [('stack', предмет, кол-во)] для материалов. -> (план, None) или (None, чего не хватает)."""
    plan, used = [], set()
    for item, grade, count in recipe['need']:
        if grade:
            hits = [r for r in inv.recs if r[0] != 0 and inv.item(r) == item and fleta_grade(r) == grade
                    and (r[0], r[1]) not in used][:count]
            if len(hits) < count:
                return None, (item, grade, count)
            for r in hits:
                used.add((r[0], r[1]))
                plan.append(('rec', r[0], r[1], item))
        else:
            if inv.count_item(item) < count:
                return None, (item, 0, count)
            plan.append(('stack', item, count))
    return plan, None


def fleta_roll(recipe, rng=random):
    x = rng.random() * 100.0
    if x < recipe['ok']:
        return F_OK
    return F_FAIL if x < recipe['ok'] + recipe['keep'] else F_LOST


def build_fleta(eid, grade, kind, code):
    return struct.pack('>IIIH', eid, grade, kind, code)
