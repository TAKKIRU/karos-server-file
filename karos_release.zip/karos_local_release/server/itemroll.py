"""Характеристики снаряжения — как у предметов оригинала.

Запись предмета (147 байт; подсказка клиента 0x00638817):
  +7         заточка;
  +24..+44   6 × u32 вставки: черепа (оружие), руны (броня), камни (аксессуары) — белые
             характеристики НАД «Особыми характеристиками»; что даёт вставка —
             data/socket_attrs.json (itemCombAttr.lod: группа 1 аксессуары / 2 оружие / 3 броня,
             тип, значение);
  +125..+133 5 × u16 белые особые характеристики (случайные при выпадении / камни мудрых);
  +135..+143 5 × u16 жёлтые особые характеристики (камни древнего знания у ремесленника);
             номер опции -> data/item_options.json (uniqueOptionType -> навык -> skillData).
Лот комиссионки несёт те же поля (opts = вставки, хвост[-23:] = запись +123..+145) — покупка
даёт предмет ровно как у продавца.
Новая вещь (добыча, магазин, подарок) получает только белые особые характеристики настоящего
предмета игроков: того же предмета, иначе того же класса/слота/категории и близкого уровня
(так бродяге не попадут магические характеристики посоха).
Жёлтые добавляет чарование: до +8 — 1, +9..+11 — 2, +12 и выше — 3 (легендарные — ещё +1).
"""
import json, os, random, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEM_OFF, WHITE_OFF, YEL_OFF = 24, 125, 135
BLOCK_OFF, BLOCK_LEN = 123, 23
_WHITE, _YELLOW = {}, {}          # ключ -> [кортеж 5 опций]
OPTIONS, SOCKETS = {}, {}


def _j(name):
    try:
        return json.load(open(os.path.join(ROOT, 'data', name), encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def _keys(item, it):
    lv = it.get('lvl', 0) // 10
    return [('i', item), ('c', it.get('cat'), it.get('cls'), it.get('slot'), lv),
            ('c', it.get('cat'), it.get('cls'), it.get('slot'), lv - 1),
            ('c', it.get('cat'), it.get('cls'), it.get('slot'), lv + 1),
            ('b', it.get('cat'), (it.get('cls') or 0) // 100, it.get('slot'))]


def init(items):
    if OPTIONS:
        return
    OPTIONS.update({int(k): v for k, v in _j('item_options.json').items()})
    SOCKETS.update({int(k): v for k, v in _j('socket_attrs.json').items()})
    for g in _j('commission_snapshot.json') if isinstance(_j('commission_snapshot.json'), list) else []:
        it = items.get(g.get('item'))
        if not it or it.get('kind') != 1 or 'tail' not in g:
            continue
        blk = bytes.fromhex(g['tail'])[-BLOCK_LEN:]
        white = struct.unpack_from('<5H', blk, WHITE_OFF - BLOCK_OFF)
        yel = struct.unpack_from('<5H', blk, YEL_OFF - BLOCK_OFF)
        for k in _keys(g['item'], it):
            if any(white):
                _WHITE.setdefault(k, []).append(white)
            if any(yel):
                _YELLOW.setdefault(k, []).extend(v for v in yel if v)


def _pick(table, item, items):
    it = items.get(item) or {}
    for k in _keys(item, it):
        if table.get(k):
            return table[k]
    return None


def roll_white(item, items, rng=random):
    """Белые особые характеристики новой вещи или None."""
    it = items.get(item)
    if not it or it.get('kind') != 1:
        return None
    pool = _pick(_WHITE, item, items)
    return rng.choice(pool) if pool else None


def apply_white(rec, white):
    struct.pack_into('<5H', rec, WHITE_OFF, *white)


def apply_lot(rec, opts, block, enchant):
    struct.pack_into('<6I', rec, GEM_OFF, *list(opts)[:6])
    rec[BLOCK_OFF:BLOCK_OFF + BLOCK_LEN] = block[:BLOCK_LEN]
    rec[7] = enchant & 0xff


def yellow_limit(rec, items):
    lv = rec[7]
    n = 1 if lv <= 8 else (2 if lv <= 11 else 3)
    name = (items.get(struct.unpack_from('<I', rec, 2)[0]) or {}).get('name', '').lower()
    return n + (1 if 'легенд' in name else 0)


def add_yellow(rec, items, rng=random):
    """Чарование: добавить жёлтую характеристику. -> номер опции или None (нет места/образцов)."""
    item = struct.unpack_from('<I', rec, 2)[0]
    cur = list(struct.unpack_from('<5H', rec, YEL_OFF))
    if sum(1 for v in cur if v) >= yellow_limit(rec, items):
        return None
    pool = _pick(_YELLOW, item, items)
    if not pool:
        return None
    opt = rng.choice(pool)
    cur[cur.index(0)] = opt
    struct.pack_into('<5H', rec, YEL_OFF, *cur)
    return opt


def describe(rec):
    """-> ([белые сверху], [белые особые], [жёлтые]) строками — для журнала/пульта."""
    def opt(i):
        return ', '.join(f"{e[3]} +{e[1] or e[2]}{'%' if not e[1] else ''}" for e in OPTIONS.get(i, {}).get('effects', []))
    socks = [f"{SOCKETS[g][4]} +{SOCKETS[g][2]}" for g in struct.unpack_from('<6I', rec, GEM_OFF) if g in SOCKETS]
    white = [opt(i) for i in struct.unpack_from('<5H', rec, WHITE_OFF) if i]
    yel = [opt(i) for i in struct.unpack_from('<5H', rec, YEL_OFF) if i]
    return socks, white, yel


def bonuses(recs):
    """Сумма характеристик от вставок и особых опций надетого: {тип: [плюс, процент]}."""
    out = {}
    for rec in recs:
        for g in struct.unpack_from('<6I', rec, GEM_OFF):
            s = SOCKETS.get(g)
            if s:
                b = out.setdefault(s[1], [0.0, 0.0])
                b[0] += s[2]
                b[1] += s[3]
        for i in struct.unpack_from('<5H', rec, WHITE_OFF) + struct.unpack_from('<5H', rec, YEL_OFF):
            for e in OPTIONS.get(i, {}).get('effects', []):
                b = out.setdefault(e[0], [0.0, 0.0])
                b[0] += e[1]
                b[1] += e[2]
    return out
