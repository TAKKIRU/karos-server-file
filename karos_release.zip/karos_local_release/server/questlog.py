"""Квесты: состояние персонажа и пакеты 09/xx.

Опкоды (порядок обработчиков в таблице клиента совпадает с подопкодами; 09/02 и
09/04 приходят при входе в мир в дампе оригинала):
  09/00 CQuestStartPacket    C->S взять квест (+0 eid, +4 квест BE)
                             S->C +0 eid BE, +4 квест BE, +12 код BE16 (0x51 = ок)
  09/01 CQuestRewardPacket   C->S сдать квест (+4 квест BE)
                             S->C +0 eid, +4 квест, +12 u32 BE, +16 код BE16 (0x51)
                             клиент сам пишет в чат награды из своей таблицы
  09/02 CQuestListPacket     S->C +0 eid, +4 число BE16, с +6 записи по 1044 байта:
                             квест LE32 + 20 блоков целей по 52 байта (как в quest.lod,
                             но на +8 блока — ТЕКУЩИЙ прогресс)
  09/03 CQuestPerformPacket  S->C +0 eid, +4 квест, +8 тип цели, +12 цель, +16 прогресс (BE)
  09/04 CQuestCompleteList   S->C +0 eid, +4 n1 BE16, +6 n2 BE16, затем n1 и n2 LE32 id
                             (второй список — выполненные квесты)
  09/05 CQuestGiveupPacket   C->S/S->C +0 eid, +4 квест
Типы целей: 1 убить, 3 собрать (предмет с моба aux), 8 поговорить, 9 отнести.
"""
import json, os, random, struct

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    QUESTS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'quests.json'),
                                                     encoding='utf-8')).items()}
except OSError:
    QUESTS = {}

OK = 0x51
KILL, COLLECT, TALK, DELIVER = 1, 3, 8, 9
COLLECT_CHANCE = 0.5          # шанс выпадения квестового предмета с нужного моба
ENTRY = 4 + 20 * 52
REPEAT = 3                    # вид квеста (quest.lod +8) «Повтор»: можно брать снова после сдачи


def repeatable(qid):
    return (QUESTS.get(qid) or {}).get('kind') == REPEAT


class QuestLog:
    def __init__(self, saved=None):
        saved = saved or {}
        # active: {qid: {obj_index: progress}}
        self.active = {int(q): {int(i): c for i, c in v.items()}
                       for q, v in saved.get('active', {}).items()}
        self.done = [int(q) for q in saved.get('done', [])]

    def to_saved(self):
        return {'active': {str(q): {str(i): c for i, c in v.items()} for q, v in self.active.items()},
                'done': self.done}

    # ---- действия ----
    def accept(self, qid):
        q = QUESTS.get(qid)
        if not q or qid in self.active or (qid in self.done and not repeatable(qid)):
            return False
        self.active[qid] = {o['i']: 0 for o in q['objectives']}
        return True

    def giveup(self, qid):
        return self.active.pop(qid, None) is not None

    def on_kill(self, npc_id, rng=random):
        """-> [(qid, obj, progress, loot_item or None)] изменения прогресса."""
        out = []
        for qid, prog in self.active.items():
            for o in QUESTS[qid]['objectives']:
                cur = prog.get(o['i'], 0)
                if cur >= o['count']:
                    continue
                if o['type'] == KILL and o['target'] == npc_id:
                    prog[o['i']] = cur + 1
                    out.append((qid, o, cur + 1, None))
                elif o['type'] == COLLECT and o['aux'] == npc_id and rng.random() < COLLECT_CHANCE:
                    # прогресс сбора считает сервер по сумке (quest_collect) и сам шлёт
                    # его клиенту; здесь только выпадение предмета
                    out.append((qid, o, cur, o['target']))
        return out

    def ready(self, qid):
        """Все цели убийства/сбора выполнены (разговор/доставка засчитываются у NPC)."""
        prog = self.active.get(qid)
        if prog is None:
            return False
        for o in QUESTS[qid]['objectives']:
            if o['type'] in (KILL, COLLECT) and prog.get(o['i'], 0) < o['count']:
                return False
        return True

    def complete(self, qid):
        """-> данные квеста (награды) или None. Клиент сам сверяет цели с
        quest.lod и шлёт 09/01 только для готового квеста, поэтому доверяем ему:
        серверный счёт мог не совпасть (разные id моба, квест взят до учёта)."""
        q = QUESTS.get(qid)
        if not q or (qid in self.done and not (repeatable(qid) and qid in self.active)):
            return None
        self.active.pop(qid, None)
        if qid not in self.done:
            self.done.append(qid)
        return q

    def on_client_progress(self, qid, obj_type, target, value):
        """09/03 от клиента (разговор/доставка) — записать прогресс."""
        prog = self.active.get(qid)
        if prog is None:
            return
        for o in QUESTS[qid]['objectives']:
            if o['type'] == obj_type and o['target'] == target:
                prog[o['i']] = max(prog.get(o['i'], 0), value)


# ---- пакеты ----
def build_start(eid, qid, code=OK):
    return struct.pack('>II', eid, qid) + bytes(4) + struct.pack('>H', code) + bytes(6)


def build_reward(eid, qid, code=OK):
    return struct.pack('>II', eid, qid) + bytes(4) + struct.pack('>I', 0) + struct.pack('>H', code) + bytes(6)


def build_perform(eid, qid, obj, progress):
    return struct.pack('>IIIII', eid, qid, obj['type'], obj['target'], progress) + bytes(4)


def build_giveup(eid, qid):
    return struct.pack('>II', eid, qid) + bytes(8)


def build_list(eid, log):
    body = b''
    n = 0
    for qid, prog in log.active.items():
        e = bytearray(ENTRY)
        struct.pack_into('<I', e, 0, qid)
        for o in QUESTS[qid]['objectives']:
            blk = bytearray(bytes.fromhex(o['block']))
            struct.pack_into('<i', blk, 8, prog.get(o['i'], 0))
            e[4 + o['i'] * 52:4 + o['i'] * 52 + 52] = blk
        body += bytes(e)
        n += 1
    return struct.pack('>IH', eid, n) + body


def build_complete_list(eid, log):
    """S 09/04. Клиент на каждый 09/04 очищает свой список выполненных (+0x700, AMo 0x006668e0) и
    заполняет заново, а квест из этого списка у NPC больше не предлагает. Повторяемые («Повтор») сюда
    не кладём — иначе билет Аски пропадал после первой сдачи; после их сдачи сервер шлёт 09/04 снова."""
    done = [q for q in log.done if not repeatable(q)]
    return (struct.pack('>IHH', eid, 0, len(done))
            + b''.join(struct.pack('<I', q) for q in done))


def parse_qid(payload):
    """C->S 09/00, 09/01, 09/05: +0 eid BE, +4 квест BE."""
    if len(payload) < 8:
        return None
    return struct.unpack_from('>I', payload, 4)[0]
