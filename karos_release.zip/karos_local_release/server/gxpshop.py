"""Внутриигровой магазин (кэш-шоп, окно 16034) за караты: товары GXP-магазина.

Таблица товаров клиента — Interface/IE_LOD/CashShop.lod_rus, у сервера — data/cashshop.json
(обе пишет tools/cashshop.py). Кнопка GXP в клиенте пропатчена (tools/patch_amo_shop.py)
и шлёт запрос, на который сервер открывает окно.

Товары — каталог сайта GameXP (data/gxp_catalog.tsv): наборы выдают всё содержимое, сундуки и
шкатулки — один случайный предмет из списка, как на сайте.

Протокол (обработчики AMo):
  C 06/39 (0x004aa37f) +0 eid, +4 u64 0, +12 u16: 2 — кнопка GXP (патч), 1 — «Отмена»/X; строка.
  S 06/39 (0x0065855b): +0 eid, +4 BE64 баланс, … до 22 байт, +22 строка (NUL) -> окно + баланс.
  C 06/31 (0x004d0792) +0 eid, +4 номер товара BE32, +8 u16 9, …  — купить.
  S 06/31 (0x00653f2c, кадр от 44 байт): +0 eid, +4 номер товара, +8 код BE16
     (0x2C «Вы приобрели %s за %d карат.», 0x0A «Недостаточно денег», 0x0B «Рюкзак заполнен»,
     0x2E «Этот предмет нельзя купить»), +10 BE64 новый баланс, +22 предмет (0 — цена из таблицы).
"""
import json, os, random, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OK, NO_MONEY, BAG_FULL, NOT_FOR_SALE = 0x2C, 0x0A, 0x0B, 0x2E
GOODS = {}


def load():
    GOODS.clear()
    try:
        t = json.load(open(os.path.join(ROOT, 'data', 'cashshop.json'), encoding='utf-8'))
    except OSError:
        return 0
    GOODS.update({int(k): v for k, v in t.items()})
    return len(GOODS)


def _bal(gold):
    return max(0, min(int(gold), 0x7fffffff))     # окно форматирует как int


def build_open(eid, gold):
    return struct.pack('>IQ', eid, _bal(gold)) + bytes(10) + b'\0'


def parse_buy(pl):
    """Номер товара из C 06/31 (+8); если там не товар — первое известное BE32 в пакете."""
    for off in (4, 8):                    # клиент: +0 eid, +4 номер товара, +8 u16 9
        if len(pl) >= off + 4:
            sid = struct.unpack_from('>I', pl, off)[0]
            if sid in GOODS:
                return sid
    for off in range(0, max(0, len(pl) - 3)):
        v = struct.unpack_from('>I', pl, off)[0]
        if v in GOODS:
            return v
    return None


def roll(g):
    """Что выдать за товар: [(предмет, кол-во)]. Блок A — все предметы, O — один случайный;
    кол-во «от X до Y» — случайное."""
    blocks = g.get('blocks') or [{'mode': 'A', 'items': [[g['item'], g['count'], g['count']]]}]
    out = []
    for b in blocks:
        its = b['items'] if b['mode'] == 'A' else [random.choice(b['items'])]
        out += [(i, random.randint(a, z)) for i, a, z in its]
    return out


def build_buy(eid, sid, code, gold):
    pl = bytearray(38)
    struct.pack_into('>IIH', pl, 0, eid, sid or 0, code)
    struct.pack_into('>Q', pl, 10, _bal(gold))
    return bytes(pl)


load()
