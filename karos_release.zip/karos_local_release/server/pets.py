"""Питомцы (категория 11) — по записям оригинала (docs/capture_orig_hl.md) и клиенту.

Запись питомца (LE, переменной длины из-за имени):
  +0 uid u32, +4 шаблон petBase u32 (10075 Мирик 2-й стадии, 10020 Мяут-вор 2-й стадии),
  +8 опыт u64 (внутри уровня), +16 уровень u16 (0..10), +18 u8 тип (0 не выбран, 1 чарователь,
  2 счастливчик, 3 помощник), +19 / +23 u32 общие навыки (900001, 6), +27 / +31 / +35 u32 навыки
  типа, +39 сытость u32, +43 u8 состояние (2 — высижен), +44 u32, +48 u8 (1 — активный),
  +49 f64 и +57 u32 (вид 8 в 11/0d — время), +65 u32 таблица petLevel (1), +69 имя utf-8\\0.
Пакеты:
  S 11/01 при входе — запись текущего питомца.
  C/S 11/00 (+0 NPC BE32, +4 страница, +8 0x01C9) -> S: NPC, число BE32, 0x01C9, 0, u16 число, записи.
  S 11/02: NPC, u8, u8, 0x01C9, запись — заменить запись (по uid) в списке клиента.
  C/S 11/03 (+0 NPC, +4 uid BE32, +8 0x01C9) — выбрать питомца (эхо).
  C/S 11/04 (+0 NPC, +4 uid, +8 0x01C9) — удалить питомца (эхо; CPetDelPacket).
  C/S 11/08 (+0 1 призвать / 0 отозвать, +1 0x01C9) — эхо; при призыве — 04/02 питомца.
  C/S 11/09 (+0 u8 тип, +1 0x01C9) — выбрать тип (CPetPropPacket); ответ — «Вы выбрали тип».
  C 11/0a (+0 контейнер, +1 ячейка, +2 0x01C9) — покормить -> S 11/0d (сытость), 11/0e, эхо.
  C 11/0c (+0 номер предмета на земле BE32, +4 0x01C9) — питомец подбирает.
  S 11/0d: uid BE32, вид u8, i64 значение, i64 прибавка (виды — у build_exp).
  S 11/0e: сущность питомца BE32, 0 BE32, состояние u8.
  C/S 11/0f (NPC, uid, 0x01C9) — воскресить (CPetRevivalPacket), 11/10 (NPC, 0x01C9, 0) — купить
  слот (CPetBuyPetSlotPacket), 11/11 (NPC, uid, 0x01C9) — тренировка (CPetUpgradePacket).
Появление питомца — 04/02 вида 1 (data/pet_templates.json, запись 23:49): +2 id сущности,
+6 позиция, +22/+26 HP, +50 уровень, +0x40 npc (стадия вида), +241 eid владельца, +254 имя.
"""
import json, os, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CODE = 0x01C9
PET_EID_BASE = 0x4B00
try:
    TPL = bytes.fromhex(json.load(open(os.path.join(ROOT, 'data', 'pet_templates.json')))['pet_0402'])
    TEMPLATE_REC = bytes.fromhex(json.load(open(os.path.join(ROOT, 'data', 'pet_templates.json')))['pet_rec'])
except (OSError, ValueError, KeyError):
    TPL = TEMPLATE_REC = None
_STAGES = None

# Рост — по таблицам клиента (tools/pet_tables.py -> data/pets.json):
#   уровни 0..10, опыт до следующего — petLevel; на ур.3, 6, 9 опыт копится до порога и ждёт
#   тренировки (11/11) за TRAIN_COST карат (цены зашиты в клиенте, AMo 0x0055ebb0);
#   стадия (шаблон petBase, его NPC) меняется на ур.4 и 10 — по цепочке «следующая стадия»;
#   навыки: общие (ур.1 — 900001, ур.4 — 6) в +19/+23, навык типа — последний из столбца типа
#   в +27 (у счастливчика ур.6 из записи — только 900011). Тип (+18): 1 чарователь (атака %),
#   2 счастливчик (шанс выпадения и крита), 3 помощник (продажа вещей) — выбор 11/09.
try:
    _PT = json.load(open(os.path.join(ROOT, 'data', 'pets.json'), encoding='utf-8'))
except (OSError, ValueError):
    _PT = {'base': {}, 'levels': []}
BASE = {int(k): v for k, v in _PT['base'].items()}
LEVELS = {r['level']: r for r in _PT['levels']}
PREV = {v['next']: k for k, v in BASE.items() if v.get('next')}
CAPSULE = {v['capsule']: k for k, v in BASE.items() if v.get('capsule')}
MAX_LEVEL = max(LEVELS) if LEVELS else 10
TRAIN_COST = {3: 1000, 6: 10000, 9: 100000}
TYPE_NAMES = {1: 'чарователь', 2: 'счастливчик', 3: 'помощник'}

# Корм, голод, смерть, воскрешение, слоты, продажа помощником:
#   корм — по стадии (сообщение клиента 0x7cdf «должен соответствовать стадии»): записи Genesis —
#     ур.4 «Живительный яблочный пирог» 394 -> 800, ур.10 «Особый такояки» 716 -> 1200, т.е.
#     кормление заполняет сытость до предела стадии (petLevel +18);
#   голод — запись оригинала Pers4x: 11/0d вид 4 «720, −40» за ~23 мин призыва (шаг −40; интервал
#     в записи не меньше ~1375 с — берём 30 мин призванного времени);
#   смерть — клиент (0x0055c425): сытость (+39) <= 0 при уровне > 0 -> «Питомец мертв.»;
#   воскрешение 11/0f — цена в клиенте (0x0056281c): по ступени уровня 0x0055e79b
#     (1–3 -> 50 000, 4–9 -> 100 000, 10 -> 200 000 карат);
#   слоты 11/10 — 200 000 карат (строка 0x7cd3), не больше 5 (клиент 0x00562a11); запись Genesis:
#     список с 1 слотом, после покупки ответ «…, 2»;
#   продажа 11/0b — «Приказав питомцу продавать предметы, вы не сможете использовать его 30 минут»
#     (0x7cb2); число ячеек — стат 70 навыка помощника (900016/17/18: 6/12/18 = 1–3 страницы окна).
FOOD = {200007: 0, 200008: 1, 200009: 2}          # корм -> стадия
HUNGER_STEP = 40
HUNGER_EVERY = 1800.0
SLOT_COST = 200000
MAX_SLOTS = 5
DEFAULT_SLOTS = 1
SELL_AWAY = 1800.0
SELL_STAT = 70
# коды ответа (клиент 0x00644745): 0x1ca нет слотов, 0x1cc «питомец продаёт предметы»,
# 0x1d0 уже призван, 0x1d1 нельзя призвать, 0x1d2 «Питомец мертв.»
E_NO_SLOT, E_SELLING, E_SUMMONED, E_CANT_SUMMON, E_DEAD = 0x1ca, 0x1cc, 0x1d0, 0x1d1, 0x1d2
E_NOT_PET_ITEM, E_BAD_NAME, E_NOT_EGG, E_HATCH_ALIVE = 0x1cb, 0x1ce, 0x1cf, 0x1d3
# Высиживание и имя (запись Genesis huge_genesis_pack + клиент):
#   C 11/02 npc, сумка, ячейка, код — капсула у Мелисы -> S 11/02 (то же + запись яйца: ур.0,
#     опыт = порог ур.0 «готов к высиживанию», +43 = 0);
#   C 11/06 код, npc, uid, флаг, имя — 1 начать / 0 отменить высиживание; ответ — эхо, затем
#     11/0d вид 0 (+43 = 1, +44 = 900 с); по истечении — вид 5 (клиент: «Питомец [%s] высижен…»);
#   C 11/05 код, имя — проверка имени -> код (0x1ce «имя занято или не по правилам»), имя;
#   C 11/07 код, npc, сумка, ячейка (билет: подтип 0x31 регистрации / 0x32 смены), uid,
#     флаг (1 регистрация / 0 смена), имя -> ответ (u32 — сущность питомца для имени над ним).
HATCH_SECS = 900
NAME_TICKET = {1: 200010, 0: 200011}        # флаг 11/07 -> билет
# Смена облика (запись Genesis huge_genesis_pack_1 + клиент):
#   предмет «Изменение внешности питомца» 500200074 (окно «Билет на изменение внешнего вида
#   питомца», строка 31784) — клиент сразу шлёт C 11/12 (u32 0, код);
#   S 11/12 (CPetChangeListPacket, 0x00669c17): u32 BE число (<= 5), код, записи питомцев;
#   облики клиент берёт из petBase (0x0055ad63): не текущий, +28 != 0, капсулы нет, и
#   «следующая стадия» есть у текущего — значит и у облика (2-я стадия к 2-й, 3-я к 3-й);
#   C 11/13 (0x0065ff86): u8 сумка, u8 ячейка билета, u32 BE uid, u32 BE облик (шаблон petBase),
#   код -> эхо с кодом. Клиент по ответу ничего не меняет — сервер шлёт запись 11/02 и трату
#   билета. Genesis все 6 попыток отклонил (0x1ce + 0b/01 «Такой облик выбрать нельзя.»),
#   удачного ответа в записях нет — успех собран по логике клиента.
LOOK_TICKET = 500200074


def look_ok(cur, target):
    """Можно ли питомцу с шаблоном cur принять облик target (как фильтр окна клиента)."""
    b, t = BASE.get(cur), BASE.get(target)
    if not b or not t or cur == target or b.get('capsule') or t.get('capsule') or not t.get('later'):
        return False
    return bool(b.get('next')) == bool(t.get('next'))


def build_look_list(pets_):
    """S 11/12: число, код, записи (не больше 5)."""
    pets_ = pets_[:5]
    return struct.pack('>IH', len(pets_), CODE) + b''.join(bytes(p.raw) for p in pets_)


def name_ok(name):
    """Правила клиента: 4–12 символов (0x7ccf), без латиницы (0x7cd0) и цифр (0x7cd1)."""
    if not 4 <= len(name) <= 12:
        return False
    for ch in name:
        if ch.isdigit() or ('a' <= ch.lower() <= 'z') or ch.isspace() or ord(ch) < 32:
            return False
    return True


def grade(level):
    """Ступень уровня (клиент 0x0055e79b): 0 -> 0, 1–3 -> 1, 4–6 -> 2, 7–9 -> 3, 10 -> 4."""
    if level == 0:
        return 0
    if 1 <= level <= 3:
        return 1
    if 4 <= level <= 6:
        return 2
    if 7 <= level <= 9:
        return 3
    return 4 if level == 10 else -1


def revive_cost(level):
    return {1: 50000, 2: 100000, 3: 100000, 4: 200000}.get(grade(level), 0)


def stages(npc_info):
    """имя вида -> [npc стадии 1, 2, 3] (npcInfo 11000001..11000999)."""
    global _STAGES
    if _STAGES is None:
        _STAGES = {}
        for k in sorted(npc_info):
            if 11000000 <= k < 11001000:
                _STAGES.setdefault(npc_info[k]['name'], []).append(k)
    return _STAGES


def root_template(tid):
    seen = set()
    while tid in PREV and tid not in seen:
        seen.add(tid)
        tid = PREV[tid]
    return tid


def stage_of(level):
    return 0 if level < 4 else (1 if level < 10 else 2)


def stage_template(tid, level):
    t = root_template(tid)
    for _ in range(stage_of(level)):
        n = BASE.get(t, {}).get('next')
        if not n:
            break
        t = n
    return t


def skills_for(level, ptype):
    """-> (общие навыки [до 2], навык типа или 0) на уровне."""
    common = [LEVELS[l]['skill'] for l in sorted(LEVELS) if 1 <= l <= level and LEVELS[l]['skill']][:2]
    typed = 0
    if 1 <= ptype <= 3:
        for l in sorted(LEVELS):
            if l <= level and LEVELS[l]['types'][ptype - 1]:
                typed = LEVELS[l]['types'][ptype - 1]
    return common, typed


def exp_to_next(level):
    """Опыт до следующего уровня (petLevel); 0 — предел."""
    r = LEVELS.get(level)
    if r is None:
        return 50000 * max(1, level)
    return r['exp']


def kill_exp(level):
    """Опыт питомцу за убийство моба — по уровню питомца, не по мобу: запись оригинала Pers4x —
    Мирик ур.5 получал ровно 249 за каждого из 4 разных мобов (64 раза, опыт хозяина 4116–5480);
    в petLevel у ур.5 поле +6 = 250 (50, 90, 130 … 410 — +40 за уровень). Берём поле +6 − 1
    (оригинал, видимо, округлял вниз); точка оригинала одна — на других уровнях это вывод."""
    r = LEVELS.get(level)
    return max(1, r['x'] - 1) if r and r['x'] else 0


def sat_cap(level):
    r = LEVELS.get(level)
    return r['sat'] if r and r['sat'] else 1000


def species_root(name, npc_info):
    """Шаблон первой стадии вида по имени (npcInfo) — для капсул и питомцев старого формата."""
    for tid, b in sorted(BASE.items()):
        if b.get('capsule') and npc_info.get(b['npc'], {}).get('name') == name:
            return tid
    return None


class Pet:
    def __init__(self, raw):
        self.raw = bytearray(raw)

    @property
    def uid(self):
        return struct.unpack_from('<I', self.raw, 0)[0]

    @property
    def template(self):
        return struct.unpack_from('<I', self.raw, 4)[0]

    @property
    def level(self):
        return struct.unpack_from('<H', self.raw, 16)[0]

    @property
    def exp(self):
        return struct.unpack_from('<Q', self.raw, 8)[0]

    @property
    def ptype(self):
        return self.raw[18]

    @property
    def satiety(self):
        return struct.unpack_from('<I', self.raw, 39)[0]

    @property
    def name(self):
        e = self.raw.find(b'\0', 69) if len(self.raw) > 69 else -1
        tail = self.raw[69:e] if e > 0 else b''
        try:
            return tail.decode('utf-8')
        except UnicodeDecodeError:
            return ''

    def skills(self):
        return [x for x in struct.unpack_from('<5I', self.raw, 19) if x]

    def needs_training(self):
        thr = exp_to_next(self.level)
        return bool(self.level in TRAIN_COST and thr and self.exp >= thr)

    def normalize(self, root=None):
        """Уровень, опыт, стадия и навыки — по таблицам. root — шаблон первой стадии вида
        (у питомцев старого формата шаблон был общий). -> True, если запись изменилась."""
        before = bytes(self.raw)
        if LEVELS:
            lv = max(0, min(MAX_LEVEL, self.level))
            thr = exp_to_next(lv)
            e = self.exp
            if lv in TRAIN_COST or lv == 0:
                e = min(e, thr)
            elif thr and e >= thr:
                e = thr - 1
            if not thr:
                e = 0
            struct.pack_into('<H', self.raw, 16, lv)
            struct.pack_into('<Q', self.raw, 8, e)
        if BASE:
            t = root if root in BASE else self.template
            if t in BASE:
                struct.pack_into('<I', self.raw, 4, stage_template(t, self.level))
        if LEVELS:
            common, typed = skills_for(self.level, self.ptype)
            common = (common + [0, 0])[:2]
            struct.pack_into('<5I', self.raw, 19, common[0], common[1], typed, 0, 0)
            struct.pack_into('<I', self.raw, 39, min(self.satiety, sat_cap(self.level)))
        return bytes(self.raw) != before

    def add_exp(self, n):
        """Опыт; рост сам по себе, кроме ур.0 (высиживание) и 3/6/9 (опыт — до порога,
        дальше тренировка). -> список новых уровней."""
        e = self.exp + int(n)
        lv = self.level
        ups = []
        while lv < MAX_LEVEL and lv not in TRAIN_COST and lv != 0:
            thr = exp_to_next(lv)
            if not thr or e < thr:
                break
            e -= thr
            lv += 1
            ups.append(lv)
        thr = exp_to_next(lv)
        if lv in TRAIN_COST or lv == 0:
            e = min(e, thr)
        if lv >= MAX_LEVEL or not thr:
            e = 0
        struct.pack_into('<Q', self.raw, 8, e)
        struct.pack_into('<H', self.raw, 16, lv)
        if ups:
            self.normalize()
        return ups

    def train(self):
        """Тренировка на ур.3/6/9 при полном опыте -> новый уровень (стадия и навыки — по нему)."""
        struct.pack_into('<H', self.raw, 16, self.level + 1)
        struct.pack_into('<Q', self.raw, 8, 0)
        self.normalize()
        return self.level

    def set_type(self, t):
        self.raw[18] = t
        self.normalize()

    def feed(self, n=None, cap=None):
        """Корм заполняет сытость до предела стадии (n — прибавка вместо этого)."""
        cap = cap or sat_cap(self.level)
        v = cap if n is None else max(0, min(cap, self.satiety + n))
        struct.pack_into('<I', self.raw, 39, v)
        return v

    def food_ok(self, item):
        return FOOD.get(item) == stage_of(self.level)

    def dead(self):
        return self.level > 0 and self.satiety <= 0

    @property
    def egg(self):
        return self.level == 0

    @property
    def state(self):
        return self.raw[43]

    def set_state(self, st, secs=0):
        self.raw[43] = st
        struct.pack_into('<I', self.raw, 44, secs)

    def set_name(self, name):
        self.raw = bytearray(self.raw[:69]) + name.encode('utf-8')[:30] + bytes(1)

    def hatch(self):
        """Яйцо -> ур.1: высижен (+43 = 2), полная сытость, навыки — по таблице."""
        struct.pack_into('<H', self.raw, 16, 1)
        self.set_state(2)
        self.normalize()
        struct.pack_into('<I', self.raw, 39, sat_cap(1))
        return self

    def set_template(self, tid):
        struct.pack_into('<I', self.raw, 4, tid)

    def hunger(self, n=HUNGER_STEP):
        """Голод: −n сытости. -> новое значение."""
        v = max(0, self.satiety - n)
        struct.pack_into('<I', self.raw, 39, v)
        return v

    def npc(self, npc_info):
        b = BASE.get(self.template)
        if b:
            return b['npc']
        ids = stages(npc_info).get(self.name) or []
        if not ids:
            return 11000053
        return ids[min(stage_of(self.level), len(ids) - 1)]


def parse_list(payload):
    """S 11/00 -> [сырые записи]. Запись: 69 байт полей + имя\\0."""
    n = struct.unpack_from('>H', payload, 12)[0] if len(payload) >= 14 else 0
    out, o = [], 14
    for _ in range(n):
        e = payload.index(b'\0', o + 69)
        out.append(payload[o:e + 1])
        o = e + 1
    return out


def build_list(npc, pets, slots=None):
    """S 11/00 (клиент 0x0066783e): npc, число записей (<= 5), код, число слотов (окно +0x460)."""
    slots = max(len(pets), slots or 0, DEFAULT_SLOTS)
    out = bytearray(struct.pack('>IIHI', npc, len(pets), CODE, slots))
    for p in pets:
        out += p.raw
    return bytes(out)


def build_exp(pet, kind, value, gain):
    """S 11/0d: uid, вид, i64 значение, i64 прибавка. Виды (клиент 0x005605c4): 0 состояние
    (+43, +44), 1 опыт, 2 уровень (значение — сущность питомца, прибавка — уровень; сообщение
    «улучшен до уровня»), 3 тип (+18), 4 сытость, 5 «высижен», 6 / 7 новый навык (общий /
    типа; сообщение «Вы изучили навык»), 8 время."""
    return struct.pack('>IBqq', pet.uid, kind, int(value), int(gain))


def build_record(pet, npc=0, bag=0, slot=0, code=None):
    """S 11/02: NPC, сумка, ячейка (капсулы), код, запись (69 байт + имя) — клиент заменяет
    запись по uid (0x00561131 -> 0x0055ea69); при коде не 0x1c9 — сообщение об ошибке."""
    return struct.pack('>IBBH', npc, bag, slot, CODE if code is None else code) + \
        (bytes(pet.raw) if pet else bytes(70))


def build_slots(pl, slots):
    """S 11/10 (0x0055e44e): u32 (как в запросе), код, u32 — число слотов."""
    return bytes(pl[:4]).ljust(4, b'\0') + struct.pack('>HI', CODE, slots)


def build_sold(gold, code=None):
    """S 11/0b (0x0055b3ec): код, u32 выручка («Вы заработали [%d]»), u32, u8 0."""
    return struct.pack('>HIIB', CODE if code is None else code, int(gold), 0, 0)


def build_state(ent, state):
    return struct.pack('>IIB', ent, 0, state)


def build_spawn(pet, ent, owner_eid, x, y, z, npc_info):
    if TPL is None:
        return None
    pl = bytearray(TPL[:254])
    struct.pack_into('<I', pl, 2, ent)
    struct.pack_into('<3f', pl, 6, x, y, z)
    struct.pack_into('<I', pl, 22, 50)
    struct.pack_into('<I', pl, 26, 50)
    struct.pack_into('<H', pl, 50, pet.level)
    struct.pack_into('<I', pl, 0x40, pet.npc(npc_info))
    struct.pack_into('<I', pl, 241, owner_eid)
    name = pet.name.encode('utf-8')
    pl[253] = len(pet.name)
    return bytes(pl) + name + b'\0'


def new_egg(species, uid, template=None):
    """Яйцо из капсулы (11/02 у Мелисы): ур.0, опыт — порог ур.0 (готово к высиживанию),
    сытость 0, +43 = 0. Имя — вид (клиенту нужно непустое имя для 11/06)."""
    pet = new_pet(species, uid, template)
    struct.pack_into('<H', pet.raw, 16, 0)
    struct.pack_into('<Q', pet.raw, 8, exp_to_next(0))
    struct.pack_into('<5I', pet.raw, 19, 0, 0, 0, 0, 0)
    struct.pack_into('<I', pet.raw, 39, 0)
    pet.set_state(0)
    pet.normalize()
    return pet


def new_pet(species, uid, template=None):
    """Новый питомец ур.1 (регистрация из капсулы; высиживание с ур.0 не сделано): запись-образец
    Мяута-вора оригинала, шаблон вида — по капсуле (petBase +8), тип не выбран, сытость полная."""
    raw = bytearray(TEMPLATE_REC[:69])
    struct.pack_into('<I', raw, 0, uid)
    if template:
        struct.pack_into('<I', raw, 4, template)
    struct.pack_into('<Q', raw, 8, 0)
    struct.pack_into('<H', raw, 16, 1)
    raw[18] = 0
    struct.pack_into('<I', raw, 39, sat_cap(1))
    raw[43] = 2                                      # высижен
    pet = Pet(bytes(raw) + species.encode('utf-8') + bytes(1))
    pet.normalize()
    return pet
