"""Персонаж: сборка пакетов появления и карточки с НУЛЯ (без реплея).

Раскладка 04/02 маркер 01 00 (появление персонажа, 273 байта):
  +0   01 00        маркер «персонаж»
  +2   entity LE32
  +6   x, y, z      float
  +18  угол         float
  +22  HP, +26 maxHP, +30 MP, +34 maxMP   (LE32)
  +50  2621442      флаги/класс
  +250 длина имени (u8, после трёх нулей)
  +254 ИМЯ UTF-8 + 0x00
Найдено сверкой с дампом: имя игрока лежит на +254 в UTF-8.
"""
import struct


class Character:
    def __init__(self, eid, name='Hero', x=9775.0, y=8124.8, z=672.7,
                 hp=186, maxhp=186, mp=100, maxmp=100, level=1):
        self.eid = eid
        self.name = name
        self.x, self.y, self.z = x, y, z
        self.angle = 0.0
        self.hp, self.maxhp = hp, maxhp
        self.mp, self.maxmp = mp, maxmp
        self.level = level

    def build_appear(self, template):
        """04/02 появление персонажа: шаблон-несущая + НАШИ поля, включая имя."""
        pl = bytearray(template)
        pl[0], pl[1] = 0x01, 0x00
        struct.pack_into('<I', pl, 2, self.eid)
        struct.pack_into('<3f', pl, 6, self.x, self.y, self.z)
        struct.pack_into('<f', pl, 18, self.angle)
        for off, v in ((22, self.hp), (26, self.maxhp),
                       (30, self.mp), (34, self.maxmp)):
            struct.pack_into('<I', pl, off, int(v))
        # ★ уровень+опыт @+50 (u32le): ИМЕННО отсюда клиент берёт уровень
        # В МИРЕ (не из 02/05/08/01!). Без этого показывался ур.2 из шаблона.
        struct.pack_into('<I', pl, 50, self.level & 0xffff)
        self._write_name(pl)
        return bytes(pl)

    def _write_name(self, pl):
        """имя: [u8 длина] на +253, UTF-8 с +254, затем 0x00.

        Пакет ПЕРЕМЕННОЙ длины — хвост под имя обрезается/расширяется.
        В шаблоне под имя ~19 байт, а кириллица в UTF-8 занимает по 2 байта
        на символ, поэтому длинные имена не влезали."""
        raw = self.name.encode('utf-8')[:60]
        del pl[253:]                       # отрезаем старый хвост с именем
        pl.append(len(raw))                # длина имени
        pl.extend(raw)                     # само имя
        pl.append(0)                       # завершающий ноль

    NAME_OFF = 385          # имя в карточке (u32 на символ)
    NAME_LEN_OFF = 383      # длина имени

    def build_card(self, template):
        """02/01 карточка на экране выбора персонажа.

        Раскладка (дамп play1): +1 entity BE32, +383 длина имени,
        +385 имя ПО ОДНОМУ СИМВОЛУ В u32 LE (как в 02/02 создания).
        Пакет переменной длины: хвост с именем пересобирается."""
        pl = bytearray(template)
        struct.pack_into('>I', pl, 1, self.eid)
        # уровень+опыт упакованы в u32le @+49 (низ 16б — уровень, верх — опыт).
        # Для нового персонажа = level (опыт 0). ВАЖНО: должно совпадать с
        # уровнем в 02/05 (+44) и 08/01 (+37), иначе клиент не входит в мир.
        struct.pack_into('<I', pl, 49, self.level & 0xffff)
        for off, v in ((21, self.hp), (29, self.mp)):
            if off < len(pl):
                pl[off] = min(255, int(v))
        chars = self.name[:20]
        # ХВОСТ после имени сохраняем: в шаблоне за именем ещё 4 байта,
        # без них клиент не принимает карточку и виснет на выборе персонажа
        old_len = template[self.NAME_LEN_OFF]
        tail = bytes(template[self.NAME_OFF + old_len * 4:])
        del pl[self.NAME_LEN_OFF:]
        pl.append(len(chars))               # +383 длина
        pl.append(0)                        # +384
        for ch in chars:                    # +385 символы по u32
            pl.extend(struct.pack('<I', ord(ch)))
        pl.extend(tail)                     # хвост на место
        return bytes(pl)


def parse_create(payload):
    """02/02 создание персонажа -> имя, введённое ИГРОКОМ.

    Раскладка (дамп play1): +13 длина имени (u8), с +15 по одному символу
    в u32 LE. Поддерживает кириллицу: коды 1092,1074 = 'фв'.
    """
    if len(payload) < 16:
        return None
    n = payload[13]
    if not (1 <= n <= 24):
        return None
    chars = []
    for i in range(n):
        o = 15 + i * 4
        if o + 4 > len(payload):
            break
        c = struct.unpack_from('<I', payload, o)[0]
        if 0 < c < 0x110000:
            chars.append(chr(c))
    return ''.join(chars) or None


def parse_name(payload):
    """достать имя из 04/02 персонажа"""
    if len(payload) < 255:
        return None
    n = payload[253]
    if 0 < n < 40 and 254 + n <= len(payload):
        return payload[254:254 + n].decode('utf-8', errors='replace')
    return None


if __name__ == '__main__':
    import json, os
    SRV = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    core = json.load(open(os.path.join(SRV, 'world_core.json')))
    tpl = None
    for h in core:
        b = bytes.fromhex(h)
        if (b[0], b[1]) == (0x04, 0x02) and b[6] == 1 and b[7] == 0:
            tpl = b[6:]
            break
    print(f"шаблон появления персонажа: {len(tpl) if tpl else 0} байт")
    if tpl:
        print(f"имя в шаблоне: {parse_name(tpl)!r}")
        for nm in ('Hero', 'Тестовый', 'MyChar'):
            c = Character(0x2892, name=nm)
            out = c.build_appear(tpl)
            print(f"  собрали '{nm}' -> прочитали {parse_name(out)!r}  "
                  f"длина {len(out)} (было {len(tpl)})")
