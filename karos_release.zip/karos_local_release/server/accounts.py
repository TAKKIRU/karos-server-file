"""Хранилище персонажей аккаунта — как в оригинале.

На чистом аккаунте персонажей НЕТ: клиент показывает окно создания,
после создания — список, затем вход в мир. Раньше сервер всегда слал
две карточки из дампа — это был костыль (§117).

Персистентность: JSON рядом с сервером, чтобы персонажи не пропадали
между запусками.
"""
import json, os, struct

STORE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'accounts.json')
STARTERS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'starter_accounts.json')
BASE_EID = 0x2892          # entity первого персонажа (как в дампе)


class Account:
    def __init__(self, account_id='default'):
        self.id = account_id
        self.chars = []          # [{'slot','eid','name','level','hp','mp'}]
        self.stash = {}          # общее хранилище аккаунта {ячейка: [item, кол-во]}
        self._load()

    def _load(self):
        if not os.path.exists(STORE) and os.path.exists(STARTERS):
            # первый запуск сборки: стартовые персонажи (tools/make_release.py -> starter_accounts.json)
            try:
                data = json.load(open(STARTERS, encoding='utf-8'))
                json.dump(data, open(STORE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
            except (ValueError, OSError):
                pass
        if os.path.exists(STORE):
            try:
                data = json.load(open(STORE, encoding='utf-8'))
                self.chars = data.get(self.id, [])
                self.stash = data.get(self.id + ':stash', {})
            except (ValueError, OSError):
                self.chars = []

    def save(self):
        data = {}
        if os.path.exists(STORE):
            try:
                data = json.load(open(STORE, encoding='utf-8'))
            except (ValueError, OSError):
                data = {}
        data[self.id] = self.chars
        data[self.id + ':stash'] = self.stash
        json.dump(data, open(STORE, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)

    def create(self, name, level=1, hp=186, mp=100, cls=600):
        slot = len(self.chars)
        # eid должен быть УНИКАЛЕН. Раньше было BASE_EID+slot, но после
        # удаления слоты пересчитываются, и новый перс мог получить eid уже
        # живого персонажа -> путаница при выборе/входе. Берём max+1.
        used = {c['eid'] for c in self.chars}
        eid = max(used | {BASE_EID - 1}) + 1
        ch = {'slot': slot, 'eid': eid, 'name': name, 'cls': cls,
              'level': level, 'exp': 0, 'hp': hp, 'mp': mp}
        self.chars.append(ch)
        self.save()
        return ch

    def delete(self, eid):
        before = len(self.chars)
        self.chars = [c for c in self.chars if c['eid'] != eid]
        for i, c in enumerate(self.chars):       # пересчёт слотов
            c['slot'] = i
        self.save()
        return len(self.chars) < before

    def get(self, eid=None):
        if eid is None:
            return self.chars[0] if self.chars else None
        for c in self.chars:
            if c['eid'] == eid:
                return c
        return None

    def reset(self):
        self.chars = []
        self.save()


if __name__ == '__main__':
    import sys
    a = Account()
    if '--reset' in sys.argv:
        a.reset()
        print("список персонажей очищен")
    print(f"персонажей на аккаунте: {len(a.chars)}")
    for c in a.chars:
        print(f"   слот {c['slot']}: {c['name']!r} eid={c['eid']} ур.{c['level']}")
    if not a.chars:
        print("   (пусто — клиент покажет окно создания)")
