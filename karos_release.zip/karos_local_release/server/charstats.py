"""Боевые характеристики персонажа — как у клиента и сервера оригинала.

Окно «Персонаж» (клиент 0x0049b2cc, docs/stats.md) считает атаку так:
  t    = 08/02 блок+116 (прибавка атаки) + Σ атаки надетого в слотах 7 (оружие), 10, 17 (крылья)
         по ЗАТОЧКЕ вещи (itemAttr, data/item_stats_enchant.json) + плоские опции вещей;
  мин. = (t + блок+52 − плоские опции) × (1 + 08/02 +272 + 08/02 +280)      «295 (+228)»
  в скобках — t × множитель. Магия: блок+124, маг. атака вещей, блок+80, +272 и +284.
Сервер оригинала кладёт плоские «Сила физ. атаки» вещей в блок+52 (Pers4x: без вставки 73.5,
с ней 105.5), проценты — в +280/+284 (долей: 0.05 = 5%), заточку надетого клиент узнаёт из
06/00 +11 и массивов облика (02/05 +247, 04/02 +192, карточка +252 — по байту на слот).
Окно оригинала Pers4x: (105.5 + 290.52 + 40.5) × 1.05 = 458 … 564 — совпадает до единицы.

Урон по мобу (записи оригинала, docs/stats.md): обычный удар ≈ атака окна (канонир ×1.3), крит —
× «урон от крита» (блок+100: 1.2 у бродяги, 1.25 у снайпера + опции), шанс — блок+132 (%).
Навык — атака × множитель навыка + прибавка навыка (data/skill_dmg.json).
"""
import json, os, random, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ATK_SLOTS = (7, 10, 17)           # слоты, атаку которых клиент прибавляет в окне
DMG_K = 1.0                       # урон/атака окна: бродяга оригинала ≈1.0 (обычный 141–200 при окне
                                  # 150–172; навык 5104 ур.5: 0.9×161+81 = 226, в записи 224)
CLASS_K = {800: 1.3}              # канонир: подгонка. У оригинала урон = (1 + % атаки) × (атака × множитель навыка
                                  # + прибавка + рейтинг атаки − защита моба); защиты мобов в таблицах нет —
                                  # docs/damage_original.md
# Канонир по мобам выше себя (запись: 62 ур. против 64–69): обычный удар 1,11 окна, от разницы уровней
# не зависит — а прежние −4% за уровень давали до −15% к оригиналу.
CLASS_ABOVE = {800: 1.11}
SPLIT_ROLL = (800,)               # оружие и крылья бросаются порознь, разброс не множится на CLASS_K
                                  # (запись: отклонение 19,4; общий бросок × 1,3 давал бы 37)
# Флетта 2/1 на 1600 очках -> навык 16121017 (fletaAttr: шанс 5%; skillLevel: прибавка 200–300, множитель
# 0,7, 10 с). Запись канонира: 30 срабатываний (5,7%), к удару +301 при (250 + 0,7 × рейтинг) = 311.
FLETA_PROC = {800: dict(sid=16121017, group=2, elem=1, points=1600, chance=5.0, lo=200.0, hi=300.0, mult=0.7, secs=10.0)}
MAGIC_CLASSES = (400, 600)        # чародейка, ведунья
DEX_CRIT = 0.432                  # % шанса крита за 1 ловкости (Pers4x: +45 ловкости, 12.97 -> 32.41)
STR_ATK = 0.8                     # физ. атака за 1 силы (Pers4x: +39 силы, 42.3 -> 73.5)
DEX_ATK = 1.0                     # бродяга/лучница: физ. атака за 1 ловкости (оценка)
CRIT_CAP = 75.0
ATTR_TYPES = (1, 3, 2, 5, 4)      # порядок атрибутов в 08/02 +8/+18: сила, ловкость, живучесть,
                                  # интеллект, мудрость (бродяга оригинала: 19, 29, 15, 14, 23)
# типы характеристик опций/вставок (tools/item_options.py): 1 сила, 3 ловкость, 6 сила физ.
# атаки, 8 сила маг. атаки, 11 шанс крита, 12 урон крита, 17 физ. защита, 19 маг. защита,
# 46/28 здоровье, 47 мана, 71 сила атаки (%), 73 физ. атака (%), 74 маг. атака (%),
# 206 чёрный череп (физ. атака), 207 белый череп (маг. атака)
T_STR, T_DEX, T_PATK, T_MATK, T_CRIT, T_CDMG = 1, 3, 6, 8, 11, 12
T_PDEF, T_MDEF, T_HP, T_HP2, T_MP = 17, 19, 46, 28, 47
T_ALL_PCT, T_PATK_PCT, T_MATK_PCT, T_SKULL_P, T_SKULL_M = 71, 73, 74, 206, 207


def _j(name):
    try:
        return json.load(open(os.path.join(ROOT, 'data', name), encoding='utf-8'))
    except (OSError, ValueError):
        return {}


ENCH = {int(k): {int(e): v for e, v in d.items()} for k, d in _j('item_stats_enchant.json').items()}
SKILL_DMG = {int(k): {int(l): v for l, v in d.items()} for k, d in _j('skill_dmg.json').items()}


def item_attr(item, enchant):
    """[14 чисел itemAttr] вещи на её заточке (нет точной — ближайшая меньшая)."""
    d = ENCH.get(item)
    if not d:
        return None
    if enchant in d:
        return d[enchant]
    lower = [e for e in d if e <= enchant]
    return d[max(lower)] if lower else d[min(d)]


# Изделия из флеттоцветов («Оружие/Доспехи из флеттоцветов», itemBase категория 4/5) своих
# характеристик не имеют: клиент (0x0062e29a -> 0x0062d726) подставляет вещь класса владельца —
# оружие (слот 7) или доспех того же слота: класс тот же, базовый (×100) или того же десятка,
# требуемый уровень < 111 и ближе всего к уровню персонажа (при равных — последняя в таблице) —
# и берёт её запись itemAttr со ступенью x = ступени изделия (x = 1..6 у заточки 1, 4, … 16).
# MAG (612, ур.61), ступень 6: «Могучий посох разрушения» на +16 — маг. атака 1455–1551
# (в окне клиента «около 1500»; сервер считал 0 — урон мага ~100).
FLETA_CATS = (4, 5)
_SUB = {}


def fleta_substitute(item, cls, level):
    """-> id вещи-образца для изделия из флеттоцветов или None (не изделие)."""
    try:
        import loot
    except ImportError:
        return None
    it = loot.ITEMS.get(item) or {}
    if it.get('kind') != 1 or it.get('cat') not in FLETA_CATS or it.get('cls'):
        return None
    slot = 7 if it['cat'] == 4 else it.get('slot', 1)
    key = (slot, int(cls), int(level))
    if key not in _SUB:
        c = int(cls)
        cand = [(i, v['lvl']) for i, v in loot.ITEMS.items()
                if i < 1000000 and v.get('kind') == 1 and v.get('slot') == slot and i in ENCH
                and v.get('lvl', 0) < 111
                and v.get('cls') and (v['cls'] == c or (v['cls'] % 100 == 0 and v['cls'] // 100 == c // 100)
                                      or (c % 100 == 0 and v['cls'] == c + 10)
                                      or (c % 10 > 0 and v['cls'] // 10 == c // 10))]
        cand.sort(key=lambda t: (abs(t[1] - int(level)), -t[0]))
        _SUB[key] = cand[0][0] if cand else None
    return _SUB[key]


def effective_attr(item, enchant, cls=None, level=None):
    """itemAttr вещи; изделие из флеттоцветов — по вещи-образцу на ступени (заточка 3·ступень − 2)."""
    if cls is not None and level is not None:
        sub = fleta_substitute(item, cls, level)
        if sub:
            st = max(1, min(6, int(enchant or 1)))
            return item_attr(sub, 3 * st - 2)
    return item_attr(item, enchant)


def gear(recs):
    """Надетые записи (контейнер 0) -> атака/защита вещей по заточке."""
    g = {'wmin': 0.0, 'wmax': 0.0, 'mwmin': 0.0, 'mwmax': 0.0, 'armor': 0.0}
    for r in recs:
        if r[0] != 0:
            continue
        v = item_attr(struct.unpack_from('<I', r, 2)[0], r[7])
        if not v:
            continue
        if r[1] in ATK_SLOTS:
            g['wmin'] += v[0]
            g['wmax'] += v[1]
            g['mwmin'] += v[2]
            g['mwmax'] += v[3]
        g['armor'] += v[6]
    return g


def bget(b, t, i=0):
    return b.get(t, [0.0, 0.0])[i]


def skill_dmg(sid, level):
    lv = SKILL_DMG.get(int(sid))
    if not lv:
        return None
    return lv.get(int(level)) or lv[max(l for l in lv if l <= max(level, min(lv)))]


def finish(stats, cls, blk116=0.0, blk124=0.0, crit=None, crit_dmg=None, opt=None):
    """Итог для окна и урона. stats.base_atk/base_matk — уже с плоскими опциями (блок+52/+80).
    opt — суммы опций надетого {тип: [плюс, %]} (полные, для процентов окна)."""
    opt = opt or {}
    stats.cls_base = (int(cls) // 100) * 100
    stats.magic = stats.cls_base in MAGIC_CLASSES
    stats.blk116, stats.blk124 = blk116, blk124
    stats.pct_all = bget(opt, T_ALL_PCT, 1) / 100
    stats.pct_phys = bget(opt, T_PATK_PCT, 1) / 100
    stats.pct_mag = bget(opt, T_MATK_PCT, 1) / 100
    mp = 1 + stats.pct_all + stats.pct_phys
    mm = 1 + stats.pct_all + stats.pct_mag
    stats.atk_min = (blk116 + stats.wmin + stats.base_atk) * mp
    stats.atk_max = (blk116 + stats.wmax + stats.base_atk) * mp
    stats.matk_min = (blk124 + stats.mwmin + stats.base_matk) * mm
    stats.matk_max = (blk124 + stats.mwmax + stats.base_matk) * mm
    base_crit = crit if crit is not None else 5.0
    stats.crit = min(CRIT_CAP, base_crit + bget(opt, T_CRIT, 0) + bget(opt, T_CRIT, 1))
    stats.crit_dmg = (crit_dmg if crit_dmg is not None else 1.2) + bget(opt, T_CDMG, 0) \
        + bget(opt, T_CDMG, 1) / 100
    stats.attack = (stats.atk_min + stats.atk_max) / 2
    return stats


def above_floor(cls_base):
    return CLASS_ABOVE.get(cls_base, 0.0) / CLASS_K.get(cls_base, 1.0)


def split_roll(stats, lo, hi, rng=random):
    """Бросок атаки из окна."""
    cls, parts = getattr(stats, 'cls_base', 0), getattr(stats, 'atk_parts', ())
    if cls not in SPLIT_ROLL or not parts or sum(parts) <= 0 or hi <= lo:
        return rng.uniform(lo, max(lo, hi))
    t = sum(rng.random() * w for w in parts) / sum(parts)
    mid, v = (lo + hi) / 2, lo + (hi - lo) * t
    return mid + (v - mid) / CLASS_K.get(cls, 1.0)


def fleta_proc(cls_base, fleta, rng=random):
    """Сработала ли флетта на этом ударе. -> описание FLETA_PROC или None."""
    p = FLETA_PROC.get(cls_base)
    if not p:
        return None
    elem, pts = (fleta or {}).get(p['group'], (0, 0))
    return p if elem == p['elem'] and pts >= p['points'] and rng.random() * 100 < p['chance'] else None


def proc_damage(stats, p, rng=random):
    """Прибавка урона срабатывания: от защиты моба не зависит, % атаки и крит действуют."""
    pct = getattr(stats, 'pct_all', 0.0) + getattr(stats, 'pct_phys', 0.0)
    return (rng.uniform(p['lo'], p['hi']) + p['mult'] * getattr(stats, 'acc', 0.0)) * (1 + pct)


def roll(stats, skill=None, rng=random):
    """-> (урон, крит?). skill = (множитель, мин., макс.) или None."""
    if getattr(stats, 'magic', False) and stats.matk_max > 0:
        lo, hi = stats.matk_min, stats.matk_max
    else:
        lo, hi = stats.atk_min, stats.atk_max
    base = split_roll(stats, lo, hi, rng)
    if skill:
        dmg = base * skill[0] + rng.uniform(skill[1], max(skill[1], skill[2]))
        dmg *= 1 + getattr(stats, 'skill_pow', 0.0) / 100     # «сила навыков» % (08/02 +324: крылья)
    else:
        dmg = base
    dmg *= DMG_K * CLASS_K.get(getattr(stats, 'cls_base', 0), 1.0)
    crit = rng.random() * 100 < getattr(stats, 'crit', 0)
    if crit:
        dmg *= getattr(stats, 'crit_dmg', 1.2)
    return dmg, crit
