"""Характеристики персонажа — как считает сервер оригинала (разбор записей, docs/stats.md).

08/02 несёт два блока по 380 байт: +32 — итог («A»), +412 — база («B»: уровень + атрибуты,
без вещей, пассивок и бафов). Атрибуты: +6 5×u16 своя база (сила, ловкость, живучесть,
интеллект, мудрость), +18 5×u16 прибавка (вещи, пассивки, флетта, бафы) — прибавка
входит и в B (сверено: +2 ловкости от навыка 5003 меняют B: уклон +0.1, крит +0.904 …).

База B (формулы подобраны по 15 состояниям 5 персонажей 4 классов; где «точно» —
расхождение 0 на всех точках):
  реген HP  5.4 + 0.85·ур + 0.75·жив        (точно)
  реген MP  −1.87 + 0.12·ур + 0.55·мудр      (точно)
  +24 дальность 10 (оружие заменяет своей, itemAttr[5]: ружьё 160)
  +28 коэф. уклонения 6.5 + 0.05·ловк       (точно)
  +32 шанс блока 8 + 0.1·ловк                 (точно; окно 0x0049b2cc читает именно +32)
  +40/+44 шаг/бег 45.2 / 65
  +56 скорость атаки 0.85 + 0.002·ловк        (точно; «кулак», оружие заменяет своей)
  +60 рейтинг атаки 4 + 0.5·ловк             (точно)
  +64 физ. защита 20.545 + 0.455·ур           (точно)
  +72 рейтинг защиты 0.35·ловк                (точно)
  +84 маг. рейтинг 2.25 + 0.25·ур + 0.475·инт (точно)
  +96 скорость навыка 100, +100 урон крита 1.2
  +104 2.0475 + 0.2275·ур + 0.6·жив           (точно)
  +132 шанс крита 2.02 + 0.06·ур + 0.452·ловк (точно)
  +80 маг. атака ≈ −10.14 + 0.308·ур + 2.84·инт, +88 маг. защита ≈ 17.78 + 0.197·ур + 0.123·инт,
  +92 ≈ 3.288 + 0.1226·ур + 0.1·мудр          (±0.7 — у импортированных поправка до точного)
  HP / MP / физ. атака зависят от класса: MP +10 за мудрость, атака +0.8 за силу (точно);
  остальное — по классу (паладин 200: ур.5 и Genesis ур.7–10), у импортированных —
  точная поправка по их 08/02.

Итог A = B, затем:
  оружие (слот 7): скорость атаки и дальность — свои (itemAttr[4], [5]);
  вещи по заточке: физ. защита itemAttr[6], маг. защита [7] (атаку оружия клиент прибавляет сам);
  эффекты (тип, значение, процент) пассивок (skillBase вид 0), стихий флетты, бафов,
  вставок (навык вставки, itemCombAttr +44) и особых характеристик:
    значение — прибавка к полю; процент у скорости атаки/бега/навыка, уклонения и блока —
    множитель на каждый эффект отдельно (руны 2×20% уклонения: ×1.44, навыки 5103 и 16001
    сверены по 10 шагам); процент у HP/MP — доля базы B (15004: +1% = 66.928 при B 6692.8);
    проценты атаки (71/73/74) — в +272/+280/+284 (клиент умножает окно сам).
"""
import json, os, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _j(name):
    try:
        return json.load(open(os.path.join(ROOT, 'data', name), encoding='utf-8'))
    except (OSError, ValueError):
        return {}


FX = _j('skill_effects.json')                    # tools/skill_effects.py
# пассивные камни супер-навыков (tools/super_table.py): эффект как у пассивного навыка ур.1
# камни «Усиление» (61xxxx, 62xxxx) — эффект бафа, пока действует баф супер-навыка (сервер вешает
# его с ключом −камень); «смертоносная атака» (6105xx): атака +n%, защита −n% (описание предмета)
for _k, _v in _j('super_skills.json').get('stones', {}).items():
    if _v.get('kind') == 5 and _v.get('eff') and _k not in FX:
        FX[_k] = {'k': 0, 'c': 0, 'lv': {'1': _v['eff']}}
    elif _v.get('kind') == 6 and _v.get('eff') and int(_k) // 10000 in (61, 62) and _k not in FX:
        _e = list(_v['eff'])
        if int(_k) // 100 == 6105:
            _e.append([17, 0.0, -_v['eff'][0][2]])
        FX[_k] = {'k': 23, 'c': 0, 'lv': {'1': _e}}
SOCK_SKILL = {int(k): v for k, v in _j('socket_skill.json').items()}
SOCK_INLINE = {int(k): v for k, v in _j('socket_attrs.json').items()}
OPTIONS = {int(k): v for k, v in _j('item_options.json').items()}
FLETA = _j('fleta.json')
EQUIP_SKILL = {int(k): {int(e): v for e, v in d.items()} for k, d in _j('item_equip_skill.json').items()}
ENCH = {int(k): {int(e): v for e, v in d.items()} for k, d in _j('item_stats_enchant.json').items()}

PASSIVE, ACTIVE, DEBUFF, BUFF = 0, 11, 13, 23
# виды навыков, чьи эффекты — не характеристики: 21 лечение % (зелья 99987/99988),
# 22 восстановление числом (6000019), 25 аура-«родитель» (её эффект — отдельный баф 300501…)
NOT_STAT = (11, 13, 21, 22, 25)
ATTR_OF = {1: 0, 81: 0, 3: 1, 2: 2, 100: 2, 5: 3, 101: 3, 4: 4, 102: 4}   # тип -> индекс атрибута
FIELDS = (0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84,
          88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132)
# тип эффекта -> поле блока (значение прибавляется; процент — доля базы)
FLAT = {6: 52, 7: 116, 8: 80, 9: 124, 10: 60, 11: 132, 12: 100, 16: 72, 17: 64, 18: 64,
        19: 88, 20: 88, 21: 28, 22: 32, 30: 4, 31: 16}
MULT = {13: (56,), 14: (96,), 21: (28,), 22: (32,), 27: (40, 44)}   # процент — множитель
# тип -> смещение 08/02 вне блоков (доли атаки — в долях, остальное — как есть)
PAY = {64: 248, 96: 292, 32: 304, 99: 304, 33: 316, 105: 316, 59: 228, 60: 228, 62: 240,
       82: 228, 65: 240, 108: 324, 128: 404}
PAY_FRAC = {71: 272, 73: 280, 74: 284}
P_HP, P_MP = 176, 180

# Класс: (HP: c0, за уровень; MP: c0, за уровень; атака: c0, за уровень) при формулах
# HP = c0 + k·ур + VIT_HP·жив, MP = c0 + k·ур + 10·мудр, атака = c0 + k·ур + 0.8·сила.
# 200 — точно по записи (ур.5: 396 / 123 / 12.9; Genesis ур.7–10: +56.33 HP, +8 MP, +0.25);
# прочие — рост по прежней таблице (progression), база как у 200.
VIT_HP = 50.0          # HP за 1 живучести — в записях нет ни одной вещи с живучестью (оценка)
_HP_L = {100: 60, 200: 56.33, 300: 46, 400: 42, 500: 36, 600: 34, 700: 46, 800: 46}
_MP_L = {100: 6, 200: 8, 300: 8, 400: 10, 500: 14, 600: 15, 700: 8, 800: 8}
_ATK_L = {100: 0.3, 200: 0.25, 300: 0.3, 400: 0.25, 500: 0.15, 600: 0.15, 700: 0.3, 800: 0.3}
# стартовые атрибуты (паладин 200 — точно по записи ур.5; прочие — по роли класса)
START_ATTR = {100: (10, 7, 10, 6, 7), 200: (9, 7, 10, 7, 7), 300: (8, 10, 8, 7, 7),
              400: (6, 7, 8, 10, 9), 500: (7, 10, 8, 7, 8), 600: (6, 7, 8, 10, 9),
              700: (8, 9, 8, 8, 7), 800: (9, 9, 8, 7, 7)}


def base_cls(cls):
    return (int(cls) // 100) * 100 if cls else 600


CLASS_INFO = _j('class_info.json')            # tools/class_table.py (classInfo, classRace)


def _cinfo(cls):
    return (CLASS_INFO.get('classes') or {}).get(str(int(cls)))


def class_attrs(cls, rank=0):
    """Своя база атрибутов по классу и рангу (classInfo / classRace, сверено с 08/02 оригинала):
    раса + прибавка базового класса + прибавка класса за каждую ступень classChange — смену класса
    (ур.10, 45) и повышение ранга (25/40, 60/75). Для второго класса ранги первого считаются
    пройденными (без них смену не дают). Нет данных — None."""
    b = base_cls(cls)
    ci = _cinfo(b)
    race = (CLASS_INFO.get('races') or {}).get(str(ci['race'])) if ci else None
    if not ci or not race:
        return None
    out = [a + c for a, c in zip(race['attrs'], ci['bonus'])]
    cls, rank = int(cls), max(0, min(2, int(rank or 0)))
    if cls == b:
        return out
    first = cls // 10 * 10 if cls % 10 else cls
    second = cls if cls % 10 else None
    for c, n in ((first, 1 + (2 if second else rank)), (second, 1 + rank)):
        if c and _cinfo(c):
            out = [a + n * x for a, x in zip(out, _cinfo(c)['bonus'])]
    return out


def start_attr(cls):
    return class_attrs(base_cls(cls)) or list(START_ATTR.get(base_cls(cls), START_ATTR[200]))


def skill_fx(sid, lv):
    """[(тип, значение, процент)] навыка на уровне (нет такого уровня — ближайший меньший)."""
    s = FX.get(str(int(sid)))
    if not s or not s.get('lv'):
        return []
    d = s['lv']
    if str(lv) in d:
        return d[str(lv)]
    lower = [int(k) for k in d if int(k) <= int(lv)]
    return d[str(max(lower) if lower else min(int(k) for k in d))]


def skill_kind(sid):
    s = FX.get(str(int(sid)))
    return s.get('k') if s else None


# Инь (флетта группа 1, стихия 2; навык 16121022): в оригинале 2019 — только перезарядка −2…−15% (код 64;
# запись Pers4x: 845 очков -> −10%). По просьбе — ещё +% ко всем пяти характеристикам, «как на Karos
# Genesis». Числа Genesis не найдены (в их вики и записях Инь нет), поэтому по этапам взяты те же, что у
# перезарядки: 2/4/6/8/10/15 %. Поменять — здесь.
YIN = (1, 2)
YIN_ALL_ATTR = (2.0, 4.0, 6.0, 8.0, 10.0, 15.0)


def fleta_stage(group, elem, pts):
    """-> (навык этапа, этап) или (None, 0). Этап — сколько порогов (10/100/…/1600)
    достигнуто: 845 очков = 5-й этап (Pers4x: −10% перезарядки)."""
    st = FLETA.get(str(group), {}).get(str(elem))
    if not st:
        return None, 0
    n = sum(1 for cost, _ in st if pts >= cost)
    return (st[0][1], n) if n else (None, 0)


def item_attr(item, enchant):
    d = ENCH.get(item)
    if not d:
        return None
    if enchant in d:
        return d[enchant]
    lower = [e for e in d if e <= enchant]
    return d[max(lower)] if lower else d[min(d)]


def gear_effects(rec):
    """Эффекты одной надетой вещи: навык самой вещи (itemAttr +84 по заточке: крылья —
    HP +1004, MP +328, сила навыков +3%), вставки (через их навык), особые характеристики."""
    out = []
    es = EQUIP_SKILL.get(struct.unpack_from('<I', rec, 2)[0])
    if es:
        lv = rec[7]
        sk = es.get(lv) or es[max([e for e in es if e <= lv] or [min(es)])]
        out += [[t, v, p, 'equip'] for t, v, p in skill_fx(sk, 1)]
    for g in struct.unpack_from('<6I', rec, 24):
        if not g:
            continue
        sk = SOCK_SKILL.get(g)
        fx = skill_fx(sk, 1) if sk else []
        if not fx and g in SOCK_INLINE:
            s = SOCK_INLINE[g]
            fx = [[s[1], s[2], s[3]]]
        out += fx
    for i in struct.unpack_from('<5H', rec, 125) + struct.unpack_from('<5H', rec, 135):
        for e in OPTIONS.get(i, {}).get('effects', []):
            out.append([e[0], e[1], e[2]])
    try:                                         # «Камень души» в костюме (soulstone.py, +80 / +92)
        import soulstone
        out += soulstone.effects(rec)
    except ImportError:
        pass
    return out


def base_block(cls, level, a):
    """Блок B по уровню и атрибутам (сила, ловкость, живучесть, интеллект, мудрость)."""
    S, D, V, I, W = a
    L = level
    c = base_cls(cls)
    hpL, mpL, atkL = _HP_L.get(c, 46), _MP_L.get(c, 8), _ATK_L.get(c, 0.25)
    # паладин ур.5 (9, 7, 10, 7, 7): HP 396, MP 123, атака 12.9
    hp = 396 - 5 * hpL - VIT_HP * 10 + hpL * L + VIT_HP * V
    mp = 123 - 5 * mpL - 70 + mpL * L + 10 * W
    atk = 12.9 - 5 * atkL - 0.8 * 9 + atkL * L + 0.8 * S
    B = dict.fromkeys(FIELDS, 0.0)
    B.update({0: hp, 4: 5.4 + 0.85 * L + 0.75 * V, 12: mp, 16: -1.87 + 0.12 * L + 0.55 * W,
              24: 10.0, 28: 6.5 + 0.05 * D, 32: 8 + 0.1 * D, 40: 45.2, 44: 65.0, 52: atk,
              56: 0.85 + 0.002 * D, 60: 4 + 0.5 * D, 64: 20.545 + 0.455 * L, 72: 0.35 * D,
              80: -10.14 + 0.308 * L + 2.84 * I, 84: 2.25 + 0.25 * L + 0.475 * I,
              88: 17.78 + 0.197 * L + 0.123 * I, 92: 3.288 + 0.1226 * L + 0.1 * W,
              96: 100.0, 100: 1.2, 104: 2.0475 + 0.2275 * L + 0.6 * V,
              132: 2.02 + 0.06 * L + 0.452 * D})
    return B


class Result:
    pass


def collect_effects(skills=(), fleta=None, buffs=(), equipped=()):
    """-> список (тип, значение, процент, источник)."""
    eff = []
    for sid, lv in skills:
        if skill_kind(sid) == PASSIVE:
            eff += [(t, v, p, 'skill %d' % sid) for t, v, p in skill_fx(sid, lv)]
    for g, (el, pts) in (fleta or {}).items():
        sk, st = fleta_stage(g, el, pts)
        if sk:
            eff += [(t, v, p, 'fleta %s/%s' % (g, el)) for t, v, p in skill_fx(sk, st)]
            if (int(g), int(el)) == YIN and st:
                pct = YIN_ALL_ATTR[min(st, len(YIN_ALL_ATTR)) - 1]
                eff += [(t, 0.0, pct, 'fleta %s/%s все характеристики' % (g, el)) for t in (1, 3, 2, 5, 4)]
    for b in buffs:
        sid, lv = b[0], b[1]
        extra = b[2] if len(b) > 2 else None
        if sid < 0 and str(-sid) in FX:          # камень «Усиление» при бафе супер-навыка
            sid = -sid
        k = skill_kind(sid) if sid > 0 else None
        if k == 25 and str(sid * 100 + 1) in FX:  # аура: эффект — у навыка id×100+1 (3005 -> 300501)
            if any(x[0] == sid * 100 + 1 for x in buffs):
                continue                         # оригинал шлёт в 05/09 и ауру, и её эффект
            sid, k = sid * 100 + 1, skill_kind(sid * 100 + 1)
        if k in NOT_STAT:
            continue                         # лечение/восстановление, атаки, дебафы
        fx = skill_fx(sid, lv) if sid > 0 else []
        if not fx and extra:                     # баф без эффектов в таблице — из описания
            m = {'atk': 71, 'def': 17, 'aspd': 13, 'move': 27, 'exp': 59, 'cd': 64}
            fx = [(m[k], 0.0, v * 100) for k, v in extra.items() if k in m]
            # макс. HP / MP числом («Суп из хэллоуинской тыквы» +1000 здоровья на 30 мин)
            fx += [(46 if k == 'maxhp' else 47, float(v), 0.0) for k, v in extra.items()
                   if k in ('maxhp', 'maxmp')]
            if extra.get('crit'):                # «Усиление крита на 1» — шанс крита числом
                fx.append((11, float(extra['crit']), 0.0))
        eff += [(t, v, p, 'buff %d' % sid) for t, v, p in fx]
    for rec in equipped:
        it = struct.unpack_from('<I', rec, 2)[0]
        eff += [(e[0], e[1], e[2], ('equip %d' if len(e) > 3 else 'item %d') % it)
                for e in gear_effects(rec)]
    return eff


def compute(cls, level, base_attr, skills=(), fleta=None, buffs=(), equipped=(), calib=None):
    """Полный расчёт. equipped — записи предметов (147 байт) с контейнером 0.
    calib — поправки импортированного персонажа {'B': {поле: Δ}, 'A': {поле: Δ}}."""
    r = Result()
    eff = collect_effects(skills, fleta, buffs, equipped)
    # Атрибуты от навыка самой вещи (кольца 56703: ловкость +1) оригинал показывает в
    # прибавке (+18), но в формулы не берёт: Pers4x — «+45», а крит/уклон/скорость по +43.
    bonus = [0.0] * 5
    shown = [0.0] * 5
    for t, v, p, src in eff:
        if t in ATTR_OF:
            i = ATTR_OF[t]
            d = v + base_attr[i] * p / 100
            shown[i] += d
            if not src.startswith('equip'):
                bonus[i] += d
    attrs = [b + x for b, x in zip(base_attr, bonus)]
    B = base_block(cls, level, attrs)
    for k, d in ((calib or {}).get('B') or {}).items():
        B[int(k)] = B.get(int(k), 0.0) + d
    A = dict(B)
    P = {}
    # вещи: защита по заточке, оружие — скорость и дальность
    wmin = wmax = mwmin = mwmax = 0.0
    parts = []                                    # ширина броска каждой вещи с атакой
    weapon = None
    for rec in equipped:
        it = struct.unpack_from('<I', rec, 2)[0]
        import charstats as _cs                  # изделия из флеттоцветов — по вещи-образцу класса
        v = _cs.effective_attr(it, rec[7], cls, level) if _cs.fleta_substitute(it, cls, level)             else item_attr(it, rec[7])
        if not v:
            continue
        A[64] += v[6]
        A[88] += v[7]
        if rec[1] in (7, 10, 17):                 # оружие и крылья — атака окна
            wmin += v[0]
            wmax += v[1]
            mwmin += v[2]
            mwmax += v[3]
            if v[1] > v[0]:
                parts.append(v[1] - v[0])
        if rec[1] == 7 and v[4] > 0:
            weapon = v
    if weapon:
        A[56] = weapon[4]
        if weapon[5] > 0:
            A[24] = weapon[5]
    # 1-й проход: значения (прибавки) и всё, что идёт вне блока
    for t, v, p, _ in eff:
        if t in ATTR_OF or t in (28, 29):
            continue        # 28/29 «Здоровье/Мана» — текущие (восстановление), не максимум
        if t == 46:
            P[P_HP] = P.get(P_HP, 0.0) + v + B[0] * p / 100
        elif t == 47:
            P[P_MP] = P.get(P_MP, 0.0) + v + B[12] * p / 100
        elif t in PAY_FRAC:
            P[PAY_FRAC[t]] = P.get(PAY_FRAC[t], 0.0) + p / 100
        elif t in PAY:
            P[PAY[t]] = P.get(PAY[t], 0.0) + (p or v)
        elif t in FLAT and v:
            A[FLAT[t]] += v
    for k, d in ((calib or {}).get('A') or {}).items():
        A[int(k)] = A.get(int(k), 0.0) + d
    # 2-й проход: проценты. Скорости, уклонение, блок, физ./маг. защита — множитель на
    # каждый эффект от уже набранного (баф 310301 ур.5: защита 336.845 -> 370.53 = ×1.1
    # вместе с вещами); прочие — доля базы B.
    for t, v, p, _ in eff:
        if not p or t in ATTR_OF or t in (28, 29, 46, 47) or t in PAY_FRAC or t in PAY:
            continue
        if t in MULT:
            for f in MULT[t]:
                A[f] *= 1 + p / 100
        elif t in (17, 18, 19, 20):
            A[FLAT[t]] *= 1 + p / 100
        elif t in FLAT:
            A[FLAT[t]] += B[FLAT[t]] * p / 100
    A[0] += P.get(P_HP, 0.0)
    A[12] += P.get(P_MP, 0.0)
    # безопасные пределы: ничего отрицательного там, где клиент/бой этого не ждут
    for f in (0, 12):
        A[f] = max(1.0, A[f])
    for f in (28, 32, 56, 96, 132):
        A[f] = max(0.0, A[f])
    A[56] = max(0.1, A[56])
    r.A, r.B, r.P = A, B, P
    r.attrs = attrs
    r.bonus = [int(round(x)) for x in shown]
    r.effects = eff
    r.weapon = (wmin, wmax, mwmin, mwmax)
    r.weapon_parts = parts
    return r


def calibrate(raw0802, cls, level, base_attr, skills=(), fleta=None, equipped=()):
    """Поправки импортированного персонажа: разница между его 08/02 оригинала и формулами.
    B — по всем полям базы; A — только то, чего не объясняют навыки/флетта/вещи
    (у Pers2xxxxx: маг. защита −60 и «прибавка атаки» +40 — источник не найден).
    Бафы в момент снимка (зелья HP и т.п.) в поправку A не берём."""
    r = compute(cls, level, base_attr, skills, fleta, (), equipped)
    cal = {'B': {}, 'A': {}}
    for f in FIELDS:
        rb = struct.unpack_from('<f', raw0802, 412 + f)[0]
        d = rb - r.B[f]
        if abs(d) > 1e-3:
            cal['B'][f] = round(d, 4)
    r = compute(cls, level, base_attr, skills, fleta, (), equipped, cal)
    for f in FIELDS:
        if f in (0, 12, 4, 16):                    # HP/MP: бафы зелий в снимке
            continue
        ra = struct.unpack_from('<f', raw0802, 32 + f)[0]
        d = ra - r.A[f]
        if f in (56, 40, 44):                      # скорость: множители бафов
            continue
        if abs(d) > 1e-3:
            cal['A'][f] = round(d, 4)
    return cal
