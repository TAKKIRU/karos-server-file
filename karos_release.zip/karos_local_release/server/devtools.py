"""Пульт разработчика: локальный HTTP (127.0.0.1:10199) для окна tools/devpanel.py (F2).

Глобальные множители (DEV) сервер читает на лету: скорость бега, опыт, караты,
урон игрока, режим бога, убийство с одного удара, множители HP/атаки/защиты.

Команды к персонажу в игре выполняет Session, которую handle() регистрирует
при входе в мир (SESSIONS[eid]); её методы — замыкания внутри handle().

API (JSON):
  GET  /state                   -> {'dev': {...}, 'players': [...], 'warps': [...]}
  POST /dev   {"move": 3, ...}  -> изменить множители (и разослать скорость/статы)
  POST /cmd   {"eid": 0, "op": "level", "value": 30}
       op: level | exp | gold | item | heal | teleport (target) | goto (x, y) |
           kill (radius, objects, uidx) | restat | fleta | skillpts | petexp | petsat | pethatch | save |
           bag (act: list | sort | sell | destroy | dismantle | stash, cells: [ref из list]) |
           craft (act: list | make, rid, count) |
           pet (autofeed, feed_below, loot_cats, ptype)
       eid 0 — первый персонаж в игре.

Только для локальных программ (_H._refusal, иначе 403): привязки к 127.0.0.1 мало — открытая в браузере
страница тоже шлёт запросы с этого компьютера.
  * заголовка Origin быть не должно (браузер ставит его на любой POST страницы);
  * Host — 127.0.0.1:порт или localhost:порт (иначе подмена DNS: страница читала бы /state);
  * POST — только Content-Type: application/json (страница не пошлёт его без предзапроса CORS,
    а разрешений CORS пульт не выдаёт).
"""
import json, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 10199
DRAIN_MAX = 1 << 16     # столько тела отклонённого запроса дочитать, чтобы ответ 403 дошёл

DEV = {
    'move': 2.0,        # скорость бега/ходьбы
    'exp': 10.0,        # множитель опыта с мобов к оригиналу (server.EXP_RATE, по просьбе ×10)
    'gold': 15.0,       # множитель карат
    'dmg': 1.0,         # урон игрока по мобам
    'one_hit': False,   # моб умирает с одного удара
    'god': False,       # мобы не наносят урона
    'hp': 1.0,          # множители характеристик персонажа
    'atk': 1.0,
    'def': 1.0,
    'aggro': True,      # мобы отвечают на удар
    'safe_enchant': True,   # неудачная заточка не ломает предмет
    'eid_prep': 20.0,       # событие EID: секунд на бафы после входа (потом 10 с отсчёта и старт)
    'eid_anytime': True,    # Парящий остров, Демоническая башня — в любое время (False — по расписанию клиента)
    'respawn_fast': False,  # возрождение мобов 30 с, боссов 60 с (False — как в оригинале, progression.respawn_delay)
    'exp_gap': True,        # опыт меньше, если игрок выше моба (оригинал: 0,9 / 0,7 / … / 0,1); False — всегда полный
}
_lock = threading.Lock()
SESSIONS = {}           # eid -> Session
WARPS = []              # [{'id', 'name', 'map'}] — заполняет server.py
ACCOUNTS = {}           # {'list', 'get', 'set'} — функции server.py


class Session:
    """Ручки одного персонажа; поля — функции, их задаёт handle()."""

    def __init__(self, eid, name, **ops):
        self.eid, self.name = eid, name
        self.ops = ops

    def info(self):
        f = self.ops.get('info')
        return f() if f else {'eid': self.eid, 'name': self.name}

    def run(self, op, args):
        f = self.ops.get(op)
        if not f:
            return {'ok': False, 'error': f'нет команды {op}'}
        res = f(**args)
        return {'ok': True, 'result': res}


def register(sess):
    with _lock:
        SESSIONS[sess.eid] = sess


def unregister(eid, sess=None):
    with _lock:
        if eid in SESSIONS and (sess is None or SESSIONS[eid] is sess):
            del SESSIONS[eid]


def _apply_dev(changes):
    """Обновить DEV; скорость/статы разослать всем персонажам."""
    for k, v in changes.items():
        if k not in DEV:
            continue
        DEV[k] = bool(v) if isinstance(DEV[k], bool) else float(v)
    for s in list(SESSIONS.values()):
        try:
            s.run('restat', {})
        except Exception as e:          # noqa: BLE001 — пульт не должен ронять сервер
            print('devtools restat:', e, flush=True)


class _H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _reply(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _refusal(self):
        """Почему запрос не от локальной программы, или None."""
        if self.headers.get('Origin') is not None:
            return 'команды с веб-страниц не принимаются'
        port = self.server.server_address[1]
        hosts = [h.strip().lower() for h in self.headers.get_all('Host', [])]
        if len(hosts) != 1 or hosts[0] not in (f'127.0.0.1:{port}', f'localhost:{port}'):
            return 'неверный Host'
        if self.command == 'POST' and self.headers.get_content_type() != 'application/json':
            return 'нужен Content-Type: application/json'
        return None

    def _refuse(self, why):
        size = self.headers.get('Content-Length', '')
        if size.isdigit():
            self.rfile.read(min(int(size), DRAIN_MAX))      # не дочитать — Windows оборвёт ответ
        self._reply({'ok': False, 'error': why}, 403)

    def do_GET(self):
        why = self._refusal()
        if why:
            return self._refuse(why)
        if self.path.startswith('/state'):
            acc = {'list': ACCOUNTS['list'](), 'active': ACCOUNTS['get']()} if ACCOUNTS else {}
            self._reply({'dev': DEV, 'players': [s.info() for s in list(SESSIONS.values())],
                         'warps': WARPS, 'accounts': acc})
        else:
            self._reply({'error': 'not found'}, 404)

    def do_POST(self):
        why = self._refusal()
        if why:
            return self._refuse(why)
        n = int(self.headers.get('Content-Length') or 0)
        try:
            data = json.loads(self.rfile.read(n) or b'{}')
        except ValueError:
            return self._reply({'ok': False, 'error': 'bad json'}, 400)
        try:
            if self.path.startswith('/dev'):
                _apply_dev(data)
                return self._reply({'ok': True, 'dev': DEV})
            if self.path.startswith('/account') and ACCOUNTS:
                return self._reply({'ok': True, 'active': ACCOUNTS['set'](data.get('id', 'default'))})
            if self.path.startswith('/cmd'):
                eid = int(data.pop('eid', 0) or 0)
                op = data.pop('op', '')
                sess = SESSIONS.get(eid) if eid else next(iter(SESSIONS.values()), None)
                if not sess:
                    return self._reply({'ok': False, 'error': 'нет персонажа в игре'})
                return self._reply(sess.run(op, data))
        except Exception as e:              # noqa: BLE001
            return self._reply({'ok': False, 'error': f'{type(e).__name__}: {e}'}, 500)
        self._reply({'error': 'not found'}, 404)


def serve(port=PORT):
    try:
        srv = ThreadingHTTPServer(('127.0.0.1', port), _H)
    except OSError as e:
        print(f'пульт разработчика: порт {port} занят ({e})', flush=True)
        return None
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f'пульт разработчика: http://127.0.0.1:{port} (окно — tools/devpanel.py, F2)', flush=True)
    return srv
