"""Коробки костюмов/аватаров и купоны выбора — по описаниям предметов (itemBase_Name).

«Коробка с костюмом» 1000010447: «Содержит вечный Уникальный Костюм Тёмных сил» ->
4 купона «Уникальный Костюм Тёмных сил» (вид 2, категория 59): «Часть костюма: Торс /
Ноги / Кисти рук / Ступни», «Срок действия: 7 дней / 30 дней / вечный».
Купон -> деталь «<имя> (торс)» … для базового класса персонажа (cls 100…800) с тем же
сроком (itemBase [31]: 604800 / 2592000 / 0 — у трёх вариантов детали отличается только срок).
Характеристики детали оригинал давал выбрать в окне настройки (строки 34002–34013,
таблицы itemMixed*); протокола этого окна в записях нет — деталь выдаётся без них.
"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PART = {'торс': 'торс', 'ноги': 'ноги', 'кисти рук': 'кисти рук', 'ступни': 'ступни'}
BOX, COUPON = {}, {}          # коробка -> [купоны]; купон -> (имя, часть, срок в секундах)
_PARTS = {}                   # (имя, часть, базовый класс, срок) -> id


def _norm(s):
    return re.sub(r'\s+', ' ', s or '').strip().lower()


def _period(text):
    t = text.lower()
    if 'вечн' in t:
        return 0
    m = re.search(r'(\d+)\s*(дн|день|дня)', t)
    return int(m.group(1)) * 86400 if m else None


def init(items):
    if BOX or COUPON:
        return
    sys.path.insert(0, os.path.join(ROOT, 'tools'))
    try:
        from boxes import records, decode, SRC
        recs = list(records(decode(open(SRC, 'rb').read(), 0)))
    except OSError:
        return
    desc = {i: (n, d) for i, n, d in recs}
    by_name = {}
    for iid, (n, d) in desc.items():
        it = items.get(iid) or {}
        if it.get('kind') == 2 and it.get('cat') == 59 and 'купон' in d.lower():
            m = re.search(r'Часть костюма:\s*([А-Яа-яё ]+?)\s*(?:\n|Требуется|$)', d)
            per = _period(d.split('Срок действия:')[-1]) if 'Срок действия' in d else None
            if m:
                COUPON[iid] = (_norm(n), _norm(m.group(1)), per)
                by_name.setdefault(_norm(n), []).append(iid)
    for iid, it in items.items():
        if it.get('kind') == 1 and it.get('cat') in (56, 57):
            m = re.match(r'(.+?)\s*\((торс|ноги|кисти рук|ступни)\)\s*$', it.get('name', ''))
            if m:
                _PARTS[(_norm(m.group(1)), m.group(2), (it.get('cls') or 0) // 100 * 100,
                        it.get('period', 0))] = iid
    for iid, (n, d) in desc.items():
        if 'коробк' not in _norm(n):
            continue
        m = re.search(r'Содержит\s+(вечный\s+)?(.+?)(?:\s+на\s+(\d+)\s+дн[а-я]*)?\s*\.', d)
        if not m:
            continue
        name = _norm(m.group(2))
        per = 0 if m.group(1) else (int(m.group(3)) * 86400 if m.group(3) else None)
        cps = [c for c in by_name.get(name, []) if per is None or COUPON[c][2] == per]
        if cps:
            BOX[iid] = cps
    init_wings(items)


def _wing_name(box_name):
    """«Коробка с древними крыльями Благословения (7 дней)» -> «древние крылья благословения (7 дней)»."""
    m = re.match(r'коробка с\s+(.*)$', _norm(box_name))
    if not m:
        return None
    words = []
    for w in m.group(1).split():
        if w == 'крыльями':
            w = 'крылья'
        elif w.endswith('ими') or w.endswith('ыми'):
            w = w[:-3] + ('ие' if w.endswith('ими') else 'ые')
        words.append(w)
    return ' '.join(words)


def init_wings(items):
    """Коробки аватаров крыльев (320001…, 1000000302…): по названию -> сами крылья."""
    names = {}
    for iid, it in items.items():
        if it.get('kind') == 1 and it.get('cat') in (25, 68):
            names.setdefault(_norm(it.get('name')), iid)
    for iid, it in items.items():
        n = it.get('name', '')
        if iid in BOX or 'крыл' not in n.lower() or 'коробк' not in n.lower():
            continue
        w = _wing_name(n)
        if w and w in names:
            BOX[iid] = [names[w]]


def part_for(coupon, cls):
    """Деталь костюма для купона и класса персонажа или None."""
    c = COUPON.get(coupon)
    if not c:
        return None
    name, part, per = c
    base = (int(cls) // 100) * 100
    return _PARTS.get((name, part, base, per if per is not None else 0))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    items = {int(k): v for k, v in json.load(open(os.path.join(ROOT, 'data', 'items.json'),
                                                    encoding='utf-8')).items()}
    init(items)
    print(len(BOX), 'коробок,', len(COUPON), 'купонов,', len(_PARTS), 'деталей')
    print(1000010447, BOX.get(1000010447), [part_for(c, 311) for c in BOX.get(1000010447, [])])
    w = [b for b in BOX if 'крыл' in items[b]['name'].lower()]
    print(len(w), 'коробок крыльев;', [(items[b]['name'], items[BOX[b][0]]['name']) for b in w[:4]])
