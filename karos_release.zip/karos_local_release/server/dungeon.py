"""Скрипты подземелий: двери, волны мобов, стены лабиринта.

Пакеты (записи оригинала orig_hl / remain3, раскладка совпала с NeoAsmara):
  S 0a/00 (20 байт BE): u32 карта, u32 вид, u32 номер, u32 параметр, i32 −1.
      вид 46 — включить объект/моба с номером точки (волна появляется), 47 — выключить;
      0, 36, 42 — двери, эффекты и таймеры сцены (.me), их исполняет клиент.
      Параметр: 1 — от триггера, 2 — от смерти мобов.
  C 0a/01 (8 байт BE): u32 карта, u32 номер триггера (игрок дошёл до точки) -> S 0a/01 эхо и события.
  S 0a/04 (12 байт): начальное состояние стен лабиринта (логово Гельменко, 137 пакетов).
  S 04/04 при входе в подземелье: eid, карта, 01, u32 группа входа, карта (иначе нули).

Правила — data/dungeon_rules.json (tools/dungeon_import.py, из NeoAsmara): этапы (required_spawns —
номера в data/dungeon_spawns.json; все убиты -> события), kill_events (убит моб с номером точки ->
события), триггеры (requires_stages — этапы, без которых проход закрыт). Сверено с записями оригинала:
колокольня 29516 (триггер 200 -> волна 500–515, комнаты 300/400/500, босс 900), катакомбы 29014/29614
(триггеры 644 и 99, двери 96/95/91/34/64…).
Проход подземелья — на один вход в карту: новый мир при входе = новый проход (как инстанс оригинала).
"""
import json, math, os, struct

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _j(name):
    try:
        return json.load(open(os.path.join(ROOT, 'data', name), encoding='utf-8'))
    except (OSError, ValueError):
        return {}


RULES = (_j('dungeon_rules.json') or {}).get('maps', {})
SPAWNS = _j('dungeon_spawns.json') or {}
# Парящий остров / Демоническая башня: сценарий из .me клиента (tools/eid_tables.py -> eid.json, script) —
# вместо догадки NeoAsmara (у них «убит N -> триггер N», на острове это верно только для 201)
for _ev, _e in ((_j('eid.json') or {}).get('events') or {}).items():
    _sc = _e.get('script')
    if _sc:
        _r = RULES.setdefault(str(_ev), {})
        _r['kill_events'] = _sc.get('kill_events', {})
        _r['triggers'] = {**(_r.get('triggers') or {}), **(_sc.get('triggers') or {})}
        _r['attackable'] = _sc.get('attackable', [])
ACTIVATE, DEACTIVATE = 46, 47
TRIGGER_REACH = 400.0          # NeoAsmara требует 200 от точки триггера; клиент шлёт 0a/01 сам — с запасом
# Двери/стены карт без записанного сценария (tools/dungeon_doors.py): открыть при входе (0a/04 и 0a/00 вида 0),
# серверные триггеры — по убийству рядом с их дверью. Нава/Вастиан, Гипогей, Зал испытаний, канализация, Волансия
DOORS = _j('dungeon_doors.json') or {}
for _mid, _d in DOORS.items():
    RULES.setdefault(_mid, {})['doors'] = _d


def rule(map_id):
    return RULES.get(str(map_id)) or {}


def scripted(map_id):
    """У карты есть сценарий (этапы, триггеры, события смерти или триггеры у дверей) — мобы из полного
    списка .mo (со спящими волнами)."""
    r = rule(map_id)
    d = r.get('doors') or {}
    return bool(r.get('stages') or r.get('triggers') or r.get('kill_events') or d.get('near_triggers')
                or d.get('open_events'))


def spawns(map_id):
    """Полный список объектов .mo (со скрытыми волнами) — только для карт со сценарием."""
    return SPAWNS.get(str(map_id)) if scripted(map_id) else None


def zone_tail(map_id):
    """Хвост 04/04 (9 байт после eid и карты): 01, группа входа, карта — как в записи оригинала."""
    g = rule(map_id).get('entry_group')
    return struct.pack('>BII', 1, int(g), int(map_id)) if g else bytes(9)


def event_body(map_id, ev):
    kind, ref, a, b = (list(ev) + [0, 0xffffffff])[:4]
    return struct.pack('>IIIII', int(map_id), int(kind), int(ref), int(a), int(b) & 0xffffffff)


class Run:
    """Проход подземелья. Методы возвращают (пакеты 0a/00, [(вид 46/47, номер точки)])."""

    def __init__(self, map_id):
        self.map_id = int(map_id)
        self.rule = rule(map_id)
        self.dead = set()          # номера в списке dungeon_spawns (sidx) убитых мобов
        self.emitted = set()       # ключи уже отправленных событий (каждое — один раз)
        self.sent = set()          # сами события: этапы и события смерти у вариантов сцены пересекаются
        self.state = {}            # номер объекта -> последнее 46/47
        self.fired = set()         # сработавшие триггеры
        self.completed = False

    def initial(self):
        """0a/04 стен лабиринта при входе (логово Гельменко — из записи; карты из dungeon_doors — «открыть»:
        состояние 1 = анимация открытия, AMo 0x005f4d33)."""
        out = [bytes.fromhex(p['body']) for p in self.rule.get('initial_packets', [])
               if p.get('sub') == 4]
        out += [struct.pack('>III', 0, int(o), 1) for o in (self.rule.get('doors') or {}).get('open_objects', [])]
        return out

    def entry(self):
        """События 0a/00 при входе: двери сцены, открытые сразу (dungeon_doors open_events)."""
        return self._emit('doors:entry', (self.rule.get('doors') or {}).get('open_events', []))

    def near_kill(self, x, z):
        """Убит моб в (x, z): серверный триггер, у одной из дверей которого он стоял (dungeon_doors)."""
        d = self.rule.get('doors') or {}
        r2 = float(d.get('near', 600.0)) ** 2
        known = set(self.rule.get('kill_events') or {})
        for tid, t in sorted((d.get('near_triggers') or {}).items(), key=lambda kv: int(kv[0])):
            if tid in known or ('near:' + tid) in self.emitted:
                continue
            if any((px - x) ** 2 + (pz - z) ** 2 <= r2 for px, pz in t['pos']):
                return self._emit('near:' + tid, t['events'])   # один триггер за убийство: волны по очереди
        return [], []

    def _emit(self, key, events):
        if key in self.emitted:
            return [], []
        self.emitted.add(key)
        bodies, acts = [], []
        for ev in events:
            kind, ref = int(ev[0]), int(ev[1])
            if kind in (ACTIVATE, DEACTIVATE):
                # включение/выключение — по состоянию объекта: повтор того же — пропуск,
                # а выключенный объект можно включить снова (47, затем 46)
                if self.state.get(ref) == kind:
                    continue
                self.state[ref] = kind
            else:
                t = tuple(int(v) for v in ev[:3])
                if t in self.sent:
                    continue                 # дверь/эффект уже отправлены (этап и смерть моба совпали)
                self.sent.add(t)
            bodies.append(event_body(self.map_id, ev))
            if ev[0] in (ACTIVATE, DEACTIVATE):
                acts.append((ev[0], int(ev[1])))
        return bodies, acts

    def _stage_done(self, i):
        st = self.rule.get('stages', [])
        return i < len(st) and set(st[i].get('required_spawns', [])) <= self.dead

    def kill(self, sidx, ref, pos=None):
        """Убит моб подземелья (номер в списке, номер точки .mo, его (x, z) — для триггеров у дверей)."""
        bodies, acts = [], []
        if sidx is None:
            return bodies, acts
        self.dead.add(int(sidx))
        if pos is not None:
            bodies, acts = self.near_kill(*pos)
        stages = self.rule.get('stages', [])
        ref_s = str(int(ref or 0))
        kev = self.rule.get('kill_events', {})
        room = any(str(s.get('native_event')) == ref_s for s in stages if 'native_event' in s)
        if ref_s in kev and not room:
            b, a = self._emit('native:' + ref_s, kev[ref_s])
            bodies += b
            acts += a
        for i, s in enumerate(stages):
            if self._stage_done(i):
                key = 'native:%s' % s['native_event'] if 'native_event' in s else 'stage:%d' % i
                b, a = self._emit(key, s.get('events', []))
                bodies += b
                acts += a
        done = self.rule.get('completion_spawns')
        if done and set(done) <= self.dead:
            self.completed = True
        return bodies, acts

    def trigger(self, tid, x, y, z):
        """C 0a/01: игрок у точки триггера. -> (ответ разрешён?, пакеты, включения)."""
        t = self.rule.get('triggers', {}).get(str(int(tid)))
        if not t:
            return True, [], []                      # неизвестный триггер — только эхо (как раньше)
        if t.get('passive_only'):
            return True, [], []
        p = t.get('position')
        if p and math.hypot(p[0] - x, p[1] - y) > TRIGGER_REACH:
            return False, [], []
        for i in t.get('requires_stages', []):
            if not self._stage_done(int(i)):
                return False, [], []                 # «сначала одолейте стражей прохода»
        if int(tid) in self.fired:
            return True, [], []
        self.fired.add(int(tid))
        key = 'native:%s' % t['native_event'] if 'native_event' in t else 'trigger:%d' % int(tid)
        bodies, acts = self._emit(key, t.get('events', []))
        acts += [(ACTIVATE, int(r)) for r in t.get('activate_references', [])]
        return True, bodies, acts
