"""Свитки трансформации (превращение в существо) — данные data/transform.json (tools/transform_table.py).

Пакеты (запись оригинала orig_hl_Pers4x: «Благословленный свиток трансформации»; клиент AMo):
  C 06/5a (сборщик 0x0058f8a5): +0 eid, +4 eid цели, +8 u8 сумка, +9 u8 ячейка, +10 свиток,
      +14 номер превращения (0 — первый запрос из рюкзака), +18 u16 код:
      0x175 — применить, 0x24e — отмена (окно выбора закрыто).
  S 06/5a (обработчик 0x006665b3, CItemTranformUseItemPacket) — та же раскладка, код:
      0x24d — открыть окно выбора существа (0x0044185a; в записи: +14 = свиток),
      0x175 — «Вы успешно превратились в существо %s» (+14 номер превращения),
      0x24b «Невозможно превратиться в данной зоне», 0x24c «Невозможно превратить цель»,
      0x24e «Превращение отменено» (в записи — нули на +8..+17), 0x24f «Цель превращается».
  S 08/10 (обработчик 0x00666803, CCharInfoTransformPacket, кадр >= 17): +0 eid, +4 номер
      превращения (0 — вернуть облик), +8 u8 0xff, +9 u16 0x175 — так в записи у чужих игроков.
Особые навыки облика (transformSkill, поле 'skills') приходят 05/01 как обычные навыки; урон, мана,
длительность бафа — из skillLevel. Вне своего облика такой навык считается обычным ударом.
Длительность — у навыка существа (skillLevel +140), 300 с. Этот же навык (transformBase +44, например
81010) накладывается как баф (05/09) на время облика — прибавки существа из skill_effects.
"""
import json, os, struct

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    FORMS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'transform.json'),
                                                   encoding='utf-8')).items()}
except (OSError, ValueError):
    FORMS = {}
SCROLLS = {v['scroll'] for v in FORMS.values()}
# особые навыки обликов (transformSkill: атаки, бафы, дебафы) — клиент даёт их только в облике
CREATURE_SKILLS = {sk for v in FORMS.values() for sk in v.get('skills', ())}
CANCEL_POTION = 60926                     # «Зелье отмены превращения»

USE, OPEN, NO_ZONE, NO_TARGET, CANCEL, BUSY = 0x175, 0x24d, 0x24b, 0x24c, 0x24e, 0x24f


def parse(pl):
    pl = bytes(pl) + bytes(max(0, 20 - len(pl)))
    eid, target, cont, cell, item, form, code = struct.unpack_from('>IIBBIIH', pl, 0)
    return {'eid': eid, 'target': target, 'cont': cont, 'cell': cell, 'item': item,
            'form': form, 'code': code}


def build(r, code, form=None, item=None, cont=None, cell=None):
    return struct.pack('>IIBBIIH', r['eid'], r['target'],
                       r['cont'] if cont is None else cont, r['cell'] if cell is None else cell,
                       r['item'] if item is None else item,
                       r['form'] if form is None else form, code)


def build_char(eid, form):
    return struct.pack('>IIBH', eid, form, 0xff, USE)


def allowed(form_id, sid):
    """Навык можно применить: не навык существа, или он есть у текущего облика."""
    return sid not in CREATURE_SKILLS or sid in (FORMS.get(form_id) or {}).get('skills', ())


def check(form_id, scroll, level):
    """-> запись превращения, если её можно взять этим свитком на этом уровне."""
    f = FORMS.get(form_id)
    if f and f['scroll'] == scroll and level >= f['lvl']:
        return f
    return None
