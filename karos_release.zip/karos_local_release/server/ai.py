"""AI мобов — приближенный к оригиналу.

Данные для поведения взяты реверсом из клиента (§75, §77):
  npcInfo.o104_f64 — РАДИУС АГРО   (мобы 200-350, объекты 0)
  npcInfo.o96_f64  — ДАЛЬНОСТЬ АТАКИ (ближний бой 20-30, лучники 100)
  npcInfo.o60_i    — уровень

Сам алгоритм в клиенте отсутствует (§72): классы CActMob* — только
анимации. Поэтому реализована стандартная схема MMO, управляемая
вытащенными числами:
    idle -> (ПО НАМ УДАРИЛИ) -> chase -> (в дальности атаки) -> attack
    -> (игрок ушёл дальше leash) -> return -> idle

★ МОБЫ ПАССИВНЫЕ. Проверено по дампу play1: из 18 боёв ПЕРВЫМ бил игрок
во ВСЕХ 18 случаях, ни один моб не напал без провокации. Наблюдение
пользователя это подтвердило. Поэтому o104 (200-350) — это радиус
ПРЕСЛЕДОВАНИЯ/обзора, а НЕ авто-агро.
"""
import math, time, random
import progression
import terrain
import navgrid
import superskill

TICK = 0.5              # шаг обновления, секунд
LEASH = 2.5             # во сколько раз дальше агро моб теряет цель
ATTACK_CD = 2.0         # перезарядка атаки моба, секунд
RESPAWN = 30.0          # время до респауна

# --- блуждание в покое (эталон: дамп mobs-20260822, моб 2993) ---
# В оригинале мобы постоянно бродят у точки спавна: mode=0 идёт (отрезок
# ~15-40 ед.), затем mode=2 остановка (from==to) и пауза, потом новая точка.
WANDER_MIN, WANDER_MAX = 25.0, 85.0   # длина отрезка от точки спавна
WANDER_RADIUS = 120.0                 # дальше спавна не уходит
WANDER_SPEED = 45.0                   # ед/сек пешком (в дампе ~20-30)
WANDER_PAUSE = (1.5, 4.5)             # пауза стоя между отрезками
CHASE_SPEED = 110.0                   # погоня (оригинал: 70–120 ед/с, режим 1 «бег» в 04/01)
WINDUP = 0.75                         # замах: 05/00 моба -> урон 05/02 (оригинал 0.62–0.84 с, медиана 0.76)
FIRST_HIT = 1.0                       # подошёл — пауза перед первым замахом

# Агрессия (записи оригинала orig_hl / remain3: мобы выше 10 ур. нападают сами — 47 из 112 первых
# атак без удара игрока, в т.ч. ур.15 на игрока 62; мобы до 10 ур. только отвечают — orig_1).
# Погоня начиналась на 40–250 ед. от игрока (медиана ~115) -> радиус 180.
AGGRO_FROM = 10                       # ур. моба выше этого — нападает сам
AGGRO_RADIUS = 180.0
# Реакция 05/0b (записи оригинала orig_hl/remain3, 88 случаев): 1 «заметил» -> через 1.25–1.40 с
# (медиана 1.33) 10 «агрессия» и погоня -> ещё через ~1.35 с 0 (значок снят). Не напал — 1, затем 0.
# Мобы до 10 ур. значков не показывают (orig_1 — ни одного 05/0b).
NOTICE = 1.33                         # заметил — пауза перед погоней
REACT_CLEAR = 1.35                    # после «агрессии» значок снимается
RETURN_MAX = 8.0                      # дольше идёт домой (застрял) — сразу на спавн
AWAKE = 1500.0                        # дальше от игроков мобы не обновляются (клиент их не видит)


def _aggro_on():
    try:
        from devtools import DEV
        return bool(DEV.get('aggro', True))
    except ImportError:
        return True


def pos(p, now=None):
    """Где игрок сейчас: 04/01 несёт точку «куда», а идёт он со своей скоростью (раньше мобы у точки
    назначения замечали игрока, когда он был ещё далеко)."""
    path = getattr(p, 'path', None)
    if not path:
        return p.x, p.y
    x0, y0, x1, y1, t0, v = path
    L = math.hypot(x1 - x0, y1 - y0)
    k = 1.0 if L < 1 else min(1.0, max(0.0, ((now or time.time()) - t0) * v / L))
    return x0 + (x1 - x0) * k, y0 + (y1 - y0) * k


def dist(a, b):
    if hasattr(b, 'path'):
        bx, by = pos(b)
        return math.hypot(a.x - bx, a.y - by)
    return math.hypot(a.x - b.x, a.y - b.y)


class MobAI:
    """Обновляет состояние мобов. Возвращает события для рассылки клиенту."""

    def __init__(self, world, combat=None):
        self.world = world
        self.combat = combat
        self.last = time.time()

    def tick(self, now=None):
        """-> список событий: ('move', mob, fx,fy,fz) | ('attack', mob, player, dmg)
                              | ('respawn', mob) | ('react', mob, None, состояние 05/0b)"""
        now = now or time.time()
        if now - self.last < TICK:
            return []
        dt = now - self.last
        self.last = now
        events = []
        if getattr(self.world, 'hold', False):
            return events                     # событие EID до старта: мобы на карте не действуют
        players = list(self.world.players.values())
        reacting = {m.target for m in self.world.mobs.values() if m.alive and m.state == 'notice'}
        for mob in self.world.mobs.values():
            if getattr(mob, 'dormant', False):
                continue                      # волна подземелья ещё не вызвана (dungeon.py)
            if not mob.alive:
                if getattr(mob, 'no_respawn', False):
                    continue                  # подземелье: убитые не возрождаются до нового входа
                delay = getattr(mob, 'respawn', None) or progression.respawn_delay(mob)
                if now - getattr(mob, 'died_at', now) > delay:
                    self._respawn(mob)
                    events.append(('respawn', mob, None, 0))
                continue
            if getattr(mob, 'gather', None) or getattr(mob, 'static', False):
                continue                      # узел добычи; стартер/кристалл/ключ события — не ходят и не бьют
                                              # (у них в npcInfo агрессия 250 — раньше бродили по карте)
            rc = getattr(mob, 'react_clear', None)
            if rc is not None and now >= rc:             # значок над головой снимается (и вдали от игроков)
                mob.react_clear = None
                events.append(('react', mob, None, 0))
            if mob.state == 'idle' and not any(abs(mob.x - p.x) < AWAKE and abs(mob.y - p.y) < AWAKE
                                               for p in players):
                continue                      # вдали от игроков мобы стоят (клиент их не видит)
            if mob.state == 'idle' and mob.level > AGGRO_FROM and mob.aggro > 0 and _aggro_on():
                # одновременно игрока «замечает» только один моб — остальные ждут своей очереди
                _rad = mob.atk_range * 1.2 if getattr(mob, 'anchored', False) else AGGRO_RADIUS
                p = next((p for p in players if p.hp > 0 and dist(mob, p) <= _rad
                          and p.eid not in reacting
                          and not getattr(p, 'dead', False) and not self._safe(p)), None)
                if p:
                    mob.target, mob.state = p.eid, 'notice'     # заметил («!» над головой) — нападёт через миг
                    mob.notice_at = now
                    mob.react_clear = None
                    reacting.add(p.eid)
                    events.append(('react', mob, None, 1))
            if mob.state == 'notice':
                t = self.world.players.get(mob.target)
                if (not t or t.hp <= 0 or getattr(t, 'dead', False) or self._safe(t)
                        or dist(mob, t) > AGGRO_RADIUS * 1.5):
                    mob.state, mob.target = 'idle', None        # потерял из виду — значок снят
                    events.append(('react', mob, None, 0))
                    continue
                if now - getattr(mob, 'notice_at', now) >= NOTICE:
                    mob.state = 'chase'
                    mob.react_clear = now + REACT_CLEAR
                    events.append(('react', mob, None, 10))
            ev = self._update(mob, players, dt, now)
            if ev:
                events.append(ev)
        return events

    def _safe(self, p):
        f = getattr(self.world, 'in_safe', None)
        return bool(f and f(p.x, p.y))

    def provoke(self, mob, player_eid):
        """моба ударили — он отвечает. Единственный способ начать бой."""
        if getattr(mob, 'gather', None) or getattr(mob, 'static', False):
            return                                 # руда; стартер/ключ события EID — не отвечают
        if mob.alive and mob.state in ('idle', 'notice'):
            if mob.state == 'notice':
                mob.react_clear = time.time()      # ударили до «агрессии» — значок снять
            mob.target = player_eid
            mob.state = 'chase'

    def _update(self, mob, players, dt, now):
        # Моб не будет бродить сам по себе, если у него нет агро (мирный NPC),
        # но если его ударили (state != 'idle'), он должен драться!
        if mob.aggro <= 0 and mob.state == 'idle':  
            return None
        target = mob.target and self.world.players.get(mob.target)

        if mob.state == 'idle':
            return self._wander(mob, now, dt)   # в покое — бродит у спавна
        if mob.state == 'notice':
            return None                        # переход в погоню — в tick (там же 05/0b)

        # дебафы от камней супер-навыков (superskill.on_hit)
        if superskill.mob_mod(mob, 'stun', now):
            return None
        rooted = superskill.mob_mod(mob, 'root', now)
        speed = CHASE_SPEED * superskill.mob_mod(mob, 'move', now, 1.0)

        if not target or getattr(target, 'dead', False) or self._safe(target):
            mob.state = 'return'          # цель ушла в «белую зону» / погибла — домой
            mob.target = None
            return None

        d = dist(mob, target)
        home = math.hypot(mob.x - mob.spawn_x, mob.y - mob.spawn_y)

        if home > mob.aggro * LEASH:           # слишком далеко от дома
            mob.state = 'return'
            mob.target = None
            return None

        if mob.state == 'chase':
            if d <= mob.atk_range:
                mob.state = 'attack'
                mob.windup_at = None
                mob.last_atk = max(getattr(mob, 'last_atk', 0), now - ATTACK_CD + FIRST_HIT)
                return None
            # Бежим не В точку игрока, а до дистанции удара: раньше моб
            # вставал прямо в координаты игрока и клиент «телепортировал»
            # его под персонажа.
            stop = mob.atk_range * 0.8
            tx = target.x + (mob.x - target.x) / d * stop
            ty = target.y + (mob.y - target.y) / d * stop
            if getattr(mob, 'anchored', False):          # метеоры башни: бьют рядом, но не ходят
                mob.state, mob.target = 'idle', None
                return None
            return None if rooted else self._step_to(mob, tx, ty, dt, speed)

        if mob.state == 'attack':
            if d > mob.atk_range * 1.2:
                mob.state = 'chase'
                mob.windup_at = None
                return None
            if superskill.mob_mod(mob, 'noatk', now):
                return None
            w = getattr(mob, 'windup_at', None)
            if w is None:
                if now - getattr(mob, 'last_atk', 0) >= ATTACK_CD / superskill.mob_mod(mob, 'aspd', now, 1.0):
                    mob.windup_at = now
                    return ('windup', mob, target, 0)        # замах (05/00), урон — через WINDUP
                return None
            if now - w >= WINDUP:
                mob.windup_at = None
                mob.last_atk = now
                return ('attack', mob, target, self._mob_damage(mob))
            return None

        if mob.state == 'return':
            mob.windup_at = None
            if getattr(mob, 'return_at', None) is None:
                mob.return_at = now
            stuck = now - mob.return_at > RETURN_MAX
            if math.hypot(mob.x - mob.spawn_x, mob.y - mob.spawn_y) < 30 or stuck:
                fx, fy, fz = mob.x, mob.y, mob.z
                mob.x, mob.y, mob.z = mob.spawn_x, mob.spawn_y, mob.spawn_z
                mob.state = 'idle'
                mob.return_at = None
                mob.wander_target = None
                mob.wander_pause_until = now + random.uniform(*WANDER_PAUSE)
                mob.hp = mob.maxhp            # регенерация как в оригинале
                # застрял (стена на пути) — домой напрямую; дальше снова бродит у спавна
                return ('move', mob, (fx, fy, fz), 0) if stuck else ('stop', mob, (mob.x, mob.y, mob.z), 0)
            if rooted:
                return None
            ev = self._step_to(mob, mob.spawn_x, mob.spawn_y, dt, speed)
            if ev is None:                    # путь домой перекрыт — не стоять на месте боя
                mob.return_at = now - RETURN_MAX - 1
            return ev
        return None

    def _wander(self, mob, now, dt):
        """Блуждание в покое (эталон — дамп с оригинала). Только у мобов
        (aggro>0); статичные NPC/объекты стоят. Возвращает событие движения
        ('move', mode=0) или остановки ('stop', mode=2 -> from==to)."""
        if mob.aggro <= 0 or getattr(mob, 'anchored', False):
            return None                        # NPC/объект/метеор — не бродит
        tgt = getattr(mob, 'wander_target', None)
        if tgt is None:
            if now < getattr(mob, 'wander_pause_until', 0.0):
                return None                    # стоит на паузе после отрезка
            mn = getattr(mob, 'map_name', None)
            for _try in range(6):                      # цель — на проходимой клетке (.nav)
                ang = random.uniform(0, 2 * math.pi)
                r = random.uniform(WANDER_MIN, WANDER_MAX)
                tgt = (mob.spawn_x + math.cos(ang) * r,
                       mob.spawn_y + math.sin(ang) * r)
                if not mn or navgrid.walkable(mn, tgt[0], tgt[1]) is not False:
                    break
            else:
                tgt = (mob.spawn_x, mob.spawn_y)
            mob.wander_target = tgt
        if math.hypot(tgt[0] - mob.x, tgt[1] - mob.y) < 6.0:
            mob.wander_target = None
            mob.wander_pause_until = now + random.uniform(*WANDER_PAUSE)
            return ('stop', mob, (mob.x, mob.y, mob.z), 0)
        return self._step_to(mob, tgt[0], tgt[1], dt, WANDER_SPEED)

    @staticmethod
    def _step_to(mob, tx, ty, dt, speed=CHASE_SPEED):
        fx, fy, fz = mob.x, mob.y, mob.z
        d = math.hypot(tx - mob.x, ty - mob.y)
        if d < 1:
            return None
        step = min(d, speed * dt)
        mn = getattr(mob, 'map_name', None)
        nx, ny = mob.x + (tx - mob.x) / d * step, mob.y + (ty - mob.y) / d * step
        if mn and navgrid.blocked(mn, mob.x, mob.y, nx, ny):   # стена: обход
            # карта без .nav (изученная проходимость): сначала — по следу игрока (navgrid.trail_next)
            tp = None if navgrid.has_nav(mn) else navgrid.trail_next(mn, mob.x, mob.y)
            if tp is not None and math.hypot(tp[0] - mob.x, tp[1] - mob.y) > 1                     and not navgrid.blocked(mn, mob.x, mob.y, tp[0], tp[1]):
                dd = math.hypot(tp[0] - mob.x, tp[1] - mob.y)
                st = min(dd, speed * dt)
                nx, ny = mob.x + (tp[0] - mob.x) / dd * st, mob.y + (tp[1] - mob.y) / dd * st
                tx, ty = tp
            elif abs(nx - mob.x) > 0.5 and not navgrid.blocked(mn, mob.x, mob.y, nx, mob.y):
                ny = mob.y                              # вдоль одной оси
            elif abs(ny - mob.y) > 0.5 and not navgrid.blocked(mn, mob.x, mob.y, mob.x, ny):
                nx = mob.x
            else:
                mob.wander_target = None               # тупик: выбрать другую цель
                return None
        mob.x, mob.y = nx, ny
        if mn:                                         # идёт по рельефу (.ter), не по воздуху
            h = terrain.height(mn, mob.x, mob.y)
            if h is not None and abs(h - mob.spawn_z) < 600:
                mob.z = h
        mob.angle = math.atan2(ty - fy, tx - fx)
        return ('move', mob, (fx, fy, fz), 1 if speed > WANDER_SPEED else 0)   # бег / шаг

    @staticmethod
    def _mob_damage(mob):
        """урон моба по игроку. В дампе игрок получал 3..9 от мобов ур.19-24
        и редкие большие удары (§109)."""
        base = 3 + mob.level * 0.25
        return max(1, int(round(random.uniform(base * 0.6, base * 1.4))))

    @staticmethod
    def _respawn(mob):
        mob.x, mob.y, mob.z = mob.spawn_x, mob.spawn_y, mob.spawn_z
        mob.hp = mob.maxhp
        mob.alive = True
        mob.react_clear = None
        mob.state = 'idle'
        mob.target = None


if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from content import Content
    from state import World, Player
    c = Content()
    w = World('berneo', c)
    w.load_mobs()
    p = Player(0x2892, 0, 0, 0, name='Тест')
    # поставим игрока рядом с первым агрессивным мобом
    aggr = [m for m in w.mobs.values() if m.aggro > 0]
    m0 = aggr[0]
    p.x, p.y, p.z = m0.x + 150, m0.y, m0.z
    w.add_player(p)
    ai = MobAI(w)
    print(f"мобов: {len(w.mobs)}, агрессивных: {len(aggr)}")
    print(f"цель-моб: {m0.name} ур.{m0.level} агро={m0.aggro:.0f} "
          f"атака с {m0.atk_range:.0f}")
    print(f"игрок в {dist(m0,p):.0f} единицах\n")
    t = 0
    for i in range(14):
        t += TICK
        for kind, mob, extra, dmg in ai.tick(now=t):
            if kind == 'move':
                print(f"  [{t:4.1f}] {mob.name[:14]:16} {mob.state:7} -> "
                      f"({mob.x:.0f},{mob.y:.0f})  до игрока {dist(mob,p):.0f}")
            elif kind == 'attack':
                print(f"  [{t:4.1f}] {mob.name[:14]:16} АТАКУЕТ игрока, урон {dmg}")
