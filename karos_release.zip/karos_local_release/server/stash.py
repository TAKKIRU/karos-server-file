"""Хранилище: личное (06/1a, 06/1b, 06/1c, 06/1d, 06/2c, 06/2e) и общее аккаунта (06/29, 06/2a,
06/2b, 06/2d). Номера и раскладки — по обработчикам AMo (таблица CClientNet, категория 06) и
записям оригинала (orig_1, orig_hl_Pers4x, remain3_persons).

Вещи хранятся целиком — записью предмета 147 байт (заточка, вставки, особые характеристики,
uid сохраняются), по ячейке хранилища.

C/S 06/2e (CItemStashOpenLevelListPacket, обработчик 0x00656f90; разговор с NPC хранилища):
  C: +0 eid, +4 NPC, +8 u16 0.
  S: +0 eid, +4 NPC, +8 u16 n, n × (u32 LE вид, u32 LE уровень): вид 1 — личное хранилище,
     2 — хранилище гильдии. Уровень 0..3 — сколько дополнительных страниц открыто.
C 06/1c (список, сборщик 0x00544777): +0 eid, +4 NPC, +8, +12, +16 u32 0, +20 u16 0xc6.
S 06/1c (CItemStashListPacket, 0x00656597): +0 eid, +4 0, +8 уровень, +12 вместимость,
  +16 u32 число записей, +20 u16 код (0xc6; 199 — клиент ничего не делает), с +22 записи
  по 146 байт: u32 LE предмет, u16 LE ячейка, затем запись 147 байт с +7 (заточка, uid, кол-во…).
  Оригинал отвечает двумя: сначала вместимость без записей (32 + 8 × уровень: 0x20, 0x38),
  потом записи.
S 06/2b (CItemAccountStashListPacket, 0x00656d3d): та же шапка, записи по 151 байту:
  u32 предмет, u16 ячейка, u32 0, запись 147 байт с +6. Код 0x251 — «Доступен предмет. Принять?».
C/S 06/1a, 06/29 (положить, 0x006563ab / 0x00656b51): +0 eid, +4 NPC, +8 сумка u32,
  +12 ячейка u32, +16 предмет, +20 u64 кол-во, +28 ячейка хранилища, +32 u16 код.
  Ответ — эхо с кодом 0xc6, до него 06/06 опустевшей ячейки сумки и 06/06 карат: плата
  10 (личное) / 100 (общее). Коды: 10 «Недостаточно денег», 0x84 «Этот предмет нельзя хранить».
C/S 06/1b, 06/2a (забрать, 0x006564ea / 0x00656c90): +0 eid, +4 NPC, +8 ячейка хранилища,
  +12 u64 кол-во (FF..FF — всё), +20 u16 код. До эха — 06/06 с вещью в сумке (тот же uid).
C/S 06/2c, 06/2d (переложить внутри хранилища, 0x0065678d / 0x00656e83; сборщик 0x006265d6):
  +0 eid, +4 u32, +8 ячейка-источник, +12 предмет, +16 u64 кол-во, +24 ячейка-цель, +28 u32,
  +32 u32, +36 u64 кол-во, +44 u16 код: 200 (личное) / 0xca (общее) — успех.
C 06/1d (расширить, сборщик 0x005448f1, окно 0x00544da2): цена — FUN_005441ab: уровень 0 — 100,
  1 — 1000, 2 — 10 000; на уровне 3 — «Дальнейшее расширение невозможно».
S 06/1d (CItemStashExtendPacket, 0x006566cd): +0 eid, +4 u32, +8 u16 код (0xc6 — успех,
  10 — «Недостаточно денег»), +10 u32 новый уровень.
Страницы окна (0x004c2e9c): контейнер 0x0f — основная, 0x10/0x11/0x12 — по 8 ячеек,
  открываются уровнями 1/2/3.
"""
import random, struct, time

REC = 147
OK, IGNORE, NO_MONEY, CANT_STORE = 0xc6, 199, 10, 0x84
SWAP_OK, ACC_SWAP_OK = 200, 0xca
CAP_BASE, CAP_PAGE, MAX_LEVEL = 32, 8, 3
ACCOUNT_CAP = 56          # вместимость общего хранилища в данных не найдена — как личное на ур.3
EXTEND_PRICE = {0: 100, 1: 1000, 2: 10000}
FEE_PERSONAL, FEE_ACCOUNT = 10, 100
KIND_PERSONAL = 1
GOLD = 999999


def capacity(level):
    return CAP_BASE + CAP_PAGE * max(0, min(MAX_LEVEL, level))


def new_rec(item, count, durability=0):
    r = bytearray(REC)
    struct.pack_into('<I', r, 2, item)
    struct.pack_into('<II', r, 8, random.getrandbits(32), random.getrandbits(32))
    struct.pack_into('<I', r, 16, count)
    if durability:
        struct.pack_into('<I', r, 0x48, durability)
    return r


def load(stash, durability=None):
    """{ячейка: hex записи | [item, кол-во] (старый формат)} -> {int: bytearray}."""
    out = {}
    for k, v in (stash or {}).items():
        try:
            s = int(k)
        except ValueError:
            continue
        if isinstance(v, str):
            r = bytearray(bytes.fromhex(v)[:REC].ljust(REC, b'\0'))
        elif isinstance(v, (list, tuple)) and len(v) >= 2:
            r = new_rec(int(v[0]), int(v[1]), (durability or {}).get(int(v[0]), 0))
        else:
            continue
        r[0], r[1], r[6] = 0, 0, 0
        out[s] = r
    return out


def legacy(stash):
    return any(not isinstance(v, str) for v in (stash or {}).values())


def dump(recs):
    return {str(s): bytes(r).hex() for s, r in sorted(recs.items())}


def item_of(r):
    return struct.unpack_from('<I', r, 2)[0]


def count_of(r):
    return struct.unpack_from('<I', r, 16)[0]


def set_count(r, n):
    struct.pack_into('<I', r, 16, max(0, n))


def rec146(slot, r):
    return struct.pack('<IH', item_of(r), slot) + bytes(r[7:REC])


def rec151(slot, r):
    return struct.pack('<IHI', item_of(r), slot, 0) + bytes(r[6:REC])


def build_list(eid, recs, level, cap, account=False, with_items=True):
    items = sorted(recs.items()) if with_items else []
    body = struct.pack('>IIIIIH', eid, 0, level, cap if not with_items else 0, len(items), OK)
    pack = rec151 if account else rec146
    return body + b''.join(pack(s, r) for s, r in items)


def build_levels(eid, npc, level):
    return struct.pack('>IIH', eid, npc, 1) + struct.pack('<II', KIND_PERSONAL, level)


def parse_put(pl):
    """06/1a/06/29 -> (NPC, сумка, ячейка, предмет, кол-во, ячейка хранилища)."""
    pl = bytes(pl) + bytes(max(0, 34 - len(pl)))
    eid, npc, cont, cell, item = struct.unpack_from('>IIIII', pl, 0)
    n = struct.unpack_from('>Q', pl, 20)[0]
    sslot = struct.unpack_from('>I', pl, 28)[0]
    return npc, cont, cell, item, n, sslot


def parse_take(pl):
    """06/1b/06/2a -> (ячейка хранилища, кол-во или None — всё)."""
    pl = bytes(pl) + bytes(max(0, 22 - len(pl)))
    sslot = struct.unpack_from('>I', pl, 8)[0]
    n = struct.unpack_from('>Q', pl, 12)[0]
    return sslot, (None if n >= 0x7fffffffffffffff or n == 0 else n)


def with_code(pl, off, code, size):
    b = bytearray(bytes(pl)[:size].ljust(size, b'\0'))
    struct.pack_into('>H', b, off, code)
    return bytes(b)


def put(recs, sslot, rec, n, cap, stackable):
    """Положить n шт. записи rec в ячейку sslot. -> True / False (занято чужим, нет места)."""
    if not (0 <= sslot < cap):
        return False
    cur = recs.get(sslot)
    if cur is not None:
        if not stackable or item_of(cur) != item_of(rec):
            return False
        set_count(cur, count_of(cur) + n)
        return True
    r = bytearray(rec)
    r[0], r[1], r[6] = 0, 0, 0
    set_count(r, n)
    recs[sslot] = r
    return True


def take(recs, sslot, n=None):
    """Забрать из ячейки. -> копия записи с забранным количеством или None."""
    cur = recs.get(sslot)
    if cur is None:
        return None
    have = count_of(cur) or 1
    k = have if n is None else max(1, min(have, n))
    out = bytearray(cur)
    set_count(out, k)
    if k >= have:
        del recs[sslot]
    else:
        set_count(cur, have - k)
    return out


def parse_swap(pl):
    pl = bytes(pl) + bytes(max(0, 46 - len(pl)))
    return struct.unpack_from('>I', pl, 8)[0], struct.unpack_from('>I', pl, 24)[0]


def swap(recs, a, b, cap):
    if a == b or not (0 <= a < cap and 0 <= b < cap) or a not in recs:
        return False
    ra, rb = recs.pop(a), recs.pop(b, None)
    recs[b] = ra
    if rb is not None:
        recs[a] = rb
    return True


def build_extend(eid, npc, code, level):
    return struct.pack('>IIHI', eid, npc, code, level)
