"""Событийные подземелья (EID): «Парящий остров» (Extreme 1002030…1009099) и «Демоническая башня»
(T_darkcliff 2005060…2009099). Таблицы — data/eid.json (tools/eid_tables.py из EIDMain/EIDCondition/…).

Протокол (категория 0x13, разобран по AMo.exe — docs/protocol.md):
  C 13/00 u32 0                      окно событий у Аски (0x004442bc) -> S 13/00 u32 n, n × u32 номер события
  C 13/01 u16 0x20d, u32 событие     заявка (кнопка 0xa0a2, 0x00579b89)  -> S 13/01 u16 код, u32 событие
  C 13/02 u16 0, u32 событие         войти (кнопка 0xa0a3, 0x00579bd1)    -> S 13/02 u16 код, u32 событие
  S 13/03 u32 событие, u32 секунд    длительность этапа: клиент показывает «значение − секунды с кода 0x218»
          (0x0057d30e: [+0xc0] − (часы − [+0xc4])) — слать ПОЛНУЮ длительность, не остаток (остаток
          давал двойную скорость, таймер проскакивал 0 и показывал огромное число)
  S 13/04 u32 событие, u32 строка (команда, 0…), u32 полоса, u32 максимум полосы, u32 B, u32 A, u32 вид
          — строка табло «A : B» (0x00659c99 -> 0x0068ae95 ищет событие по +0 -> 0x005780e7);
          у нас A — очки, B — порог / очки соперника
  S 13/05 u16 код, u32 событие, u32 этап (0 — основной, 4 — финальный)
Коды (0x00687ed6 / 0x0068ba27, строки EIDString):
  0x20d «Отряд игрока %s сформирован», 0x20e «Вы выиграли жребий… войдите, пока не истекло время»,
  0x204 «Проверьте время и дату», 0x20a «Требуется %s» (билет), 0x20b «Проверьте уровень…»,
  0x210 «Сейчас войти нельзя», 0x212 — вход разрешён (окно закрывается),
  0x213 «Начало через %d сек.», 0x214 — табло на N команд, 0x218 — начало этапа (включает таймер),
  0x217 — снять таймер, 0x216 — событие завершено (победа), 0x219 — провал; 0x216/0x217/0x219 выключают
  таймер (0x0068ba27).
Заморозка: на карте события клиент каждый кадр ставит флаг «можно действовать» = (этап >= 0)
(0x006884bb, флаг +0x1c0; без него — «Вы не можете двигаться», строка 37050, и навыки не уходят).
Этап ставит только 0x218, а 0x213/0x214 сбрасывают его в −1. Поэтому на подготовке шлём 0x218 сразу
(таймер показывает время до старта), а 0x213 не шлём вовсе — отсчёт пишем в чат.
Ворота: EIDMain[16] (9900804) — открыть на основном этапе, [34] (9900805) — на финальном; модель
extreme_door_basic в клиенте статичная (FIX, без анимаций) — ворота просто исчезают (04/03).
Сценарий карты (стартеры, волны, ключи, двери) — dungeon.py по events[*].script (tools/eid_tables.py).

Одиночная игра: в оригинале — отряды (остров — 2 команды от 3 игроков, башня — 1 команда от 2), у нас —
одна команда из одного игрока: соперника на острове нет (победа — если набраны очки к концу этапа).
Клиент сам не пустит заявку без отряда — нужна правка EIDMain (tools/patch_eid_solo.py, режим 0).
"""
import json, os, struct, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _j(name):
    try:
        return json.load(open(os.path.join(ROOT, 'data', name), encoding='utf-8'))
    except (OSError, ValueError):
        return {}


DATA = _j('eid.json') or {}
EVENTS = {int(k): v for k, v in (DATA.get('events') or {}).items()}
CONDS = {int(k): v for k, v in (DATA.get('conditions') or {}).items()}

OK_FORMED, OK_WON, BAD_TIME, BAD_TICKET, BAD_LEVEL, BAD_NOW, OK_ENTER = 0x20d, 0x20e, 0x204, 0x20a, 0x20b, 0x210, 0x212
R_COUNT, R_BOARD, R_CLEAR, R_START, R_DONE, R_FAIL = 0x213, 0x214, 0x217, 0x218, 0x216, 0x219
MAIN, FINAL = 0, 4
END_LINGER = 60.0         # после итога (босс убит / время вышло) — минута до переноса домой, отсчёт в чат
# Остров (по просьбе): в таблице порога нет (9999999 — этап до конца таймера, к боссу — команда с бо́льшим
# счётом). У нас путь к боссу открывается, как только команда набрала ISLAND_SCORE; не набрала за время этапа —
# провал. После победы — ISLAND_LINGER секунд отсчёта и перенос в Бернео
ISLAND_SCORE = 30000
ISLAND_LINGER = 30.0
END_SAY = (60, 30, 10, 5, 3, 2, 1)
PREP = 20.0               # после входа — время на бафы и зелья, затем 10 с отсчёта (в чат) и старт

# Награда — по видео оригинала (гайд «Демоническая башня / Парящий остров», 2021): письма «Ваша награда»
# от Karos Online. Первое пришло сразу после полубосса башни / в конце основного этапа острова
# («Получено письмо»); в письмах: Зелье активности ×5, Дух земли ур.2 (башня) или Дух воина ур.2
# (остров) ×n, Экстракт врокиана ×n, Очищенный порошок из руны. «n зависит от уровня подземелья» —
# видно одно значение: башня 71–80 -> 14 духов (= нижний уровень // 5; для других уровней то же
# правило — оценка). Как предметы разложены по двум письмам, в видео не видно. С босса острова в
# видео подобран «Камень магии». Билеты 63058/63059/63061 (EIDMain [45]/[46]) в видео не выдавались.
ACTIVITY, EARTH2, WARRIOR2, VROKIAN, RUNE_POWDER, MAGIC_STONE = 100140025, 63056, 54617, 99996, 63048, 63049
MAIL_TITLE = 'Ваша награда'


def _targets():
    """mapWarpTargetPos: номер -> (карта, x, y, высота или None)."""
    out = {}
    for t in (_j('warps.json') or {}).get('mapWarpTargetPos', []):
        p = t.get('pos') or []
        if len(p) >= 2:
            out[int(t['src'])] = (int(t['dst']), float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else None)
    return out


TARGETS = _targets()


def schedule(ev):
    """Секунды суток стартов события: первый в first_hour, далее каждые period в пределах window."""
    e = EVENTS[ev]
    out, i = [], 0
    while i * e['period'] < e['window']:
        out.append((e['first_hour'] * 3600 + i * e['period']) % 86400)
        i += 1
    return out


def open_now(ev, now=None):
    """Идёт запись (reg_before секунд до старта) — как EventInform: остров 13:55–14:00 и т.д."""
    lt = time.localtime(now or time.time())
    sec = lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec
    days = str(EVENTS[ev].get('days', 1111111))
    if len(days) == 7 and days[(lt.tm_wday + 1) % 7] != '1':        # строка дней с воскресенья
        return False
    return any(0 <= (st - sec) % 86400 <= EVENTS[ev]['reg_before'] for st in schedule(ev))


def body(code, ev, extra=None):
    b = struct.pack('>HI', code, ev)
    return b + struct.pack('>I', extra) if extra is not None else b


def list_for(level):
    """S 13/00: события, подходящие по уровню."""
    ids = [k for k, e in sorted(EVENTS.items()) if e['lo'] <= level <= e['hi']]
    return struct.pack('>I', len(ids)) + b''.join(struct.pack('>I', i) for i in ids)


def check(ev, level, tickets, anytime=False):
    """Заявка C 13/01 -> код ответа (OK_FORMED — принята)."""
    e = EVENTS.get(ev)
    if not e:
        return BAD_NOW
    if not e['lo'] <= level <= e['hi']:
        return BAD_LEVEL
    if not anytime and not open_now(ev):
        return BAD_TIME
    if e.get('ticket') and tickets < 1:
        return BAD_TICKET
    return OK_FORMED


def reward_count(ev):
    return max(1, int(EVENTS[ev]['lo']) // 5)


def reward_mail(ev, part):
    """('mail', заголовок, текст, [(предмет, кол-во)]) — письмо за этап: part 'main' / 'boss'."""
    e, n = EVENTS[ev], reward_count(ev)
    tower = e.get('teams') == 1
    place = 'Демоническая башня' if tower else 'Парящий остров'
    if part == 'main':
        return ('mail', MAIL_TITLE, '%s: основной этап пройден.' % place,
                [(ACTIVITY, 5), (EARTH2 if tower else WARRIOR2, n)])
    return ('mail', MAIL_TITLE, '%s: босс побеждён.' % place, [(VROKIAN, n), (RUNE_POWDER, 1)])


class Run:
    """Ход события для одного игрока (одиночная команда A, строка табло 0)."""

    def __init__(self, ev):
        self.ev = ev
        self.e = EVENTS[ev]
        self.island = self.e.get('teams', 1) >= 2
        self.stage_secs = None
        self.stage = None          # MAIN / FINAL
        self.until = 0.0           # конец этапа
        self.start_at = 0.0        # старт основного этапа (после подготовки и отсчёта)
        self.count_at = 0.0        # когда написать «Начало через 10 с»
        self.final_at = 0.0        # старт финального этапа (после отсчёта)
        self.score = 0
        self.need_killed = False
        self.main_mail = False     # письмо за основной этап уже отправлено
        self.result = None         # 'win' / 'lose'
        self.end_at = 0.0
        self.said = set()          # уже сказанные секунды отсчёта до выхода

    def entry_target(self):
        return self.e['warps'].get('1') or self.e['warps'].get(1)

    def cond(self):
        st = MAIN if self.stage is None else self.stage
        return CONDS.get(int(self.e['stages'][str(st)]), {})

    def raw(self, i, default=0):
        r = self.e.get('raw') or []
        return r[i] if i < len(r) else default

    def need_score(self):
        """Порог очков текущего этапа (0 — без порога). Остров: основной этап — ISLAND_SCORE."""
        need = self.cond().get('score') or 0
        if self.island and (self.stage in (None, MAIN)):
            return ISLAND_SCORE
        return 0 if need >= 9999999 else need

    def final_boss(self):
        """Босс финального этапа (EIDCondition этапа 4: остров — «Белые крылья», башня — Лабан)."""
        return int(CONDS.get(int(self.e['stages'][str(FINAL)]), {}).get('need_npc') or 0)

    # ---- события -> пакеты (cat, sub, тело) и псевдопакеты: ('doors', [NPC]), ('msg', текст),
    #      ('hold', да/нет) — мобы карты стоят, ('sleep'/'wake', [NPC]) — убрать / выпустить,
    #      ('mail', заголовок, текст, [(предмет, n)]), ('loot', [(предмет, n)]) ----
    def begin(self, now, prep=PREP):
        """Игрок на карте: табло (0x214) и сразу этап 0x218 (иначе клиент заморожен — см. docstring
        модуля); таймер табло (13/03) на подготовке показывает время до старта; ворота закрыты, мобы
        стоят (hold). Через prep секунд — «Начало через 10 с» в чат, ещё через 10 с — старт."""
        cd = self.e.get('countdown', 10)
        self.count_at = now + prep
        self.start_at = self.count_at + cd
        out = [(0x13, 0x05, body(R_BOARD, self.ev, MAIN)),
               (0x13, 0x05, body(R_START, self.ev, MAIN)),
               (0x13, 0x03, struct.pack('>II', self.ev, int(prep + cd))),
               ('hold', True)]
        if self.final_boss():
            out.append(('sleep', [self.final_boss()]))   # босс — только на финальном этапе (раньше его
                                                         # убивали на основном, и финал проигрывался)
        out.append(('msg', 'До начала %d с — время на бафы и зелья.' % int(prep + cd)))
        return out

    def _stage(self, stage, now):
        self.stage = stage
        c = self.cond()
        secs = c.get('seconds', 600)
        self.stage_secs = secs
        self.until = now + secs
        self.need_killed = not c.get('need_npc')
        gate = self.raw(16) if stage == MAIN else self.raw(34)
        out = [(0x13, 0x05, body(R_START, self.ev, stage)), self.time_pkt(), self.score_pkt()]
        if self.e.get('teams', 1) >= 2:                  # строка команды B — пустая
            out.append((0x13, 0x04, struct.pack('>7I', self.ev, 1, 0, 1, 0, 0, 0)))
        if stage == MAIN:
            out.append(('hold', False))
            out.append(('msg', 'Начали!'))
            if self.island and self.final_boss():
                out.append(('msg', 'Наберите %d очков за %d мин — откроется путь к боссу «Белые крылья».'
                            % (ISLAND_SCORE, max(1, round(secs / 60)))))
        if stage == FINAL and self.final_boss():
            out.append(('wake', [self.final_boss()]))
        if gate:
            out.append(('doors', [gate]))
        return out

    def time_pkt(self):
        return (0x13, 0x03, struct.pack('>II', self.ev, int(self.stage_secs or self.cond().get('seconds', 600))))

    def score_pkt(self):
        need = self.need_score()                # без порога: «очки : 0»
        cap = need or max(1, self.score)
        return (0x13, 0x04, struct.pack('>7I', self.ev, 0, min(self.score, cap), cap, need, self.score, 0))

    def tick(self, now):
        """-> (пакеты, действие): действие None | ('warp', номер точки) | ('home', номер)."""
        out = []
        if self.result:
            left = self.end_at - now
            for s in END_SAY:
                if left <= s and s not in self.said:
                    self.said.add(s)
                    if left > s - 1:
                        out.append(('msg', 'Возврат в Бернео через %d с.' % s))
            if now >= self.end_at:
                return out, ('home', self.e.get('return_warp'))
            return out, None
        if self.stage is None:
            if self.count_at and now >= self.count_at:
                self.count_at = 0.0
                out.append(('msg', 'Начало через %d с.' % int(self.e.get('countdown', 10))))
            if self.start_at and now >= self.start_at:
                out += self._stage(MAIN, now)
            return out, None
        if self.final_at:
            if now >= self.final_at:
                self.final_at = 0.0
                out += self._stage(FINAL, now)
                return out, self._boss_warp()
            return out, None
        if now >= self.until:
            return self._finish(now, timeout=True)
        return out, None

    def kill(self, npc_id, now):
        """Убит моб: очки по EIDElement текущего этапа, нужный моб этапа."""
        if self.stage is None or self.result or self.final_at:
            return [], None
        c = self.cond()
        pts = (c.get('points') or {}).get(str(npc_id), 0)
        self.score += pts
        out = [self.score_pkt()] if pts else []
        if c.get('need_npc') == npc_id:
            self.need_killed = True
        need = self.need_score()
        if self.stage == MAIN and need and self.score >= need and self.need_killed:
            return out + self._to_final(now), None       # башня: 50 000 и полубосс; остров: 30 000 -> к боссу
        if self.stage == FINAL and self.need_killed:
            res, act = self._finish(now, timeout=False)
            return out + res, act
        return out, None

    def _to_final(self, now):
        """Основной этап пройден: снять таймер (0x217), письмо с наградой, отсчёт EIDMain[33] и финал."""
        wait = self.raw(33) or 10
        self.final_at = now + wait
        out = [(0x13, 0x05, body(R_CLEAR, self.ev, MAIN)), ('msg', 'Финальный этап через %d с.' % wait)]
        if not self.main_mail:
            self.main_mail = True
            out.append(reward_mail(self.ev, 'main'))
        return out

    def _boss_warp(self):
        if self.e.get('teams') == 1:          # башня: «к боссу — через телепорт»; точка следом за входом
            nxt = int(self.entry_target() or 0) + 1        # (mapWarpTargetPos 20050601 -> 20050602)
            if TARGETS.get(nxt, (None,))[0] == self.e['map']:
                return ('warp', nxt)
        return None

    def _finish(self, now, timeout):
        self.result = 'win' if (self.stage == FINAL and not timeout) else 'lose'
        self.end_at = now + (ISLAND_LINGER if self.island else END_LINGER)
        code = R_DONE if self.result == 'win' else R_FAIL
        out = [(0x13, 0x05, body(code, self.ev, self.stage))]
        if self.result == 'win':
            out.append(reward_mail(self.ev, 'boss'))
            if self.e.get('teams', 1) >= 2:
                out.append(('loot', [(MAGIC_STONE, 1)]))       # «Камень магии» с босса острова (видео)
            out.append(('msg', 'Босс побеждён! Награда — на почте.'))
        else:
            out.append(('msg', 'Время вышло.'))
        return out, None
