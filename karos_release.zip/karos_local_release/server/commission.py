"""Комиссионка (CGuiCommission) — «витрина» из справочника предметов.

Опкоды (таблица описаний клиента 0x823b2c + 4*sub, категория 06):
  06/3c список  06/3d добавить  06/3e удалить  06/3f выставить  06/40 снять
  06/41 расчёт  06/42 купить  06/43 комиссия
06/3c S->C (обработчик 0x0065e9cf, разбор 0x0065dab5), payload:
  +0 режим u32 (0/1 — список)  +4 u32  +8 u32  ...  +34 u32  +38 страница u32
  +42 число лотов u32  +46 всего лотов u32 (страниц = всего/10)  +50 код BE16 0xCB
  с +52 лоты переменной длины (порядок чтения клиента):
    u32 лот, u32 предмет, u32 кол-во, u64 цена, u64 срок, 6×u32, u64,
    строка-продавец\\0, 3×u32, 8 байт, 2×u32, 3×(u32,u64), 2×u32, 1 байт, 11×u16
  Назначение полей после «u64 срок» не снято — нули.
06/42 S->C (0x0065ac5f): код BE16 на +8 (кадр +0xe): 0xCB — куплено.
Все числа — BE (читаются ntohl).
"""
import struct

PAGE = 10
OK = 0xCB
SELLER = 'Торговец'.encode('cp1251')


def catalog(items):
    """Что продаётся: снаряжение, расходники, материалы с ценой > 0 (id < 100000)."""
    out = []
    for iid, it in items.items():
        if iid >= 100000 or not it.get('price'):
            continue
        if it['kind'] in (1, 2, 3, 7, 8):
            out.append(iid)
    return sorted(out)


PRICE_OVERRIDE = {'Лотерейный билет': 10000}     # жетон гачи (gacha.TOKEN_PRICE)


def lot_price(it):
    if it.get('name') in PRICE_OVERRIDE:
        return PRICE_OVERRIDE[it['name']]
    p = it.get('price') or 50 * max(1, it.get('lvl', 1))   # без цены у торговца — от уровня
    return max(1, int(p * 1.5))


def lot_bytes(lot, item, count, price, seller=SELLER, enchant=0, opts=(0,) * 6,
              registered=0, expire=0, tail=None):
    """Лот — раскладка из записи оригинала (tools/cap_commission.py): u32 лот, u32 предмет,
    u32 заточка, u32 время выставления, u32 id продавца, u32 0, u32 кол-во, 6×u32 вставки/
    опции, u64 цена, продавец\0, u32 срок, 91 байт нулей."""
    import time as _t
    now = int(_t.time())
    if isinstance(seller, str):
        seller = seller.encode('utf-8')
    return (struct.pack('>7I', lot, item, enchant, registered or now - 3600, 0, 0, count)
            + struct.pack('>6I', *opts) + struct.pack('>Q', price) + seller + bytes(1)
            + struct.pack('>I', expire or now + 7 * 86400) + (tail or bytes(91))[:91].ljust(91, bytes(1)))


def build_lot(iid, it):
    if iid in SNAPSHOT:
        g = SNAPSHOT[iid]
        return lot_bytes(iid, g['item'], g['count'], g['price'], g['seller'], g['enchant'],
                         tuple(g['opts']), tail=bytes.fromhex(g['tail']) if g.get('tail') else None)
    stack = it.get('stack', 1)
    n = 10 if stack > 1 else 1
    return lot_bytes(iid, iid, n, lot_price(it) * n)


# Слепок комиссионки оригинала (запись 23:04, tools/cap_commission.py): лоты игроков.
try:
    import json as _json, os as _os
    SNAPSHOT = {g['lot']: g for g in _json.load(open(_os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), 'data',
        'commission_snapshot.json'), encoding='utf-8'))}
except OSError:
    SNAPSHOT = {}
PRICE_DIV = 1000          # цены игроков оригинала — в 1000 раз меньше (по просьбе)
for _g in SNAPSHOT.values():
    _g['price'] = max(1, _g['price'] // PRICE_DIV)
# постоянный лот: жетоны гачи (Лотерейный билет, gacha.TOKEN) — 10 шт. за 100 000 карат
SNAPSHOT[1] = {'lot': 1, 'item': 99998, 'enchant': 0, 'count': 10, 'price': 100000,
               'seller': 'Торговец', 'opts': [0] * 6, 'cat': 603, 'name': 'Лотерейный билет'}


def build_list(items, cat_ids, page, mode=0):
    total = len(cat_ids)
    lots = cat_ids[page * PAGE:(page + 1) * PAGE]
    head = bytearray(52)
    struct.pack_into('>I', head, 0, mode)
    struct.pack_into('>I', head, 38, page)
    struct.pack_into('>I', head, 42, len(lots))
    struct.pack_into('>I', head, 46, total)
    struct.pack_into('>H', head, 50, OK)
    return bytes(head) + b''.join(build_lot(i, items.get(i, {})) for i in lots)


def find_lot(payload, items):
    """Купить: id лота (= id предмета) где-то в запросе (формат запроса не снят)."""
    for o in range(0, max(0, len(payload) - 3)):
        v = struct.unpack_from('>I', payload, o)[0]
        if v in items and items[v].get('price'):
            return v
    return None


# ---- как в оригинале (запись Karos Genesis 21:47-21:48) ----
# 06/1e C->S (52 байта): +0 NPC BE32, +8 категория BE32 (100 оружие, 200 броня,
# 300 аксессуары/крылья, 400 расходники, 500 флетта-снаряжение, 600 материалы/руны,
# 700 прочее), +16 страница BE32 (с 1), +20 110, +28 13, +32 сортировка (3 цена,
# 4 уровень), +33 порядок (1 по возрастанию, 2 по убыванию), +51 код 0xCB.
# 06/1e S->C: первые 38 байт — эхо запроса, дальше как build_list (+38 страница,
# +42 лотов, +46 всего, +50 0xCB, лоты). Лот = id предмета.
# 06/24 C->S: +0 NPC, +4 лот BE32, +8 код; S->C — то же с кодом 0xCB (+8 BE16).

def in_category(it, code):
    cat, kind = it.get('cat', 0), it.get('kind', 0)
    if code == 100:
        return kind == 1 and cat == 1
    if code == 200:
        return kind == 1 and cat == 2
    if code == 300:
        return kind == 1 and cat not in (1, 2, 4, 5)
    if code == 400:
        return kind in (8, 9) or (cat == 7 and kind != 3)
    if code == 500:
        return kind == 1 and cat in (4, 5)
    if code == 600:
        return kind == 3 or cat in (8, 11)
    if code == 700:
        return not (kind == 1 or kind in (8, 9) or kind == 3 or cat in (7, 8, 11))
    return True


def catalog_all(items):
    """Всё, что можно купить: обычные предметы (id < 100000 и серия 999xxxxxx нет)."""
    return sorted(i for i, it in items.items()
                  if (i < 100000 or it.get('cat') in (58, 68)) and it.get('name')   # + аватары
                  and not it['name'].endswith('.dds') and it.get('kind') in (1, 2, 3, 7, 8, 9))


def parse_request(req):
    """06/1e C->S (52 байта, BE; записи оригинала): +4 поиск (1), +8 раздел, +12 класс (0 все,
    200 паладин, 300 бродяга, 600 ведунья, 800 канонир; подкласс 310/320 — точно), +16/+20
    уровень от/до, +24/+28 заточка от/до, +32 сортировка (1 уровень, 2 заточка, 3 общая
    цена, 4 цена за штуку), +33 порядок
    (1/2), +34 id предмета (поиск по названию), +38 страница (0/1 — первая)."""
    req = bytes(req) + bytes(max(0, 52 - len(req)))
    f = dict(zip(('search', 'cat', 'cls', 'lvmin', 'lvmax', 'enmin', 'enmax'),
                 struct.unpack_from('>7I', req, 4)))
    f.update(sort=req[32], order=req[33], item=struct.unpack_from('>I', req, 34)[0],
             page=max(1, struct.unpack_from('>I', req, 38)[0]))
    if not f['lvmax']:
        f['lvmax'] = 999
    if not f['enmax'] and not f['enmin']:
        f['enmax'] = 99
    return req, f


# Дерево разделов клиента (0x00554300: код -> строка): 100 Оружие (101 двуручный меч,
# 102 копьё, 103 меч, 104 доп. кинжал, 105 доп. меч, 106 лук, 107 дубина/посох, 108 ружьё,
# 109 щит, 110 другое), 200 Доспехи (202 торс, 203 ноги, 204 плечи, 205 рукавицы, 206 обувь,
# 208 другое), 300 Аксес. (301 ожерелье, 302 серьги, 303 кольцо, 304 мини-я), 400 Расход.
# (401 зелье, 402 чарование, 403 другое), 600 Ремесло (601 рыболовство, 602 добыча руды,
# 603 другое), 700 Другое.
WEAPON_SUB = {110: 101, 120: 102, 200: 103, 310: 104, 320: 105, 500: 106, 400: 107, 600: 107,
              810: 108, 820: 108}
ARMOR_SUB = {1: 202, 2: 203, 3: 205, 4: 206}
ACC_SUB = {21: 301, 19: 301, 24: 302, 18: 302, 22: 303, 20: 303}
_SUB_ITEM, _SUB_KC = {}, {}


def _votes(items):
    """Подразделы по слепку оригинала: лоты, снятые запросом подраздела (204, 401…)."""
    if _SUB_ITEM or not SNAPSHOT:
        return
    import collections
    vi, vk = collections.defaultdict(collections.Counter), collections.defaultdict(collections.Counter)
    for g in SNAPSHOT.values():
        c = g.get('cat', 0)
        it = items.get(g['item'])
        if not it or not c % 100:
            continue
        vi[g['item']][c] += 1
        vk[(it.get('kind'), it.get('cat'))][c] += 1
    _SUB_ITEM.update({i: v.most_common(1)[0][0] for i, v in vi.items()})
    _SUB_KC.update({k: v.most_common(1)[0][0] for k, v in vk.items()})


def item_subcat(iid, it, items=None):
    """Подраздел комиссионки для предмета (код дерева клиента)."""
    if items is not None:
        _votes(items)
    if iid in _SUB_ITEM:
        return _SUB_ITEM[iid]
    kind, cat, slot, cls = it.get('kind'), it.get('cat'), it.get('slot'), it.get('cls') or 0
    name = (it.get('name') or '').lower()
    if kind == 1:
        if cat == 1:
            if 'удочк' in name:
                return 601
            if 'кирк' in name:
                return 602
            return WEAPON_SUB.get(cls, 110)
        if cat == 2:
            return 109 if slot == 8 else ARMOR_SUB.get(slot, 208)
        if cat == 3:
            return ACC_SUB.get(slot, 304)
        if cat in (6, 25, 68):                   # маунты на плечах, крылья, аватары крыльев
            return 204
        if cat in (5, 56, 57):                   # флетта-доспехи, костюмы
            return 208
        if cat in (4, 58):                       # флетта-оружие, аватары оружия
            return 110
        if cat == 47:
            return 304
        return 700
    if cat in (47, 48, 49, 50, 51):              # капсулы, корм, билеты питомцев — «Мини я»
        return 304
    if (kind, cat) in _SUB_KC:
        return _SUB_KC[(kind, cat)]
    if 'пропуск' in name or 'метка вход' in name:
        return 700
    if kind in (2, 8, 9) or (kind == 7 and cat == 7):
        if cat in (26, 27, 43, 44, 45, 46):
            return 402
        if cat in (11,) and ('наживк' in name or 'приман' in name):
            return 601
        return 403
    if kind == 3:
        return 603
    return 700


def _cat_ok(sub, code):
    if code % 100 == 0:                          # раздел целиком — с подразделами
        return sub // 100 == code // 100
    return sub == code


def _cls_ok(item_cls, code):
    if not code or not item_cls:                 # класс не выбран / вещь для всех классов
        return True
    if code % 100:                               # подкласс (310, 320…)
        return item_cls == code
    return item_cls // 100 == code // 100


def _ok(f, it, enchant):
    if not _cls_ok(it.get('cls', 0), f['cls']):
        return False
    lvl = it.get('lvl', 0)
    if lvl and not f['lvmin'] <= lvl <= f['lvmax']:   # уровень 0 (расходники) — всегда
        return False
    return f['enmin'] <= enchant <= f['enmax']


def build_list_orig(items, all_ids, req):
    req, f = parse_request(req)
    if f['item']:                                # поиск по названию — конкретный предмет
        snap = [lot for lot, g in SNAPSHOT.items() if g['item'] == f['item']]
        ids = snap or ([f['item']] if f['item'] in items else [])
    else:
        _votes(items)
        snap = [lot for lot, g in SNAPSHOT.items()
                if g['item'] in items
                and _cat_ok(g['cat'] if g.get('cat', 0) % 100 else item_subcat(g['item'], items[g['item']]),
                            f['cat'])
                and _ok(f, items[g['item']], g.get('enchant', 0))]
        # лотов игроков в подразделе нет — витрина из справочника (тот же подраздел)
        ids = snap or [i for i in all_ids if _cat_ok(item_subcat(i, items[i]), f['cat'])
                       and _ok(f, items[i], 0)]
        if snap:                                 # аватары крыльев/оружия — всегда (их мало у игроков)
            have = {SNAPSHOT[l]['item'] for l in snap}
            ids += [i for i in all_ids if items[i].get('cat') in (58, 68) and i not in have
                    and _cat_ok(item_subcat(i, items[i]), f['cat']) and _ok(f, items[i], 0)]

    def price_of(i):
        return SNAPSHOT[i]['price'] if i in SNAPSHOT else lot_price(items[i])

    def unit_of(i):
        return price_of(i) / max(1, SNAPSHOT[i].get('count', 1) if i in SNAPSHOT else 1)

    def lvl_of(i):
        return items.get(SNAPSHOT[i]['item'] if i in SNAPSHOT else i, {}).get('lvl', 0)

    def ench_of(i):
        return SNAPSHOT[i].get('enchant', 0) if i in SNAPSHOT else 0

    def seller_of(i):
        return SNAPSHOT[i].get('seller', '') if i in SNAPSHOT else ''
    # +32 сортировка (записи оригинала: 3 — общая цена, 4 — цена за штуку, порядок 1 по
    # возрастанию / 2 по убыванию; 1 — уровень, 2 — заточка — кнопки окна по порядку)
    key = {1: lambda i: (lvl_of(i), ench_of(i), unit_of(i)),
           2: lambda i: (ench_of(i), lvl_of(i), unit_of(i)),
           3: price_of, 4: lambda i: (unit_of(i), price_of(i)),
           5: seller_of}.get(f['sort'])
    if key:
        ids.sort(key=key, reverse=(f['order'] == 2))
    pages = max(1, (len(ids) + PAGE - 1) // PAGE)
    page = min(f['page'], pages)
    body = build_list(items, ids, page - 1)
    head = bytearray(body[:52])
    head[0:38] = req[0:38]
    struct.pack_into('>I', head, 38, page)
    return bytes(head) + body[52:]


def lot_price_any(it):
    return lot_price(it) if it.get('price') else max(100, 50 * max(1, it.get('lvl', 1)))


# ---- лоты игрока: выставление и продажа (запись Genesis huge_genesis_pack*) ----
# C/S 06/21 (выставить; сборщик 0x005538c0, ответ 0x00659b79): +0 u32 (1 или NPC), +4 сумка,
#   +8 ячейка, +12 кол-во, +16 u64 цена за штуку, +24 u16 код. Ответ — эхо с 0xCB (0x0c —
#   «Невозможно зарегистрироваться сейчас»). Дальше 06/06 ячейки и карат (плата за выставление),
#   06/1f с лотом (режим 2) и 06/25 (4 байта 0).
# S 06/1f (0x0065ec0e): +0 режим (2 — в продаже, 3 — продан: «Предмет [ %s ] продан.»),
#   +4 1, +8 1, +12 лот, +16 предмет, +20 заточка, +24 u64 цена за штуку, +32 u64 кол-во,
#   +40 6×u32 вставки, +64 u64 сумма, +72 продавец\0, u32 срок (выставление + 6 дней), до 172 байт.
#   При входе оригинал присылает 06/25 и 06/1f со всеми лотами (режимы 2 и 3).
# S 06/20 (0x0065adc0): +0 режим, +4 n, n × u32 LE лот — убрать лоты из вкладки режима.
# C 06/22 (снять лот, сборщик 0x00559912): +0 u32, +4 u32, +8 u32, +12 u16; ответ (0x00659bec):
#   код u16 на +8, 0xCB — успех.
# C/S 06/23 (расчёт, 0x0065d9e4): C «00 00», S u16 0xCB; затем 06/06 карат и 06/20 режим 3.
#   Запись: продано на 10 700 000, получено 10 165 000 — комиссия 5%.
# Плата за выставление — SellAgencyCommission.lod (номер -> карат): 1, 2 — 10; 3, 4 — 20; 5, 6 — 50;
#   7, 8 — 100; 9, 10 — 170; 11, 12 — 260; 13, 14 — 370; 15, 16 — 500; 17, 18 — 650; 19, 20 — 820.
#   В записи лот на 700 000 стоил 10, на 5 000 000 и 10 000 000 — 20: номер = число цифр суммы − 4
#   (подобрано по записи).
# Покупателей в одиночной игре нет: лот «покупает» рынок — по цене не выше 3 цен комиссионки
#   (lot_price_any) через время, растущее с ценой; дороже — не продаётся (лот можно снять).
REG_OK, REG_FAIL = 0xCB, 0x0C
MODE_SALE, MODE_SOLD = 2, 3
SETTLE_FEE = 0.05
LOT_DAYS = 6
MAX_LOTS = 10
REG_FEE = {1: 10, 2: 10, 3: 20, 4: 20, 5: 50, 6: 50, 7: 100, 8: 100, 9: 170, 10: 170, 11: 260,
           12: 260, 13: 370, 14: 370, 15: 500, 16: 500, 17: 650, 18: 650, 19: 820, 20: 820}
MY_LOT_LEN = 172


def reg_fee(total):
    return REG_FEE[max(1, min(20, len(str(max(1, int(total)))) - 4))]


def parse_register(pl):
    pl = bytes(pl) + bytes(max(0, 26 - len(pl)))
    a, cont, cell, n = struct.unpack_from('>4I', pl, 0)
    return a, cont, cell, n, struct.unpack_from('>Q', pl, 16)[0]


def build_my_lot(mode, lot, rec, count, price, seller, expire):
    item = struct.unpack_from('<I', rec, 2)[0]
    socks = struct.unpack_from('<6I', rec, 24) if len(rec) >= 48 else (0,) * 6
    if isinstance(seller, str):
        seller = seller.encode('utf-8')
    b = (struct.pack('>6I', mode, 1, 1, lot, item, rec[7] if len(rec) > 7 else 0)
         + struct.pack('>QQ', price, count) + struct.pack('>6I', *socks)
         + struct.pack('>Q', price * count) + seller + b'\0' + struct.pack('>I', expire))
    return b[:MY_LOT_LEN].ljust(MY_LOT_LEN, b'\0')


def build_removed(mode, lots):
    return struct.pack('>II', mode, len(lots)) + b''.join(struct.pack('<I', x) for x in lots)


def sale_delay(price, fair, rng):
    """Через сколько секунд рынок купит лот, или None — слишком дорого."""
    ratio = price / float(max(1, fair))
    if ratio > 3:
        return None
    base = 30 + 60 * rng.random() if ratio <= 1 else 60 + 900 * (ratio - 1)
    return base * (0.8 + 0.4 * rng.random())


def lot_view(lot):
    """Запись лота игрока (dict из accounts.json) -> (rec, count, price)."""
    return bytes.fromhex(lot['rec']), lot['count'], lot['price']
