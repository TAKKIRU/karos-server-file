"""Сервер-эмулятор Karos — точка входа.

Три стадии входа (§70) + генеративный мир из состояния (§76).
Стадии по портам: 10001 гейт -> 10110 mid -> 10101 игра.

Отличие от login_server.py (прототип): мир наполняется из СОСТОЯНИЯ
(Content + World), а не только воспроизводит дамп. world_core — несущая
для пакетов с неразобранной раскладкой.
"""
import socket, struct, os, sys, json, threading, time, re, random, math

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from content import Content
from state import World, Player, Entity
from combat import (Combat, build_damage, build_damage_multi, build_hp, parse_attack, ATK_NORMAL, ATK_CRIT, ATK_MISS, ATK_BLOCK, ATK_BLOCK_FULL,
                    build_attack_start, ack_attack_start, ENT_PLAYER, ENT_MOB)
from equip import Equipment, Stats, parse_wear, parse_putoff, build_wear_reply, build_stats
from character import Character, parse_create
import questlog              # квесты (quests.py — старый неиспользуемый модуль, не подключается)
import dungeon
import eid as eidmod             # событийные подземелья (имя eid занято локальными переменными)
from accounts import Account
from ai import MobAI, TICK
from inventory import (Inventory, build_putin, apply_equipped, empty_rec,
                       build_pickup_notice, GOLD, build_putout, parse_slot_req,
                       set_bag_sizes, BAG_EQUIP_SLOTS)
import loot
import devtools
import buffs
import gacha
import pets
import enchant
import itemroll
from devtools import DEV
import progression
import statcalc
import costume
import hair                  # причёски и цвет волос (06/5b)
import charstats
from progression import PlayerStats
import commission
import gxpshop
import crafting as craft
import terrain
import transform
import postbox
import stash
import inventory
import superskill
import mobdebuff
import consumables
import soulstone
import navgrid
import eventdiary
import gather
import gifts
from ground import Ground, build_drop, build_hide
COMM_CAT = commission.catalog(loot.ITEMS)
COMM_ALL = commission.catalog_all(loot.ITEMS)
GACHA = gacha.Gacha(loot.ITEMS)
itemroll.init(loot.ITEMS)   # 06/1e — все категории
set_bag_sizes(loot.ITEMS)
inventory.set_stack_sizes(loot.ITEMS)
# «Малая сумка» (12 ячеек, 30 дней — истекала сразу) -> вечная «Элитная кожаная
# сумка» на 32 ячейки: сумки на 30 в itemBase нет, вместимость задаёт клиент
BAG_REPLACE = {69012: 69006,
               69001: 69010, 69011: 69010}   # сумки на 12 (Подержанная кожаная, Из кожи кабана) -> на 48
ITEM_PERIODS = {i: v['period'] for i, v in loot.ITEMS.items() if v.get('period')}      # всё, что продаётся в комиссионке
import threading as _th

SRV = HERE   # шаблоны лежат рядом с сервером
# Категории исходящих пакетов, которые пишем в лог С СОДЕРЖИМЫМ (первые 64
# байта): бой (05), статусы/HP/опыт (08), предметы (06), NPC/квесты (09).
# Движение (04) и heartbeat (0b) — без hex, их десятки тысяч.
LOG_OUT_HEX = {0x05, 0x06, 0x08, 0x09}
ST = json.load(open(os.path.join(SRV, 'stage_templates.json')))
GATE, MID, GAME, CARDS = ST['gate'], ST['mid'], ST['game'], ST['cards']
WORLD_CORE = json.load(open(os.path.join(SRV, 'world_core.json')))
# Реальные шаблоны персонажа 1-го уровня (нулевой опыт), извлечённые из
# свежего дампа. Нужны, потому что world_core-шаблоны — от персонажа 2 lvl
# с накопленным опытом, из-за чего клиент показывал ур.2 и забитый опыт.
_L1 = json.load(open(os.path.join(SRV, 'level1_templates.json')))
W0205 = bytes.fromhex(_L1['w0205'])   # 02/05 данные мира
G0801 = bytes.fromhex(_L1['g0801'])   # 08/01 гейдж героя
S0802 = bytes.fromhex(_L1['s0802'])   # 08/02 статы (реальный 1 lvl)
G0800 = bytes.fromhex(_L1['g0800'])   # 08/00 HP/MP гейдж
# Расход маны навыков (tools/skill_mp.py из skillLevel.lod): {id: {уровень: MP}}
try:
    SKILL_MP = json.load(open(os.path.join(os.path.dirname(SRV), 'data', 'skill_mp.json'),
                              encoding='utf-8'))
except OSError:
    SKILL_MP = {}


def skill_mp_cost(sid, level=1):
    lv = SKILL_MP.get(str(sid), {})
    return lv.get(str(level)) or lv.get('1') or 0
# Боевые шаблоны (05/02 урон, 08/06 HP сущности) — их НЕТ в world_core,
# из-за чего урон/HP клиенту не отправлялись. Взяты из свежего дампа.
_CT = json.load(open(os.path.join(SRV, 'combat_templates.json')))
T0502 = bytes.fromhex(_CT['0502'])
T0806 = bytes.fromhex(_CT['0806'])
T0500 = bytes.fromhex(_CT['0500']) if _CT.get('0500') else None
# Карточки по классам (из реального сервера): класс -> payload карточки.
# Класс задаётся на +9 (u32le): 100/200 мечник|паладин, 300 бродяга,
# 400 чародейка, 500 лучница, 600 ведунья, 800 канонир.
CLASS_CARDS = json.load(open(os.path.join(SRV, 'class_cards.json')))

# Стартовое снаряжение по классам. Все шаблоны (02/01, 02/05, 04/02, 06/05…)
# записаны с персонажа-ведуньи и несут ЕЁ вещи: броня 42001..43201 + оружие
# 16001. Раньше любой класс входил с оружием ведуньи — у бойцов ближнего боя
# не было анимаций стойки/бега/удара («вертикальное скольжение»), обычная
# атака не начиналась. Комплекты классов берём из карточек реального
# сервера (class_cards.json): 4 вещи брони @132..144 и оружие @156 (u32 LE).
WITCH_GEAR = (42001, 42401, 42801, 43201, 16001)


def _card_gear(hexcard):
    b = bytes.fromhex(hexcard)
    return tuple(struct.unpack_from('<I', b, o)[0] for o in (132, 136, 140, 144, 156))


CLASS_GEAR = {int(k): _card_gear(v) for k, v in CLASS_CARDS.items()}
# Паладин (200): карточки с реального сервера нет. По itemBase: оружие 5001
# «Small Sword» — модель HKF_ (женщина-рыцарь, как паладин в игре); 1001/3001 —
# HAM_ (мужчина, класс 100). Броня по шагу классов 32001/34001/36001… -> 34001.
CLASS_GEAR.setdefault(200, (34001, 34401, 34801, 35201, 5001))

# Стартовый навык класса. Шаблоны несут навык ведуньи 11001 (05/05 список
# навыков, 02/05 панель) — у других классов он «не подходит к оружию».
# Навыки идут блоками по 2000 на класс: 100->1001 («Powerful Strike» в
# skillBase), 600->11001 (ведунья) => класс N*100 -> (2N-1)*1000+1.
WITCH_SKILL = 11001


# Первый навык дерева класса — из расшифрованных SkillTree_<класс>.lod
# (tools/lod_decode.py). Совпадает с (2N-1)*1000+1, кроме канонира (15003).
CLASS_SKILL = {100: 1001, 200: 3001, 300: 5001, 400: 7001,
               500: 9001, 600: 11001, 800: 15003}


def base_cls(cls):
    """Базовый класс: 310/311/322 -> 300 (для стартовых вещей и навыка)."""
    return (int(cls) // 100) * 100


def _load_class_change():
    """classChange.lod_rus (режим 1): u32 число, записи по 6×i32:
    [новый класс, ступень, из класса, уровень, золото, нужный предмет].
    Ступень 0 — смена класса (100 -> 110/120 на 10 ур., 110 -> 111/112 на 45),
    1 и 2 — повышение ранга внутри класса (25/40, 60/75 ур.)."""
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(SRV), 'tools'))
        from lod_decode import decode
        d = decode(open(os.path.join(os.path.dirname(SRV), 'ResUnpak', 'Interface', 'IE_Lod',
                                     'classChange.lod_rus'), 'rb').read(), 1)
    except (OSError, ImportError):
        return []
    n = struct.unpack_from('<I', d, 0)[0]
    return [dict(zip(('to', 'step', 'frm', 'level', 'gold', 'item'),
                     struct.unpack_from('<6i', d, 4 + k * 24))) for k in range(n)]


CLASS_CHANGE = _load_class_change()
# Золотая рыбка (gambleGoldFish.lod -> tools/gamble_table.py -> data/gamble.json)
try:
    GAMBLE = json.load(open(os.path.join(os.path.dirname(SRV), 'data', 'gamble.json'), encoding='utf-8'))
except (OSError, ValueError):
    GAMBLE = {}
G_OK, G_BAGFULL, G_LACK, G_FAIL = 0x69, 0x0b, 0x6b, 0x6c


def class_change_rule(cur_cls, new_cls):
    """Правило смены cur -> new (ступень 0) или повышения ранга (new == cur)."""
    for r in CLASS_CHANGE:
        if r['to'] == new_cls and r['frm'] == cur_cls:
            return r
    return None


def class_skill(cls):
    return CLASS_SKILL.get(base_cls(cls), WITCH_SKILL)


# Вторая рука. Паладин: стартовый навык 3001 «Shield bash» требует щит
# (маска 32768 = тип 15); щит 29001 «Buckler» (класс 200) — из itemBase.
CLASS_OFFHAND = {200: 29001}
OFFHAND_SLOT = 8          # ПРЕДПОЛОЖЕНИЕ: слот рядом с оружием (оружие = 7)
GEAR_BASE = {'card': 128, '0205': 123, 'appear': 68}   # смещение слота 0
PAIR_SLOTS = {22: 23, 24: 25}   # второе кольцо / вторые серьги (оригинал Pers4x: 56703 в 22 и 23)


def add_offhand(payload, kind, cls):
    item = CLASS_OFFHAND.get(base_cls(cls))
    if not item:
        return payload
    pl = bytearray(payload)
    off = GEAR_BASE[kind] + 4 * OFFHAND_SLOT
    if len(pl) >= off + 4 and struct.unpack_from('<I', pl, off)[0] == 0:
        struct.pack_into('<I', pl, off, item)
    return bytes(pl)


INV_REC = 147     # 06/05: +4 ?, +5 число записей, с +6 записи по 147 байт:
                  # [контейнер 0=надето/1=сумка][слот][item LE32][слот][0]...


def saved_equipped(eid):
    """Надетые вещи из сохранённого инвентаря персонажа (или None)."""
    ch = ACCOUNT.get(eid) if eid is not None else None
    if not ch or not ch.get('inv'):
        return None
    eq = Inventory.from_saved(b'\0' * 6, ch['inv']).equipped()
    # вещь не своего слота (старая «Малая сумка» в торсе) в облик не попадает —
    # её переложит fix_equipped() при входе, а 02/05 уходит раньше
    def ok(sl, it):
        info = loot.ITEMS.get(it, {})
        if info.get('cat') == 13:
            return sl in BAG_EQUIP_SLOTS
        return not info.get('slot') or info['slot'] == sl or sl == 8 or PAIR_SLOTS.get(info['slot']) == sl
    return {sl: it for sl, it in eq.items() if ok(sl, it)}


def saved_enchants(eid):
    """{слот: заточка} надетого (байты после массива слотов в 02/05/04/02/карточке)."""
    ch = ACCOUNT.get(eid) if eid is not None else None
    if not ch or not ch.get('inv'):
        return {}
    iv = Inventory.from_saved(b'\0' * 6, ch['inv'])
    return {r[1]: r[7] for r in iv.recs if r[0] == 0}


def dress(payload, kind, cls, eid=None):
    """Одеть пакет (карточка/02/05/04/02): классовые вещи, щит, а если у
    персонажа уже есть сохранённый инвентарь — ровно то, что на нём надето."""
    pl = add_offhand(swap_gear(payload, cls), kind, cls)
    eq = saved_equipped(eid)
    if eq is not None:
        pl = apply_equipped(pl, GEAR_BASE[kind], eq, slots=range(1, 31),
                            enchants=saved_enchants(eid))
    return pl


def dress_own(payload, kind, eid):
    """Импортированный персонаж: облик оригинала, но вещи — те, что надеты сейчас."""
    eq = saved_equipped(eid)
    if eq is None:
        return payload
    return apply_equipped(payload, GEAR_BASE[kind], eq, slots=range(1, 31),
                          enchants=saved_enchants(eid))


def add_offhand_inventory(payload, cls):
    """Добавить вторую руку (щит паладина) в список инвентаря 06/05 как
    надетую вещь — копия записи оружия (слот 7) со слотом OFFHAND_SLOT."""
    item = CLASS_OFFHAND.get(base_cls(cls))
    if not item or len(payload) < 6:
        return payload
    pl = bytearray(payload)
    n = pl[5]
    for i in range(n):
        o = 6 + i * INV_REC
        if o + INV_REC > len(pl):
            break
        if pl[o] == 0 and pl[o + 1] == 7:              # надетое оружие
            rec = bytearray(pl[o:o + INV_REC])
            rec[1] = OFFHAND_SLOT
            struct.pack_into('<I', rec, 2, item)
            rec[6] = OFFHAND_SLOT
            end = 6 + n * INV_REC
            pl[end:end] = rec
            pl[5] = n + 1
            break
    return bytes(pl)


def swap_gear(payload, cls):
    """Заменить вещи и стартовый навык ведуньи из шаблона на классовые."""
    gear = CLASS_GEAR.get(base_cls(cls), WITCH_GEAR)
    if base_cls(cls) == 600 or gear == WITCH_GEAR:
        return payload
    pl = bytes(payload)
    for old, new in zip(WITCH_GEAR, gear):
        pl = pl.replace(struct.pack('<I', old), struct.pack('<I', new))
    pl = pl.replace(struct.pack('<I', WITCH_SKILL), struct.pack('<I', class_skill(cls)))
    return pl


WTPL = {}
for _h in WORLD_CORE:
    _b = bytes.fromhex(_h)
    WTPL.setdefault((_b[0], _b[1]), _b[6:])

# шаблон появления МОБА: 04/02 с маркером 00 01 (не игрок 01 00)
PLAYER_TPL = None
for _h in WORLD_CORE:
    _b = bytes.fromhex(_h)
    if (_b[0], _b[1]) == (0x04, 0x02) and _b[6] == 0x01 and _b[7] == 0x00:
        PLAYER_TPL = _b[6:]
        break

MOB_TPL = None
for _h in WORLD_CORE:
    _b = bytes.fromhex(_h)
    if (_b[0], _b[1]) == (0x04, 0x02) and _b[6] == 0x00 and _b[7] == 0x01:
        MOB_TPL = _b[6:]
        break

# ТОЧНАЯ последовательность входа в мир с оригинального сервера (дамп play1).
# Реплей слал ещё 10 лишних пакетов из поздней части записи — из-за них
# всплывали окна (награды за вход) прямо на экране загрузки.
ENTER_SEQUENCE = [
    (0x0a, 0x0f), (0x04, 0x04), (0x0f, 0x11), (0x16, 0x01),
    (0x08, 0x07), (0x08, 0x08), (0x09, 0x02), (0x09, 0x04),
    (0x05, 0x05), (0x05, 0x0c), (0x08, 0x02), (0x08, 0x01),
    (0x08, 0x00),
    # 06/05 список инвентаря: в дампе с оригинала идёт сразу после 08/00.
    # Без него окно персонажа пустое (слоты экипировки/сумка без вещей).
    (0x06, 0x05),
    (0x08, 0x0f), (0x08, 0x09),
]
# ЭКСПЕРИМЕНТ: после добавления 06/05 навыки стали серыми у всех классов.
# KAROS_NO_INV=1 в окружении — не слать 06/05 (проверить эту гипотезу).
if os.environ.get('KAROS_NO_INV') == '1':
    ENTER_SEQUENCE = [op for op in ENTER_SEQUENCE if op != (0x06, 0x05)]

CONTENT = Content()
ACTIVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'active_account.txt')


def account_ids():
    try:
        data = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'accounts.json'),
                              encoding='utf-8'))
        return sorted(k for k in data if ':' not in k)
    except (OSError, ValueError):
        return ['default']


def set_account(aid):
    """Сменить аккаунт (персонажи + хранилище аккаунта). Действует с выбора персонажа."""
    global ACCOUNT
    ACCOUNT = Account(aid)
    try:
        open(ACTIVE_FILE, 'w', encoding='utf-8').write(aid)
    except OSError:
        pass
    print(f"     АККАУНТ: {aid} ({len(ACCOUNT.chars)} перс.)", flush=True)
    return aid


try:
    _active = open(ACTIVE_FILE, encoding='utf-8').read().strip() or 'default'
except OSError:
    _active = 'default'
ACCOUNT = Account(_active)
DEFAULT_MAP = 'berneo'
DEFAULT_MAP_ID = 19003
MAP_NAMES = {mid: m['name'] for mid, m in CONTENT.maps.items()}
try:
    WARPS = json.load(open(os.path.join(os.path.dirname(SRV), 'data', 'warp_gates.json'),
                           encoding='utf-8'))      # tools/warps.py
except OSError:
    WARPS = {'gates': {}, 'targets': {}}
# Точки телепорта, которые в таблице клиента лежат вне меша карты (по сетке пола из меша, tools/map_floor.py):
# номер -> (x, z, высота пола). «Родовая гробница Вастиана» 29004 (ruin01) — (2865, 596): ближайший пол в 500 к
# западу, комната x 2000–2300, z 500–900, пол 2106–2180 — игрок стоял в пустоте рядом с картой.
# «Старая Волансия» 29013 (Labyrinth_02) — в таблице (0, 0), угол карты; точка прибытия карты (правила NeoAsmara
# arrival) — (636, 302), высота 100.
TARGET_FIX = {29004: (2300.0, 650.0, 2180.0), 29013: (635.95, 302.03, 100.12)}
for _tid, (_x, _z, _h) in TARGET_FIX.items():
    if str(_tid) in WARPS['targets']:
        WARPS['targets'][str(_tid)].update(x=_x, z=_z, y=_h)
_EID_MAPS = {_ev['map'] for _ev in eidmod.EVENTS.values()}
for _tid, _t in eidmod.TARGETS.items():         # точки карт событий EID: входы команд, точка у босса башни
    if _t[0] in _EID_MAPS and str(_tid) not in WARPS['targets']:
        WARPS['targets'][str(_tid)] = {'map': _t[0], 'x': _t[1], 'z': _t[2], 'name': 'EID'}


def build_zone(eid, map_id):
    """04/04 CMoveZone (обработчик 0x006669db), 17 байт как в дампе:
    +0 eid BE32, +4 карта BE32. Для своего eid клиент меняет карту: убирает
    чужие сущности, грузит зону. При входе в мир шлётся с картой входа.
    Подземелье (запись оригинала, колокольня/катакомбы): +8 01, +9 группа входа, +13 карта."""
    return struct.pack('>II', eid, map_id) + dungeon.zone_tail(map_id)


def map_entry(map_id):
    """Точка входа на карту без своей точки назначения (подземелья, 04/07 с
    номером карты): рядом с воротами-выходом этой карты, иначе — любая точка
    назначения на ней."""
    name = MAP_NAMES.get(map_id, '')
    for g in WARPS['gates'].values():
        if g['map'] == map_id:
            x1, z1, x2, z2 = g['box']
            cx, cz = ((x1 + x2) / 2, (z1 + z2) / 2) if x2 or z2 else (x1, z1)
            return {'map': map_id, 'x': cx + 250, 'z': cz + 250, 'name': f'{name} (вход)'}
    for t in WARPS['targets'].values():
        if t['map'] == map_id:
            return t
    return None


HEIGHTS_FILE = os.path.join(os.path.dirname(SRV), 'data', 'heights_learned.json')
HEIGHT_CELL = 200
try:
    HEIGHTS = json.load(open(HEIGHTS_FILE, encoding='utf-8'))
except (OSError, ValueError):
    HEIGHTS = {}
HEIGHTS_DIRTY = [False]
# Пол карт без спавнов — из меша карты (tools/map_floor.py -> data/floor_heights.json). Прежние
# «130» в лаборатории — плоскость ПОД картой (комнаты на 200–290), по ней ходил провалившийся.
MAP_FLOOR = {}
try:
    FLOORS = json.load(open(os.path.join(os.path.dirname(SRV), 'data', 'floor_heights.json'),
                            encoding='utf-8'))
except (OSError, ValueError):
    FLOORS = {}
for _m in FLOORS:                       # выученное по ходьбе на этих картах — неверно (см. выше)
    HEIGHTS.pop(_m, None)
FLOOR_DROP = 25                         # ставим чуть выше пола: клиент сам опускает на пол


def mesh_floor(map_name, x, z):
    """Пол из меша: самая частая высота вершин в клетках 3×3 вокруг точки (или None)."""
    g = FLOORS.get(map_name)
    if not g:
        return None
    cell = g['cell']
    cx, cz = int(x // cell), int(z // cell)
    cnt = {}
    for r in range(0, 4):                          # пусто рядом — ищем дальше (до 3 клеток)
        for dx in range(-1 - r, 2 + r):
            for dz in range(-1 - r, 2 + r):
                for h, n in g['h'].get(f'{cx + dx},{cz + dz}', []):
                    cnt[h] = cnt.get(h, 0) + n
        if cnt:
            return float(max(cnt.items(), key=lambda kv: kv[1])[0])
    return None


def learn_height(map_name, x, y, z):
    """Высота, на которой клиент ИДЁТ (04/01: смещение по плоскости, высота «откуда» =
    «куда»), — в сетку 200×200. При падении сквозь карту клиент шлёт ту же точку с
    убывающей высотой — такое не запоминаем."""
    cell = f"{int(x // HEIGHT_CELL)},{int(y // HEIGHT_CELL)}"
    m = HEIGHTS.setdefault(map_name, {})
    if m.get(cell) is None or abs(m[cell] - z) > 0.5:
        m[cell] = round(z, 1)
        HEIGHTS_DIRTY[0] = True


def save_heights():
    if HEIGHTS_DIRTY[0]:
        HEIGHTS_DIRTY[0] = False
        try:
            json.dump(HEIGHTS, open(HEIGHTS_FILE, 'w', encoding='utf-8'), separators=(',', ':'))
        except OSError:
            pass


def learned_height(map_name, x, z):
    m = HEIGHTS.get(map_name)
    if not m:
        return None
    cx, cz = int(x // HEIGHT_CELL), int(z // HEIGHT_CELL)
    best = None
    for r in range(0, 4):                      # ближайшая клетка в радиусе 3
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if max(abs(dx), abs(dz)) != r:
                    continue
                v = m.get(f"{cx + dx},{cz + dz}")
                if v is not None and (best is None or v > best):
                    best = v                   # из нескольких — верхний пол (падать вниз безопасно)
        if best is not None:
            return best
    return None


def ground_height(map_name, x, z, default):
    """Высота земли. Открытые карты — рельеф из .ter (terrain.py); если рядом точка спавна или
    место, где ходил клиент, выше рельефа (город Центри-Хейл стоит на платформе +140–200) —
    берём её. Карты без рельефа — пол из меша, выученная высота или ближайшая точка спавна."""
    t = terrain.height(map_name, x, z)
    best, h = None, default
    for s in CONTENT.spawns.get(map_name, []):
        tile = s.get('tile', 0)
        ts = CONTENT.tile_size(map_name)
        sx, sz = s['x'] + (tile % 64) * ts, s['z'] + (tile // 64) * ts
        d = (sx - x) ** 2 + (sz - z) ** 2
        if d < 1e10 and (best is None or d < best):
            best, h = d, s['y']
    if t is not None:
        top = t
        if best is not None and best < 800 ** 2 and h > t + 30:
            top = h
        lh = learned_height(map_name, x, z)
        if lh is not None and t + 30 < lh < t + 400:
            top = max(top, lh)
        return top + 5
    if not CONTENT.spawns.get(map_name):
        f = mesh_floor(map_name, x, z)
        if f is not None:
            return f + FLOOR_DROP
        f = learned_height(map_name, x, z)
        if f is not None:
            return f + 5
        if map_name in MAP_FLOOR:
            return MAP_FLOOR[map_name] + 5
        return default
    return h


SPAWN_XYZ = (9775.0, 8124.8, 672.7)   # старт из шаблона 02/05 (§76)
PLAYER_NAME = os.environ.get('KAROS_NAME', 'Герой')   # имя создаётся НАМИ


def frame(cat, sub, payload, seq):
    return struct.pack('>I', 6 + len(payload)) + bytes([cat, sub, 0, 0]) \
        + struct.pack('>H', seq) + payload


def patch_addr(hexpl, port):
    pl = bytearray(bytes.fromhex(hexpl))
    i = 0
    while i < len(pl) - 5:
        if pl[i] == 0x55 and pl[i+1] == 0x77 and pl[i+2] == 0x95:
            pl[i], pl[i+1], pl[i+2], pl[i+3] = 127, 0, 0, 1
            pl[i+4] = port & 0xff; pl[i+5] = (port >> 8) & 0xff
            i += 6
        else:
            i += 1
    return bytes(pl)


def recv_frames(buf):
    out = []
    while len(buf) >= 4:
        n = struct.unpack('>I', buf[:4])[0]
        if n == 0 or n > 0x100000 or len(buf) < 4 + n:
            break
        out.append(buf[4:4 + n]); buf = buf[4 + n:]
    return out, buf


# ---- сборка пакетов из состояния (§76) ----

def raw_of(player_or_ch, op):
    """Сырой пакет персонажа из оригинала ('raw' в аккаунте) или None."""
    raw = getattr(player_or_ch, 'raw', None)
    if raw is None and isinstance(player_or_ch, dict):
        raw = {k: bytes.fromhex(v) for k, v in (player_or_ch.get('raw') or {}).items() if v}
    return (raw or {}).get(op)


def base_attrs(player, raw_only=False):
    """Своя база атрибутов (сила, ловкость, живучесть, интеллект, мудрость): по классу и рангу
    (statcalc.class_attrs — раса + прибавки классов за ступени). У импортированного — 08/02
    оригинала +6 плюс ступени, пройденные уже здесь (ранг в записи — подбором: при каком ранге
    class_attrs даёт ровно эти атрибуты); raw_only — как в записи (для калибровки)."""
    cls, rank = getattr(player, 'cls', 600), getattr(player, 'rank', 0)
    r82 = raw_of(player, '08/02')
    if r82 and len(r82) >= 16:
        raw = list(struct.unpack_from('<5H', r82, 6))
        r25 = raw_of(player, '02/05')
        if raw_only or not r25 or len(r25) < 8:
            return raw
        cls0 = struct.unpack_from('<H', r25, 4)[0]
        rank0 = next((r for r in range(3) if statcalc.class_attrs(cls0, r) == raw), None)
        now = statcalc.class_attrs(cls, rank)
        if rank0 is None or now is None or (cls, rank) == (cls0, rank0):
            return raw
        then = statcalc.class_attrs(cls0, rank0)
        return [a + max(0, n - t) for a, n, t in zip(raw, now, then)]
    return statcalc.class_attrs(cls, rank) or statcalc.start_attr(cls)


FLETA_OFF = 905   # 02/05: +905 стихия группы 1, +909 группы 2, +917 / +921 очки (записи оригинала)


def fleta_groups(player, raw_only=False):
    """Флетта: {группа: (стихия, вложенные очки)}. Группа 1 — 2 стихии, группа 2 — 5
    (fletaAttr.lod); у группы одна выбранная стихия. Импортированный — из 02/05 оригинала
    (+905 стихия 1-й группы, +909 2-й, +917/+921 очки: Pers2xxxxx 2/1 1600, Pers4x ещё
    1/2 845), иначе — 'fleta_g' аккаунта (старые 'fleta_pts' — по группам, стихия 1)."""
    g = None if raw_only else getattr(player, 'fleta_g', None)
    if g is not None:
        return g
    g = {}
    raw = raw_of(player, '02/05')
    if raw and len(raw) >= FLETA_OFF + 20:
        e1, e2 = struct.unpack_from('<2I', raw, FLETA_OFF)
        p1, p2 = struct.unpack_from('<2I', raw, FLETA_OFF + 12)
        if e1:
            g[1] = (e1, p1)
        if e2:
            g[2] = (e2, p2)
    elif not raw_only:
        for k, v in (getattr(player, 'fleta_pts', None) or {}).items():
            if int(k) in (1, 2) and v:
                g[int(k)] = (1, int(v))
    if not raw_only:
        player.fleta_g = g
    return g


def write_fleta(payload, player):
    """Записать выбранные стихии и очки флетты в 02/05."""
    pl = bytearray(payload)
    if len(pl) < FLETA_OFF + 20:
        return bytes(pl)
    g = fleta_groups(player)
    for i, grp in enumerate((1, 2)):
        el, pts = g.get(grp, (0, 0))
        struct.pack_into('<I', pl, FLETA_OFF + 4 * i, el)
        struct.pack_into('<I', pl, FLETA_OFF + 12 + 4 * i, pts)
    return bytes(pl)


# Панель быстрых слотов — в 02/05: +465, 36 записей по 12 байт (u32 LE id, вид, число; пусто —
# 0, −1, −1). Так в 02/05 оригинала (Pers4x, 1806 байт) и в 08/11 Genesis (навыки 3001, 3002, 3005,
# вид 9). Клиент меняет панель сам и шлёт C 06/0b (+0 eid, +4 слот BE32, +8 id, +12 вид, +16 число —
# LE) и C 06/0c (+0 eid, +4 слот BE32 — убрать); ответов в записях нет. Сервер хранит панель в учётке
# ('quick') и отдаёт её при входе.
QS_OFF, QS_N = 465, 36


def quick_block(raw):
    """{слот: [id, вид, число]} из 02/05 (непустые)."""
    out = {}
    if raw and len(raw) >= QS_OFF + 12 * QS_N:
        for i in range(QS_N):
            e = list(struct.unpack_from('<3I', raw, QS_OFF + 12 * i))
            if e[1] != 0xffffffff:
                out[str(i)] = e
    return out


def write_quick(payload, player):
    _pc = ACCOUNT.get(player.eid) or {}
    q = _pc.get('quick')
    pl = bytearray(payload)
    if q is None or len(pl) < QS_OFF + 12 * QS_N:
        return bytes(pl)
    for i in range(QS_N):
        e = q.get(str(i)) or (0, 0xffffffff, 0xffffffff)
        struct.pack_into('<3I', pl, QS_OFF + 12 * i, *[int(x) & 0xffffffff for x in e])
    return bytes(pl)


def build_enter_world(player):
    """02/05 — реальный шаблон персонажа 1 lvl (нулевой опыт) из свежего
    дампа. Старый world_core-шаблон был от персонажа 2 lvl с накопленным
    опытом -> клиент выводил ур.2 и забитый опыт. Позицию тут НЕ пишем:
    она приходит в появлении 04/02 (+6), а не в 02/05."""
    own = raw_of(player, '02/05')
    pl = bytearray(own or W0205)
    struct.pack_into('>I', pl, 0, player.eid)
    if own:                                  # импортированный: класс/облик как есть
        struct.pack_into('<I', pl, 44, player.level & 0xffff)
        struct.pack_into('<I', pl, 114, getattr(player, 'map', DEFAULT_MAP_ID))
        return dress_own(write_quick(write_fleta(pl, player), player), '0205', player.eid)
    # КЛАСС @+4 (u32le): шаблон записан с ведуньи (600). Клиент по нему решает,
    # чьи навыки доступны — у остальных классов навыки были серыми.
    struct.pack_into('<I', pl, 4, getattr(player, 'cls', 600))
    struct.pack_into('<I', pl, 44, player.level & 0xffff)   # уровень+опыт
    # карта входа @+114 (u32le): в шаблоне оригинала 19003, в шаблоне 1 ур. — 0
    struct.pack_into('<I', pl, 114, getattr(player, 'map', DEFAULT_MAP_ID))
    return write_quick(write_fleta(pl, player), player)


APPEAR_CLASS_OFF = 240   # 04/02 персонажа: класс u16 (клиент: кадр+0xf6)


def set_appear_class(payload, cls):
    """Записать класс в пакет появления персонажа (в шаблоне — 600)."""
    pl = bytearray(payload)
    if len(pl) >= APPEAR_CLASS_OFF + 4:
        struct.pack_into('<I', pl, APPEAR_CLASS_OFF, cls)
    return bytes(pl)


def patch_eid(payload, new_eid, old_eids=(0x2892, 0x297e)):
    """Заменить ЗАШИТЫЙ eid игрока из шаблона дампа на актуальный (BE32 и LE32).
    Пакеты входа (0a/0f, 04/04, 09/02, 05/05, 08/02 и др.) содержат eid игрока
    из дампа (10386 в world_core, 10622 в level1). Без замены не-первый персонаж
    не входит: пакеты ссылаются на чужую сущность."""
    pl = bytes(payload)
    for old in old_eids:
        if old == new_eid:
            continue
        pl = pl.replace(struct.pack('>I', old), struct.pack('>I', new_eid))
        pl = pl.replace(struct.pack('<I', old), struct.pack('<I', new_eid))
    return pl


def build_hero_gage(player):
    """08/01 гейдж героя. НЕСЁТ И HP/MP (+9/+13/+17/+21), И уровень+опыт (+37).
    Без выставления текущего HP клиент показывал 150/150 из шаблона при каждом
    убийстве (ложное «восстановление HP как при левелапе»)."""
    pl = bytearray(raw_of(player, '08/01') or G0801)
    struct.pack_into('>I', pl, 1, player.eid)
    struct.pack_into('<I', pl, 9, max(0, int(player.hp)))
    struct.pack_into('<I', pl, 13, int(player.maxhp))
    struct.pack_into('<I', pl, 17, max(0, int(player.mp)))
    struct.pack_into('<I', pl, 21, int(player.maxmp))
    # Клиент (обработчик 0x00661dea) копирует 94 байта с +9 в структуру героя:
    # +37 уровень u16, +59 очки ФЛЕТТЫ («ОФ» на панели), +63 опыт u64 (внутри
    # уровня), +71 опыт до следующего уровня u64 — по ним полоска «0/48»,
    # +87 очки НАВЫКОВ (структура+0x840: из неё клиент вычитает цену навыка
    # в обработчиках 05/06 и 05/07).
    # +25 скорость бега, +29 ходьбы (структура 0x802/0x806, читает FUN_005d878c;
    # анимация ног сама масштабируется от отношения к базовой) — ×MOVE_RATE
    # скорости — итог 08/02 (A+44 бег, A+40 шаг: пассивки, флетта, бафы) × пульт
    run, walk = struct.unpack_from('<2f', raw_of(player, '08/01') or G0801, 25)
    run, walk = getattr(player, 'run_speed', run), getattr(player, 'walk_speed', walk)
    mv = DEV['move']
    struct.pack_into('<2f', pl, 25, run * mv, walk * mv)
    struct.pack_into('<f', pl, 33, getattr(player, 'aspd', BASE_ASPD))   # скорость анимации атаки
    struct.pack_into('<I', pl, 37, player.level & 0xffff)
    struct.pack_into('<I', pl, 59, getattr(player, 'fleta', 0))
    struct.pack_into('<I', pl, 87, skill_points(player))
    struct.pack_into('<Q', pl, 63, max(0, int(getattr(player, 'exp', 0))))
    struct.pack_into('<Q', pl, 71, exp_to_next(player.level))
    return bytes(pl)


MAX_LEVEL = 110     # потолок (оружие 103 ур.). Клиент сам потолка не знает: «опыт/до след.» —
                    # из 08/01 +63/+71 (0x0048a120); «0/0 1000%» было от «до след.» = 0
BASE_ASPD, BASE_DELAY = 0.866, 55     # в дампе: посох (задержка 55) -> 0.866


def attack_speed(inv):
    """Скорость атаки по надетому оружию (слот 7): 0.866 × 55 / задержка
    (itemBase +116: посох 55, меч 50, кинжал 30 -> ≈1.59). Клиент копирует это
    значение (08/01 +33, 08/02 +88) в контроллер анимации."""
    w = inv.find(0, 7) if inv else None
    delay = loot.ITEMS.get(Inventory.item(w), {}).get('delay', 0) if w is not None else 0
    return BASE_ASPD * BASE_DELAY / delay if delay else BASE_ASPD


def build_stats_full(player, stats):
    """08/02 (docs/stats.md): +6 5×u16 своя база атрибутов, +18 5×u16 прибавка, блок +32 —
    итог (A), блок +412 — база (B); вне блоков: +176/+180 прибавка HP/MP, +228 опыт %,
    +248 −% перезарядки, +272/+280/+284 доли атаки (общей/физ./маг.), +292 отражение,
    +304/+316 похищение HP/MP, +324 сила навыков %, +404 тип 128. Всё — statcalc."""
    pl = bytearray(raw_of(player, '08/02') or S0802)
    res = getattr(stats, 'res', None)
    if res is not None:
        mul = {0: DEV['hp'], 12: DEV['hp'], 52: DEV['atk'], 80: DEV['atk'],
               64: DEV['def'], 88: DEV['def']}
        for blk, vals in ((32, res.A), (412, res.B)):
            for off, v in vals.items():
                if blk + off + 4 <= len(pl):
                    struct.pack_into('<f', pl, blk + off, float(v) * mul.get(off, 1.0))
        for off in (176, 180, 228, 240, 248, 252, 272, 280, 284, 292, 304, 316, 324, 404):
            if off + 4 <= len(pl):
                struct.pack_into('<f', pl, off, float(res.P.get(off, 0.0)))
        struct.pack_into('<5H', pl, 6, *[max(0, min(65535, int(v))) for v in base_attrs(player)])
        struct.pack_into('<5H', pl, 18, *[max(0, min(65535, v)) for v in res.bonus])
    struct.pack_into('>I', pl, 0, player.eid)   # иначе eid дампа — клиент 08/02 игнорирует
    return bytes(pl)


def exp_to_next(level):
    """Опыт до следующего уровня. Таблицы в клиенте нет (её присылает сервер).
    ур.1 -> 48 (как в дампе), ур.10 ≈ 2.9 тыс., ур.30 ≈ 52 тыс., ур.50 ≈ 390 тыс.,
    ур.100 ≈ 21 млн — рост ускоряется с уровнем, как в оригинале (квестовые
    награды «Коалиции» в 100+ тыс. опыта рассчитаны на такие уровни)."""
    if level in EXP_TABLE:
        return EXP_TABLE[level]
    pts = sorted(EXP_TABLE.items())
    for (l0, e0), (l1, e1) in zip(pts, pts[1:]):        # между точками — геометрически
        if l0 < level < l1:
            return int(round(e0 * (e1 / e0) ** ((level - l0) / (l1 - l0))))
    l1, e1 = pts[-1]
    return int(round(e1 * 1.10 ** (level - l1)))       # выше последней точки — +10% за уровень


# Опыт до следующего уровня (08/01 +71): оригинал — ур.5 1577, ур.60 28 666 463,
# ур.62 33 552 308, ур.89 516 610 899 (импорт 4 персонажей);
# Karos Genesis — ур.7-10 (у Genesis таблица, похоже, та же, а опыт за мобов ×10)
EXP_TABLE = {1: 48, 5: 1577, 7: 4602, 8: 8810, 9: 16863, 10: 20203, 60: 28666463,
             62: 33552308, 89: 516610899}
# Полная таблица ур.1–89 (tools/exp_table.py): форма кривой — Karos Genesis ур.1–70 (лучница,
# huge_genesis_pack_2), масштаб — точки оригинала (1, 5, 60, 62 — точно), 63–89 — к точке 89.
try:
    EXP_TABLE = {int(k): int(v) for k, v in json.load(open(os.path.join(
        os.path.dirname(SRV), 'data', 'exp_table.json'), encoding='utf-8')).items()} or EXP_TABLE
except (OSError, ValueError):
    pass
EXP_SCALE = 20203 / (40 * 10 ** 1.6 * 1.06 ** 10)   # старая формула, подогнанная к ур.10


# Коралловый остров (29506): переход с Зерона — с 70 уровня и с «Меткой входа на Коралловый остров»
# (64005, расходуется; продают торговцы пристаней Зерона — tools/patch_shops.py) или с
# «Пропуском на Коралловый остров» (64013, награда квеста, не расходуется).
CORAL_MAP = 29506
CORAL_LEVEL = 70
CORAL_MARK, CORAL_PASS = 64005, 64013
SKILL_MAX_LEVEL = 5   # «1/5» в окне навыков
_SKILL_MAXLV = {}


def skill_max_level(sid):
    """Число уровней навыка по записям skillLevel (buffs.info); 0 — нет данных."""
    if not _SKILL_MAXLV:
        for (s_, lv_) in buffs.info():
            if lv_ > _SKILL_MAXLV.get(s_, 0):
                _SKILL_MAXLV[s_] = lv_
    return _SKILL_MAXLV.get(int(sid), 0)
QUEST_LEVEL_CAP = 2
# Возврат в город: свиток (расходуется) и камень (многоразовый). Точка — mapWarpTargetPos.
RETURN_ITEMS = {57105: True, 57104: False}
try:   # состав коробок из описаний предметов (tools/boxes.py)
    BOXES = {int(k): v for k, v in json.load(open(os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'boxes.json'),
        encoding='utf-8'))['boxes'].items()}
except OSError:
    BOXES = {}
RETURN_DEFAULT = 190031   # «Город Бернео» (mapWarpTargetPos)


EXP_RATE = 10       # множитель опыта с мобов к оригиналу (по просьбе ×10, чтобы не качаться сотни часов; пульт F2)
ZONE_RECONNECT = os.environ.get('KAROS_ZONE') == 'reconnect'   # старый переход через 02/07
GATHER_EVERY = 2        # руда — каждый 2-й взмах кирки (как в оригинале)
FLETA_PER_KILL = 0.1   # доля очка флетты за моба своего уровня (≈10 мобов на очко)
AUTO_LOOT = os.environ.get('KAROS_AUTOLOOT', '1') != '0'   # ВРЕМЕННО: добыча сразу в сумки
GROUND_DROPS = os.environ.get('KAROS_GROUND', '1') != '0'   # дроп на землю (0 — сразу в сумку)
COMMISSION = os.environ.get('KAROS_COMMISSION', '1') != '0' # витрина комиссионки (0 — эхо)
MOVE_RATE = 2.0     # по умолчанию; на лету — DEV['move'] (пульт F2)
DEV['move'], DEV['exp'] = MOVE_RATE, EXP_RATE


def mob_exp(mob, player=None, bonus=0.0):
    """Опыт за моба: базовый опыт официальной базы × доля по разнице уровней × DEV['exp'] (progression)."""
    xp = progression.mob_exp(mob.level, getattr(player, 'level', mob.level), exp_to_next, DEV['exp'],
                             hp=getattr(mob, 'maxhp', None), npc_id=getattr(mob, 'npc_id', None),
                             info={'name': getattr(mob, 'name', ''), 'grade': getattr(mob, 'grade', None)})
    # bonus — опыт % из характеристик (08/02 +228: зелья, кольца, VIP; +240 Цветок удачи); оригинал — вниз
    return max(1, int(xp * (1 + bonus / 100.0) + 1e-9))


def build_skill_list(tpl, eid, learned):
    """05/05 список навыков: +0 eid BE32, +4 число BE16, затем N×u32 id навыка,
    затем N×u32 уровень. База — из шаблона (действия, стартовый навык класса),
    поверх — изученные персонажем (аккаунт 'skills': [[id, уровень], ...])."""
    n = struct.unpack_from('>H', tpl, 4)[0]
    ids = list(struct.unpack_from(f'<{n}I', tpl, 6))
    lv = list(struct.unpack_from(f'<{n}I', tpl, 6 + 4 * n))
    have = dict(zip(ids, lv))
    for sid, lvl in learned or []:
        have[int(sid)] = max(have.get(int(sid), 0), int(lvl) or 1)
    ids = list(have)
    return (struct.pack('>IH', eid, len(ids)) + struct.pack(f'<{len(ids)}I', *ids)
            + struct.pack(f'<{len(ids)}I', *(have[i] for i in ids)))


# Стихии флетты (08/04 +4, порядок как в окне «Флетта»): 0 Ян, 1 Инь, 2 Воздух,
# 3 Огонь, 4 Дерево, 5 Земля, 6 Вода. Уровень стихии 1..6 (этап; первый — за 10 очков).
# Эффект этапа — своё допущение (в клиенте только id эффектов 161210xx):
FLETA_EFFECTS = {
    2: ('aspd', 0.09),      # Воздух: скорость атаки +9% за этап (Genesis: 1.51 -> 1.65)
    3: ('attack', 0.06),    # Огонь: физ. атака +6%
    4: ('hp', 0.06),        # Дерево: макс. HP +6%
    5: ('defense', 0.04),   # Земля: −4% получаемого урона
    6: ('mp', 0.06),        # Вода: макс. MP +6%
    0: ('attack', 0.03),    # Ян: атака +3%
    1: ('defense', 0.02),   # Инь: −2% получаемого урона
}


FLETA_STEP = (10, 100, 200, 400, 800, 1600)   # fletaAttr: цена этапов 1..6


def fleta_level(points):
    lvl, need = 0, 0
    for c in FLETA_STEP:
        need += c
        if points >= need:
            lvl += 1
    return lvl


def fleta_mult(player, kind):
    """Эффекты стихий флетты теперь считает statcalc (fletaAttr -> навык этапа); множитель
    оставлен для совместимости и равен 1."""
    return 1.0


def fleta_bonus(player):
    return 0.0


def skill_points(player):
    """Очки навыков: по 1 за уровень, минус потраченные (sp_spent в аккаунте)."""
    return max(0, player.level - 1 - getattr(player, 'sp_spent', 0))


def build_position(player):
    """04/02 позиция игрока. ВАЖНО: этот пакет содержит ИМЯ на +254 —
    без перезаписи при каждом движении утекал ник из дампа."""
    tpl = WTPL[(0x04, 0x02)]
    ch = Character(player.eid, name=player.name, x=player.x, y=player.y,
                   z=player.z, hp=player.hp, maxhp=player.maxhp,
                   mp=player.mp, maxmp=player.maxmp, level=player.level)
    ch.angle = player.angle
    cls = getattr(player, 'cls', 600)
    own = raw_of(player, '04/02')
    if own:                                  # импортированный: облик оригинала
        pl = dress_own(ch.build_appear(own), 'appear', player.eid)
    else:
        pl = set_appear_class(dress(ch.build_appear(tpl), 'appear', cls, player.eid), cls)
    return with_speeds(pl, player)


def with_speeds(pl, player):
    """04/02 своего персонажа: +38 бег, +42 шаг, +46 скорость анимации атаки — те же значения, что в
    08/01 +25/+29/+33 (сверено на 4 персонажах оригинала). Здесь оставались значения шаблона/записи,
    и после варпа (04/02) клиент замедлялся до следующего 08/00 — «скорость упала и вернулась»."""
    if len(pl) < 50:
        return pl
    pl = bytearray(pl)
    run, walk = struct.unpack_from('<2f', raw_of(player, '08/01') or G0801, 25)
    run, walk = getattr(player, 'run_speed', run), getattr(player, 'walk_speed', walk)
    struct.pack_into('<3f', pl, 38, run * DEV['move'], walk * DEV['move'], getattr(player, 'aspd', BASE_ASPD))
    return bytes(pl)


def build_mob_spawn(mob):
    """04/02 появление моба: несущая-шаблон + наши поля (§76).
    +2 entity LE16, +6 позиция float, +0x40 тип NPC LE32 (модель)."""
    tpl = MOB_TPL
    if tpl is None:
        return None
    pl = bytearray(tpl)
    struct.pack_into('<H', pl, 0x02, mob.eid & 0xffff)
    struct.pack_into('<3f', pl, 0x06, mob.x, mob.y, mob.z)
    struct.pack_into('<I', pl, 22, int(mob.hp))       # HP -> полоска совпадает
    struct.pack_into('<I', pl, 26, int(mob.maxhp))
    struct.pack_into('<I', pl, 0x40, mob.npc_id)
    # +50 уровень u16 (как у игрока в 04/02) — в шаблоне 1: все мобы были «ур.1»
    struct.pack_into('<H', pl, 50, max(1, int(getattr(mob, 'level', 1) or 1)) & 0xffff)
    # +0x44 = номер точки спавна в карте клиента (UniqIndex, с 1 по порядку
    # файлов <карта><тайл>.npc). Клиент (обработчик 0x00667a45) КЛОНИРУЕТ моба
    # с этой точки: модель, имя. В шаблоне было 460 (точка паука) -> все мобы
    # были пауками; при 0 клиент моба не создаёт вовсе.
    uidx = getattr(mob, 'uidx', 0)
    if not uidx:
        return None
    struct.pack_into('<I', pl, 0x44, uidx)
    return bytes(pl)


# Обзор мобов как у оригинала (записи orig_hl / remain3): появление 04/02 на 190–650 ед. от игрока
# (медиана ~400), исчезновение 04/03 на 400–720 (медиана ~550). Раньше мобы слались в радиусе 3000
# и не убирались вовсе: клиент держал сотни мобов карты, и движение каждого (04/01) шло ему —
# 1.3 млн пакетов за 45 мин игры (~480/с), FPS падал до 20, предметы срабатывали с задержкой.
VIEW_IN, VIEW_OUT = 700.0, 900.0
HUNT_GAGE = 110000          # шкала автоохоты (08/0a): максимум оригинала


def build_disappear(eid, kind=1):
    """04/03 CMoveDisappearPacket: u8 тип (1 моб, 0 игрок), u32 BE id (как в записях оригинала)."""
    return bytes([kind]) + struct.pack('>I', eid)


def send_nearby_mobs(world, player, send_fn, spawned, radius=3000, limit=40):
    """Досылает мобов рядом с игроком, которых он ещё не видел, и убирает ушедших далеко.
    Настоящий сервер шлёт их по мере движения, а не пачкой при входе. NPC — в прежнем радиусе."""
    n = 0
    for eid in [e for e in spawned if e in world.mobs]:
        m = world.mobs[eid]
        if getattr(m, 'dormant', False) or abs(m.x - player.x) > VIEW_OUT or abs(m.y - player.y) > VIEW_OUT or                 math.hypot(m.x - player.x, m.y - player.y) > VIEW_OUT:
            send_fn(0x04, 0x03, build_disappear(eid))
            spawned.discard(eid)
    for m in world.near(player.x, player.y, radius=radius):
        if m.eid in spawned:
            continue
        if getattr(m, 'dormant', False):
            continue                               # волна подземелья ещё не вызвана; открытые ворота EID
        if not getattr(m, 'is_npc', False):
            if not m.alive or math.hypot(m.x - player.x, m.y - player.y) > VIEW_IN:
                continue                           # мёртвых не шлём; дальних — когда подойдёт
        sp = build_mob_spawn(m)
        if sp:
            send_fn(0x04, 0x02, sp)
            spawned.add(m.eid)
            n += 1
            if n >= limit:
                break
    return n


REGEN_EVERY = 3.0     # сек; регенерация HP/MP вне зависимости от боя
REGEN_FRAC = 0.03     # доля от максимума за тик (не меньше 1)


def regen(player):
    """Медленное восстановление HP/MP. True, если что-то изменилось."""
    if getattr(player, 'dead', False):
        return False                      # лежит до воскрешения
    changed = False
    for cur, mx in (('hp', 'maxhp'), ('mp', 'maxmp')):
        v, m = getattr(player, cur), getattr(player, mx)
        if 0 < v < m:
            setattr(player, cur, min(m, v + max(1, int(m * REGEN_FRAC))))
            changed = True
        elif cur == 'mp' and v == 0 and m:
            setattr(player, cur, max(1, int(m * REGEN_FRAC)))
            changed = True
    return changed


def ai_loop(ai, world, send_fn, spawned, stop, log_fn=None, player=None):
    """Фоновый цикл AI: движение и атаки мобов рассылаются клиенту."""
    errors = 0
    next_regen = time.time() + REGEN_EVERY
    while not stop.is_set():
        time.sleep(TICK)
        try:
            _cb = getattr(world, 'on_tick', None)
            if _cb is not None:
                _cb()                            # событийное подземелье (eid.py): таймер, этапы
            if player is not None and time.time() >= next_regen:
                next_regen = time.time() + REGEN_EVERY
                if regen(player):
                    send_fn(0x08, 0x00, build_player_hp(G0800, player))
            for kind, mob, extra, dmg in ai.tick():
                if mob.eid not in spawned:
                    continue                     # клиент этого моба не видит
                if kind == 'move':
                    tpl = WTPL.get((0x04, 0x01))
                    if tpl:
                        send_fn(0x04, 0x01, build_mob_move(tpl, mob, extra, mode=dmg or 0))
                elif kind == 'react':                # 05/0b: eid моба BE, состояние BE (1 заметил, 10 агрессия, 0 снять)
                    send_fn(0x05, 0x0b, struct.pack('>II', mob.eid, dmg))
                elif kind == 'windup':
                    if T0500 and extra:          # замах над головой; урон придёт через ai.WINDUP
                        send_fn(0x05, 0x00, build_attack_start(
                            T0500, ENT_MOB, mob.eid, ENT_PLAYER, extra.eid,
                            (mob.x, mob.y, mob.z), (extra.x, extra.y, extra.z)))
                elif kind == 'stop':
                    tpl = WTPL.get((0x04, 0x01))
                    if tpl:
                        send_fn(0x04, 0x01, build_mob_move(tpl, mob, extra, mode=2))
                elif kind == 'attack':
                    player = extra
                    if player and not getattr(player, 'dead', False):
                        dmg = progression.mob_damage(mob.level, getattr(player, 'defense', 21.0),
                                                     giant=getattr(mob, 'is_giant', False),
                                                     boss=getattr(mob, 'is_boss', False))
                        _hk = progression.mob_hit_kind(player.level, mob.level, getattr(player, 'evasion', 0.0),
                                                       getattr(player, 'block', 0.0))
                        dmg = {4: 0, 6: 0, 5: dmg * 0.6, 2: dmg * 1.2}.get(_hk, dmg)
                        if dmg > 0:                       # промах / полный блок — 0
                            dmg = max(1, int(round(dmg * superskill.mob_mod(mob, 'atk', time.time(), 1.0))))
                        dmg = int(dmg)
                        if DEV['god']:
                            dmg = 0
                        _now = time.time()
                        for _sk in superskill.roll_procs(getattr(player, 'procs', ()), (4,)):
                            _k = statcalc.skill_kind(_sk)            # навык от вещи при получении удара
                            for _t, _v, _p in statcalc.skill_fx(_sk, 1):
                                if _k == 21 and _t == 28:            # лечение (украшения восстановления)
                                    player.hp = min(player.maxhp, player.hp + int(_v + dmg * _p / 100.0))
                                elif _t == 96:                        # отражение урона («Тёмная мощь»)
                                    player.proc_reflect = (_p, _now + superskill.PROC_BUFF_SECS)
                        _refl = getattr(player, 'reflect', 0.0)
                        _pr = getattr(player, 'proc_reflect', (0, 0))
                        if _pr[1] > _now:
                            _refl = max(_refl, _pr[0])
                        if _refl > 0 and dmg > 0 and mob.hp > 1:          # отражение урона
                            mob.hp = max(1, mob.hp - max(1, int(dmg * min(_refl, 100) / 100)))
                            send_fn(0x08, 0x06, build_hp(T0806, mob.eid, mob.hp))
                        player.hp = max(0, player.hp - dmg)
                        if log_fn:
                            log_fn(f"     моб {mob.eid} бьёт игрока: урон {dmg}, HP {player.hp}")
                        # 05/02 урон: атакует МОБ (тип 1), цель — ИГРОК (тип 0)
                        send_fn(0x05, 0x02, build_damage(
                            T0502, mob.eid, player.eid, dmg, _hk,
                            (player.x, player.y, player.z),
                            attacker_type=ENT_MOB, target_type=ENT_PLAYER))
                        send_fn(0x08, 0x00, build_player_hp(G0800, player))
                        if player.hp <= 0:
                            # смерть: мобы теряют цель; персонаж лежит до воскрешения (C 04/00 по OK)
                            for mm in world.mobs.values():
                                if mm.target == player.eid:
                                    mm.target = None
                                    mm.state = 'return'
                            player.dead = True
                            if log_fn:
                                log_fn("     игрок погиб — ждём воскрешения (04/00)")
                elif kind == 'respawn':
                    sp = build_mob_spawn(mob)
                    if sp:
                        send_fn(0x04, 0x02, sp)
        except (OSError, ConnectionError):
            break
        except Exception as e:
            # раньше ошибки глотались молча — теперь видны в логе (первые 20)
            errors += 1
            if errors <= 20:
                import traceback
                msg = f"     !!! ОШИБКА AI: {e!r}"
                print(msg, flush=True)
                if log_fn:
                    log_fn(msg + chr(10) + traceback.format_exc())
            continue


def build_mob_move(tpl, mob, frm, mode=0):
    """04/01 движение сущности: moveMode @+1, entity BE32 @+2,
    откуда @+6, куда @+18. mode: 0=идёт, 2=остановка (from==to) — эталон
    из дампа с оригинала."""
    pl = bytearray(tpl)
    pl[1] = mode & 0xff
    struct.pack_into('>I', pl, 2, mob.eid)
    struct.pack_into('<3f', pl, 6, *frm)
    struct.pack_into('<3f', pl, 18, mob.x, mob.y, mob.z)
    return bytes(pl)


def build_player_hp(tpl, player):
    """08/00 HP/MP гейдж: eid BE32 @+1, HP@+9, maxHP@+13, MP@+17, maxMP@+21
    (u32le). ВАЖНО: 08/00 ТОЖЕ несёт упакованное уровень+опыт @+37 (как 08/01)!
    Без его выставления клиент при каждом обновлении HP видел уровень 1 из
    шаблона и сбрасывал уровень (с ложной анимацией левелапа)."""
    pl = bytearray(raw_of(player, '08/00') or tpl)
    struct.pack_into('>I', pl, 1, player.eid)
    struct.pack_into('<I', pl, 9, max(0, int(player.hp)))
    struct.pack_into('<I', pl, 13, int(player.maxhp))
    struct.pack_into('<I', pl, 17, max(0, int(player.mp)))
    struct.pack_into('<I', pl, 21, int(player.maxmp))
    struct.pack_into('<I', pl, 37, player.level & 0xffff)   # уровень (опыт — в 08/01 +63)
    # +25/+29 скорость бега/ходьбы и +33 скорость анимации — те же поля, что в
    # 08/01. Здесь стояли значения шаблона (65/45.2), а 08/00 шлётся при каждом
    # ударе, зелье и регенерации -> ускорение ×2 то включалось, то сбрасывалось.
    # скорости — итог 08/02 (A+44 бег, A+40 шаг: пассивки, флетта, бафы) × пульт
    run, walk = struct.unpack_from('<2f', raw_of(player, '08/01') or G0801, 25)
    run, walk = getattr(player, 'run_speed', run), getattr(player, 'walk_speed', walk)
    mv = DEV['move']
    struct.pack_into('<2f', pl, 25, run * mv, walk * mv)
    struct.pack_into('<f', pl, 33, getattr(player, 'aspd', BASE_ASPD))
    return bytes(pl)


# Карточки выбора персонажа. Ключевой урок из дампа с оригинала:
#   ПУСТОЙ слот  = карточка eid=0, имя пустое, всё в нулях (0x01 + нули) —
#                  клиент рисует «создать персонажа».
#   ЗАНЯТЫЙ слот = eid + имя + статы.
# Раньше на пустые слоты слался шаблон-заглушка с НЕнулевым eid и именем
# «Пустой» — клиент показывал их персонажами-призраками: выбрать можно, а
# войти нельзя (за карточкой нет персонажа). Теперь пустые слоты настоящие.
MAX_SLOTS = 4                              # позиций в окне выбора
# Переход на другую карту идёт через 02/07 (переподключение): клиент снова
# показывает выбор персонажа и Enter берёт ПЕРВУЮ карточку — раньше это был
# чужой персонаж (P7xx -> BBB). Запоминаем, кто переходит.
PENDING_WARP = {'eid': 0, 't': 0.0}


def pending_warp_eid(max_age=300):
    if PENDING_WARP['eid'] and time.time() - PENDING_WARP['t'] < max_age:
        return PENDING_WARP['eid']
    return 0
EMPTY_CARD = bytes([0x01]) + bytes(388)    # реальная пустая карточка (дамп)


def send_cards(send_fn, _unused=None):
    """02/01 — реальные персонажи аккаунта + пустые слоты под создание."""
    if not CARDS:
        return 0
    slots = max(MAX_SLOTS, len([c for c in ACCOUNT.chars if not c.get('hidden')]))
    chars = [c for c in ACCOUNT.chars if not c.get('hidden')]   # скрытые — не в окне выбора
    pend = pending_warp_eid()
    if pend:   # переход между картами: этот персонаж — первой карточкой (Enter выберет его)
        chars.sort(key=lambda c: c.get('eid') != pend)
    n = 0
    for slot in range(slots):
        ch = chars[slot] if slot < len(chars) else None
        if ch and raw_of(ch, '02/01'):
            card = bytearray(dress_own(raw_of(ch, '02/01'), 'card', ch['eid']))   # облик оригинала
            card[0] = 0x01
            # имя — ЛОКАЛЬНОЕ: в карточке оригинала ник с настоящего сервера (+383 длина, +385 u32/символ)
            nm = (ch.get('name') or 'Hero')[:20]
            if len(card) > 385:
                card = bytearray(card[:383]) + bytes([len(nm), 0]) +                     b''.join(struct.pack('<I', ord(c)) for c in nm) + bytes(card[385 + card[383] * 4:])
        elif ch:
            # карточка НУЖНОГО КЛАССА (из реального сервера), иначе клиент
            # показывал класс из шаблона, а не выбранный при создании.
            cls = ch.get('cls', 600)
            tpl = CLASS_CARDS.get(str(cls)) or CLASS_CARDS.get('600') or CARDS[0]
            base = bytearray(bytes.fromhex(tpl))
            base[0] = 0x01
            struct.pack_into('<I', base, 9, cls)  # <-- ФИКС: принудительно пишем класс на +9
            card = Character(ch['eid'], name=ch['name'],
                             hp=ch.get('hp', 150), mp=ch.get('mp', 90),
                             level=ch.get('level', 1)).build_card(bytes(base))
            card = dress(card, 'card', cls, ch['eid'])   # 200: от ведуньи
        else:
            card = EMPTY_CARD              # пустой слот -> клиент даст «создать»
        send_fn(0x02, 0x01, card)
        n += 1
    return n


# Зелья стартового инвентаря (06/05 шаблона, имена — из itemBase).
# Сила лечения в таблицах пока не найдена — значения ПРИБЛИЗИТЕЛЬНЫЕ.
POTIONS = {
    54006: ('hp', 60),   # Starting Health Potion
    54005: ('hp', 40),   # Minor Health Potion
    54206: ('mp', 60),   # Starting Mana Potion
    54205: ('mp', 40),   # Minor Mana Potion
}


def find_potion(payload):
    """Найти ID зелья в запросе 06/02 клиента (поле ещё не сверено с дампом:
    ищем известный ID как BE32/LE32 в любом месте пакета)."""
    for i in range(0, max(0, len(payload) - 3)):
        for fmt in ('>I', '<I'):
            v = struct.unpack_from(fmt, payload, i)[0]
            if v in POTIONS:
                return v, i
    return None, None


def build_item_use(eid, item):
    """06/02 S->C (обработчик клиента 0x006582a4): +0 eid BE32, +6 item BE32.
    Клиент пишет «использован предмет» и запускает перезарядку."""
    pl = bytearray(16)
    struct.pack_into('>I', pl, 0, eid)
    struct.pack_into('>I', pl, 6, item)
    return bytes(pl)


def handle(conn, addr, port):
    stage = {10001: 'ГЕЙТ', 10110: 'MID', 10101: 'ИГРА'}.get(port, str(port))
    print(f"[+] {addr[0]}:{addr[1]} стадия={stage}", flush=True)
    seq = [1]
    buf = b''
    conn.settimeout(120)
    world = None
    player = None
    equipment = Equipment()
    stats = PlayerStats()
    pos_fix = [False]        # первое 04/00 после входа: поставить на сохранённую точку
    zone_pending = [False]   # смена карты (04/04): ждём 04/00 клиента
    qsent = {}               # (квест, цель) -> отправленный клиенту прогресс
    spawned = set()
    char_name = [PLAYER_NAME]
    ai = None
    # Флаг остановки AI — НОВЫЙ на каждый вход в мир (см. 02/04). Раньше один
    # Event на всё соединение: после выхода в меню он оставался выставленным,
    # и поток AI при повторном входе сразу завершался -> мобы застывали.
    ai_stop = [_th.Event()]
    send_lock = _th.Lock()   # send() зовут и handle, и поток AI
    inv = [None]             # Inventory текущего персонажа (заводится на 06/05 входа)
    # Один замок на пакеты клиента, таймер крафта и команды пульта, меняющие сумку. Поток пакетов держит
    # его всегда, кроме ожидания recv: команда пульта не попадёт в середину обработки пакета.
    op_lock = _th.RLock()
    craft_job = [None]       # крафт своими силами: таймер полосы изготовления
    tf_job = [None]          # превращение: таймер возврата облика

    qlog = [None]            # QuestLog текущего персонажа (заводится на 02/04)
    last_save = [0.0]

    def saved_return_point():
        """Точка «Камня возврата»: сохранённая здесь (06/27), иначе — из 02/05 оригинала (+421 число,
        +425 точка mapWarpTargetPos: MAG 1901002 «Замок Эристум», ANGEL 190061 «Баласон»)."""
        _pc = ACCOUNT.get(player.eid) or {}
        if _pc.get('return_point'):
            return _pc['return_point']
        r = raw_of(player, '02/05')
        if r and len(r) >= 429:
            n, pt = struct.unpack_from('<II', r, 421)
            if n and str(pt) in WARPS['targets']:
                return pt
        return RETURN_DEFAULT

    def drop_spawned():
        """Перенос внутри карты: прежних мобов убрать у клиента (04/03), иначе они оставались навсегда."""
        for eid in list(spawned):
            if world and eid in world.mobs:
                send(0x04, 0x03, build_disappear(eid))
        spawned.clear()

    def send_hair_color():
        """Цвет волос персонажа (S 06/5b, hair.py) — после входа и смены карты; свой цвет не шлём."""
        _pc = ACCOUNT.get(player.eid) if player else None
        rgb = (_pc or {}).get('hair_color')
        if rgb and any(rgb):
            send(0x06, 0x5b, hair.build_color(player.eid, rgb))

    def set_hair_color(rgb):
        _pc = ACCOUNT.get(player.eid)
        if _pc is None:
            return None
        _pc['hair_color'] = [int(x) for x in rgb]
        ACCOUNT.save()
        send(0x06, 0x5b, hair.build_color(player.eid, rgb))
        jot(f"     цвет волос: {hair.color_name(rgb)} {list(rgb)}")
        return hair.color_name(rgb)

    def send_buff_icons():
        """Иконки бафов, переживших переход карты / выход (05/09 с оставшимся временем)."""
        send_hair_color()
        bf = getattr(player, 'buffs', None) if player else None
        if not bf or not bf.active:
            return
        left = [(sid, lv, t) for sid, lv, t in bf.remaining() if sid > 0]
        if left:
            send(0x05, 0x09, buff_list(left))
        restat()
        jot(f"     бафы восстановлены: {[(sid, t) for sid, _, t in bf.remaining()]}")

    def save_state():
        """Сохранить персонажа: карта, позиция, угол, HP/MP, уровень, опыт,
        флетта, очки навыков. Инвентарь/квесты/хранилище пишутся сразу при
        изменении (save_inv/save_quests)."""
        save_heights()
        if not player:
            return
        _pc = ACCOUNT.get(player.eid)
        if _pc is None:
            return
        _pc.update({'map': getattr(player, 'map', DEFAULT_MAP_ID),
                    'pos': [player.x, player.y, player.z], 'angle': player.angle,
                    'hp': int(player.hp), 'mp': int(player.mp),
                    'level': player.level, 'exp': player.exp,
                    'fleta': getattr(player, 'fleta', 0),
                    'fleta_exp': round(getattr(player, 'fleta_exp', 0.0), 3),
                    'sp_spent': getattr(player, 'sp_spent', 0)})
        bf = getattr(player, 'buffs', None)
        if bf is not None:             # бафы и зелья — с временем окончания (переход карт = новый вход)
            _pc['buffs'] = [[sid, lv, round(t, 1), eff] for sid, (lv, t, eff) in bf.active.items()
                            if t > time.time() + 1]
        ACCOUNT.save()
        last_save[0] = time.time()

    def start_world(map_id):
        """Заселить карту и запустить AI (вход в мир и варп)."""
        w = World(MAP_NAMES[map_id], CONTENT)
        w.map_id = map_id                   # подземелья: расстановка по номеру карты
        w.ground = Ground()                 # предметы на земле этой карты
        w.add_player(player)
        nmob = w.load_mobs()
        w.dungeon = dungeon.Run(map_id) if dungeon.rule(map_id) else None   # двери/волны/лабиринт
        w.on_tick = world_tick
        a = MobAI(w)
        ai_stop[0].set()              # гасим AI прошлой карты/входа
        ai_stop[0] = _th.Event()      # и заводим свежий флаг
        _th.Thread(target=ai_loop, args=(a, w, send, spawned, ai_stop[0], jot, player),
                   daemon=True).start()
        spawned.clear()
        print(f"     КАРТА: {MAP_NAMES[map_id]} ({map_id}), мобов {nmob}, "
              f"NPC {len(w.npcs)}", flush=True)
        return w, a

    def do_warp(target_id):
        """Перенос игрока в точку mapWarpTargetPos. Та же карта — своё 04/02 в
        новой точке; другая — сохранить карту/позицию и 02/07 (переподключение)."""
        nonlocal world, ai
        t = WARPS['targets'].get(str(target_id))
        if not t and int(target_id) in MAP_NAMES:
            t = map_entry(int(target_id))           # хранитель подземелья шлёт номер карты
        if not t or t['map'] not in MAP_NAMES:
            jot(f"     варп {target_id}: нет точки/карты")
            return False
        player.x, player.y = t['x'], t['z']
        player.z = (t['y'] + 5) if t.get('y') is not None else ground_height(MAP_NAMES[t['map']], t['x'], t['z'], player.z)
        changed = t['map'] != player.map
        player.map = t['map']
        _pc = ACCOUNT.get(player.eid)
        if _pc is not None:
            _pc['map'], _pc['pos'] = player.map, [player.x, player.y, player.z]
            _pc['level'], _pc['exp'] = player.level, player.exp
            ACCOUNT.save()
        if changed and not ZONE_RECONNECT:
            # Другая карта — как оригинал (запись Karos Genesis, 22:04): 04/04 (eid,
            # карта), клиент грузит карту и шлёт 04/00, и только тогда — свой 04/02,
            # навыки, квесты (zone_pending). Раньше 04/02 уходил сразу -> вылет.
            world, ai = start_world(player.map)
            zone_pending[0] = True
            send(0x04, 0x04, build_zone(player.eid, player.map))
        elif changed:
            # Другая карта: 04/04 на лету клиент не переживает (вылет в игре).
            # Шлём 02/07 «смена канала» с адресом игрового сервера: клиент
            # переподключается и входит заново (02/04) — уже на новой карте.
            ai_stop[0].set()
            PENDING_WARP.update(eid=player.eid, t=time.time())
            send(0x02, 0x07, bytes.fromhex(MID['0207']))
        else:
            send(0x04, 0x02, build_position(player))     # та же карта — просто переставить
            drop_spawned()
        jot(f"     варп -> {t['name']} ({MAP_NAMES[player.map]} {player.x:.0f},{player.y:.0f})")
        print(f"     ВАРП: {t['name']} -> {MAP_NAMES[player.map]}", flush=True)
        return True

    def save_quests():
        _pc = ACCOUNT.get(player.eid) if player else None
        if _pc is not None and qlog[0] is not None:
            _pc['quests'] = qlog[0].to_saved()
            ACCOUNT.save()

    def quest_reply(req, code_off, ok):
        """Ответ 09/00 / 09/01 из копии запроса: код результата BE16 на code_off."""
        r = bytearray(req) + bytes(max(0, code_off + 8 - len(req)))
        struct.pack_into('>I', r, 0, player.eid)
        struct.pack_into('>H', r, code_off, questlog.OK if ok else 0x59)
        return bytes(r)

    def stat_input(iv=None):
        """Состояние для statcalc: (база атрибутов, навыки, флетта, бафы, надетое)."""
        iv = iv or inv[0]
        recs = [bytes(r) for r in (iv.recs if iv else []) if r[0] == 0 and r[1] not in (13, 14, 15)]
        pc = ACCOUNT.get(player.eid) or {}
        skills = [(int(a), int(b)) for a, b in pc.get('skills', [])]
        skills += [(e[0], e[1]) for e in super_entries() if e[1] > 0]    # супер-навыки
        skills += [(e[2], 1) for e in super_entries() if e[2]]           # их камни (пассивные)
        bf = getattr(player, 'buffs', None)
        blist = [(sid, lv, eff) for sid, (lv, _t, eff) in bf.active.items()] if bf else []
        try:
            blist += pet_buffs()
        except NameError:                        # до объявления помощников питомца
            pass
        return base_attrs(player), skills, fleta_groups(player), blist, recs

    def stat_calib(iv=None):
        """Поправки импортированного персонажа (statcalc.calibrate) по его 08/02 оригинала
        и состоянию на момент импорта: навыки — сырой 05/05, вещи — 02/05 (+123 id, +247
        заточка; записи — из инвентаря), флетта — 02/05 +905.."""
        r82 = raw_of(player, '08/02')
        if not r82 or len(r82) < 788:
            return None
        pc = ACCOUNT.get(player.eid) or {}
        cal = pc.get('stat_cal')
        if cal and cal.get('v') == 5:
            return cal
        sb = pc.get('stat_base') or {}
        lvl0 = sb.get('level', player.level)
        r55 = raw_of(player, '05/05')
        skills = []
        if r55 and len(r55) >= 6:
            n = struct.unpack_from('>H', r55, 4)[0]
            if len(r55) >= 6 + 8 * n:
                skills = list(zip(struct.unpack_from(f'<{n}I', r55, 6),
                                  struct.unpack_from(f'<{n}I', r55, 6 + 4 * n)))
        if not skills:
            skills = [(int(a), int(b)) for a, b in pc.get('skills', [])]
        # супер-навыки на момент импорта (их прибавка уже в 08/02 оригинала)
        _mine = superskill.group_skills(player.cls)
        _sup = [e for e in superskill.parse_list(raw_of(player, '05/0c')) if e[0] in _mine]
        skills += [(e[0], e[1]) for e in _sup if e[1] > 0] + [(e[2], 1) for e in _sup if e[2]]
        raw = raw_of(player, '02/05')
        recs = []
        if raw and len(raw) >= 278:
            iv = iv or inv[0]
            ids = struct.unpack_from('<31I', raw, 123)
            ench = raw[247:278]
            for sl, it in enumerate(ids):
                if not it or sl in (13, 14, 15):
                    continue
                r = None
                if iv:
                    r = iv.find(0, sl)
                    if r is None or Inventory.item(r) != it:
                        r = iv.find_item(it, None)
                r = bytearray(r) if r is not None else bytearray(147)
                r[0], r[1], r[7] = 0, sl, ench[sl]
                struct.pack_into('<I', r, 2, it)
                recs.append(bytes(r))
        cal = statcalc.calibrate(r82, player.cls, lvl0, base_attrs(player, raw_only=True), skills,
                                 fleta_groups(player, raw_only=True), recs)
        cal['v'] = 5
        cal['level'] = lvl0
        if ACCOUNT.get(player.eid) is not None:
            pc['stat_cal'] = cal
            ACCOUNT.save()
        jot(f"     поправки характеристик ({player.name}): B {cal['B']} A {cal['A']}")
        return cal

    def compute_stats(iv=None):
        """Характеристики как у сервера оригинала (statcalc.py, docs/stats.md): база по уровню
        и атрибутам, пассивные навыки, стихии флетты, бафы, вещи по заточке, вставки и особые
        характеристики. Итог — в stats (бой) и stats.res (полный 08/02)."""
        attrs, skills, fl, blist, recs = stat_input(iv)
        res = statcalc.compute(player.cls, player.level, attrs, skills, fl, blist, recs,
                               stat_calib(iv))
        A, B, P = res.A, res.B, res.P
        stats.res = res
        stats.max_hp, stats.max_mp = A[0], A[12]
        stats.base_atk, stats.base_matk = A[52], A[80]
        stats.base_def, stats.defense, stats.base_mdef = B[64], A[64], A[88]
        stats.wmin, stats.wmax, stats.mwmin, stats.mwmax = res.weapon
        stats.armor = A[64] - B[64]
        stats.attr_bonus = res.bonus
        stats.cls_base = statcalc.base_cls(player.cls)
        stats.magic = stats.cls_base in charstats.MAGIC_CLASSES
        stats.pct_all, stats.pct_phys, stats.pct_mag = P.get(272, 0.0), P.get(280, 0.0), P.get(284, 0.0)
        mp_, mm_ = 1 + stats.pct_all + stats.pct_phys, 1 + stats.pct_all + stats.pct_mag
        stats.atk_min = (A[116] + stats.wmin + A[52]) * mp_
        stats.atk_max = (A[116] + stats.wmax + A[52]) * mp_
        stats.matk_min = (A[124] + stats.mwmin + A[80]) * mm_
        stats.matk_max = (A[124] + stats.mwmax + A[80]) * mm_
        stats.attack = (stats.atk_min + stats.atk_max) / 2
        stats.crit = max(0.0, min(charstats.CRIT_CAP, A[132]))
        player.evasion, player.block = A.get(28, 0.0), A.get(32, 0.0)   # промах/блок мобов (08/02 +28/+32)
        stats.skill_pow = P.get(324, 0.0)          # «сила навыков» % (крылья и др.) — к урону навыков
        stats.crit_dmg = max(1.0, A[100])
        stats.atk_parts, stats.acc = res.weapon_parts, A[60]     # бросок по вещам; рейтинг атаки
        stats.hp_steal, stats.mp_steal = P.get(304, 0.0), P.get(316, 0.0)
        player.reflect = P.get(292, 0.0)          # отражение урона, % (камень «Усиление»)
        player.drop_pct = P.get(240, 0.0)         # шанс выпадения, % (loot.roll)
        player.aspd = A[56]
        player.run_speed, player.walk_speed = A[44], A[40]

    def restat(send_now=True):
        """Пересчитать характеристики (уровень, атрибуты, навыки, флетта, бафы, надетое)
        и отправить 08/02 + 08/01 + 08/00."""
        if not player:
            return
        stats.recalc(player.level, getattr(player, 'cls', 600),
                     inv[0].equipped() if inv[0] else {})
        compute_stats()
        player.procs = superskill.procs_for((inv[0].equipped() if inv[0] else {}).values())
        if DEV['hp'] != 1:
            stats.max_hp *= DEV['hp']
            stats.max_mp *= DEV['hp']
        if DEV['atk'] != 1:
            for k in ('base_atk', 'wmin', 'wmax', 'base_matk', 'mwmin', 'mwmax', 'attack',
                      'atk_min', 'atk_max', 'matk_min', 'matk_max'):
                setattr(stats, k, getattr(stats, k) * DEV['atk'])
        if DEV['def'] != 1:
            stats.defense *= DEV['def']
            stats.base_mdef *= DEV['def']
        player.move_mult = 1.0
        player.maxhp = max(1, int(round(stats.max_hp)))
        player.maxmp = max(0, int(round(stats.max_mp)))
        player.defense = stats.defense
        player.hp, player.mp = min(player.hp, player.maxhp), min(player.mp, player.maxmp)
        if send_now:
            send(0x08, 0x02, build_stats_full(player, stats))
            send(0x08, 0x01, build_hero_gage(player))
            send(0x08, 0x00, build_player_hp(G0800, player))
            pet_icons()

    def pet_icons():
        """Значки навыков-бафов призванного питомца у хозяина (05/09, срок 0) — как в записи Genesis
        (huge_genesis_pack_2): при призыве — 900001, после выбора типа — 900001 + 900009, при новом
        навыке типа старый снимается (05/09 «снят»), новый список — целиком."""
        try:
            cur = [s_ for s_, _l, _x in pet_buffs()]
            old = pet_state.setdefault('icons', [])
        except NameError:
            return
        gone = [s_ for s_ in old if s_ not in cur]
        if gone:
            send(0x05, 0x09, buff_list([(s_, 1, 0) for s_ in gone], add=False))
        if cur and (gone or any(s_ not in old for s_ in cur)):
            send(0x05, 0x09, buff_list([(s_, 1, 0) for s_ in cur]))
        pet_state['icons'] = cur

    def give_item(item, count, notice=True, profile=None):
        """Предмет в сумку: снаряжение — в надетую сумку, остальное — в особую
        (со стаком). -> True, если поместилось. Снаряжению — белые/жёлтые характеристики
        (profile = (камни, жёлтые, заточка) с лота комиссионки, иначе — itemroll)."""
        if not inv[0]:
            return False
        item = BAG_REPLACE.get(item, item)
        info = loot.ITEMS.get(item, {})
        per = info.get('period', 0)
        if info.get('kind') == 1:
            if count > 1:                           # снаряжение не складывается: по одной вещи
                ok = False                          # (сумка «x3» одной записью роняла клиент)
                for _ in range(count):
                    if not give_item(item, 1, notice=False, profile=profile):
                        break
                    ok = True
                if ok and notice:
                    send(0x06, 0x03, build_pickup_notice(player.eid, item, count))
                return ok
            rec = inv[0].add(item, count, stack=False, cont=inv[0].gear_container(), period=per)
            if rec is not None:
                stored = inv[0].find(rec[0], rec[1])
                if stored is not None:
                    if profile:                       # лот комиссионки: ровно как у продавца
                        itemroll.apply_lot(stored, *profile)
                    else:                             # новая вещь: белые особые при выпадении
                        w = itemroll.roll_white(item, loot.ITEMS)
                        if w:
                            itemroll.apply_white(stored, w)
                    rec = bytearray(stored)
        else:
            stack = info.get('stack', 100 if item == GOLD else 1) > 1 or item == GOLD
            if stack or count <= 1:
                if stack and item != GOLD and count > 0:    # с лимитом стопки: может занять несколько ячеек
                    got = inv[0].add_stack(item, count, period=per)
                    if got is None:
                        return False
                    for r1 in got[:-1]:
                        send(0x06, 0x06, build_putin(player.eid, r1))
                    rec = got[-1]
                else:
                    rec = inv[0].add(item, count, stack=stack, period=per)
            else:                                   # нестакуемые (метки входа x3) — по одной
                rec = None
                for _ in range(count):
                    r1 = inv[0].add(item, 1, stack=False, period=per)
                    if r1 is None:
                        break
                    send(0x06, 0x06, build_putin(player.eid, r1))
                    rec = r1
                if rec is not None:
                    if notice:
                        send(0x06, 0x03, build_pickup_notice(player.eid, item, count))
                    quest_collect(item)
                    return True
        if rec is None:
            return False
        send(0x06, 0x06, build_putin(player.eid, rec))
        if notice and count > 0:
            send(0x06, 0x03, build_pickup_notice(player.eid, item, count))
        if count > 0 and item != GOLD:
            quest_collect(item)
        return True

    def quest_collect(item):
        """Цель «собрать/купить предмет» (тип 3): прогресс = сколько его в сумке.
        Клиент сам его не считает — без 09/03 «Флеттодоспехи» не завершались."""
        if not qlog[0] or not inv[0]:
            return
        have = inv[0].count_item(item)
        changed = False
        for qid, prog in qlog[0].active.items():
            for o in questlog.QUESTS[qid]['objectives']:
                if o['type'] == questlog.COLLECT and o['target'] == item:
                    val = min(o['count'], have)
                    # клиенту — каждое изменение ровно один раз (повтор того же
                    # значения клиент считает новым выполнением -> «выполнено» ×2)
                    if qsent.get((qid, o['i'])) != val:
                        qsent[(qid, o['i'])] = val
                        send(0x09, 0x03, questlog.build_perform(player.eid, qid, o, val))
                        jot(f"     квест {qid}: собрано {item} {val}/{o['count']}")
                    if prog.get(o['i'], 0) != val:
                        prog[o['i']] = val
                        changed = True
        if changed:
            save_quests()

    def take_items(pairs, why, keep=None):
        """Забрать предметы [(item, count)] из сумок и показать изменения клиенту."""
        for item, cnt in pairs:
            for cont, cell, rec in inv[0].take_item(item, cnt, keep):
                if rec is None:
                    send(0x06, 0x06, build_putout(player.eid, cont, cell, item))
                else:
                    send(0x06, 0x06, build_putin(player.eid, rec))
        jot(f"     {why}: забрано {[(loot.item_name(i), n) for i, n in pairs]}")

    def craft_make(rid):
        """Изготовить по рецепту: проверки, шанс, материалы и караты. -> код 06/16."""
        rec = craft.RECIPES.get(rid)
        if not rec or not inv[0]:
            return craft.ERROR
        miss = craft.missing(inv[0], rec)
        if miss:
            jot(f"     крафт {rid}: не хватает {[(loot.item_name(i), n, h) for i, n, h in miss]}")
            return craft.NO_MATS
        if inv[0].gold() < rec['cost']:
            return craft.NO_MONEY
        ok = craft.roll(rec)
        if ok and not give_item(rec['item'], 1, notice=False):
            return craft.BAG_FULL
        take_items(rec['mats'], f"крафт {rid}")
        if rec['cost']:
            give_item(GOLD, -rec['cost'], notice=False)
        save_inv()
        jot(f"     крафт {rid} {rec['name']}: {'успех' if ok else 'неудача'}, "
            f"{rec['cost']} карат")
        return craft.OK if ok else craft.FAIL

    def untransform(why=''):
        """Вернуть облик (S 08/10 с номером 0)."""
        if tf_job[0]:
            tf_job[0].cancel()
            tf_job[0] = None
        if getattr(player, 'form', 0):
            fm = transform.FORMS.get(player.form) or {}
            player.form = 0
            send(0x08, 0x10, transform.build_char(player.eid, 0))
            sk = fm.get('skill')
            if sk and getattr(player, 'buffs', None) and sk in player.buffs.active:
                del player.buffs.active[sk]                   # баф существа снимается с обликом
                send(0x05, 0x09, buff_list([(sk, 1, 0)], add=False))
                restat()
            jot(f"     превращение снято {why}")

    def super_entries(tpl=None):
        """Супер-навыки персонажа: сохранённые или из его 05/0c (импорт/шаблон — только навыки
        своей группы классов)."""
        _pc = ACCOUNT.get(player.eid)
        if _pc is not None and 'super' in _pc:
            return _pc['super']
        if tpl is None:
            tpl = raw_of(player, '05/0c') or WTPL.get((0x05, 0x0c))
        mine = superskill.group_skills(player.cls)
        ent = [e for e in superskill.parse_list(tpl) if e[0] in mine]
        if _pc is not None:
            _pc['super'] = ent
        return ent

    def sys_msg(text):
        """Системное сообщение в чат (S 03/00: eid 0, канал 7, имя, текст — как в записях)."""
        send(0x03, 0x00, struct.pack('>II', 0, 7) + b'\0' + 'Система'.encode('utf-8') + b'\0'
             + text.encode('utf-8') + b'\0')

    def coral_gate(tid):
        """Переход на Коралловый остров: уровень и метка/пропуск. -> True, если можно (метка списана)."""
        t = WARPS['targets'].get(str(tid)) or {}
        if t.get('map') != CORAL_MAP or getattr(player, 'map', 0) == CORAL_MAP:
            return True
        if player.level < CORAL_LEVEL:
            sys_msg(f'Коралловый остров доступен с {CORAL_LEVEL} уровня.')
            return False
        if inv[0] and inv[0].count_item(CORAL_PASS):
            return True
        if inv[0] and inv[0].count_item(CORAL_MARK):
            for cont, cell, rec in inv[0].take_item(CORAL_MARK, 1):
                if rec is None:
                    send(0x06, 0x06, build_putout(player.eid, cont, cell, CORAL_MARK))
                else:
                    send(0x06, 0x06, build_putin(player.eid, rec))
            save_inv()
            jot("     Коралловый остров: метка входа списана")
            return True
        sys_msg('Нужна «Метка входа на Коралловый остров» (продают торговцы пристаней Зерона) '
                'или «Пропуск на Коралловый остров».')
        return False

    def proc_effect(sk, mob=None, dmg=0):
        """Срабатывание навыка от вещи (itemInvokeSkill): -> множитель урона этого удара."""
        k = statcalc.skill_kind(sk)
        fx = statcalc.skill_fx(sk, 1)
        now = time.time()
        if k == statcalc.ACTIVE:
            if not fx:
                jot(f"     срабатывание {sk}: дополнительный удар")
                return 2.0
            if mob is not None:
                db = getattr(mob, 'debuffs', None)
                if db is None:
                    db = mob.debuffs = {}
                for t, _v, pct in fx:
                    if t == 13:
                        db['aspd'] = (max(0.1, 1 + pct / 100.0), now + superskill.DEBUFF_SECS)
                    elif t == 27:
                        db['move'] = (max(0.1, 1 + pct / 100.0), now + superskill.DEBUFF_SECS)
                jot(f"     срабатывание {sk}: замедление цели {fx}")
        elif k == statcalc.BUFF and getattr(player, 'buffs', None):
            player.buffs.active[-sk] = (1, now + superskill.PROC_BUFF_SECS, {})
            restat()
            jot(f"     срабатывание {sk}: баф {fx} на {superskill.PROC_BUFF_SECS:.0f} с")
        elif k == 21:                                   # лечение: тип 28 — HP (значение и/или % урона)
            heal = sum(v + dmg * p / 100.0 for t, v, p in fx if t == 28)
            if heal > 0 and player.hp < player.maxhp:
                player.hp = min(player.maxhp, player.hp + int(heal))
                send(0x08, 0x00, build_player_hp(G0800, player))
                jot(f"     срабатывание {sk}: лечение +{int(heal)}")
        return 1.0

    def take_quest_items(q):
        """При сдаче квеста забрать собранные для него предметы (тип 3 и 9)."""
        if not inv[0]:
            return
        need = {}
        for o in q.get('objectives', []):
            if o['type'] in (questlog.COLLECT, questlog.DELIVER) and o['target']:
                need[o['target']] = max(need.get(o['target'], 0), o['count'])
        for item, cnt in need.items():
            for cont, cell, rec in inv[0].take_item(item, cnt):
                if rec is None:
                    send(0x06, 0x06, build_putout(player.eid, cont, cell, item))
                else:
                    send(0x06, 0x06, build_putin(player.eid, rec))
            jot(f"     квестовый предмет {item} x{cnt} забран")

    def gain_exp(amount, max_levels=None):
        """Опыт: внутри уровня (+63), «до следующего» (+71); на левелапе —
        очки навыков и полное HP/MP. Отправляет 08/01. max_levels — не больше
        стольких уровней за раз (остаток опыта сгорает)."""
        player.exp += int(amount)
        leveled = False
        start = player.level
        while player.level < MAX_LEVEL and player.exp >= exp_to_next(player.level):
            if max_levels is not None and player.level - start >= max_levels:
                player.exp = exp_to_next(player.level) - 1
                break
            player.exp -= exp_to_next(player.level)
            player.level += 1
            leveled = True
        if leveled:
            restat(send_now=False)                   # HP/MP/атака/защита растут с уровнем
            player.hp, player.mp = player.maxhp, player.maxmp
            send(0x08, 0x02, build_stats_full(player, stats))
            send(0x08, 0x00, build_player_hp(G0800, player))
            print(f"     ЛЕВЕЛАП: ур.{player.level}", flush=True)
        send(0x08, 0x01, build_hero_gage(player))
        _pc = ACCOUNT.get(player.eid)
        if _pc:
            _pc['level'], _pc['exp'] = player.level, player.exp
            ACCOUNT.save()
        return leveled

    def quest_started(qid, q):
        """Квест взят (у NPC или автозаданием): счёт заново, предмет выдачи, уже собранное."""
        for k_ in [k_ for k_ in qsent if k_[0] == qid]:
            del qsent[k_]                            # повторный квест («Повтор»): счёт заново
        _si = q.get('start_item')                    # quest.lod +64: письмо/посылка «отнести»,
        if _si and inv[0] and not inv[0].count_item(_si):   # арендованная кирка …
            _got = give_item(_si, 1)
            save_inv()
            jot(f"     квест {qid}: выдан {loot.item_name(_si)}{'' if _got else ' — НЕТ МЕСТА'}")
        for o in q['objectives']:                    # уже собранное — сразу (перья у билета Аски
            if o['type'] == questlog.COLLECT and o['target']:   # ждали ещё одно перо с моба)
                quest_collect(o['target'])

    def give_quest_rewards(q):
        """Награда за квест: опыт, золото, предметы (клиент лишь пишет о них)."""
        take_quest_items(q)
        if q.get('exp'):
            gain_exp(q['exp'], max_levels=QUEST_LEVEL_CAP)
        # предметы награды — по одному на класс (19003136: поножи 32403 мечника … 46403 канонира);
        # запись Genesis лучницы: выдан только 40403 «Поножи охотника-лучника» (класс 500).
        # Раньше сервер выдавал все. Общие предметы (класс 0) — всегда.
        my = statcalc.base_cls(getattr(player, 'cls', 600))
        for r in q.get('rewards', []):
            if r['type'] == 'gold':
                give_item(GOLD, int(r['amount']))
            else:
                ic = loot.ITEMS.get(r['item'], {}).get('cls') or 0
                if ic and statcalc.base_cls(ic) != my:
                    continue
                give_item(r['item'], r['count'])
        save_inv()

    def quest_kill(mob):
        """Прогресс квестов за убийство: 09/03, квестовые предметы — в сумку."""
        if not qlog[0]:
            return
        for qid, obj, prog, item in qlog[0].on_kill(mob.npc_id):
            if item:
                give_item(item, 1)               # прогресс сбора шлёт quest_collect
                continue
            send(0x09, 0x03, questlog.build_perform(player.eid, qid, obj, prog))
            jot(f"     квест {qid}: цель {obj['type']}/{obj['target']} {prog}/{obj['count']}")
        save_quests()

    def dungeon_apply(bodies, acts):
        """События подземелья: 0a/00 клиенту; вид 46 — волна (моб с номером точки) появляется, 47 — убрать."""
        for b in bodies:
            send(0x0a, 0x00, b)
        for kind, ref in acts:
            for m in world.mobs.values():
                if getattr(m, 'uidx', 0) != ref or getattr(m, 'sidx', None) is None:
                    continue
                if kind == dungeon.ACTIVATE and m.alive:
                    m.dormant = False
                elif kind == dungeon.DEACTIVATE:
                    m.dormant = True
                    if m.eid in spawned:
                        send(0x04, 0x03, build_disappear(m.eid))
                        spawned.discard(m.eid)
        if acts and player:
            send_nearby_mobs(world, player, send, spawned)
        if bodies:
            jot(f"     подземелье: событий 0a/00 {len(bodies)}, включений {len(acts)}")

    def dungeon_enter():
        """Карта загружена: стены лабиринта (0a/04), как оригинал при входе; событие EID — табло и отсчёт."""
        purge_passes_live()
        dg = getattr(world, 'dungeon', None) if world else None
        for b in (dg.initial() if dg else []):
            send(0x0a, 0x04, b)
        if dg is not None:
            dungeon_apply(*dg.entry())               # двери, открытые сразу (dungeon_doors.json)
        run = eid_state['run']
        if run is not None:
            if player.map == run.e['map'] and run.stage is None and not run.start_at:
                _prep = float(DEV.get('eid_prep', eidmod.PREP))
                eid_apply(run.begin(time.time(), _prep), None)
                jot(f"     событие EID {run.ev}: вход, подготовка {_prep:.0f} с, отсчёт {run.e.get('countdown')} с")
            elif player.map != run.e['map']:
                eid_state['run'] = None              # ушёл с карты события — событие закрыто

    # ---- событийные подземелья EID (eid.py, категория 0x13) ----
    eid_state = {'run': None, 'pending': None}

    def eid_apply(pkts, act):
        for p in pkts:
            if p[0] == 'doors':                      # ворота этапа (EIDMain[16]/[34]): убрать с карты
                _g = []
                for m in list(world.npcs.values()) + list(world.mobs.values()):
                    if m.npc_id in p[1]:
                        m.dormant = True             # и не досылать снова (send_nearby_mobs)
                        _g.append(f"{m.eid}{'' if m.eid in spawned else '(не видел)'}")
                        if m.eid in spawned:
                            send(0x04, 0x03, build_disappear(m.eid))
                            spawned.discard(m.eid)
                jot(f"     EID ворота {p[1]} открыты: {', '.join(_g) or 'нет на карте'}")
                continue
            if p[0] == 'msg':
                sys_msg(p[1])
                continue
            if p[0] == 'hold':                       # до старта мобы карты стоят (ai.py, world.hold)
                world.hold = bool(p[1])
                continue
            if p[0] in ('sleep', 'wake'):            # босс финала: спит до финального этапа
                _g = []
                for m in world.mobs.values():
                    if m.npc_id in p[1]:
                        _g.append(m.eid)
                        if p[0] == 'sleep':
                            m.dormant = True
                            if m.eid in spawned:
                                send(0x04, 0x03, build_disappear(m.eid))
                                spawned.discard(m.eid)
                        else:
                            m.dormant = False
                            m.alive, m.hp, m.state, m.target = True, m.maxhp, 'idle', None
                            m.x, m.y, m.z = m.spawn_x, m.spawn_y, m.spawn_z
                if p[0] == 'wake' and player:
                    send_nearby_mobs(world, player, send, spawned)
                jot(f"     EID босс {p[1]}: {'спит' if p[0] == 'sleep' else 'выпущен'} ({_g or 'нет на карте'})")
                continue
            if p[0] == 'mail':                       # награда письмом «Ваша награда» (как в оригинале)
                _pc = ACCOUNT.get(player.eid) or {}
                _pc.setdefault('mail', []).append(postbox.new_mail(p[1], p[2], p[3]))
                ACCOUNT.save()
                send(0x10, 0x04, postbox.build_count(_pc['mail']))
                jot(f"     EID письмо «{p[1]}»: " + ', '.join(f'{loot.item_name(i)} x{n}' for i, n in p[3]))
                continue
            if p[0] == 'loot':                       # добыча с босса — сразу в сумку
                for _i, _n in p[1]:
                    give_item(_i, _n)
                save_inv()
                continue
            send(p[0], p[1], p[2])
            if p[:2] == (0x13, 0x05):                # ход события — в лог (для сверки в игре)
                _c, _e, _s = struct.unpack('>HII', p[2])
                _r = eid_state['run']
                jot(f"     EID {_e}: код {_c:#x}, этап {_s}, очки {_r.score if _r else 0}")
        if not act:
            return
        kind, val = act
        if kind == 'warp' and val:
            do_warp(val)
        elif kind == 'home':
            eid_state['run'] = None
            world.hold = False
            if val:
                do_warp(val)

    def world_tick():
        """Тик потока ИИ (каждые TICK с, и когда клиент молчит): ход EID и пульс аур. Пульс раньше
        шёл только при входящем пакете — стоящий без дела игрок терял эффект ауры (остаток 4 с)."""
        eid_tick()
        if player and inv[0]:
            check_auras(time.time())

    def eid_tick():
        run = eid_state['run']
        if run is None or not world or player.map != run.e['map']:
            return
        eid_apply(*run.tick(time.time()))

    def mob_killed(mob):
        """Моб убит игроком: опыт, флетта, добыча, квесты (руда — добыча руды)."""
        if mob.state == 'notice' or getattr(mob, 'react_clear', None) is not None:
            send(0x05, 0x0b, struct.pack('>II', mob.eid, 0))   # убит со значком реакции — снять
            mob.react_clear = None
        mob.alive = False
        mob.state = 'dead'
        mob.died_at = time.time()
        _dg = getattr(world, 'dungeon', None)
        if _dg is not None and getattr(mob, 'sidx', None) is not None:
            dungeon_apply(*_dg.kill(mob.sidx, getattr(mob, 'uidx', 0), (mob.spawn_x, mob.spawn_y)))   # комната зачищена -> двери/волна
        _er = eid_state['run']
        if _er is not None and player.map == _er.e['map']:
            eid_apply(*_er.kill(mob.npc_id, time.time()))               # очки события EID
        if getattr(mob, 'gather', None):   # узел руды — добыча
            got = [f"{loot.item_name(i)} x{n}" for i, n in gather.mine() if give_item(i, n)]
            save_inv()                      # опыта за руду нет (оригинал)
            jot(f"     добыча руды: {', '.join(got)}")
            return
        # флетта копится: ~10 мобов своего уровня на 1 очко
        # (сильнее моб — быстрее, слабее — медленнее)
        gain = FLETA_PER_KILL * max(0.3, min(2.0, 1 + (mob.level - player.level) * 0.1))
        _bf = getattr(player, 'buffs', None)            # «Платиновый бустер флетты»: +30%
        if _bf:
            gain *= 1 + sum((x[2] or {}).get('fleta', 0) for x in _bf.active.values()
                            if isinstance(x[2], dict))
        player.fleta_exp = getattr(player, 'fleta_exp', 0.0) + gain
        while player.fleta_exp >= 1.0:
            player.fleta_exp -= 1.0
            player.fleta = getattr(player, 'fleta', 0) + 1
        _res = getattr(stats, 'res', None)
        # бонус опыта: +228 (зелья, VIP, кольца) и +240 («Цветок удачи» тип 62 +30%: «временное увеличение
        # получаемого опыта, можно сочетать с зельем опыта» — оригинал кладёт его в +240, отдельно от +228)
        _xp = mob_exp(mob, player, (_res.P.get(228, 0.0) + _res.P.get(240, 0.0)) if _res is not None else 0.0)
        gain_exp(_xp)                  # опыт + левелап, 08/01
        pet_gain(_xp)                  # опыт питомцу (если призван)
        give_loot(mob)                 # золото/зелья/вещи
        quest_kill(mob)                # прогресс квестов

    # ---- питомцы (pets.py, категория 11) ----
    pet_state = {'out': False, 'ent': 0}

    def pet_list():
        """Питомцы персонажа; уровень, стадия и навыки приводятся к таблицам клиента
        (у питомцев старого формата шаблон был общий — берём вид по имени)."""
        _pc = ACCOUNT.get(player.eid) if player else None
        out = []
        for h in (_pc or {}).get('pets', []):
            p = pets.Pet(bytes.fromhex(h))
            nm = CONTENT.npc.get(pets.BASE.get(p.template, {}).get('npc'), {}).get('name')
            root = pets.species_root(p.name, CONTENT.npc) if nm and p.name and nm != p.name \
                and p.uid not in (_pc or {}).get('pet_look', []) else None
            p.normalize(root)
            out.append(p)
        return out

    def pet_active():
        _pc = ACCOUNT.get(player.eid) if player else None
        uid = (_pc or {}).get('pet_active')
        return next((p for p in pet_list() if p.uid == uid), None), _pc

    def pet_save(pet):
        _pc = ACCOUNT.get(player.eid)
        if _pc is None:
            return
        lst = _pc.setdefault('pets', [])
        for i, h in enumerate(lst):
            if pets.Pet(bytes.fromhex(h)).uid == pet.uid:
                lst[i] = pet.raw.hex()
        ACCOUNT.save()

    def pet_spawn():
        pet, _pc = pet_active()
        if not pet:
            return False
        pet_state['ent'] = pets.PET_EID_BASE + (pet.uid & 0xff)
        pet_state['out'] = True
        sp = pets.build_spawn(pet, pet_state['ent'], player.eid, player.x + 60, player.y + 60,
                              player.z, CONTENT.npc)
        if sp:
            send(0x04, 0x02, sp)
        return True

    def pet_follow():
        if not pet_state['out'] or not WTPL.get((0x04, 0x01)):
            return
        class _P:          # точка «куда» — рядом с хозяином
            eid = pet_state['ent']
            x, y, z = player.x + 60, player.y + 60, player.z
        send(0x04, 0x01, build_mob_move(WTPL[(0x04, 0x01)], _P, (player.x, player.y, player.z), mode=0))

    def pet_gain(exp_gain):
        if not pet_state['out']:
            return
        pet, _pc = pet_active()
        if not pet:
            return
        if exp_gain <= 0:
            return
        g = int(pets.kill_exp(pet.level) * DEV['exp'])  # по уровню питомца (оригинал: ур.5 — 249)
        if g <= 0:
            return
        _bf = getattr(player, 'buffs', None)
        if _bf:                     # «Суперускоритель» (навык 31111: тип 72 +100% опыта питомцу)
            g = int(g * (1 + sum(p / 100 for k_, x in list(_bf.active.items()) if k_ > 0 and x[1] > time.time()
                                 for t, v, p in statcalc.skill_fx(k_, x[0]) if t == 72)))
        sk0 = pet.skills()
        ups = pet.add_exp(g)
        send(0x11, 0x0d, pets.build_exp(pet, 1, pet.exp, g))
        pet_save(pet)
        if ups:
            pet_grown(pet, sk0)

    def pet_grown(pet, sk0):
        """Новый уровень питомца: навыки (11/0d 6/7 — «Вы изучили навык»), уровень (11/0d 2 —
        «улучшен до уровня»), запись целиком (11/02), новая стадия — заново 04/02, прибавки."""
        for s_ in pet.skills():
            if s_ not in sk0:
                common, _t = pets.skills_for(pet.level, pet.ptype)
                send(0x11, 0x0d, pets.build_exp(pet, 6 if s_ in common else 7, s_, 0))
        send(0x11, 0x0d, pets.build_exp(pet, 2, pet_state['ent'] if pet_state['out'] else 0, pet.level))
        send(0x11, 0x02, pets.build_record(pet))
        jot(f"     питомец {pet.name}: ур.{pet.level}, шаблон {pet.template}, навыки {pet.skills()}")
        if pet_state['out']:
            pet_spawn()
            restat()

    def pet_slots():
        _pc = ACCOUNT.get(player.eid) if player else None
        n = len((_pc or {}).get('pets', []))
        return min(pets.MAX_SLOTS, max(n, int((_pc or {}).get('pet_slots', pets.DEFAULT_SLOTS))))

    def pet_unsummon(why=''):
        """Сервер сам отзывает питомца (смерть, продажа): 11/08 «0», прибавки — заново."""
        if pet_state['out']:
            pet_state['out'] = False
            send(0x11, 0x08, bytes([0]) + struct.pack('>H', pets.CODE))
            restat()
            jot(f"     питомец отозван{': ' + why if why else ''}")

    def check_pet(now):
        """Голод призванного питомца: −40 сытости за каждые 30 мин призыва (накопление — в
        учётке, между сеансами), при 0 — смерть и отзыв."""
        t0 = pet_state.get('t')
        pet_state['t'] = now
        _pc = ACCOUNT.get(player.eid) if player else None
        if _pc is None:
            return
        for uid_, end in list(_pc.get('pet_hatch', {}).items()):
            if now >= end:
                del _pc['pet_hatch'][uid_]
                pet_hatched(int(uid_))
        if not pet_state['out'] or t0 is None or now - t0 > 120 or now < t0:
            return
        acc = _pc.get('pet_hunger', 0.0) + (now - t0)
        if acc < pets.HUNGER_EVERY:
            _pc['pet_hunger'] = acc
            return
        _pc['pet_hunger'] = acc - pets.HUNGER_EVERY
        pet, _ = pet_active()
        if not pet:
            return
        v = pet.hunger()
        pet_save(pet)
        send(0x11, 0x0d, pets.build_exp(pet, 4, v, -pets.HUNGER_STEP))
        jot(f"     питомец {pet.name} голодает: сытость {v}")
        if pet.dead():
            pet_unsummon('умер от голода')
            sys_msg('Питомец мертв.')
        else:
            pet_autofeed(pet)

    def pet_cfg():
        """Настройки питомца (пульт F2, вкладка «Питомец»; по образцу Karos Unity): автокормление
        «кормом его стадии из сумки, когда сытость ниже N %», категории сбора трофеев (пусто — всё)."""
        _pc = ACCOUNT.get(player.eid) if player else None
        cfg = (_pc or {}).get('pet_cfg') or {}
        return {'autofeed': bool(cfg.get('autofeed', False)), 'feed_below': int(cfg.get('feed_below', 40)),
                'loot': list(cfg.get('loot', []))}

    def pet_autofeed(pet):
        cfg = pet_cfg()
        if not cfg['autofeed'] or not inv[0] or pet.egg or pet.dead():
            return False
        cap = pets.sat_cap(pet.level) or 1
        if pet.satiety * 100 >= cfg['feed_below'] * cap:
            return False
        r0 = next((r for r in inv[0].recs if r[0] != inventory.EQUIP and Inventory.item(r) in pets.FOOD
                   and pet.food_ok(Inventory.item(r))), None)
        if r0 is None:
            return False
        it, cont, cell = Inventory.item(r0), r0[0], r0[1]
        rec, left = inv[0].use(it, cell, cont)
        if left == 0:
            send(0x06, 0x06, build_putout(player.eid, cont, cell, it))
        elif rec is not None:
            send(0x06, 0x06, build_putin(player.eid, rec))
        v0 = pet.satiety
        v = pet.feed()
        pet_save(pet)
        save_inv()
        send(0x11, 0x0d, pets.build_exp(pet, 4, v, v - v0))
        jot(f"     питомец {pet.name}: автокормление {loot.item_name(it)} {v0} -> {v}")
        return True

    LOOT_CATS = {'gold': 'Караты', 'gear': 'Снаряжение', 'use': 'Расходники', 'mat': 'Материалы', 'other': 'Прочее'}

    def loot_cat(item):
        if item == GOLD:
            return 'gold'
        k = loot.ITEMS.get(item, {}).get('kind')
        return {1: 'gear', 2: 'use', 3: 'mat'}.get(k, 'other')

    def pet_hatched(uid):
        """Конец высиживания: 11/0d вид 5 (клиент: «высижен, к Мелисе»), сытость, запись."""
        pet = next((p for p in pet_list() if p.uid == uid), None)
        if not pet or not pet.egg:
            return
        pet.hatch()
        pet_save(pet)
        send(0x11, 0x0d, pets.build_exp(pet, 5, 2, 0))
        send(0x11, 0x0d, pets.build_exp(pet, 4, pet.satiety, pet.satiety))
        send(0x11, 0x02, pets.build_record(pet))
        jot(f"     питомец {pet.name} высижен: ур.{pet.level}, навыки {pet.skills()}")

    def pet_name_taken(name, uid=None):
        # имя занято другим питомцем любого персонажа аккаунта
        for ch in getattr(ACCOUNT, 'chars', []):
            for h in (ch or {}).get('pets', []):
                p = pets.Pet(bytes.fromhex(h))
                if p.uid != uid and p.name == name:
                    return True
        return False

    # ---- дебафы навыков на мобах (mobdebuff.py): иконки 05/09 и урон каждую секунду ----
    mob_dbf = {'icons': {}, 'dots': {}}

    def skill_secs(sid, lv):
        return (buffs.info().get((sid, lv)) or buffs.info().get((sid, 1)) or (0, ''))[0] or 0

    def debuff_mob(mob, sid, lv, stun=False, secs=None):
        now = time.time()
        fx = statcalc.skill_fx(sid, lv)
        secs = secs or skill_secs(sid, lv) or mobdebuff.DEFAULT_SECS
        out, dot = mobdebuff.apply(mob, fx, secs, now, stun=stun)
        send(0x05, 0x09, mobdebuff.build_icon(mob.eid, sid, lv, player.level, secs))
        mob_dbf['icons'][(mob.eid, sid, lv)] = now + secs
        if dot > 0:
            mob_dbf['dots'][(mob.eid, sid)] = [dot, now + secs, now + 1.0]
        jot(f"     дебаф {sid} ур.{lv} на {mob.eid} ({secs:.0f} с): {out}"
            f"{f', урон {dot:.0f}/с' if dot else ''}")

    def skill_drain(mob, sid, lv):
        """Удары с похищением: 32 «похищение ОЗ» — число HP персонажу (6302: 80…200, «похищение
        его здоровья»); 29 «мана −n» с «поглощением» в описании (5907, 6704) — мана персонажу, не
        больше маны моба (progression.mob_mp)."""
        fx = statcalc.skill_fx(sid, lv)
        hp = sum(v for t, v, p in fx if t == 32 and v > 0)
        mp = 0
        if 'поглощ' in (buffs.info().get((sid, lv)) or buffs.info().get((sid, 1)) or (0, ''))[1].lower():
            mp = min(progression.mob_mp(mob.level), sum(-v for t, v, p in fx if t == 29 and v < 0))
        if (hp and player.hp < player.maxhp) or (mp and player.mp < player.maxmp):
            player.hp = min(player.maxhp, player.hp + int(hp))
            player.mp = min(player.maxmp, player.mp + int(mp))
            send(0x08, 0x00, build_player_hp(G0800, player))
            jot(f"     навык {sid}: похищено HP +{int(hp)}, MP +{int(mp)}")

    hot_state = {}          # предмет -> [что, число, %?, шаг, до, следующий тик]

    def buff_list(entries, add=True, caster=0):
        """05/09 своего персонажа: уровень наложившего — свой (у оригинала 0x3c у паладина ур.60)."""
        return buffs.build_list(player.eid, entries, add, caster, getattr(player, 'level', 0))

    aura_next = {}                    # аура -> время следующего «пульса» её эффекта (id×100+1)

    def check_auras(now):
        """Ауры паладина и т.п.: эффект id×100+1 «пульсирует» — 05/09 снять + наложить с остатком
        период+1 с каждые skillLevel +148 секунд (оригинал remain3: 300501 каждые ~3.2 с)."""
        bf = getattr(player, 'buffs', None)
        if not bf or not player:
            return
        for sid in [k for k in list(aura_next) if k not in bf.active]:
            aura_next.pop(sid, None)          # зовётся из потока ИИ — наложение может менять словарь
        for sid, (lv, _t, _e) in list(bf.active.items()):
            if sid <= 0:
                continue
            child = buffs.pulse_child(sid, lv)
            if not child:
                continue
            nxt = aura_next.get(sid)
            if nxt is None:
                aura_next[sid] = now + buffs.period(sid, lv)
                continue
            if now >= nxt:
                per = buffs.period(sid, lv)
                aura_next[sid] = now + per
                send(0x05, 0x09, buff_list([(child, lv, 0)], add=False))
                send(0x05, 0x09, buff_list([(child, lv, int(per) + 1)]))

    def check_hot(now):
        """Зелья восстановления по времени (consumables.HOT): тик каждые N секунд, по окончании —
        значок 05/09 снимается."""
        if not hot_state or not player:
            return
        changed = False
        for it, st in list(hot_state.items()):
            what, amt, pct, step, until, nxt = st
            while nxt <= now and nxt <= until:
                if what == 'hp' and player.hp < player.maxhp:
                    player.hp = min(player.maxhp, player.hp + int(player.maxhp * amt / 100 if pct else amt))
                    changed = True
                elif what == 'mp' and player.mp < player.maxmp:
                    player.mp = min(player.maxmp, player.mp + int(player.maxmp * amt / 100 if pct else amt))
                    changed = True
                nxt += step
            st[5] = nxt
            if now >= until:
                del hot_state[it]
                send(0x05, 0x09, buff_list([(it, 1, 0)], add=False))
        if changed:
            send(0x08, 0x00, build_player_hp(G0800, player))

    def check_mob_debuffs(now):
        if not world or not (mob_dbf['icons'] or mob_dbf['dots']):
            return
        for key, until in list(mob_dbf['icons'].items()):
            mob = world.mobs.get(key[0])
            if mob is None or not mob.alive:
                del mob_dbf['icons'][key]
            elif now >= until:
                del mob_dbf['icons'][key]
                send(0x05, 0x09, mobdebuff.build_icon(key[0], key[1], key[2], player.level, 0, add=False))
        for key, d in list(mob_dbf['dots'].items()):
            mob = world.mobs.get(key[0])
            if mob is None or not mob.alive or now >= d[1] + 0.5:
                del mob_dbf['dots'][key]
                continue
            while now >= d[2] and d[2] <= d[1] + 0.01 and mob.hp > 0:
                d[2] += 1.0
                dmg = max(1, int(round(d[0] * DEV['dmg'])))
                mob.hp = max(0, mob.hp - dmg)
                send(0x08, 0x06, build_hp(T0806, mob.eid, mob.hp))
                jot(f"     дебаф {key[1]}: урон {dmg} по {mob.eid}, HP {mob.hp}")
            if mob.hp == 0:
                del mob_dbf['dots'][key]
                mob_killed(mob)

    def pet_sell_room(pet):
        """Ячеек продажи у помощника: стат 70 навыка типа (900016/17/18 -> 6/12/18)."""
        if not pet or pet.ptype != 3:
            return 0
        best = 0
        for s_ in pet.skills():
            for e in (statcalc.FX.get(str(s_), {}).get('lv', {}).get('1') or []):
                if e[0] == pets.SELL_STAT:
                    best = max(best, int(e[1]))
        return best

    def pet_buffs():
        """Навыки призванного питомца — прибавки хозяину (вид 23: атака %, шанс выпадения, крит…)."""
        try:
            if not pet_state['out']:
                return []
        except NameError:
            return []
        pet, _ = pet_active()
        return [(s_, 1, None) for s_ in (pet.skills() if pet else [])
                if statcalc.skill_kind(s_) == statcalc.BUFF]

    # ---- GXP-рюкзак (кэш-хранилище предметов, 06/48-06/49) ----
    GXP_UID0 = 1000

    def gxp_list():
        _pc = ACCOUNT.get(player.eid) if player else None
        if _pc is None:
            return []
        lst = _pc.setdefault('gxp', [])
        lst[:] = [x for x in lst if x[0] in loot.ITEMS]   # неизвестные клиенту — не показываем
        return lst

    def build_gxp_page(page, per=15):
        lst = gxp_list()
        chunk = lst[(page - 1) * per:page * per]
        out = bytearray(struct.pack('>III', page, len(chunk), len(lst)))
        for i, (item, cnt) in enumerate(chunk):
            out += struct.pack('<IIII', GXP_UID0 + (page - 1) * per + i, 0, item, cnt)
        return bytes(out)

    # ---- пульт разработчика (devtools.py, окно tools/devpanel.py по F2) ----
    def dev_info():
        return {'eid': player.eid, 'name': player.name, 'level': player.level,
                'exp': player.exp, 'exp_next': exp_to_next(player.level),
                'hp': int(player.hp), 'maxhp': int(player.maxhp),
                'mp': int(player.mp), 'maxmp': int(player.maxmp),
                'map': player.map, 'map_name': MAP_NAMES.get(player.map, ''),
                'x': round(player.x), 'y': round(player.y),
                'gold': inv[0].gold() if inv[0] else 0,
                'fleta': getattr(player, 'fleta', 0), 'sp': skill_points(player),
                'stats': {k: round(float(getattr(stats, k, 0) or 0), 1) for k in (
                    'atk_min', 'atk_max', 'matk_min', 'matk_max', 'wmin', 'wmax', 'mwmin', 'mwmax',
                    'base_atk', 'base_matk', 'blk116', 'blk124', 'crit', 'crit_dmg', 'defense', 'base_mdef')},
                'magic': bool(getattr(stats, 'magic', False))}

    def dev_refresh():
        send(0x08, 0x02, build_stats_full(player, stats))
        send(0x08, 0x01, build_hero_gage(player))
        send(0x08, 0x00, build_player_hp(G0800, player))

    def dev_level(value):
        player.level = max(1, min(MAX_LEVEL, int(value)))
        player.exp = 0
        restat(send_now=False)
        player.hp, player.mp = player.maxhp, player.maxmp
        dev_refresh()
        save_state()
        jot(f"     [пульт] уровень -> {player.level}")
        return dev_info()

    def dev_exp(value):
        gain_exp(int(value))
        return dev_info()

    def dev_item(id, count=1):
        ok = give_item(int(id), int(count))
        save_inv()
        return ok

    def dev_gold(value):
        return dev_item(GOLD, value)

    def dev_heal():
        player.hp, player.mp = player.maxhp, player.maxmp
        dev_refresh()
        return dev_info()

    def dev_goto(x, y):
        player.x, player.y = float(x), float(y)
        player.z = ground_height(MAP_NAMES.get(player.map, ''), player.x, player.y, player.z)
        send(0x04, 0x02, build_position(player))
        drop_spawned()
        n = send_nearby_mobs(world, player, send, spawned) if world else 0
        save_state()
        jot(f"     [пульт] перенос -> {player.x:.0f},{player.y:.0f} (мобов {n})")
        return dev_info()

    def dev_teleport(target):
        return do_warp(int(target))

    def dev_mobs(level=None, near=0):
        """Мобы карты по уровням: [(уровень, сколько, ближайший x, y, npc_id)]."""
        if not world:
            return []
        groups = {}
        for m in world.mobs.values():
            if not m.alive or getattr(m, 'gather', None):
                continue
            d = (m.x - player.x) ** 2 + (m.y - player.y) ** 2
            g = groups.setdefault(m.level, [0, d, m])
            g[0] += 1
            if d < g[1]:
                g[1], g[2] = d, m
        out = [{'level': lv, 'count': c, 'x': round(m.x), 'y': round(m.y),
                'npc': getattr(m, 'npc_id', 0), 'dist': round(d ** 0.5)}
               for lv, (c, d, m) in sorted(groups.items())]
        return out

    def dev_hunt(level):
        """Перенос к ближайшему мобу нужного уровня (или ближайшего к нему)."""
        ms = dev_mobs()
        if not ms:
            return None
        best = min(ms, key=lambda g: (abs(g['level'] - int(level)), g['dist']))
        return dev_goto(best['x'] + 150, best['y'] + 150)

    def dev_kill(radius=1500, objects=True, uidx=None):
        """Убить живых мобов вокруг (с опытом и добычей). objects=False — не трогать стартеры/кристаллы/
        ключи событий (static): убитый ключ снимает остаток своей волны (сценарий .me); uidx — только
        мобов с этим номером точки карты."""
        if not world:
            return 0
        n = 0
        r2 = float(radius) ** 2
        for m in list(world.mobs.values()):
            if not m.alive or getattr(m, 'gather', None) or getattr(m, 'dormant', False):
                continue                  # волна подземелья, которой ещё нет, не убивается
            if not objects and getattr(m, 'static', False):
                continue
            if uidx is not None and getattr(m, 'uidx', None) != int(uidx):
                continue
            if (m.x - player.x) ** 2 + (m.y - player.y) ** 2 > r2:
                continue
            dmg = max(1, int(m.hp))
            m.hp = 0
            send(0x05, 0x02, build_damage(T0502, player.eid, m.eid, dmg, ATK_NORMAL,
                                          (m.x, m.y, m.z), attacker_type=ENT_PLAYER,
                                          target_type=ENT_MOB))
            send(0x08, 0x06, build_hp(T0806, m.eid, 0))
            mob_killed(m)
            n += 1
        jot(f"     [пульт] убито мобов: {n}")
        return n

    def dev_bag(act='list', cells=None):
        """Массовые действия с сумкой (пульт F2, вкладка «Сумка»; в Karos Unity — «отметьте предметы и
        нажмите разбор / корзину ещё раз»; в клиенте оригинала отметок нет). act: list | sell | destroy |
        dismantle | stash; cells — [[контейнер, ячейка], ...]. Продажа — по цене торговца (как 06/0e),
        разборка — правила разборки клиента (как 06/56), хранилище — личное, с платой 10 (как 06/1a).
        cells — приметы из list (inventory.stamp): список мог устареть, по одному адресу [сумка, ячейка]
        уничтожалась чужая вещь. Не совпало — вещь не трогаем, в ответе stale."""
        if not inv[0]:
            return {'items': []}
        if act == 'sort':
            return bag_sort()
        if act == 'list':
            out = []
            for r in sorted(inv[0].recs, key=lambda r: (r[0], r[1])):
                it = Inventory.item(r)
                if r[0] == inventory.EQUIP or it == GOLD:
                    continue
                info = loot.ITEMS.get(it, {})
                out.append({'cont': r[0], 'cell': r[1], 'item': it, 'name': loot.item_name(it),
                            'n': Inventory.count32(r) or 1, 'kind': info.get('kind'), 'lvl': info.get('lvl'),
                            'ref': inventory.stamp(r),
                            'improved': info.get('kind') == 1 and inventory.improved(r),
                            'sell': info.get('sell') or info.get('price', 0) // 2,
                            'dismantle': bool(craft.dismantle_rule(it, info.get('kind'), info.get('lvl')))})
            return {'items': out, 'gold': inv[0].gold()}
        done, gold0 = [], inv[0].gold()
        _pc = ACCOUNT.get(player.eid) or {}
        srecs = stash.load(_pc.get('stash'), inventory.DURABILITY) if act == 'stash' else None
        cap = stash.capacity(int(_pc.get('stash_level', 0))) if act == 'stash' else 0
        stale = 0
        for ref in (cells or []):
            cont, cell = int(ref[0]), int(ref[1])
            r = inv[0].find(cont, cell)
            if r is None or r[0] == inventory.EQUIP or inventory.stamp(r) != list(ref):
                stale += 1
                continue
            it, n = Inventory.item(r), Inventory.count32(r) or 1
            if it == GOLD:
                continue
            info = loot.ITEMS.get(it, {})
            if act == 'sell':
                price = info.get('sell') or info.get('price', 0) // 2
                if price <= 0:
                    continue
                _r0 = bytes(r)
                inv[0].remove(r[0], r[1], None, it)
                send(0x06, 0x06, build_putout(player.eid, int(cont), int(cell), it))
                repur.append({'rec': _r0, 'n': n, 'price': price})
                del repur[:-REPUR_MAX]
                give_item(GOLD, price * n, notice=False)
                done.append(f'{loot.item_name(it)} x{n}')
            elif act == 'destroy':
                inv[0].remove(r[0], r[1], None, it)
                send(0x06, 0x06, build_putout(player.eid, int(cont), int(cell), it))
                done.append(f'{loot.item_name(it)} x{n}')
            elif act == 'dismantle':
                rule = craft.dismantle_rule(it, info.get('kind'), info.get('lvl'))
                if not rule or inv[0].gold() < rule['cost']:
                    continue
                res = craft.dismantle_roll(rule)
                ok = bool(res and give_item(res[0], res[1]))   # материал — до удаления: нет места — вещь цела
                if res and not ok:
                    done.append(f"{loot.item_name(it)} — нет места")
                    continue
                inv[0].remove(r[0], r[1], item=it)
                send(0x06, 0x06, build_putout(player.eid, int(cont), int(cell), it))
                if rule['cost']:
                    give_item(GOLD, -rule['cost'], notice=False)
                done.append(f"{loot.item_name(it)} -> {loot.item_name(res[0]) + ' x%d' % res[1] if ok else 'неудача'}")
            elif act == 'stash':
                stk = info.get('stack', 1) > 1
                slot = next((s for s, c in srecs.items() if stk and stash.item_of(c) == it), None)
                if slot is None:
                    slot = next((s for s in range(cap) if s not in srecs), None)
                if slot is None or inv[0].gold() < stash.FEE_PERSONAL:
                    break                                  # хранилище полно / нет на плату
                copy = bytearray(r)
                rest, got, k = inv[0].remove(r[0], r[1], None, it)
                stash.put(srecs, slot, copy, k, cap, stk)
                send(0x06, 0x06, build_putout(player.eid, int(cont), int(cell), it))
                give_item(GOLD, -stash.FEE_PERSONAL, notice=False)
                done.append(f'{loot.item_name(it)} x{k}')
        if act == 'stash' and done:
            _pc['stash'] = stash.dump(srecs)
        save_inv()
        if act == 'sell' and repur:
            send(0x06, 0x57, build_repur())
        jot(f"     [пульт] сумка: {act} — {len(done)}: {', '.join(done)[:300]}")
        return {'done': done, 'stale': stale, 'gold': inv[0].gold(), 'gold_delta': inv[0].gold() - gold0}

    def quick_saved():
        """Быстрые слоты персонажа для правки: {слот: [id, сумка, ячейка]} или None (править нечего)."""
        pc = ACCOUNT.get(player.eid) if player else None
        if pc is None:
            return None
        if pc.get('quick') is None:
            raw = raw_of(player, '02/05')
            if not raw:
                return None
            pc['quick'] = quick_block(raw)
        return pc['quick']

    def bag_tidy_saved(pc):
        """Вход в мир, до 02/05 и 06/05: просроченные пропуска прочь, стопки — до лимита, быстрые слоты
        влитых стопок — на ту, куда влились."""
        if not pc or not pc.get('inv'):
            return
        iv = Inventory.from_saved(bytes(6), pc['inv'])
        gone = iv.purge_passes(loot.ITEMS)
        changed, removed = iv.merge_stacks()
        if not (gone or changed or removed):
            return
        q = quick_saved()
        for k, e in list((q or {}).items()):
            if any(list(e) == [it, c, s] for c, s, it in gone):
                del q[k]
                continue
            for c, s, it, tc, ts in removed:
                if list(e) == [it, c, s]:
                    q[k] = [it, tc, ts]
                    break
        pc['inv'] = iv.to_saved()
        ACCOUNT.save()
        jot(f"     сумка при входе: просроченных пропусков убрано {len(gone)} "
            f"({', '.join(loot.item_name(x[2]) for x in gone)}), стопок влито {len(removed)}")

    def purge_passes_live():
        """Смена карты и вход в событие: пропуск, истёкший за время игры. Ячейку чистит пустая 06/06:
        06/07 стёр бы чужой быстрый слот с тем же номером ячейки."""
        if not (player and inv[0]):
            return
        gone = inv[0].purge_passes(loot.ITEMS)
        if not gone:
            return
        q = quick_saved()
        for c, s, it in gone:
            send(0x06, 0x06, build_putin(player.eid, empty_rec(c, s)))
            for k, e in list((q or {}).items()):
                if list(e) == [it, c, s]:
                    del q[k]
        save_inv()
        jot(f"     просроченные пропуска убраны: {[loot.item_name(x[2]) for x in gone]}")

    def bag_sort():
        """Кнопка сумки клиента (C 06/51) и пульт F2: объединить стопки и разложить как считает клиент
        (inventory.sort_all). На каждую перемену — 06/06 ячеек (байт +4 = 1 — без подсказки «надеть»,
        0x006533c1), затем S 06/08: по нему клиент переносит быстрый слот (0x00621d24; предметы уже должны
        стоять на новых местах). 06/07 не шлём — стирает быстрый слот (0x00621b43). 06/52 не шлём — клиент
        по нему очищает все сетки сумок (0x0061ca84). В конце 06/06 тронутых ещё раз — пересчёт количеств."""
        if craft_job[0]:
            return {'error': 'идёт изготовление — дождитесь конца'}
        before = {id(r): bytes(r) for r in inv[0].recs}
        quick = quick_saved()

        def put(rec):
            p = bytearray(build_putin(player.eid, rec))
            p[4] = 1
            send(0x06, 0x06, bytes(p))

        def linked(item, c, s):
            return [k for k, e in (quick or {}).items() if list(e) == [item, c, s]]

        changed, removed = inv[0].merge_stacks()
        for r in changed:
            put(r)
        for c, s, it, tc, ts in removed:
            put(empty_rec(c, s))
            src = linked(it, c, s)
            if src and not linked(it, tc, ts):         # иначе клиент увёл бы слот цели в пустую ячейку
                send(0x06, 0x08, struct.pack('>IBBIBBI', player.eid, c, s, it, tc, ts, 0))
            for k in src:
                quick[k] = [it, tc, ts]
        old = {(r[0], r[1]): bytearray(r) for r in inv[0].recs}
        swaps, skipped = inv[0].sort_all(loot.ITEMS)
        for c, s, tc, ts, item, other in swaps:
            a, b = old.pop((c, s)), old.pop((tc, ts), None)
            a[0], a[1] = tc, ts
            old[(tc, ts)] = a
            put(a)
            if b is not None:
                b[0], b[1] = c, s
                old[(c, s)] = b
            put(b if b is not None else empty_rec(c, s))
            send(0x06, 0x08, struct.pack('>IBBIBBI', player.eid, c, s, item, tc, ts, other))
            src, dst = linked(item, c, s), linked(other, tc, ts) if other else []
            for k in src:
                quick[k] = [item, tc, ts]
            for k in dst:
                quick[k] = [other, c, s]
        touched = [r for r in inv[0].recs if before[id(r)] != bytes(r)]
        for r in touched:
            put(r)
        if touched or removed:
            save_inv()
        jot(f"     сортировка: стопок влито {len(removed)}, обменов {len(swaps)}, тронуто {len(touched)}, "
            f"пропущены сумки {skipped}")
        return {'moved': len(touched), 'merged': len(removed), 'skipped': skipped}

    def craft_keep(r):
        """«Изготовить всё» не берёт в материалы улучшенное снаряжение."""
        return loot.ITEMS.get(Inventory.item(r), {}).get('kind') == 1 and inventory.improved(r)

    def craft_room(item):
        """Сколько штук результата влезет (как кладёт give_item)."""
        item = BAG_REPLACE.get(item, item)
        info = loot.ITEMS.get(item, {})
        if info.get('kind') != 1 and info.get('stack', 1) > 1:         # стопками до лимита
            return min(craft.BATCH_MAX, inv[0].room_for(item))
        return inv[0].free_count()

    def dev_craft(act='list', rid=None, count=0):
        """«Изготовить всё» (пульт F2, вкладка «Крафт»; в Karos Unity — CraftMakeAll). list — рецепты, на
        которые хватает материалов; make — до count попыток (столько подтвердили на пульте). Шанс, цена и
        материалы — рецепта; останавливается на нехватке или полной сумке. Как и обычный крафт сервера,
        не проверяет навык ремесла; ремесленник рядом не нужен."""
        if not inv[0]:
            return {'recipes': []}
        if act == 'list':
            out = []
            for k in craft.LISTED:
                rec = craft.RECIPES[k]
                n = craft.affordable(inv[0], rec, GOLD, craft_keep)
                kept = sum(inv[0].count_item(m) - inv[0].count_item(m, craft_keep) for m, _ in rec['mats'])
                if n:
                    out.append({'rid': k, 'name': rec['name'], 'group': rec['group'], 'count': n,
                                'cost': rec['cost'], 'chance': rec['chance'] / 100, 'kept': kept,
                                'mats': [[loot.item_name(m), per] for m, per in rec['mats']]})
            return {'recipes': sorted(out, key=lambda x: (x['group'], x['name'], x['rid']))}
        if act != 'make' or rid is None or int(rid) not in craft.LISTED:
            return {'error': 'нет такого рецепта'}
        if craft_job[0]:
            return {'error': 'идёт изготовление — дождитесь конца'}
        rid, want = int(rid), min(craft.BATCH_MAX, max(0, int(count)))
        rec = craft.RECIPES[rid]
        tries = made = 0
        stop = 'готово'
        while tries < want:
            can = min(want - tries, craft.affordable(inv[0], rec, GOLD, craft_keep))
            if not can:
                stop = 'не хватает материалов или карат'
                break
            room = craft_room(rec['item'])
            if not room:
                stop = 'сумка полна'
                break
            n = ok = 0
            while n < can and ok < room:          # не больше удач, чем мест: материалы зря не тратим
                n += 1
                ok += bool(craft.roll(rec))
            take_items([(m, per * n) for m, per in rec['mats']], f"крафт {rid} x{n}", craft_keep)
            if rec['cost']:
                give_item(GOLD, -rec['cost'] * n, notice=False)
            if ok:
                give_item(rec['item'], ok)
            tries += n
            made += ok
        if tries:
            save_inv()
        jot(f"     [пульт] изготовить всё {rid} {rec['name']}: попыток {tries}, удачно {made}, {stop}")
        return {'tries': tries, 'made': made, 'failed': tries - made, 'stop': stop}

    def dev_pet(autofeed=None, feed_below=None, loot_cats=None, ptype=None):
        """Настройки питомца с пульта: автокормление и порог, категории сбора трофеев, тип способности
        (1 чарователь, 2 счастливчик, 3 помощник; в клиенте тип выбирается раз — здесь можно сменить)."""
        _pc = ACCOUNT.get(player.eid) if player else None
        if _pc is None:
            return {'ok': False}
        cfg = _pc.setdefault('pet_cfg', {})
        if autofeed is not None:
            cfg['autofeed'] = bool(autofeed)
        if feed_below is not None:
            cfg['feed_below'] = max(5, min(95, int(feed_below)))
        if loot_cats is not None:
            cfg['loot'] = [c for c in loot_cats if c in LOOT_CATS]
        pet, _ = pet_active()
        if ptype is not None and pet and not pet.egg and int(ptype) in pets.TYPE_NAMES \
                and int(ptype) != pet.ptype:
            pet.set_type(int(ptype))                     # навыки типа пересчитывает normalize()
            pet_save(pet)
            send(0x11, 0x02, pets.build_record(pet))     # клиенту — запись целиком
            if pet_state['out']:
                pet_spawn()
            restat()
            sys_msg('Тип питомца: %s.' % pets.TYPE_NAMES[int(ptype)])
        ACCOUNT.save()
        if pet and cfg.get('autofeed'):
            pet_autofeed(pet)
        info = None
        if pet:
            info = {'name': pet.name, 'level': pet.level, 'type': pets.TYPE_NAMES.get(pet.ptype, 'не выбран'),
                    'satiety': pet.satiety, 'cap': pets.sat_cap(pet.level), 'out': bool(pet_state['out'])}
        jot(f"     [пульт] питомец: {pet_cfg()} {info}")
        return {'cfg': pet_cfg(), 'cats': LOOT_CATS, 'pet': info}

    def dev_fleta(value):
        player.fleta = max(0, int(value))
        restat()
        save_state()
        return dev_info()

    def dev_skillpts(value):
        player.sp_spent = max(0, player.level - 1 - int(value))
        send(0x08, 0x01, build_hero_gage(player))
        save_state()
        return dev_info()

    def dev_petexp(value):
        """Опыт текущему питомцу (рост — как от охоты; на ур.3/6/9 — до порога тренировки)."""
        pet, _ = pet_active()
        if not pet:
            return False
        sk0 = pet.skills()
        ups = pet.add_exp(int(value))
        send(0x11, 0x0d, pets.build_exp(pet, 1, pet.exp, int(value)))
        pet_save(pet)
        if ups:
            pet_grown(pet, sk0)
        return {'pet': pet.name, 'level': pet.level, 'exp': pet.exp, 'template': pet.template,
                'type': pet.ptype, 'skills': pet.skills(), 'train': pet.needs_training()}

    def dev_petsat(value):
        """Сытость текущему питомцу (0 — смерть: проверка воскрешения); счётчик голода — с нуля,
        value < 0 — сразу «−40» голода (как через 30 мин призыва)."""
        pet, _pc = pet_active()
        if not pet:
            return False
        value = int(value)
        if value < 0:
            _pc['pet_hunger'] = pets.HUNGER_EVERY
            pet_state['t'] = time.time() - 1
            check_pet(time.time())
            pet, _ = pet_active()
        else:
            v0 = pet.satiety
            pet.feed(value - v0)
            pet_save(pet)
            send(0x11, 0x0d, pets.build_exp(pet, 4, pet.satiety, pet.satiety - v0))
            if pet.dead():
                pet_unsummon('сытость 0')
        return {'pet': pet.name, 'satiety': pet.satiety, 'dead': pet.dead(), 'out': pet_state['out']}

    def dev_pethatch():
        # высиживание — сразу (вместо 15 минут)
        _pc = ACCOUNT.get(player.eid)
        hs = (_pc or {}).get('pet_hatch', {})
        for k in hs:
            hs[k] = 0
        check_pet(time.time())
        return {'hatched': len(hs) == 0, 'pets': [(p.name, p.level, p.state) for p in pet_list()]}

    QUEST_AUTO_MAX = 20      # активных квестов не больше: список 09/02 — 1044 байта на квест

    def quest_available(q, log):
        if q['min_level'] > player.level or player.level > (q.get('max_level') or 999) or q['id'] in log.active:
            return False                 # уровни — quest.lod +52/+56 (сверено с официальной базой)
        if q['id'] in log.done and not questlog.repeatable(q['id']):
            return False
        return not q.get('prev') or q['prev'] in log.done

    def quest_done_all(qid, log):
        """Все цели квеста выполнены, включая «поговорить/отнести» (их засчитывает клиент у NPC, 09/03)."""
        prog = log.active.get(qid)
        if prog is None:
            return False
        return all(prog.get(o['i'], 0) >= o['count'] for o in questlog.QUESTS[qid]['objectives'])

    def dev_quests(act='list'):
        """Автозадания (Karos Unity: AutoQuest — список, принять, награда); в клиенте окна нет — пульт F2.
        act: list | accept (все доступные по уровню, с выполненным предыдущим, до QUEST_AUTO_MAX активных) |
        turn_in (сдать без похода к NPC те, где выполнены все цели)."""
        log = qlog[0]
        if not log:
            return {'error': 'журнал квестов не загружен'}
        done_now = []
        if act == 'accept':
            avail = sorted((q for q in questlog.QUESTS.values() if quest_available(q, log)),
                           key=lambda q: (-q['min_level'], q['id']))
            for q in avail:
                if len(log.active) >= QUEST_AUTO_MAX:
                    break
                if log.accept(q['id']):
                    quest_started(q['id'], q)
                    done_now.append(q['title'])
        elif act == 'turn_in':
            for qid in [k for k in log.active if quest_done_all(k, log)]:
                q = log.complete(qid)
                if q:
                    give_quest_rewards(q)
                    send(0x09, 0x01, questlog.build_reward(player.eid, qid))
                    done_now.append(q['title'])
        if act in ('accept', 'turn_in'):
            send(0x09, 0x02, questlog.build_list(player.eid, log))
            send(0x09, 0x04, questlog.build_complete_list(player.eid, log))
            save_quests()
            jot(f"     [пульт] автозадания {act}: {len(done_now)} — {', '.join(done_now)[:300]}")
        active = []
        for qid, prog in log.active.items():
            q = questlog.QUESTS.get(qid) or {}
            goals = ['%d/%d' % (min(prog.get(o['i'], 0), o['count']), o['count']) for o in q.get('objectives', [])]
            active.append({'id': qid, 'title': q.get('title', '?'), 'level': q.get('min_level'),
                           'goal': (q.get('goal') or '')[:80], 'progress': goals,
                           'ready': quest_done_all(qid, log)})
        return {'done': done_now, 'active': active,
                'available': sum(1 for q in questlog.QUESTS.values() if quest_available(q, log))}

    def dev_hair(act='list', id=None, color=None, rgb=None):
        """Пульт: причёски класса и цвет волос (hair.py). act: list | style (id — выдать причёску в сумку,
        без ножниц) | color (color — номер в палитре или rgb [r, g, b]; 0 — свой цвет)."""
        _pc = ACCOUNT.get(player.eid) or {}
        if act == 'style' and id:
            ok = give_item(int(id), 1)
            save_inv()
            return {'ok': ok, 'name': loot.item_name(int(id))}
        if act == 'color':
            if rgb is None and color is not None:
                rgb = hair.PALETTE[int(color) % len(hair.PALETTE)][1]
            if rgb is not None:
                return {'ok': True, 'name': set_hair_color(rgb)}
        return {'styles': [{'id': i, 'name': n} for i, n in hair.styles_for(player.cls, loot.ITEMS)],
                'palette': [{'name': n, 'rgb': list(c)} for n, c in hair.PALETTE],
                'color': hair.color_name(_pc.get('hair_color'))}

    def dev_locked(f):
        def run(**kw):
            with op_lock:
                return f(**kw)
        return run

    def dev_register():
        devtools.register(devtools.Session(
            player.eid, player.name, info=dev_info, level=dev_level, exp=dev_exp, petexp=dev_petexp, petsat=dev_petsat, pethatch=dev_pethatch,
            item=dev_locked(dev_item), gold=dev_locked(dev_gold), heal=dev_heal, goto=dev_goto,
            teleport=dev_teleport, mobs=dev_mobs, hunt=dev_hunt, kill=dev_locked(dev_kill), hair=dev_locked(dev_hair),
            quests=dev_locked(dev_quests),
            bag=dev_locked(dev_bag), pet=dev_locked(dev_pet), craft=dev_locked(dev_craft),
            fleta=dev_fleta, skillpts=dev_skillpts, restat=lambda: restat() or True,
            save=lambda: save_state() or True))

    def give_loot(mob):
        """Добыча с моба сразу в сумку (06/06) + сообщение в чат (06/03)."""
        if not inv[0] or not player:
            return
        got = []
        for item, count in loot.roll(mob, player):
            if item == GOLD:
                if give_item(item, count):           # золото — сразу в сумку
                    got.append(f"золото x{count}")
                continue
            if AUTO_LOOT or not GROUND_DROPS:        # автосбор (временно) — сразу в сумки
                if give_item(item, count):
                    got.append(f"{loot.item_name(item)} x{count}")
                    continue
                if not GROUND_DROPS:
                    continue                         # места нет — на землю
            # остальное — на землю у моба, с подписью; подбирается кликом (06/03)
            base = next((r for r in inv[0].recs if r[0] == 1), None)
            g = world.ground.drop(player.eid, item, count, mob.x, mob.y, mob.z, base,
                                  period=loot.ITEMS.get(item, {}).get('period', 0))
            send(0x06, 0x04, build_drop(player.eid, g))
            got.append(f"{loot.item_name(item)} x{count} (на землю)")
        if got:
            save_inv()
            jot(f"     добыча: {', '.join(got)}; золото {inv[0].gold()}")

    def use_special(pl):
        """06/02 C->S: +0 eid, +4 контейнер, +5 ячейка, +6 item BE32. Подарки
        новичка, свиток/камень возврата. -> True, если обработано."""
        if len(pl) < 10:
            return False
        item = struct.unpack_from('>I', pl, 6)[0]
        info = loot.ITEMS.get(item, {})
        name = info.get('name', '')
        costume.init(loot.ITEMS)
        if item == hair.DYE:                           # «Краска Мореаля (вечная)»: следующий цвет, не расходуется
            if inv[0].find(pl[4], pl[5]) is None:
                return False
            _pc = ACCOUNT.get(player.eid) or {}
            name_, rgb = hair.next_color(_pc.get('hair_color'))
            send(0x06, 0x02, build_item_use(player.eid, item))
            set_hair_color(rgb)
            sys_msg('Цвет волос: %s. Ещё раз краской — следующий цвет.' % name_)
            return True
        if item == hair.SCISSORS:                      # «Ножницы Мореаля»: следующая причёска класса на 30 дней
            styles = hair.styles_for(player.cls, loot.ITEMS)
            if not styles:
                sys_msg('Для вашего класса причёсок нет.')
                send(0x06, 0x02, pl)
                return True
            _pc = ACCOUNT.get(player.eid) or {}
            k = (int(_pc.get('hair_next', 0)) % len(styles))
            sid, sname = styles[k]
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            give_item(sid, 1)
            _pc['hair_next'] = k + 1
            save_inv()
            ACCOUNT.save()
            sys_msg('Причёска «%s» — в сумке, наденьте её (30 дней).' % sname)
            jot(f"     ножницы: причёска {sid} «{sname}»")
            return True
        if item == transform.CANCEL_POTION:            # «Зелье отмены превращения»
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            save_inv()
            untransform('(зелье)')
            return True
        if item in costume.BOX or item in costume.COUPON:
            # коробка костюма/крыльев -> купоны (или сами крылья); купон -> деталь костюма
            # для класса персонажа с тем же сроком (costume.py)
            if item in costume.COUPON:
                part = costume.part_for(item, player.cls)
                contents = [(part, 1)] if part else []
            else:
                contents = [(c, 1) for c in costume.BOX[item]]
            need = info.get('lvl', 0)
            if not contents or player.level < need:
                jot(f"     {name}: {'нет содержимого' if not contents else f'нужен ур.{need}'}")
                send(0x06, 0x02, pl)
                return True
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            for it, n in contents:
                if not give_item(it, n):
                    jot(f"     нет места для {loot.item_name(it)}")
            save_inv()
            jot(f"     открыт {name}: {[loot.item_name(i) for i, _ in contents]}")
            return True
        if item in BOXES or item in gifts.GIFTS:
            need = info.get('lvl', 0)
            if player.level < need:
                jot(f"     подарок {item}: нужен ур.{need}")
                send(0x06, 0x02, pl)
                return True
            # состав — из описания предмета («[Состав]», tools/boxes.py); нет его —
            # свой набор (подарок ур.1)
            contents = [tuple(x) for x in BOXES[item]] if item in BOXES                 else gifts.open_gift(item, player)
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            for it, n in contents:
                give_item(it, n)
            save_inv()
            jot(f"     открыт {name}: {contents}")
            return True
        consumables.init()
        if item in consumables.BOXN:                   # «Содержит 50 маленьких зелий восстановления»
            it_, n_ = consumables.BOXN[item]
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            give_item(it_, n_)
            save_inv()
            jot(f"     открыта коробка {item}: {loot.item_name(it_)} x{n_}")
            return True
        _town = consumables.town_target(item, WARPS['targets'])
        if item in RETURN_ITEMS or _town:
            consume = RETURN_ITEMS.get(item, True)
            if consume:
                rec, left = inv[0].use(item, pl[5], pl[4])
                if rec is None:
                    return False
                if left == 0:
                    send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
                else:
                    send(0x06, 0x06, build_putin(player.eid, rec))
                save_inv()
            send(0x06, 0x02, build_item_use(player.eid, item))
            _pc = ACCOUNT.get(player.eid) or {}
            # «Свиток возврата в <город>» — в его город; «Камень возврата» — в сохранённую точку
            do_warp(_town if _town and item != 57104 else saved_return_point())
            return True
        # капсула с питомцем: регистрация питомца (вид — по имени капсулы/описанию)
        _tpl = pets.CAPSULE.get(item)                 # капсула вида (petBase +8)
        _species = CONTENT.npc.get(pets.BASE[_tpl]['npc'], {}).get('name') if _tpl else None
        if not _species:
            _species = next((n for n in pets.stages(CONTENT.npc)
                             if n and n.lower() in name.lower()), None) if 'капсул' in name.lower() \
                or name in pets.stages(CONTENT.npc) else None
            _tpl = pets.species_root(_species, CONTENT.npc) if _species else None
        if _species and pets.TEMPLATE_REC and \
                len((ACCOUNT.get(player.eid) or {}).get('pets', [])) >= pet_slots():
            sys_msg('Недостаточно слотов для регистрации дополнительных питомцев. '
                    'Освободите слот для нового питомца.')
            return True
        if _species and pets.TEMPLATE_REC:
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            _pc = ACCOUNT.get(player.eid)
            _n = max([pets.Pet(bytes.fromhex(h)).uid & 0xff for h in _pc.get('pets', [])] + [-1]) + 1
            pet = pets.new_pet(_species, uid=(player.eid << 8 | (_n & 0xff)) & 0x7fffffff,
                               template=_tpl)
            _pc.setdefault('pets', []).append(pet.raw.hex())
            _pc['pet_active'] = pet.uid
            ACCOUNT.save()
            save_inv()
            send(0x11, 0x01, bytes(pet.raw))
            jot(f"     зарегистрирован питомец {_species}")
            return True
        # зелья-бафы и «Дух воина»: эффект — из описания предмета (buffs.item_buff)
        _sb = buffs.skill_buff(item) if getattr(player, 'buffs', None) and not buffs.item_buff(item) else None
        if _sb:                          # баф по навыку предмета (записи: «Цветок удачи», VIP, …)
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            sid, sec = _sb
            now_ = time.time()
            old = player.buffs.active.get(sid)
            if item in buffs.VIP:                    # VIP: повтор продлевает; 30 дн. заменяет 3 дн.
                for v in buffs.VIP.values():
                    if v != sid and v in player.buffs.active:
                        o_ = player.buffs.active.pop(v)
                        send(0x05, 0x09, buff_list([(v, 1, 0)], add=False))
                        sec += max(0, int(o_[1] - now_))
                if old:
                    sec += max(0, int(old[1] - now_))
            player.buffs.active[sid] = (1, now_ + sec, {})
            send(0x05, 0x09, buff_list([(sid, 1, sec)], caster=item))
            restat()
            save_inv()
            jot(f"     баф предмета {name}: навык {sid} на {sec} с")
            return True
        _iskill = buffs.ITEM_SKILLS.get(item)
        if _iskill and statcalc.skill_kind(_iskill) in (21, 22) and not buffs.item_buff(item):
            # мгновенно: вид 22 — число (жёлтая печенька 6000022: мана +150), 21 — % от максимума
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            for t, v, p in statcalc.skill_fx(_iskill, 1):
                if t == 28:
                    player.hp = min(player.maxhp, player.hp + int(v + player.maxhp * p / 100))
                elif t == 29:
                    player.mp = min(player.maxmp, player.mp + int(v + player.maxmp * p / 100))
            send(0x08, 0x00, build_player_hp(G0800, player))
            save_inv()
            jot(f"     предмет {name}: навык {_iskill} {statcalc.skill_fx(_iskill, 1)}")
            return True
        if item in consumables.RANDOM_BOX:              # коробки из записей (день рождения, костюмы)
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            it_, n_ = random.choice(consumables.RANDOM_BOX[item])
            give_item(it_, n_)
            save_inv()
            jot(f"     открыта {name}: {loot.item_name(it_)} x{n_}")
            return True
        if getattr(player, 'buffs', None) and buffs.item_buff(item):
            rec, left = inv[0].use(item, pl[5], pl[4])
            if rec is None:
                return False
            send(0x06, 0x02, build_item_use(player.eid, item))
            if left == 0:
                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], item))
            else:
                send(0x06, 0x06, build_putin(player.eid, rec))
            key, sec = buffs.add_item(player.buffs, item)
            if key and key > 0:     # оригинал: 05/09 с навыком-эффектом, источник — id предмета
                send(0x05, 0x09, buff_list([(key, 1, sec)], caster=item))
            restat()
            save_inv()
            jot(f"     баф предмета {name}: навык {key}, {player.buffs.active[key][2]} на {sec} с")
            return True
        return False

    def fix_equipped():
        """Надетое не в своём слоте (по itemBase) — переложить: сумки в 13..15,
        прочее — в свой слот, если он свободен, иначе в сумку."""
        if not inv[0]:
            return
        for r in [x for x in inv[0].recs if x[0] == 0]:
            info = loot.ITEMS.get(Inventory.item(r), {})
            want = info.get('slot', 0)
            if not want or r[1] == want or (info.get('cat') == 13 and r[1] in BAG_EQUIP_SLOTS)                     or PAIR_SLOTS.get(want) == r[1]:
                continue
            if info.get('cat') == 13:
                want = inv[0].free_bag_equip_slot()
            if want and inv[0].find(0, want) is None:
                r[1] = r[6] = want
            else:
                cell = inv[0].free_cell(inv[0].gear_container())
                if cell:
                    r[0], r[1], r[6] = cell[0], cell[1], 0
            jot(f"     надетое {Inventory.item(r)} переложено -> [{r[0]}][{r[1]}]")

    lot_tick = [0.0]
    # ---- выкуп проданного торговцу (06/57, 06/58; запись Genesis huge_genesis_pack) ----
    # S 06/57 (CItemRepurItemListPacket): +0 eid, +4 u8 n (до 8), n × запись 147 байт (+0 0, +1 номер
    # в списке, количество — проданное); новая — в конце, девятая вытесняет первую. C 06/57 «eid, 0» —
    # окно торговца открыто (ответ — список). C 06/58 (CItemRepurchaserBuyPacket, сборщик 0x004e82d6,
    # вызов 0x004e8fb1): +0 eid, +4 номер в списке, +8 предмет, +12 u8 9, +13 u16, +15 u64 −1;
    # S 06/58 — то же, +13 код (0x2c — «Приобретено: %s. Цена: %d» по цене продажи itemBase +100 ×
    # количество из +15; 0x1db — «Недостаточно каратов»).
    REPUR_MAX, REPUR_OK, REPUR_NOGOLD = 8, 0x2c, 0x1db
    repur = []

    def build_repur():
        out = bytearray(struct.pack('>IB', player.eid, len(repur)))
        for i, e in enumerate(repur):
            r = bytearray(e['rec'])
            r[0], r[1] = 0, i
            struct.pack_into('<I', r, 16, e['n'])
            out += r
        return bytes(out)

    def lots_of():
        _pc = ACCOUNT.get(player.eid) if player else None
        return (_pc.setdefault('lots', []), _pc) if _pc is not None else ([], None)

    def send_lots():
        """06/25 + 06/1f со всеми лотами игрока (как оригинал при входе)."""
        lots, _pc = lots_of()
        send(0x06, 0x25, bytes(4))
        for L in lots:
            rec, n, price = commission.lot_view(L)
            send(0x06, 0x1f, commission.build_my_lot(commission.MODE_SOLD if L.get('sold') else
                                                     commission.MODE_SALE, L['lot'], rec, n, price,
                                                     player.name, L['expire']))

    def check_lots(now):
        """Рынок покупает выставленные лоты (commission.sale_delay)."""
        if now - lot_tick[0] < 5:
            return
        lot_tick[0] = now
        lots, _pc = lots_of()
        sold = [L for L in lots if not L.get('sold') and L.get('sell_at') and now >= L['sell_at']]
        for L in sold:
            L['sold'] = 1
            rec, n, price = commission.lot_view(L)
            send(0x06, 0x20, commission.build_removed(commission.MODE_SALE, [L['lot']]))
            send(0x06, 0x1f, commission.build_my_lot(commission.MODE_SOLD, L['lot'], rec, n, price,
                                                     player.name, L['expire']))
            jot(f"     лот {L['lot']} продан: {loot.item_name(L['item'])} x{n} по {price}")
        if sold:
            ACCOUNT.save()

    def save_inv():
        _pc = ACCOUNT.get(player.eid) if player else None
        if _pc is not None and inv[0] is not None:
            _pc['inv'] = inv[0].to_saved()
            ACCOUNT.save()
    _logp = os.path.join(HERE, f'emu_{port}.log')
    try:                                     # ротация: больше 50 МБ -> emu_N.log.old
        if os.path.getsize(_logp) > 50_000_000:
            os.replace(_logp, _logp + '.old')
    except OSError:
        pass
    logf = open(_logp, 'a', encoding='utf-8')

    def jot(s):
        with send_lock:
            logf.write(s + chr(10)); logf.flush()

    jot(f"===== соединение {addr[0]}:{addr[1]} стадия {stage} =====")

    def send(cat, sub, payload):
        with send_lock:
            conn.sendall(frame(cat, sub, payload, seq[0]))
            seq[0] = (seq[0] + 1) & 0xFFFF   # u16: после 65535 -> 0 (был вылет)
            line = f"  -> {cat:#04x}/{sub:#04x} len={len(payload)+6}"
            if cat in LOG_OUT_HEX:   # боевые/статусные — с содержимым
                line += f"  {bytes(payload)[:64].hex()}"
            logf.write(line + chr(10)); logf.flush()

    op_lock.acquire()
    try:
        while True:
            try:
                op_lock.release()                # ждём клиента — пусть работают пульт и таймер крафта
                try:
                    data = conn.recv(65536)
                finally:
                    op_lock.acquire()
            except socket.timeout:
                break
            except OSError:                  # клиент оборвал соединение (10053/10054)
                break
            if not data:
                break
            buf += data
            frames, buf = recv_frames(buf)
            for f in frames:
                if len(f) < 2:
                    continue
                cat, sub = f[0], f[1]
                # вход (01/07, 02/00, 02/0b) несёт логин и пароли — в лог только начало кадра;
                # у 06/41 (уничтожение) — без хвоста с цифрами подтверждения
                _shown = 6 if (cat, sub) in ((0x01, 0x07), (0x02, 0x00), (0x02, 0x0b)) else                     32 if (cat, sub) == (0x06, 0x41) else 48
                jot(f"  <- {cat:#04x}/{sub:#04x} len={len(f)}  {f[:_shown].hex()}")
                if player and getattr(player, 'buffs', None) and player.buffs.active:
                    gone = player.buffs.expired()
                    if gone:
                        if any(g > 0 for g in gone):      # у бафов предметов (id < 0) иконки нет
                            send(0x05, 0x09, buff_list([(g, 1, 0) for g in gone if g > 0], add=False))
                        restat()
                        jot(f"     бафы кончились: {gone}")
                if player and inv[0]:
                    check_lots(time.time())
                    check_pet(time.time())
                    check_mob_debuffs(time.time())
                    check_hot(time.time())
                if (cat, sub) == (0x73, 0xf2):
                    pass  # <-- Лаунчер шлет хендшейк, просто игнорируем
                if (cat, sub) == (0x02, 0x00):                    # логин
                    if port == 10001:
                        send(0x0b, 0x00, bytes.fromhex(GATE['0b00']))
                        send(0x02, 0x00, bytes.fromhex(GATE['0200']))
                        send(0x02, 0x06, patch_addr(GATE['0206'], 10110))
                    elif port == 10110:
                        send(0x0b, 0x00, bytes.fromhex(MID['0b00']))
                        send(0x02, 0x00, bytes.fromhex(MID['0200']))
                        send(0x02, 0x06, patch_addr(MID['0206'], 10101))
                        if '0300' in MID:
                            send(0x03, 0x00, bytes.fromhex(MID['0300']))
                    else:                                         # игра
                        # аккаунт по логину: если в 02/00 есть слово = имени аккаунта
                        _ids = {a.lower(): a for a in account_ids()}
                        for _w in reversed(re.findall(rb'[A-Za-z0-9_]{3,}', bytes(f[6:]))):
                            if _w.decode().lower() in _ids and _ids[_w.decode().lower()] != ACCOUNT.id:
                                set_account(_ids[_w.decode().lower()])
                                break
                        send(0x0b, 0x00, bytes.fromhex(GAME['0b00']))
                        send(0x02, 0x00, bytes.fromhex(GAME['0200']))
                        if '020b' in GAME:
                            send(0x02, 0x0b, bytes.fromhex(GAME['020b']))
                        send_cards(send)

                elif (cat, sub) == (0x02, 0x02):                  # создание персонажа
                    nm = parse_create(f[6:])
                    cls = struct.unpack_from('<I', f[6:], 0)[0] if len(f) >= 10 else 600
                    if nm:
                        ch = ACCOUNT.create(nm, cls=cls)
                        char_name[0] = nm
                        print(f"     СОЗДАН ПЕРСОНАЖ: {nm!r} класс {cls} слот {ch['slot']}",
                              flush=True)
                        jot(f"     создан персонаж {nm!r} класс {cls} слот {ch['slot']}")
                    send(0x02, 0x02, f[6:])          # подтверждение
                    send_cards(send)                  # обновлённый список

                elif (cat, sub) == (0x02, 0x03):                  # удалить персонажа
                    eid = struct.unpack_from('>I', f[6:], 0)[0]
                    if ACCOUNT.delete(eid):
                        jot(f"     удалён персонаж eid={eid}")
                    send(0x02, 0x03, f[6:])
                    send_cards(send)

                elif cat == 0x09 and sub in (0x00, 0x01, 0x05) and player and qlog[0]:
                    # 09/00 взять, 09/01 сдать, 09/05 отказаться (docs/protocol.md, questlog.py)
                    pl = f[6:]
                    qid = questlog.parse_qid(pl)
                    jot(f"     09/{sub:02x} запрос: {pl.hex()} (квест {qid})")
                    q = questlog.QUESTS.get(qid)
                    if sub == 0x00:
                        ok = qlog[0].accept(qid)
                        send(0x09, 0x00, quest_reply(pl, 12, ok))
                        jot(f"     квест {qid} «{q['title'] if q else '?'}»: "
                            f"{'взят' if ok else 'отказ'}")
                        if ok and q:
                            quest_started(qid, q)
                    elif sub == 0x01:
                        q = qlog[0].complete(qid)
                        if q:
                            give_quest_rewards(q)
                        send(0x09, 0x01, quest_reply(pl, 16, bool(q)))
                        jot(f"     квест {qid}: {'сдан' if q else 'не готов'}")
                        if q and questlog.repeatable(qid):  # клиент записал его в выполненные —
                            send(0x09, 0x04, questlog.build_complete_list(player.eid, qlog[0]))  # снова доступен
                    else:
                        qlog[0].giveup(qid)
                        send(0x09, 0x05, pl)
                    save_quests()

                elif (cat, sub) == (0x09, 0x03) and player and qlog[0]:
                    # прогресс от клиента (разговор с NPC): +4 квест, +8 тип, +12 цель, +16 знач.
                    pl = f[6:]
                    if len(pl) >= 20:
                        qid, typ, tgt, val = struct.unpack_from('>IIII', pl, 4)
                        # клиент шлёт 0, 1, 1 — подтверждаем только рост, один раз:
                        # каждое эхо он засчитывал заново («выполнено» дважды)
                        if qsent.get((qid, typ, tgt), -1) < val:
                            qsent[(qid, typ, tgt)] = val
                            qlog[0].on_client_progress(qid, typ, tgt, val)
                            save_quests()
                            if val > 0:
                                send(cat, sub, pl)

                elif cat == 0x09:
                    send(cat, sub, f[6:])          # прочее 09/xx — как раньше, эхо

                elif (cat, sub) == (0x02, 0x07):                  # выбор канала
                    send(0x02, 0x07, bytes.fromhex(MID['0207']))

                elif (cat, sub) == (0x02, 0x04):                  # вход в мир
                    x, y, z = SPAWN_XYZ
                    # ВАЖНО: 02/04 несёт eid ВЫБРАННОГО персонажа (BE32 @+0).
                    # Раньше сервер всегда брал chars[0] — после удаления/
                    # создания выбранный перс переставал совпадать с chars[0],
                    # и появление игрока уходило с чужим eid -> клиент зависал
                    # на загрузке. Теперь входим именно выбранным персонажем.
                    sel = struct.unpack_from('>I', f[6:], 0)[0] if len(f) >= 10 else None
                    _pend = pending_warp_eid()
                    if _pend:                        # вход после перехода между картами
                        if sel != _pend:
                            jot(f"     вход после перехода: {sel} -> {_pend}")
                        sel = _pend
                        PENDING_WARP['eid'] = 0
                    _ch = ACCOUNT.get(sel)
                    # ВСЕГДА входим под ВЫБРАННЫМ клиентом eid. Проверено по
                    # дампу: 02/04 eid == eid в 02/05 и в появлении игрока 04/02.
                    # Если брать chars[0] (как раньше), при выборе не-первого
                    # персонажа или устаревшей карточки eid расходится и клиент
                    # виснет на загрузке.
                    _eid = sel if sel else (_ch['eid'] if _ch else 0x2892)
                    _nm = _ch['name'] if _ch else char_name[0]
                    player = Player(_eid, x, y, z, name=_nm)
                    player.level = _ch.get('level', 1) if _ch else 1
                    player.exp = _ch.get('exp', 0) if _ch else 0
                    player.cls = _ch.get('cls', 600) if _ch else 600
                    qlog[0] = questlog.QuestLog(_ch.get('quests') if _ch else None)
                    player.sp_spent = _ch.get('sp_spent', 0) if _ch else 0
                    player.rank = _ch.get('rank', 0) if _ch else 0
                    player.fleta_attr = dict(_ch.get('fleta_attr', {})) if _ch else {}
                    player.fleta_pts = dict(_ch.get('fleta_pts', {})) if _ch else {}
                    player.raw = {k: bytes.fromhex(v) for k, v in ((_ch or {}).get('raw') or {}).items() if v}
                    if _ch and 'rank' not in _ch and player.raw.get('08/02'):
                        # импортированный: ранг в записи не хранится — по атрибутам (statcalc.class_attrs),
                        # иначе сервер дал бы повторно «повысить ранг» (и взять плату)
                        _a = list(struct.unpack_from('<5H', player.raw['08/02'], 6))
                        player.rank = next((r for r in range(3)
                                            if statcalc.class_attrs(player.cls, r) == _a), 0)
                    if _ch and _ch.get('fleta_g') is not None:
                        player.fleta_g = {int(k): tuple(v) for k, v in _ch['fleta_g'].items()}
                    player.stat_base = (_ch or {}).get('stat_base')
                    if player.exp >= exp_to_next(player.level):   # старый накопительный опыт
                        player.exp = 0
                    player.buffs = buffs.Buffs()
                    for _b in (_ch or {}).get('buffs') or []:      # бафы переживают переход карт и выход
                        try:
                            if float(_b[2]) > time.time() + 1:
                                player.buffs.active[int(_b[0])] = (int(_b[1]), float(_b[2]), dict(_b[3] or {}))
                        except (TypeError, ValueError, IndexError):
                            pass
                    dev_register()
                    # характеристики по уровню и надетому — до первых 08/02/08/00
                    _iv = Inventory.from_saved(b'\0' * 6, _ch['inv']) if _ch and _ch.get('inv') else None
                    stats.recalc(player.level, player.cls, _iv.equipped() if _iv else {})
                    compute_stats(_iv)
                    player.maxhp = max(1, int(round(stats.max_hp)))
                    player.maxmp = max(0, int(round(stats.max_mp)))
                    player.hp, player.mp = player.maxhp, player.maxmp
                    player.defense = stats.defense
                    qsent.clear()
                    # сохранённая карта/позиция (после варпа); иначе старт в Бернео
                    map_id = _ch.get('map', DEFAULT_MAP_ID) if _ch else DEFAULT_MAP_ID
                    if map_id not in MAP_NAMES:
                        map_id = DEFAULT_MAP_ID
                    if _ch and _ch.get('pos') and 10 < _ch['pos'][0] < 100000 \
                            and 10 < _ch['pos'][1] < 100000:  # где вышел — там и входим
                        player.x, player.y, player.z = _ch['pos']
                        _fl = mesh_floor(MAP_NAMES.get(map_id, ''), player.x, player.y)
                        if _fl is not None and player.z < _fl - 20:    # сохранён под картой
                            player.z = _fl + FLOOR_DROP
                        player.angle = _ch.get('angle', 0.0)
                        pos_fix[0] = True
                    if _ch:
                        player.fleta = _ch.get('fleta', 0)
                        player.fleta_exp = _ch.get('fleta_exp', 0.0)
                        if _ch.get('hp'):
                            player.hp = min(player.maxhp, _ch['hp'])
                        if _ch.get('mp') is not None:
                            player.mp = min(player.maxmp, _ch['mp'])
                    player.map = map_id
                    bag_tidy_saved(_ch)
                    world, ai = start_world(map_id)
                    if raw_of(player, '02/05'):
                        send(0x02, 0x05, build_enter_world(player))
                    else:
                        send(0x02, 0x05, dress(
                            patch_eid(build_enter_world(player), player.eid),
                            '0205', player.cls, player.eid))
                    # появление СВОЕГО персонажа с нашим именем (не из реплея)
                    tplc = PLAYER_TPL
                    if raw_of(player, '04/02'):
                        send(0x04, 0x02, build_position(player))
                        tplc = None
                    if tplc:
                        ch = Character(player.eid, name=player.name,
                                       x=player.x, y=player.y, z=player.z,
                                       level=player.level)
                        send(0x04, 0x02, with_speeds(set_appear_class(dress(
                            patch_eid(ch.build_appear(tplc), player.eid),
                            'appear', player.cls, player.eid), player.cls), player))
                    # только пакеты, которые шлёт НАСТОЯЩИЙ сервер при входе,
                    # и строго в его порядке (лишние вызывали ранние окна).
                    # patch_eid: во ВСЕХ пакетах меняем зашитый eid дампа на наш —
                    # иначе не-первый персонаж не входит (пакеты про чужую сущность).
                    for op in ENTER_SEQUENCE:
                        tpl = raw_of(player, f'{op[0]:02x}/{op[1]:02x}') or WTPL.get(op)
                        if not tpl:
                            continue
                        if op == (0x08, 0x02):          # статы — реальный 1 lvl
                            body = build_stats_full(player, stats)
                        elif op == (0x08, 0x01):        # гейдж уровня/опыта
                            body = build_hero_gage(player)
                        elif op == (0x08, 0x00):        # HP/MP гейдж
                            body = build_player_hp(G0800, player)
                        elif op == (0x05, 0x05):        # навыки: база + изученные
                            body = build_skill_list(tpl, player.eid,
                                                    _ch.get('skills') if _ch else None)
                        elif op == (0x05, 0x0c):        # супер-навыки: свои (superskill.py)
                            body = superskill.build_list(player.eid, super_entries(tpl))
                        elif op == (0x04, 0x04):        # зона = карта входа
                            body = build_zone(player.eid, player.map)
                        elif op == (0x09, 0x02):        # активные квесты — свои, не из дампа
                            body = questlog.build_list(player.eid, qlog[0])
                        elif op == (0x09, 0x04):        # выполненные квесты
                            body = questlog.build_complete_list(player.eid, qlog[0])
                        elif op == (0x06, 0x05):        # инвентарь (сохранённый или стартовый)
                            fresh = add_offhand_inventory(
                                swap_gear(patch_eid(tpl, player.eid), player.cls), player.cls)
                            if _ch and _ch.get('inv'):
                                inv[0] = Inventory.from_saved(fresh[:6], _ch['inv'])
                            else:
                                inv[0] = Inventory.from_payload(fresh)
                            inv[0].ensure_bag()          # сумка на 48 слотов в слот 13
                            inv[0].replace_items(BAG_REPLACE)      # «Малая сумка» -> вечная
                            inv[0].split_gear_stacks(loot.ITEMS)   # снаряжение «x3» -> 3 вещи
                            fix_equipped()               # вещи не в своих слотах (сумка в торсе)
                            inv[0].refresh_periods(ITEM_PERIODS)   # «срок действия истёк»
                            inv[0].refresh_durability()            # кирки 0/16000
                            save_inv()
                            body = inv[0].payload()
                        else:
                            body = tpl
                        if raw_of(player, f'{op[0]:02x}/{op[1]:02x}') is body:
                            send(op[0], op[1], body)   # пакет оригинала этого персонажа
                        else:
                            send(op[0], op[1], swap_gear(patch_eid(body, player.eid), player.cls))
                        if op == (0x06, 0x05) and inv[0] and getattr(inv[0], 'rest', None):
                            for _r in inv[0].rest:      # не влезшее в 06/05 — по одной записи
                                send(0x06, 0x06, build_putin(player.eid, _r))
                            jot(f"     инвентарь: {len(inv[0].recs) - len(inv[0].rest)} в 06/05, "
                                f"{len(inv[0].rest)} досланы 06/06")
                    _pa, _ = pet_active()
                    if _pa:                              # текущий питомец (11/01)
                        send(0x11, 0x01, bytes(_pa.raw))
                    pet_state['out'] = False; pet_state['icons'] = []
                    _cv = (_ch or {}).get('costume_view')
                    if _cv:                                # показ костюма (06/46) — как Genesis при входе
                        send(0x06, 0x46, struct.pack('>IBB', player.eid, _cv[0] & 1, _cv[1] & 1))
                    for _op in ('06/28', '08/05'):     # быстрые слоты и пр. — у импортированных
                        _b = raw_of(player, _op)
                        if _b:
                            send(int(_op[:2], 16), int(_op[3:], 16), _b)
                    # статы и гейдж ещё раз — уже с учётом оружия (скорость атаки),
                    # опыта (+63/+71) и очков навыков: инвентарь известен только сейчас
                    if inv[0]:
                        restat()
                    if _ch is not None:                  # непрочитанные письма (postbox.py)
                        send(0x10, 0x04, postbox.build_count(_ch.get('mail', [])))
                    if _ch is not None and _ch.get('lots'):   # свои лоты комиссионки
                        send_lots()
                    # стихии флетты клиент знает из 02/05 (+905..): оригинал 08/04 при входе не шлёт
                    # мобов НЕ шлём при входе: настоящий сервер отправляет их
                    # только ПОСЛЕ первого движения клиента (дамп play1, +4.2с)
                    spawned.clear()

                elif (cat, sub) == (0x04, 0x06) and player:        # вошёл в портал
                    # C->S: +0 id ворот BE32, +4 код BE16 (0x123). Ответ — эхо
                    # (клиент на 0x123 молчит), затем перенос (docs/protocol.md)
                    pl = f[6:]
                    gid = struct.unpack_from('>I', pl, 0)[0] if len(pl) >= 4 else 0
                    gate = WARPS['gates'].get(str(gid))
                    jot(f"     04/06 ворота {gid}: {gate['name'] if gate else 'нет в таблице'}")
                    send(0x04, 0x06, pl)
                    if gate:
                        do_warp(gate['target'])

                elif (cat, sub) == (0x04, 0x05) and player:        # запрос варпа (NPC/свиток)
                    pl = f[6:]
                    jot(f"     04/05 запрос: {pl.hex()}")
                    tid = next((v for v in (struct.unpack_from('>I', pl, o)[0]
                                            for o in range(0, max(0, len(pl) - 3)))
                                if str(v) in WARPS['targets']), None)
                    send(0x04, 0x05, pl)
                    if tid and coral_gate(tid):
                        do_warp(tid)

                elif (cat, sub) in ((0x04, 0x00), (0x04, 0x01)):  # движение игрока
                    # клиент шлёт СВОЁ перемещение и через 04/01 (лог сессии)
                    pl = f[6:]
                    moved = False
                    if (cat, sub) == (0x04, 0x00) and len(pl) >= 20:
                        # Клиент (записи оригинала, 22 байта): +0 u8 0, +1 eid BE, +5 x, +9 y, +13 высота,
                        # +17 угол, +21 u8. Тестовый клиент шлёт без ведущего байта (eid на +0).
                        _o = 1 if player and len(pl) >= 21 and pl[1:5] == struct.pack('>I', player.eid) else 0
                        x, y, z = struct.unpack_from('<3f', pl, 4 + _o)
                        ang = struct.unpack_from('<f', pl, 16 + _o)[0]
                        moved = True
                        # 04/00 — воскрешение/появление: клиент заново строит сцену, и NPC/мобов надо
                        # прислать снова (иначе NPC «гаснут» после смерти). Сброс — ДО веток ниже: раньше он
                        # шёл после них и стирал NPC, только что посланные при смене карты, — и ворота EID
                        # при старте не убирались у клиента, если игрок стоял на месте (04/03 не уходило).
                        spawned.clear()
                        if player and getattr(player, 'dead', False) and not zone_pending[0] and not pos_fix[0]:
                            # воскрешение: клиент присылает точку воскрешения (OK в окне смерти). Оригинал
                            # (orig_hl): 05/04, 08/01 с ~20% HP/MP (1606 из 8031), своё 04/02 в этой точке
                            player.dead = False
                            player.hp = max(1, player.maxhp // 5)
                            player.mp = max(player.mp, player.maxmp // 5)
                            send(0x05, 0x04, struct.pack('>BI', 0, player.eid) + bytes(4)
                                 + struct.pack('<3f', x, y, z) + struct.pack('<f', ang))
                            restat()
                            send(0x08, 0x00, build_player_hp(G0800, player))
                            jot(f"     воскрешение в {x:.0f},{y:.0f}: HP {player.hp}/{player.maxhp}")
                        if zone_pending[0] and player:
                            # клиент загрузил новую карту: прислать себя и своё (как оригинал)
                            zone_pending[0] = False
                            pos_fix[0] = False
                            moved = False
                            spawned.clear()
                            send(0x04, 0x02, build_position(player))
                            _ch2 = ACCOUNT.get(player.eid) or {}
                            if WTPL.get((0x05, 0x05)):
                                send(0x05, 0x05, build_skill_list(WTPL[(0x05, 0x05)], player.eid,
                                                                  _ch2.get('skills')))
                            send(0x09, 0x02, questlog.build_list(player.eid, qlog[0]))
                            send(0x09, 0x04, questlog.build_complete_list(player.eid, qlog[0]))
                            restat()
                            send_buff_icons()
                            n = send_nearby_mobs(world, player, send, spawned) if world else 0
                            dungeon_enter()
                            jot(f"     смена карты: {MAP_NAMES.get(player.map)} {player.x:.0f},{player.y:.0f}, мобов {n}")
                        elif pos_fix[0] and player:
                            # первое 04/00 после входа — клиент стоит на точке карты
                            # по умолчанию; переносим на сохранённую (04/02)
                            pos_fix[0] = False
                            moved = False
                            spawned.clear()
                            send(0x04, 0x02, build_position(player))
                            send_buff_icons()
                            dungeon_enter()
                            jot(f"     вход: на сохранённую точку {player.x:.0f},{player.y:.0f}")
                    elif (cat, sub) == (0x04, 0x01) and len(pl) >= 30:
                        x, y, z = struct.unpack_from('<3f', pl, 18)   # точка «куда»
                        ang = struct.unpack_from('<f', pl, 30)[0] if len(pl) >= 34 else 0.0
                        moved = True
                        x0, y0, z0 = struct.unpack_from('<3f', pl, 6)
                        _zl = getattr(player, '_last_z', None) if player else None
                        if player and abs(z0 - z) < 0.5 and (abs(x0 - x) + abs(y0 - y)) > 1                                 and _zl is not None and abs(_zl - z) < 2                                 and 10 < x < 100000 and 10 < y < 100000:
                            if MAP_NAMES.get(player.map, '') not in FLOORS:   # пол из меша
                                learn_height(MAP_NAMES.get(player.map, ''), x, y, z)   # не в падении
                        if player:
                            player._last_z = z
                    if moved and player and 10 < x < 100000 and 10 < y < 100000:
                        if world:                     # интерьеры: проходимость по следу игрока
                            navgrid.learn(world.map_name, player.x, player.y, x, y)
                        if (cat, sub) == (0x04, 0x01):    # путь игрока: ИИ видит его в пути, а не сразу у цели
                            player.path = (x0, y0, x, y, time.time(),
                                           max(30.0, getattr(player, 'run_speed', 65.0) * DEV['move']))
                        else:
                            player.path = None
                        player.x, player.y, player.z, player.angle = x, y, z, ang
                        pet_follow()
                        if time.time() - last_save[0] > 15:
                            save_state()                 # раз в 15 с — на случай вылета
                            navgrid.save()
                            for g in world.ground.expired():   # неподобранное исчезает
                                send(0x06, 0x03, build_hide(g))
                        if (cat, sub) == (0x04, 0x00):
                            send(0x04, 0x02, build_position(player))
                        # досылаем мобов вокруг новой позиции
                        n = send_nearby_mobs(world, player, send, spawned)
                        if n:
                            print(f"     мобов отправлено: {n} (всего {len(spawned)})",
                                  flush=True)
                            jot(f"     мобов отправлено: {n}")

                elif (cat, sub) in ((0x05, 0x00), (0x05, 0x01)):  # замах / удар
                    if sub == 0x01 and player and len(f) > 15 and f[6 + 5] == 1:
                        _sid0 = struct.unpack_from('>I', f, 6 + 6)[0]
                        if not transform.allowed(getattr(player, 'form', 0), _sid0):
                            jot(f"     навык существа {_sid0} не в своём облике — обычный удар")
                            f = bytearray(f)
                            f[6 + 5] = 0
                    tgt = parse_attack(f[6:], sub)
                    # 05/00: подтверждение начала атаки с кодом 0x0024 —
                    # иначе клиент отменяет атаку и не шлёт удар 05/01
                    if (cat, sub) == (0x05, 0x00):
                        send(0x05, 0x00, ack_attack_start(f[6:]))
                        if tgt and player:
                            player.target = tgt
                    if (cat, sub) == (0x05, 0x01) and player:
                        # 05/01: +5 режим (0 обычный удар, 1 навык), +6 id навыка BE32
                        pl01 = f[6:]
                        if len(pl01) >= 10 and pl01[5] == 1:
                            sid = struct.unpack_from('>I', pl01, 6)[0]
                            cost = skill_mp_cost(sid)
                            if cost:
                                player.mp = max(0, player.mp - cost)
                                send(0x08, 0x00, build_player_hp(G0800, player))
                                jot(f"     навык {sid}: -{cost} MP -> {player.mp}/{player.maxmp}")
                            _learned = {int(a): int(b) for a, b in
                                        (ACCOUNT.get(player.eid) or {}).get('skills', [])}
                            _sup = superskill.entry(super_entries(), sid)
                            _lv = _sup[1] if _sup and _sup[1] else _learned.get(sid, 1)
                            _dur = player.buffs.add(sid, _lv) if getattr(player, 'buffs', None) else None
                            if _dur is not None:            # 0 — бессрочная аура: в 05/09 остаток 0
                                send(0x05, 0x09, buff_list([(sid, _lv, _dur)]))
                                aura_next.pop(sid, None)        # пульс эффекта ауры — заново от наложения
                                if _sup and _sup[2] // 10000 in (61, 62):   # камень «Усиление»
                                    player.buffs.active[-_sup[2]] = (1, time.time() + _dur if _dur
                                                                     else buffs.FOREVER, {})
                                    jot(f"     камень {_sup[2]} к бафу {sid} на {_dur:.0f} с")
                                restat()
                                jot(f"     баф {sid} ур.{_lv} {'бессрочно (аура)' if not _dur else f'на {_dur:.0f} с'}: "
                                    f"{player.buffs.active[sid][2]}, пульс {buffs.pulse_child(sid, _lv)}")
                    if (cat, sub) == (0x05, 0x01) and tgt and world and player:
                        # цели: массовый навык — клиент сам присылает список (запись оригинала remain3:
                        # +26 число целей, записи по 5 байт: u8 тип (1 моб), u32 BE id); ответ — один
                        # 05/02 со всеми целями. Раньше урон получала только первая цель.
                        _pl1 = f[6:]
                        _tids = [tgt]
                        if len(_pl1) > 27 and 1 < _pl1[26] <= 16 and len(_pl1) >= 27 + 5 * _pl1[26]:
                            _tids = [struct.unpack_from('>I', _pl1, 28 + 5 * i)[0]
                                     for i in range(_pl1[26]) if _pl1[27 + 5 * i] == ENT_MOB]
                        # урон как у оригинала (charstats.py): атака окна персонажа
                        # (оружие по заточке, опции, %), навык — множитель и прибавка
                        # из skillLevel, крит — шанс и сила из 08/02; по мобам выше — слабее
                        _sk = _sup = _dbf = None
                        if len(f) > 15 and f[6 + 5] == 1:
                            _sid = struct.unpack_from('>I', f, 6 + 6)[0]
                            _lv = {int(a): int(b) for a, b in
                                   (ACCOUNT.get(player.eid) or {}).get('skills', [])}.get(_sid, 1)
                            _sup = superskill.entry(super_entries(), _sid)
                            if _sup and _sup[1]:
                                _lv = _sup[1]
                            _sk = charstats.skill_dmg(_sid, _lv) or (1.5, 0, 0)
                            if statcalc.skill_kind(_sid) == statcalc.DEBUFF:
                                _dbf = (_sid, _lv)
                            elif statcalc.skill_kind(_sid) == statcalc.ACTIVE:
                                _dbf = (_sid, _lv, True)       # второй эффект удара
                        _hits = []
                        _now = time.time()
                        for tgt in _tids:
                            mob = world.mobs.get(tgt)
                            if not (mob and mob.alive) or getattr(mob, 'gather', None) and tgt != _tids[0]:
                                continue
                            if random.random() * 100 < progression.player_miss(player.level, mob.level):
                                _hits.append((mob, 0, ATK_MISS, False))     # промах по мобу выше уровнем
                                continue
                            raw, _crit = charstats.roll(stats, _sk)
                            dmg = progression.hit_damage(raw, mob.level, player.level,
                                                         charstats.above_floor(getattr(stats, 'cls_base', 0)))
                            if _sk is None:                     # срабатывание флетты — на обычном ударе
                                _fp = charstats.fleta_proc(getattr(stats, 'cls_base', 0), fleta_groups(player))
                                if _fp:
                                    dmg += charstats.proc_damage(stats, _fp) * DEV['atk'] * (
                                        stats.crit_dmg if _crit else 1.0)
                                    send(0x05, 0x08, struct.pack('>IIH', player.eid, _fp['sid'], 1))
                                    debuff_mob(mob, _fp['sid'], 1, secs=_fp['secs'])          # как в записи: 05/08, 05/09, 05/02
                                    jot(f"     срабатывание флетты {_fp['sid']} по {mob.eid}")
                            _mult = superskill.mob_mod(mob, 'def', _now, 1.0)   # «снижение защиты»
                            if _sk is not None and _sup and _sup[2] // 10000 == 63:
                                _mult *= superskill.on_hit(mob, _sup[2], _now)   # камень «Атака»
                                jot(f"     камень {_sup[2]}: дебаф {getattr(mob, 'debuffs', {})}")
                            for _ps in superskill.roll_procs(getattr(player, 'procs', ()), (2, 3)):
                                _mult *= proc_effect(_ps, mob, dmg)     # навык от вещи (itemInvokeSkill)
                            dmg = max(1, int(round(dmg * _mult * DEV['dmg'])))
                            if DEV['one_hit']:
                                dmg = max(dmg, mob.hp)
                            mob.hp = max(0, mob.hp - dmg)
                            _hits.append((mob, dmg, ATK_CRIT if _crit else ATK_NORMAL, _crit))
                        _tot = sum(h[1] for h in _hits)
                        # похищение HP/MP (08/02 +304/+316, % нанесённого урона)
                        _st = getattr(stats, 'hp_steal', 0.0), getattr(stats, 'mp_steal', 0.0)
                        if _tot and ((_st[0] > 0 and player.hp < player.maxhp) or (_st[1] > 0 and player.mp < player.maxmp)):
                            player.hp = min(player.maxhp, player.hp + int(_tot * min(_st[0], 100) / 100))
                            player.mp = min(player.maxmp, player.mp + int(_tot * min(_st[1], 100) / 100))
                            send(0x08, 0x00, build_player_hp(G0800, player))
                        if _hits:
                            send(0x05, 0x02, build_damage_multi(
                                T0502, player.eid, [(m.eid, d, k, (m.x, m.y, m.z)) for m, d, k, _c in _hits],
                                attacker_type=ENT_PLAYER, target_type=ENT_MOB))
                        for mob, dmg, _kind, _crit in _hits:
                            tgt = mob.eid
                            send(0x08, 0x06, build_hp(T0806, tgt, mob.hp))
                            if mob.hp == 0:
                                mob_killed(mob)
                            else:
                                if _dbf and dmg and (len(_dbf) == 2 or (
                                        mobdebuff.has_debuff(statcalc.skill_fx(_dbf[0], _dbf[1]))
                                        and skill_secs(_dbf[0], _dbf[1]) > 0)):
                                    debuff_mob(mob, *_dbf)
                                if ai and DEV['aggro']:
                                    ai.provoke(mob, player.eid)   # моб отвечает на любой удар
                            if _dbf and len(_dbf) == 3 and dmg:
                                skill_drain(mob, _dbf[0], _dbf[1])
                            jot(f"     удар по {tgt}: урон {dmg}{' КРИТ' if _crit else ''}"
                                f"{' ПРОМАХ' if _kind == ATK_MISS else ''}, HP {mob.hp}, моб={mob.state}"
                                f"{f' (целей {len(_hits)})' if len(_hits) > 1 else ''}")

                elif (cat, sub) == (0x06, 0x00):                  # надеть предмет
                    # C->S: +0 eid, +4 контейнер, +5 ячейка, +6 FF, +7 item BE32.
                    # Слот экипировки — из itemBase (раньше угадывался по id: сумка
                    # уезжала в слот торса). Клиент кладёт вещь в окно персонажа
                    # только в пустую ячейку: сперва 06/07 (убрать из сумки и
                    # прежнюю вещь из слота), потом 06/00 (модель) и 06/06 (иконки).
                    r = parse_wear(f[6:])
                    if r and inv[0] and player:
                        eid, slot_inv, item = r
                        info = loot.ITEMS.get(item, {})
                        se = info.get('slot') or Equipment._equip_slot_for(item)
                        if se in PAIR_SLOTS and inv[0] and inv[0].find(0, se) is not None                                 and inv[0].find(0, PAIR_SLOTS[se]) is None:
                            se = PAIR_SLOTS[se]          # второе кольцо/серьга — в парный слот
                        if info.get('cat') == 13 or se in BAG_EQUIP_SLOTS:
                            se = inv[0].free_bag_equip_slot()
                        w = inv[0].wear(item, se, slot_inv, f[6 + 4]) if se else None
                        if w is None:
                            jot(f"     надеть {item}: нет вещи/слота")
                        else:
                            src, new, old = w
                            send(0x06, 0x06, build_putout(player.eid, src[0], src[1], item))
                            if old is not None:
                                send(0x06, 0x06, build_putout(player.eid, 0, se,
                                                              Inventory.item(old)))
                            send(0x06, 0x00, build_wear_reply(f[6:], eid, se, item, new[7]))
                            send(0x06, 0x06, build_putin(player.eid, new))
                            if old is not None:
                                send(0x06, 0x06, build_putin(player.eid, old))
                            save_inv()
                            restat()
                            jot(f"     надет {item} -> слот {se}; защита {stats.defense:.0f}, "
                                f"урон {stats.base_atk + stats.wmin:.0f}-{stats.base_atk + stats.wmax:.0f}")

                elif (cat, sub) == (0x06, 0x01):                  # снять предмет
                    r = parse_putoff(f[6:])
                    if r:
                        eid, slot_equip, item = r
                        # 06/01 только очищает слот; в сумку вещь кладёт 06/06. Нельзя снять —
                        # (непустая сумка, нет места) — не отвечаем, вещь остаётся надетой.
                        rec = inv[0].putoff(slot_equip, item) if inv[0] else None
                        if rec is None:
                            jot(f"     снять {item}: нельзя (непустая сумка или нет места)")
                        else:
                            jot(f"     снят {item}")
                            send(0x06, 0x01, f[6:])
                        if rec is not None and player:
                            send(0x06, 0x06, build_putin(player.eid, rec))
                            # иконка в окне персонажа: пустая 06/06 её не убирает (проверено
                            # в игре) — шлём 06/07 «убрать из ячейки» для контейнера 0
                            send(0x06, 0x06, build_putout(player.eid, 0, slot_equip, item))
                            save_inv()
                            jot(f"     {item} -> сумка [{rec[0]}][{rec[1]}]")
                        restat()

                elif (cat, sub) == (0x06, 0x07) and player:        # убрать предмет из ячейки
                    pl = f[6:]
                    r = parse_slot_req(pl)
                    if r and player:                  # ответ как в оригинале: 06/06 с количеством 0
                        send(0x06, 0x06, build_putout(player.eid, r[0], r[1], r[2]))
                    else:
                        send(0x06, 0x07, pl)
                    if r and inv[0]:
                        cont, cell, item = r
                        rec = inv[0].find(cont, cell)
                        if rec is not None and Inventory.item(rec) == item and cont != 0:
                            inv[0].recs.remove(rec)
                            save_inv()
                            if world:                   # выброшенное падает на землю
                                g = world.ground.drop(player.eid, item, Inventory.count32(rec) or 1,
                                                      player.x, player.y, player.z, rec)
                                send(0x06, 0x04, build_drop(player.eid, g))
                            jot(f"     06/07 выброшен {item} из [{cont}][{cell}]")

                elif (cat, sub) in ((0x06, 0x0b), (0x06, 0x0c)) and player:   # панель быстрых слотов
                    pl = f[6:]
                    _pc = ACCOUNT.get(player.eid)
                    if _pc is not None and len(pl) >= 8:
                        q = _pc.get('quick')
                        if q is None:                      # первая правка — с панели из записи
                            q = _pc['quick'] = quick_block(raw_of(player, '02/05'))
                        slot = struct.unpack_from('>I', pl, 4)[0]
                        if sub == 0x0b and len(pl) >= 20 and slot < QS_N:
                            q[str(slot)] = list(struct.unpack_from('<3I', pl, 8))
                        elif sub == 0x0c:
                            q.pop(str(slot), None)
                        ACCOUNT.save()
                        jot(f"     быстрый слот {slot}: {q.get(str(slot), 'пусто')}")

                elif (cat, sub) == (0x06, 0x0e) and player:        # продажа торговцу
                    # C->S и ответ (обработчик 0x00653d90): +0 eid, +4 контейнер u32,
                    # +8 ячейка u32, +12 item, +16 eid торговца, +20 код BE16 (0x2D — ок:
                    # клиент пишет «продано за N»), +22 количество BE64. Всего 30 байт —
                    # раньше сервер ждал 31 и продажа не проходила вовсе.
                    pl = f[6:]
                    jot(f"     06/0e продажа: {pl.hex()}")
                    if len(pl) >= 30 and inv[0]:
                        cont, cell, item = struct.unpack_from('>III', pl, 4)
                        it = loot.ITEMS.get(item, {})
                        price = it.get('sell') or it.get('price', 0) // 2
                        want = struct.unpack_from('>Q', pl, 22)[0] or 1
                        loc = inv[0].locate(cont, cell, item)
                        if loc:
                            cont, cell = loc
                        _r0 = inv[0].find(cont, cell)
                        _r0 = bytes(_r0) if _r0 is not None else None
                        rest, got_item, n = inv[0].remove(cont, cell, want, item)
                        if n and _r0 is not None and price > 0:
                            repur.append({'rec': _r0, 'n': n, 'price': price})
                            del repur[:-REPUR_MAX]
                        if n:
                            if rest is not None:
                                send(0x06, 0x06, build_putin(player.eid, rest))
                            else:
                                send(0x06, 0x06, build_putout(player.eid, cont, cell, got_item))
                            give_item(GOLD, price * n, notice=False)
                            save_inv()
                            jot(f"     продано {got_item} x{n} по {price}; золото {inv[0].gold()}")
                    send(0x06, 0x0e, pl)
                    if repur:
                        send(0x06, 0x57, build_repur())

                elif (cat, sub) == (0x06, 0x4d) and player and inv[0]:   # «Камень души» в костюм
                    # CItemMixedReinforcePacket (soulstone.py): +4 сумка камня, +8 ячейка, +12 камень,
                    # +16 сумка костюма, +20 ячейка, +24 костюм, +32 код; ответ — эхо с кодом 0x1e5.
                    pl = bytearray(bytes(f[6:]).ljust(34, b'\0'))
                    sb, ss, stone, cb, cs, cost = struct.unpack_from('>IIIIII', pl, 4)
                    soulstone.init()
                    info = soulstone.STONES.get(stone)
                    r_st = inv[0].find(sb, ss)
                    r_co = inv[0].find(cb, cs)
                    cinfo = loot.ITEMS.get(cost, {})
                    why = None
                    if not info or r_st is None or Inventory.item(r_st) != stone:
                        why = 'Нет камня души.'
                    elif r_co is None or Inventory.item(r_co) != cost:
                        why = 'Нет части костюма.'
                    elif cinfo.get('slot') not in info['slots'] or cinfo.get('period'):
                        why = ('Этот камень совмещается только с постоянными поножами или кирасой.'
                               if 26 in info['slots'] else
                               'Этот камень совмещается только с постоянными ботинками или перчатками.')
                    if why:
                        sys_msg(why)
                        struct.pack_into('>H', pl, 32, 0x1e6)
                    else:
                        rec, left = inv[0].use(stone, ss, sb)
                        if left == 0:
                            send(0x06, 0x06, build_putout(player.eid, sb, ss, stone))
                        elif rec is not None:
                            send(0x06, 0x06, build_putin(player.eid, rec))
                        struct.pack_into('<I', r_co, soulstone.STONE_OFF, stone)
                        struct.pack_into('<I', r_co, soulstone.UNTIL_OFF,
                                         int(time.time()) + info['days'] * 86400)
                        send(0x06, 0x06, build_putin(player.eid, r_co))
                        save_inv()
                        struct.pack_into('>H', pl, 32, soulstone.CODE)
                        if cb == 0:
                            restat()
                        jot(f"     камень души {stone} -> {cost}: {info['fx']} на {info['days']} дн.")
                    send(0x06, 0x4d, bytes(pl[:34]))

                elif (cat, sub) == (0x06, 0x27) and player:        # сохранить точку возврата у NPC
                    # CItemReturnSlotSavePacket (S 0x006536c4): +0 eid NPC, +4 слот (клиент держит до 3),
                    # +8 код BE16, +10 точка (mapWarpTargetPos). 0xd2 — сохранено (клиент пишет название
                    # места), 0x17 — «Уже сохранено.». Запись Genesis huge_genesis_pack_2: у NPC Бернео ->
                    # 190031, Пельтрока -> 190051, Баласона -> 190061 = 190000 + (карта − 19000)·10 + 1.
                    pl = bytearray(bytes(f[6:]).ljust(14, b'\0'))
                    slot = struct.unpack_from('>I', pl, 4)[0]
                    m_ = getattr(player, 'map', DEFAULT_MAP_ID)
                    pt = 190000 + (m_ - 19000) * 10 + 1
                    if str(pt) not in WARPS['targets']:
                        on_map = sorted(int(k) for k, v in WARPS['targets'].items() if v.get('map') == m_)
                        pt = on_map[0] if on_map else RETURN_DEFAULT
                    _pc = ACCOUNT.get(player.eid)
                    code = 0xd2
                    if _pc is not None:
                        sl = _pc.setdefault('return_slots', {})
                        if sl.get(str(slot)) == pt:
                            code = 0x17
                        sl[str(slot)] = pt
                        _pc['return_point'] = pt
                        _r25 = raw_of(player, '02/05')      # окно камня берёт точку из 02/05 +425
                        if _r25 and len(_r25) >= 429:
                            _r25 = bytearray(_r25)
                            struct.pack_into('<II', _r25, 421, 1, pt)
                            player.raw['02/05'] = bytes(_r25)
                            _pc.setdefault('raw', {})['02/05'] = bytes(_r25).hex()
                        ACCOUNT.save()
                    struct.pack_into('>H', pl, 8, code)
                    struct.pack_into('>I', pl, 10, pt)
                    send(0x06, 0x27, bytes(pl[:14]))
                    jot(f"     точка возврата {slot}: {pt} {WARPS['targets'].get(str(pt), {}).get('name')}")

                elif (cat, sub) == (0x06, 0x46) and player:        # показать / скрыть костюм
                    # CSetCostumePacket (S 0x0065afac): +0 eid, +4 u8, +5 u8 — два флага показа частей
                    # костюма (клиент кладёт их в сущность +0x7f0/+0x7f1). Запись Genesis
                    # huge_genesis_pack_2: ответ — эхо, при каждом входе на карту сервер шлёт их снова.
                    pl = bytes(f[6:]).ljust(6, b'\0')
                    _pc = ACCOUNT.get(player.eid)
                    if _pc is not None:
                        _pc['costume_view'] = [pl[4], pl[5]]
                        ACCOUNT.save()
                    send(0x06, 0x46, struct.pack('>I', player.eid) + pl[4:6])

                elif (cat, sub) == (0x06, 0x14) and player and inv[0]:   # золотая рыбка / случайный обмен
                    # C 06/14 (CItemGamblePacket, сборщик 0x00518d7e): +0 eid, +4 eid NPC, +8 u8 вид
                    # (10 — рыбка, 9 — случайный обмен), +9 u32 вариант, +13 u16. S 06/14 (0x0065476e):
                    # та же раскладка, +13 код (0x69 «Успех» + «Вы приобрели: %s» по предмету +15;
                    # 0x0b «Нет места в рюкзаке»; 0x6b «Недостаточно предметов»; 0x6c «Неудача»).
                    pl = bytearray(bytes(f[6:]).ljust(19, b'\0'))
                    kind, var = pl[8], struct.unpack_from('>I', pl, 9)[0]
                    v = (GAMBLE.get('goldfish') or {}).get(str(var)) if kind == 10 else None
                    code, prize = G_LACK, 0
                    if v is None:
                        if kind == 9:
                            sys_msg('Призы случайного обмена в данных клиента не указаны — обмен не работает.')
                    elif any(inv[0].count_item(i) < n for i, n in v['give']):
                        code = G_LACK
                    else:
                        roll, acc, out = random.randrange(100), 0, None
                        for prob, it, n in v['outcomes']:
                            acc += prob
                            if roll < acc:
                                out = (it, n)
                                break
                        if out is None or not out[0]:
                            take_items([tuple(g) for g in v['give']], 'рыбка: неудача')
                            code = G_FAIL
                        elif give_item(out[0], out[1], notice=False):
                            take_items([tuple(g) for g in v['give']], f"рыбка: {v['name']}")
                            code, prize = G_OK, out[0]
                        else:
                            code = G_BAGFULL
                        save_inv()
                        jot(f"     рыбка {v['name']}: бросок {roll} -> {out}, код {code:#x}")
                    struct.pack_into('>H', pl, 13, code)
                    struct.pack_into('>I', pl, 15, prize)
                    send(0x06, 0x14, bytes(pl[:19]))

                elif (cat, sub) == (0x06, 0x57) and player:        # окно торговца: список выкупа
                    send(0x06, 0x57, build_repur())

                elif (cat, sub) == (0x06, 0x58) and player and inv[0]:   # выкупить проданное
                    pl = bytearray(bytes(f[6:]).ljust(23, b'\0'))
                    a_, b_ = struct.unpack_from('>II', pl, 4)
                    e = None
                    for idx, item_ in ((a_, b_), (b_, a_)):
                        if idx < len(repur) and Inventory.item(repur[idx]['rec']) == item_:
                            e = repur[idx]
                            break
                    if e is None:
                        e = next((x for x in repur if Inventory.item(x['rec']) in (a_, b_)), None)
                    code, n = REPUR_NOGOLD, 0
                    if e is None:
                        sys_msg('Этого предмета нет в списке выкупа.')
                    elif inv[0].gold() < e['price'] * e['n']:
                        code = REPUR_NOGOLD
                    else:
                        it = Inventory.item(e['rec'])
                        gear = loot.ITEMS.get(it, {}).get('kind') == 1
                        stackable = loot.ITEMS.get(it, {}).get('stack', 1) > 1
                        rec_ = bytearray(e['rec'])
                        struct.pack_into('<I', rec_, 16, e['n'])
                        r = inv[0].put_stack(bytes(rec_), stackable,
                                             inv[0].gear_container() if gear else inventory.BAG)
                        if r is None:
                            sys_msg('Нет места в сумке.')
                            code = 0x0b
                        else:
                            for r_ in r:
                                send(0x06, 0x06, build_putin(player.eid, r_))
                            g = inv[0].add(GOLD, -e['price'] * e['n'])
                            if g is not None:
                                send(0x06, 0x06, build_putin(player.eid, g))
                            save_inv()
                            repur.remove(e)
                            code, n = REPUR_OK, e['n']
                            struct.pack_into('>I', pl, 8, it)
                            jot(f"     выкуплено {it} x{n} за {e['price'] * n}")
                    struct.pack_into('>H', pl, 13, code)
                    struct.pack_into('>q', pl, 15, n)
                    send(0x06, 0x58, bytes(pl[:23]))
                    if code == REPUR_OK:
                        send(0x06, 0x57, build_repur())

                elif (cat, sub) == (0x08, 0x04) and player:        # вложить флетту в стихию
                    # C->S и S->C (обработчик 0x00656130): +0 eid, +4 группа, +8 стихия,
                    # +12 очки, +16 код BE16 0x120 (ок; клиент сам вычитает очки). Записи
                    # оригинала: бродяга «1, 2, 1600» -> −15% перезарядки (+248 = 15),
                    # Pers4x «1, 2, 24» поверх 845. Этап — по порогам fletaAttr (10…1600),
                    # эффект этапа — навык из fletaAttr (statcalc).
                    pl = bytearray(f[6:])
                    jot(f"     08/04 флетта: {pl.hex()}")
                    if len(pl) >= 18:
                        grp, elem, cost = struct.unpack_from('>III', pl, 4)
                        if cost <= getattr(player, 'fleta', 0) and grp in (1, 2):
                            player.fleta -= cost
                            g = fleta_groups(player)
                            el0, pts0 = g.get(grp, (elem, 0))
                            g[grp] = (elem, (pts0 if el0 == elem else 0) + cost)
                            player.fleta_g = g
                            struct.pack_into('>H', pl, 16, 0x120)
                            send(0x08, 0x04, bytes(pl))
                            restat()
                            jot(f"     флетта: группа {grp} стихия {elem} -> {g[grp][1]} очков, "
                                f"этап {statcalc.fleta_stage(grp, elem, g[grp][1])[1]}")
                            pl = None
                            _pc = ACCOUNT.get(player.eid)
                            if _pc is not None:
                                _pc['fleta'] = player.fleta
                                _pc['fleta_g'] = {str(k): list(v) for k, v in g.items()}
                                ACCOUNT.save()
                        else:
                            struct.pack_into('>H', pl, 16, 0x121)     # не хватает очков
                    if pl is not None:
                        send(0x08, 0x04, bytes(pl))

                elif (cat, sub) == (0x08, 0x03) and player:        # смена класса / ранга
                    # S->C (обработчик 0x00662e0b): +0 eid, +4 класс BE32, +8 ранг BE32,
                    # +12 код BE16 0x11A (ок) -> «вы стали …». Требования — classChange.lod:
                    # уровень и золото; сертификат (63007) не требуем — квеста на него нет.
                    pl = f[6:]
                    jot(f"     08/03 смена класса: {pl.hex()}")
                    cur = player.cls
                    want = None
                    for o in range(0, max(0, len(pl) - 1)):
                        for v in (struct.unpack_from('>I', pl, o)[0] if o + 4 <= len(pl) else None,
                                  struct.unpack_from('>H', pl, o)[0]):
                            if v and class_change_rule(cur, v):
                                want = v
                                break
                        if want:
                            break
                    rank = getattr(player, 'rank', 0)
                    rule = class_change_rule(cur, want) if want else None
                    if rule and want == cur:                       # повышение ранга
                        rule = next((r for r in CLASS_CHANGE if r['to'] == cur and r['frm'] == cur
                                     and r['step'] == rank + 1), None)
                    code = 0x11B
                    if rule and player.level >= rule['level'] and inv[0] \
                            and inv[0].gold() >= rule['gold']:
                        if rule['gold']:
                            give_item(GOLD, -rule['gold'], notice=False)
                        player.cls = rule['to']
                        player.rank = rule['step'] if rule['to'] == cur else 0
                        code = 0x11A
                        for cert in (63007, 70211):             # сертификат тратится
                            r0 = inv[0].find_item(cert, None)
                            if r0 is not None:
                                c0, s0 = r0[0], r0[1]
                                rec, left = inv[0].use(cert, s0, c0)
                                if left == 0:
                                    send(0x06, 0x06, build_putout(player.eid, c0, s0, cert))
                                elif rec is not None:
                                    send(0x06, 0x06, build_putin(player.eid, rec))
                                jot(f"     сертификат {cert} потрачен")
                                break
                        _pc = ACCOUNT.get(player.eid)
                        if _pc is not None:
                            _pc['cls'], _pc['rank'] = player.cls, player.rank
                            ACCOUNT.save()
                        save_inv()
                        print(f"     КЛАСС: {cur} -> {player.cls} (ранг {player.rank})", flush=True)
                        jot(f"     атрибуты: {base_attrs(player)}")
                        restat()                                  # прибавка атрибутов класса — сразу
                    send(0x08, 0x03, struct.pack('>III', player.eid, player.cls,
                                                 getattr(player, 'rank', 0))
                         + struct.pack('>H', code) + bytes(6))

                elif (cat, sub) in ((0x05, 0x06), (0x05, 0x07)) and player:   # изучить / поднять навык
                    # S->C (обработчики 0x00661412 / 0x00661691): +0 eid, +4 навык BE32,
                    # 05/06: +8 код BE16 0x24 (ок); 05/07: +8 уровень BE32, +12 код 0x24.
                    # Клиент сам вычитает цену из очков навыков (08/01 +87).
                    pl = bytearray(f[6:])
                    jot(f"     05/{sub:02x} навык: {pl.hex()}")
                    code_off = 8 if sub == 0x06 else 12
                    need = code_off + 2
                    pl += bytes(max(0, need - len(pl)))
                    struct.pack_into('>I', pl, 0, player.eid)
                    sid = struct.unpack_from('>I', pl, 4)[0]
                    _pc = ACCOUNT.get(player.eid)
                    learned = {int(a): int(b) for a, b in (_pc or {}).get('skills', [])}
                    # 05/07: клиент шлёт ТЕКУЩИЙ уровень (+8), в ответе ждёт НОВЫЙ —
                    # раньше уходило эхо, и навык навсегда оставался 1/5
                    new_lvl = 1 if sub == 0x06 else max(learned.get(sid, 1),
                                                         struct.unpack_from('>I', pl, 8)[0]) + 1
                    # предел — число уровней навыка в skillLevel (у 16101, 16102, 16503… их 6, эффектов
                    # в таблице нет — раньше обрезалось до 5; у одноуровневых очки уходили зря до 5);
                    # запись Genesis лучницы: 10501 и 10505 доведены до 6
                    _fx = statcalc.FX.get(str(sid)) or {}
                    _max = skill_max_level(sid) or max([int(k) for k in _fx.get('lv', {})]
                                                       or [SKILL_MAX_LEVEL])
                    if skill_points(player) > 0 and new_lvl <= _max:   # 6103 у оригинала — до 6
                        struct.pack_into('>H', pl, code_off, 0x24)
                        if sub == 0x07:
                            struct.pack_into('>I', pl, 8, new_lvl)
                        player.sp_spent = getattr(player, 'sp_spent', 0) + 1
                        learned[sid] = new_lvl
                        if _pc is not None:
                            _pc['sp_spent'] = player.sp_spent
                            _pc['skills'] = [[k, v] for k, v in learned.items()]
                            ACCOUNT.save()
                        jot(f"     навык {sid} -> ур.{new_lvl}, очков осталось {skill_points(player)}")
                        _passive = statcalc.skill_kind(sid) == statcalc.PASSIVE
                    else:
                        struct.pack_into('>H', pl, code_off, 0x25)     # не хватает очков
                        _passive = False
                    send(cat, sub, bytes(pl))
                    if _passive:
                        restat()        # пассивка — сразу в 08/02, как у оригинала (5003: +1 ловкость)

                elif (cat, sub) == (0x06, 0x03) and player and world:   # подобрать с земли
                    pl = f[6:]
                    jot(f"     06/03 подбор: {pl.hex()}")
                    # Ответ — эхо запроса с кодом 0x5A (+0 eid, +4 номер, +8 item):
                    # клиент (0x00652b1d -> 0x0063ff9e) сам убирает предмет с земли и
                    # пишет «подобрано». Раньше слали ещё 0x5B-уведомление и 0xB7, а
                    # на повторный запрос — эхо: выходило два сообщения и две анимации.
                    g = world.ground.find_in(pl)
                    if g and give_item(g['item'], g['count'], notice=False):
                        world.ground.take(g['gid'])
                        send(0x06, 0x03, pl)
                        save_inv()
                        jot(f"     подобран {loot.item_name(g['item'])} x{g['count']}")
                    elif g is None and len(pl) >= 12:
                        # предмета у сервера нет (исчез/старый мир) — убрать его у
                        # клиента, иначе персонаж бесконечно бегает вокруг
                        gid, it = struct.unpack_from('>II', pl, 4)
                        send(0x06, 0x03, build_hide({'dropper': player.eid, 'gid': gid, 'item': it}))
                        jot(f"     подбор {gid}: нет на земле -> скрыть")
                    else:
                        jot("     подбор: нет места в сумках")

                elif (cat, sub) == (0x06, 0x17) and player and inv[0]:   # заточка
                    pl = bytearray(f[6:])
                    pl += bytes(max(0, 43 - len(pl)))
                    sc, scell, sitem, tc, tcell, titem = struct.unpack_from('>6I', pl, 4)
                    scroll, target = inv[0].find(sc, scell), inv[0].find(tc, tcell)
                    code = enchant.FAIL
                    if scroll is not None and target is not None:
                        prot = any(b != 0xff for b in pl[30:42])
                        _sname = loot.ITEMS.get(sitem, {}).get('name', '')
                        code = enchant.try_enchant(
                            target, safe=DEV.get('safe_enchant', True), protected=prot,
                            scroll_grade=1 if 'Маркус' in _sname else 0,
                            item_cat=loot.ITEMS.get(Inventory.item(target), {}).get('cat', 1))
                        rec, left = inv[0].use(Inventory.item(scroll), scell, sc)
                        if left == 0:
                            send(0x06, 0x06, build_putout(player.eid, sc, scell, sitem))
                        elif rec is not None:
                            send(0x06, 0x06, build_putin(player.eid, rec))
                        if code == enchant.BROKEN:
                            inv[0].recs.remove(target)
                            send(0x06, 0x06, build_putout(player.eid, tc, tcell, titem))
                        else:
                            send(0x06, 0x06, build_putin(player.eid, bytearray(target)))
                        save_inv()
                        if tc == 0:
                            restat()
                    struct.pack_into('>H', pl, 28, code)
                    send(0x06, 0x17, bytes(pl[:43]))
                    jot(f"     заточка {loot.item_name(titem)}: код {code:#x}, "
                        f"ур. {enchant.level(target) if target is not None else '?'}")

                elif (cat, sub) == (0x06, 0x55) and player and inv[0]:   # чарование характеристик
                    pl = bytearray(f[6:])
                    pl += bytes(max(0, 18 - len(pl)))
                    mc, mcell, tc, tcell = struct.unpack_from('>4I', pl, 0)
                    mat, target = inv[0].find(mc, mcell), inv[0].find(tc, tcell)
                    code = enchant.CHAR_FAIL
                    if mat is not None and target is not None and inv[0].count32(mat) >= enchant.STONES_PER_TRY:
                        mitem = Inventory.item(mat)
                        rec = None
                        for _ in range(enchant.STONES_PER_TRY):
                            rec, left = inv[0].use(mitem, mcell, mc)
                        if left == 0:
                            send(0x06, 0x06, build_putout(player.eid, mc, mcell, mitem))
                        elif rec is not None:
                            send(0x06, 0x06, build_putin(player.eid, rec))
                        added = itemroll.add_yellow(target, loot.ITEMS)                             if __import__('random').random() < enchant.CHAR_CHANCE else None
                        code = enchant.CHAR_OK if added else enchant.CHAR_FAIL
                        if tc == 0:
                            restat()
                        send(0x06, 0x06, build_putin(player.eid, bytearray(target)))
                        save_inv()
                    struct.pack_into('>H', pl, 16, code)
                    send(0x06, 0x55, bytes(pl[:18]))
                    jot(f"     чарование характеристик: код {code:#x}")

                elif cat == 0x11 and player:                  # питомцы
                    pl = bytearray(f[6:])
                    jot(f"     11/{sub:02x} питомец: {pl.hex()}")
                    if sub == 0x00 and len(pl) >= 4:            # список у NPC
                        send(0x11, 0x00, pets.build_list(struct.unpack_from('>I', pl, 0)[0], pet_list(), pet_slots()))
                    elif sub == 0x03 and len(pl) >= 8:          # выбрать
                        uid = struct.unpack_from('>I', pl, 4)[0]
                        _pc = ACCOUNT.get(player.eid)
                        if _pc is not None and any(p.uid == uid for p in pet_list()):
                            _pc['pet_active'] = uid
                            ACCOUNT.save()
                        send(0x11, 0x03, bytes(pl))
                        _pa, _ = pet_active()
                        if _pa:
                            send(0x11, 0x01, bytes(_pa.raw))
                    elif sub == 0x08 and pl:                     # призвать / отозвать
                        _pa, _pc = pet_active()
                        _away = (_pc or {}).get('pet_away', 0) - time.time()
                        if pl[0] == 1 and _pa and _pa.egg:
                            send(0x11, 0x08, bytes([0]) + struct.pack('>H', pets.E_CANT_SUMMON))
                            continue
                        if pl[0] == 1 and _pa and _pa.dead():
                            send(0x11, 0x08, bytes([0]) + struct.pack('>H', pets.E_DEAD))
                            continue
                        if pl[0] == 1 and _away > 0:
                            send(0x11, 0x08, bytes([0]) + struct.pack('>H', pets.E_SELLING))
                            sys_msg(f'Питомец продаёт предметы: ещё {int(_away // 60) + 1} мин.')
                            continue
                        send(0x11, 0x08, bytes(pl))
                        pet_state['t'] = time.time()
                        if pl[0] == 1:
                            if not pet_spawn():
                                jot("     питомца нет")
                        else:
                            pet_state['out'] = False
                        restat()                                  # навыки питомца — прибавки хозяину
                    elif sub == 0x04 and len(pl) >= 8:          # удалить питомца
                        uid = struct.unpack_from('>I', pl, 4)[0]
                        _pc = ACCOUNT.get(player.eid)
                        if _pc is not None and pet_state['out'] and _pc.get('pet_active') == uid:
                            sys_msg('Невозможно удалить используемого питомца.')
                        elif _pc is not None:
                            _pc['pets'] = [h for h in _pc.get('pets', [])
                                           if pets.Pet(bytes.fromhex(h)).uid != uid]
                            if _pc.get('pet_active') == uid:
                                _pc.pop('pet_active', None)
                            ACCOUNT.save()
                            send(0x11, 0x04, bytes(pl))
                            jot(f"     питомец {uid:#x} удалён")
                    elif sub == 0x09 and pl:                     # выбрать тип питомца
                        pet, _ = pet_active()
                        t = pl[0]
                        if not pet:
                            sys_msg('Не используется ни один питомец.')
                        elif pet.ptype:
                            sys_msg('Нельзя изменить тип после его выбора.')
                        elif t in pets.TYPE_NAMES:
                            sk0 = pet.skills()
                            pet.set_type(t)
                            pet_save(pet)
                            send(0x11, 0x09, bytes([t]) + struct.pack('>H', pets.CODE))
                            send(0x11, 0x0d, pets.build_exp(pet, 3, t, 0))
                            for s_ in pet.skills():
                                if s_ not in sk0:
                                    send(0x11, 0x0d, pets.build_exp(pet, 7, s_, 0))
                            send(0x11, 0x02, pets.build_record(pet))
                            if pet_state['out']:
                                restat()
                            jot(f"     питомец {pet.name}: тип {t} ({pets.TYPE_NAMES[t]})")
                    elif sub == 0x11 and len(pl) >= 8:           # тренировка (ур.3/6/9 при полном опыте)
                        uid = struct.unpack_from('>I', pl, 4)[0]
                        pet = next((p for p in pet_list() if p.uid == uid), None)
                        cost = pets.TRAIN_COST.get(pet.level) if pet else None
                        if not pet or not pet.needs_training():
                            sys_msg('Питомец ещё не готов к тренировке.')
                        elif inv[0].gold() < cost:
                            sys_msg('Недостаточно каратов.')
                        else:
                            r = inv[0].add(GOLD, -cost)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            save_inv()
                            sk0 = pet.skills()
                            pet.train()
                            pet_save(pet)
                            _pa, _ = pet_active()
                            if not (_pa and _pa.uid == pet.uid):
                                pet_state_out, pet_state['out'] = pet_state['out'], False
                                pet_grown(pet, sk0)              # не призванный — без 04/02 и прибавок
                                pet_state['out'] = pet_state_out
                            else:
                                pet_grown(pet, sk0)
                        send(0x11, 0x11, bytes(pl))
                    elif sub == 0x0a and len(pl) >= 2:           # покормить (корм — по стадии)
                        pet, _ = pet_active()
                        r0 = inv[0].find(pl[0], pl[1]) if inv[0] else None
                        it = Inventory.item(r0) if r0 is not None else None
                        if pet and it is not None and pet.egg:
                            sys_msg('Питомец ещё не высижен.')
                        elif pet and it is not None and pet.dead():
                            sys_msg('Питомец мертв.')
                        elif pet and it is not None and it in pets.FOOD and not pet.food_ok(it):
                            sys_msg('Корм для питомца должен соответствовать стадии его развития.')
                        elif pet and it is not None:
                            rec, left = inv[0].use(it, pl[1], pl[0])
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, pl[0], pl[1], it))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            v0 = pet.satiety
                            v = pet.feed()
                            pet_save(pet)
                            save_inv()
                            send(0x11, 0x0d, pets.build_exp(pet, 4, v, v - v0))
                            if pet_state['out']:
                                send(0x11, 0x0e, pets.build_state(pet_state['ent'], 1))
                            jot(f"     питомец {pet.name} накормлен: {v0} -> {v}")
                        send(0x11, 0x0a, bytes(pl))
                    elif sub == 0x12:                            # окно смены облика (билет)
                        send(0x11, 0x12, pets.build_look_list([p for p in pet_list() if not p.egg]))
                    elif sub == 0x13 and len(pl) >= 12:          # сменить облик
                        uid, look = struct.unpack_from('>II', pl, 2)
                        pet = next((p for p in pet_list() if p.uid == uid), None)
                        r0 = inv[0].find(pl[0], pl[1]) if inv[0] else None
                        it = Inventory.item(r0) if r0 is not None else None
                        _pc = ACCOUNT.get(player.eid)
                        if not pet or it != pets.LOOK_TICKET or not pets.look_ok(pet.template, look) or _pc is None:
                            send(0x11, 0x13, bytes(pl[:10]) + struct.pack('>H', pets.E_BAD_NAME))
                            sys_msg('Такой облик выбрать нельзя.')
                            jot(f"     облик питомца отклонён: uid {uid:#x}, {look}, билет {it}")
                        else:
                            rec, left = inv[0].use(it, pl[1], pl[0])
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, pl[0], pl[1], it))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            old = pet.template
                            pet.set_template(look)
                            lk = _pc.setdefault('pet_look', [])
                            if uid not in lk:
                                lk.append(uid)
                            pet_save(pet)
                            save_inv()
                            send(0x11, 0x13, bytes(pl[:10]) + struct.pack('>H', pets.CODE))
                            send(0x11, 0x02, pets.build_record(pet))
                            _pa, _ = pet_active()
                            if pet_state['out'] and _pa and _pa.uid == uid:
                                pet_spawn()                      # новый облик над хозяином
                            sys_msg('Внешность питомца изменена.')
                            jot(f"     облик питомца {pet.name}: {old} -> {look}")
                    elif sub == 0x0f and len(pl) >= 10:          # воскресить (окно питомцев у NPC)
                        uid = struct.unpack_from('>I', pl, 4)[0]
                        pet = next((p for p in pet_list() if p.uid == uid), None)
                        cost = pets.revive_cost(pet.level) if pet else 0
                        if not pet or not pet.dead():
                            sys_msg('Питомец жив — воскрешать не нужно.')
                        elif inv[0].gold() < cost:
                            sys_msg('Недостаточно каратов.')
                        else:
                            r = inv[0].add(GOLD, -cost)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            save_inv()
                            v = pet.feed()
                            pet_save(pet)
                            send(0x11, 0x0d, pets.build_exp(pet, 4, v, v))
                            send(0x11, 0x02, pets.build_record(pet))
                            jot(f"     питомец {pet.name} воскрешён за {cost}")
                        send(0x11, 0x0f, bytes(pl))
                    elif sub == 0x10 and len(pl) >= 6:           # купить слот питомца
                        _pc = ACCOUNT.get(player.eid)
                        n = pet_slots()
                        if n >= pets.MAX_SLOTS:
                            sys_msg('Слотов питомцев уже максимум.')
                        elif inv[0].gold() < pets.SLOT_COST:
                            sys_msg('Недостаточно каратов.')
                        elif _pc is not None:
                            r = inv[0].add(GOLD, -pets.SLOT_COST)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            save_inv()
                            n += 1
                            _pc['pet_slots'] = n
                            ACCOUNT.save()
                            jot(f"     слотов питомцев: {n}")
                        send(0x11, 0x10, pets.build_slots(pl, n))
                    elif sub == 0x02 and len(pl) >= 8:           # капсула у Мелисы -> яйцо
                        npc_, bag, cell = struct.unpack_from('>IBB', pl, 0)
                        r0 = inv[0].find(bag, cell) if inv[0] else None
                        item = Inventory.item(r0) if r0 is not None else None
                        _tpl = pets.CAPSULE.get(item)
                        _species = CONTENT.npc.get(pets.BASE[_tpl]['npc'], {}).get('name') if _tpl else None
                        _pc = ACCOUNT.get(player.eid)
                        if not _species or _pc is None:
                            send(0x11, 0x02, pets.build_record(None, npc_, bag, cell, pets.E_NOT_PET_ITEM))
                        elif len(_pc.get('pets', [])) >= pet_slots():
                            send(0x11, 0x02, pets.build_record(None, npc_, bag, cell, pets.E_NO_SLOT))
                        else:
                            rec, left = inv[0].use(item, cell, bag)
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, bag, cell, item))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            _n = max([pets.Pet(bytes.fromhex(h)).uid & 0xff for h in _pc.get('pets', [])] + [-1]) + 1
                            egg = pets.new_egg(_species, uid=(player.eid << 8 | (_n & 0xff)) & 0x7fffffff,
                                               template=_tpl)
                            _pc.setdefault('pets', []).append(egg.raw.hex())
                            if not _pc.get('pet_active'):
                                _pc['pet_active'] = egg.uid
                            ACCOUNT.save()
                            save_inv()
                            send(0x11, 0x02, pets.build_record(egg, npc_, bag, cell))
                            jot(f"     капсула {item} -> яйцо {_species} ({egg.uid:#x})")
                    elif sub == 0x06 and len(pl) >= 11:          # начать / отменить высиживание
                        code_, npc_, uid, flag = struct.unpack_from('>HIIB', pl, 0)
                        name = bytes(pl[11:]).split(b'\0')[0].decode('utf-8', 'replace')
                        pet = next((p for p in pet_list() if p.uid == uid), None)
                        _pc = ACCOUNT.get(player.eid)
                        code = pets.CODE
                        if not pet or not pet.egg:
                            code = pets.E_HATCH_ALIVE if pet else pets.E_NOT_EGG
                        elif flag == 1 and pet.state == 0:
                            if name and pets.name_ok(name) and not pet_name_taken(name, uid):
                                pet.set_name(name)
                            pet.set_state(1, pets.HATCH_SECS)
                            _pc.setdefault('pet_hatch', {})[str(uid)] = time.time() + pets.HATCH_SECS
                        elif flag == 0 and pet.state == 1:
                            pet.set_state(0)
                            _pc.get('pet_hatch', {}).pop(str(uid), None)
                        else:
                            code = pets.E_NOT_EGG
                        if code == pets.CODE:
                            pet_save(pet)
                        out = bytearray(pl)
                        struct.pack_into('>H', out, 0, code)
                        send(0x11, 0x06, bytes(out))
                        if code == pets.CODE:
                            send(0x11, 0x0d, pets.build_exp(pet, 0, pet.state,
                                                            pets.HATCH_SECS if pet.state == 1 else 0))
                            jot(f"     высиживание {pet.name}: {'начато' if flag else 'отменено'}")
                    elif sub == 0x05 and len(pl) >= 2:           # имя свободно?
                        name = bytes(pl[2:]).split(b'\0')[0].decode('utf-8', 'replace')
                        ok = pets.name_ok(name) and not pet_name_taken(name)
                        send(0x11, 0x05, struct.pack('>H', pets.CODE if ok else pets.E_BAD_NAME) +
                             name.encode('utf-8') + bytes(1))
                    elif sub == 0x07 and len(pl) >= 13:          # регистрация / смена имени по билету
                        code_, npc_, bag, cell, uid, flag = struct.unpack_from('>HIBBIB', pl, 0)
                        name = bytes(pl[13:]).split(b'\0')[0].decode('utf-8', 'replace')
                        pet = next((p for p in pet_list() if p.uid == uid), None)
                        _pc = ACCOUNT.get(player.eid)
                        named = (_pc or {}).setdefault('pet_named', [])
                        r0 = inv[0].find(bag, cell) if inv[0] else None
                        ticket = Inventory.item(r0) if r0 is not None else None
                        code = pets.CODE
                        if not pet or _pc is None:
                            code = pets.E_NOT_EGG
                        elif ticket != pets.NAME_TICKET.get(flag):
                            sys_msg('Нет билета на регистрацию имени питомца.' if flag else
                                    'Нет билета на изменение имени питомца.')
                            code = pets.E_BAD_NAME
                        elif flag == 0 and uid not in named:
                            sys_msg('Вы еще не зарегистрировали имя питомца.')
                            code = pets.E_BAD_NAME
                        elif not pets.name_ok(name) or pet_name_taken(name, uid):
                            code = pets.E_BAD_NAME
                        else:
                            rec, left = inv[0].use(ticket, cell, bag)
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, bag, cell, ticket))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            pet.set_name(name)
                            pet_save(pet)
                            if uid not in named:
                                named.append(uid)
                            ACCOUNT.save()
                            jot(f"     питомец {uid:#x}: имя «{name}»")
                        _pa, _ = pet_active()
                        ent = pet_state['ent'] if (pet_state['out'] and _pa and _pa.uid == uid) else 0
                        send(0x11, 0x07, struct.pack('>HIBBIB', code, ent, bag, cell, uid, flag) +
                             name.encode('utf-8') + bytes(1))
                    elif sub == 0x0b and len(pl) >= 11:          # помощник продаёт вещи
                        pet, _pc = pet_active()
                        n = pl[10]
                        cells = [tuple(pl[11 + 3 * i:14 + 3 * i]) for i in range(n) if len(pl) >= 14 + 3 * i]
                        room = pet_sell_room(pet)
                        if not pet or not pet_state['out']:
                            sys_msg('Можно использовать только после призыва.')
                            send(0x11, 0x0b, pets.build_sold(0, pets.E_CANT_SUMMON))
                        elif not room:
                            sys_msg('Продавать вещи умеют только питомцы-помощники (с ур.4).')
                            send(0x11, 0x0b, pets.build_sold(0, pets.E_CANT_SUMMON))
                        else:
                            earned, sold = 0, []
                            for bag, cell, cnt in cells[:room]:
                                r0 = inv[0].find(bag, cell)
                                item = Inventory.item(r0) if r0 is not None else None
                                it = loot.ITEMS.get(item, {}) if item else {}
                                price = it.get('sell') or it.get('price', 0) // 2
                                if not item or item == GOLD or price <= 0:
                                    continue
                                rest, got, k = inv[0].remove(bag, cell, cnt or None, item)
                                if not k:
                                    continue
                                if rest is not None:
                                    send(0x06, 0x06, build_putin(player.eid, rest))
                                else:
                                    send(0x06, 0x06, build_putout(player.eid, bag, cell, got))
                                earned += price * k
                                sold.append((got, k))
                            if earned:
                                give_item(GOLD, earned, notice=False)
                            save_inv()
                            send(0x11, 0x0b, pets.build_sold(earned))
                            if sold:
                                _pc['pet_away'] = time.time() + pets.SELL_AWAY
                                ACCOUNT.save()
                                pet_unsummon('ушёл продавать')
                            jot(f"     питомец продал {sold} за {earned}")
                    elif sub == 0x0c and len(pl) >= 4:           # питомец подбирает с земли
                        g = world.ground.items.get(struct.unpack_from('>I', pl, 0)[0]) if world else None
                        _cats = pet_cfg()['loot']
                        if g and _cats and loot_cat(g['item']) not in _cats:
                            g = None                             # категория не отмечена на пульте — не берёт
                        if g and give_item(g['item'], g['count']):
                            world.ground.take(g['gid'])
                            send(0x06, 0x03, build_hide(g))
                            save_inv()
                        send(0x11, 0x0e, pets.build_state(pet_state['ent'], 2))
                    else:
                        send(cat, sub, bytes(pl))

                elif cat == 0x15 and player:                  # гача-автоматы
                    pl = f[6:]
                    jot(f"     15/{sub:02x} гача: {pl.hex()}")
                    if sub == 0x02:
                        send(0x15, 0x02, GACHA.build_machines())
                    elif sub == 0x03 and len(pl) >= 4:
                        m, slot = struct.unpack_from('>HH', pl, 0)
                        player.gacha_sel = (m, slot)
                        send(0x15, 0x03, GACHA.build_prizes(m, slot))
                    else:
                        # 15/04 прокрутка: автомат, ячейка, контейнер/ячейка монеты (оригинал)
                        m = struct.unpack_from('>H', pl, 0)[0] if len(pl) >= 2 else 0
                        slot = struct.unpack_from('>H', pl, 4)[0] if len(pl) >= 6 else 1
                        if not 1 <= m <= len(GACHA.machines):
                            m = getattr(player, 'gacha_sel', (1, 1))[0]
                        item, cnt, cost, idx = GACHA.spin(m)
                        have = inv[0].count_item(gacha.TOKEN) if inv[0] else 0
                        if have < cost:
                            send(cat, sub, pl)
                            send(0x06, 0x03, build_pickup_notice(player.eid, gacha.TOKEN, 0))
                            jot(f"     гача {m}: нет билетов ({have}/{cost})")
                        else:
                            give_item(item, cnt, notice=False)
                            send(0x15, 0x04, gacha.build_spin(m, slot, item, idx))
                            for _ in range(cost):
                                r0 = inv[0].find_item(gacha.TOKEN, None)
                                rec, left = inv[0].use(gacha.TOKEN, r0[1], r0[0])
                                if left == 0:
                                    send(0x06, 0x06, build_putout(player.eid, r0[0], r0[1], gacha.TOKEN))
                                elif rec is not None:
                                    send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            jot(f"     гача {m}: приз №{idx} {loot.item_name(item)} x{cnt} (-{cost} билетов)")

                elif (cat, sub) == (0x06, 0x48) and player:   # GXP-рюкзак: страница
                    # Запись оригинала (23:54): C +0 страница BE32 -> S: страница, на странице,
                    # всего (BE32), затем записи по 16 байт LE: uid, 0, предмет, кол-во (15 на стр.)
                    pl = f[6:]
                    page = max(1, struct.unpack_from('>I', pl, 0)[0]) if len(pl) >= 4 else 1
                    send(0x06, 0x48, build_gxp_page(page))
                    jot(f"     06/48 GXP-рюкзак, страница {page}")

                elif (cat, sub) == (0x06, 0x49) and player:   # GXP-рюкзак: забрать
                    # C: +9 uid BE32 (+13 0x0175, +15 uid LE) -> S 06/06 предмет + 06/48 стр. 1
                    pl = f[6:]
                    uid = struct.unpack_from('>I', pl, 9)[0] if len(pl) >= 13 else 0
                    lst = gxp_list()
                    k = uid - GXP_UID0
                    if 0 <= k < len(lst):
                        item, cnt = lst[k]
                        if give_item(item, cnt):
                            lst.pop(k)
                            save_inv()
                            ACCOUNT.save()
                            jot(f"     GXP: забран {loot.item_name(item)} x{cnt}")
                    send(0x06, 0x48, build_gxp_page(1))

                elif (cat, sub) == (0x05, 0x03) and player:   # подготовка навыка
                    # Запись Genesis: навык 5 (вызов ездового животного) клиент шлёт с +9 = 0,
                    # оригинал отвечает +9 = 1; у боевых навыков +9 = 2 — эхо как есть.
                    pl = bytearray(f[6:])
                    if len(pl) >= 10 and struct.unpack_from('>I', pl, 5)[0] == 5 and pl[9] == 0:
                        pl[9] = 1
                    send(cat, sub, bytes(pl))

                elif (cat, sub) == (0x03, 0x02) and player:   # действие персонажа (сесть/верхом)
                    # +0 eid, +4 действие (0 стоять, 1 сидеть, 2 верхом), +5 eid всадника BE32.
                    # Оригинал на «верхом» отвечает с eid в +5 — без него клиент сажал
                    # всадника не на животное (наполовину в земле).
                    pl = bytearray(f[6:])
                    if len(pl) >= 9 and pl[4] == 2:
                        struct.pack_into('>I', pl, 5, player.eid)
                        send(0x03, 0x16, bytes(4))
                    send(cat, sub, bytes(pl))
                    jot(f"     03/02 действие {pl[4] if len(pl) > 4 else '?'}")

                elif (cat, sub) == (0x0a, 0x02) and player:   # удар по объекту карты
                    # CEventAttackObject: клиент шлёт на каждый взмах кирки / заброс удочки
                    # (перед ним 05/00 с действием 900 — кирка, 911 — удочка, цель — объект
                    # карты тип 2). Оригинал (запись Genesis) эхо не шлёт: удочка — улов с
                    # каждого заброса (~9 с) + 08/07 счётчик уловов; кирка — руда каждый
                    # 2-й взмах (~3 с).
                    pl = f[6:]
                    w = inv[0].find(0, 7) if inv[0] else None
                    wname = loot.ITEMS.get(Inventory.item(w), {}).get('name', '').lower() if w is not None else ''
                    kind = 'fish' if 'удочк' in wname else 'ore' if 'кирк' in wname else None
                    if kind:
                        player.gather_hits = getattr(player, 'gather_hits', 0) + 1
                        if player.gather_hits % (1 if kind == 'fish' else GATHER_EVERY) == 0:
                            got = gather.fish() if kind == 'fish' else gather.mine()
                            if kind == 'fish':
                                player.fish_count = getattr(player, 'fish_count', 0) + 1
                                send(0x08, 0x07, struct.pack('>I', player.fish_count))
                            names = [f"{loot.item_name(i)} x{n}" for i, n in got if give_item(i, n)]
                            save_inv()
                            gain_exp(max(1, int(3 * DEV['exp'])))
                            jot(f"     {'улов' if kind == 'fish' else 'руда'}: {', '.join(names) or 'пусто'}")

                elif (cat, sub) in ((0x08, 0x07), (0x08, 0x08)) and player:   # рыбалка
                    pl = f[6:]
                    jot(f"     {cat:02x}/{sub:02x} рыбалка: {pl.hex()}")
                    send(cat, sub, pl)
                    if sub == 0x08 and time.time() - getattr(player, 'last_fish', 0) > 3:
                        player.last_fish = time.time()
                        for i, n in gather.fish():
                            give_item(i, n)
                            save_inv()
                            jot(f"     улов: {loot.item_name(i)}")

                elif (cat, sub) == (0x06, 0x3c) and player and COMMISSION:   # комиссионка: список
                    pl = f[6:]
                    jot(f"     06/3c комиссионка: {pl.hex()}")
                    page = struct.unpack_from('>I', pl, 38)[0] if len(pl) >= 42 else 0
                    if page * commission.PAGE >= len(COMM_CAT):
                        page = 0
                    send(0x06, 0x3c, commission.build_list(loot.ITEMS, COMM_CAT, page))

                elif (cat, sub) == (0x06, 0x1e) and player and COMMISSION:   # комиссионка: список
                    # как в оригинале (запись Genesis): категория/страница/сортировка в запросе
                    pl = f[6:]
                    jot(f"     06/1e комиссионка: {pl.hex()}")
                    send(0x06, 0x1e, commission.build_list_orig(loot.ITEMS, COMM_ALL, pl))

                elif (cat, sub) == (0x06, 0x24) and player and COMMISSION:   # комиссионка: купить лот
                    pl = bytearray(f[6:])
                    pl += bytes(max(0, 10 - len(pl)))
                    jot(f"     06/24 покупка: {pl.hex()}")
                    iid = struct.unpack_from('>I', pl, 4)[0]
                    snap = commission.SNAPSHOT.get(iid)
                    if snap:                      # лот игрока из слепка оригинала
                        iid = snap['item']
                    it = loot.ITEMS.get(iid, {})
                    n = snap['count'] if snap else (10 if it.get('stack', 1) > 1 else 1)
                    cost = (snap['price'] if snap else commission.lot_price(it) * n) if it else 0
                    prof = None
                    if snap and snap.get('tail'):
                        prof = (snap.get('opts', [0] * 6), bytes.fromhex(snap['tail'])[-itemroll.BLOCK_LEN:],
                                snap.get('enchant', 0))
                    ok = bool(it) and inv[0] is not None and inv[0].gold() >= cost                         and give_item(iid, n, profile=prof)
                    if ok:
                        give_item(GOLD, -cost, notice=False)
                        save_inv()
                    struct.pack_into('>H', pl, 8, commission.OK if ok else 0x225)
                    send(0x06, 0x24, bytes(pl[:10]))
                    jot(f"     комиссионка: {'куплено' if ok else 'отказ'} {loot.item_name(iid)} x{n} за {cost}")

                elif (cat, sub) == (0x06, 0x18) and player and inv[0]:   # чарование изделий из флеттоцветов
                    pl = bytes(f[6:]) + bytes(15)
                    _e, grade, kind = struct.unpack_from('>3I', pl, 0)
                    recipe = enchant.FLETA.get((grade, kind))
                    code = enchant.F_ERR
                    if recipe is None:
                        sys_msg('Чарование этой ступени невозможно.')
                    elif inv[0].gold() < recipe['cost']:
                        sys_msg(f"Недостаточно карат: нужно {recipe['cost']}.")
                    else:
                        plan, miss = enchant.fleta_plan(inv[0], recipe)
                        if plan is None:
                            it, gr, cnt = miss
                            sys_msg(f"Не хватает: {loot.item_name(it)}" + (f" ступени {gr}" if gr else '') + f" ×{cnt}.")
                        else:
                            r = inv[0].add(GOLD, -recipe['cost'])
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            code = enchant.fleta_roll(recipe)
                            if code in (enchant.F_OK, enchant.F_LOST):     # вещи уходят
                                for step in plan:
                                    if step[0] == 'rec':
                                        _, c_, cl, it = step
                                        rest, got, k = inv[0].remove(c_, cl, None, it)
                                        send(0x06, 0x06, build_putout(player.eid, c_, cl, it))
                                    else:
                                        _, it, cnt = step
                                        for c_, cl, rr in inv[0].take_item(it, cnt):
                                            if rr is None:
                                                send(0x06, 0x06, build_putout(player.eid, c_, cl, it))
                                            else:
                                                send(0x06, 0x06, build_putin(player.eid, rr))
                            if code == enchant.F_OK:
                                item = enchant.FLETA_ITEM[kind]
                                newr = inv[0].add(item, 1, stack=False, cont=inv[0].gear_container())
                                if newr is not None:
                                    stored = inv[0].find(newr[0], newr[1])
                                    stored[enchant.ENCH_OFF] = grade
                                    send(0x06, 0x06, build_putin(player.eid, bytes(stored)))
                            save_inv()
                            jot(f"     06/18 флеттоизделие ступени {grade} (вид {kind}): код {code:#x}")
                    send(0x06, 0x18, enchant.build_fleta(player.eid, grade, kind, code))

                elif (cat, sub) == (0x06, 0x41) and player and inv[0]:   # уничтожить предмет (корзина)
                    # C (сборщик 0x0061f761): +0 eid, +4 сумка, +8 ячейка, +12 предмет, +16 u64 кол-во
                    #   (FF..FF — всё), +24 u16 0xb5, дальше строка — цифры подтверждения, которые клиент сам
                    #   показывает в окне («Enter the numbers [ … ]»; не проверяем).
                    # S (0x0065e925): первые 26 байт с кодом 0xb5 — «уничтожено» (Genesis: 06/06
                    #   ячейки, затем эхо без строки).
                    pl = bytes(f[6:32]).ljust(26, b'\0')
                    cont, cell, item = struct.unpack_from('>III', pl, 4)
                    n = struct.unpack_from('>Q', pl, 16)[0]
                    loc = inv[0].locate(cont, cell, item)
                    if loc and loc[0] != inventory.EQUIP:
                        rest, got, k = inv[0].remove(loc[0], loc[1], None if n >= 0x7fffffffffffffff else n, item)
                        if rest is not None:
                            send(0x06, 0x06, build_putin(player.eid, rest))
                        else:
                            send(0x06, 0x06, build_putout(player.eid, loc[0], loc[1], got))
                        save_inv()
                        jot(f"     уничтожено: {loot.item_name(item)} x{k}")
                    send(0x06, 0x41, pl[:24] + struct.pack('>H', 0xb5))

                elif (cat, sub) == (0x06, 0x21) and player and inv[0]:   # комиссионка: выставить лот
                    pl = f[6:]
                    a_, cont, cell, n, price = commission.parse_register(pl)
                    lots, _pc = lots_of()
                    src = inv[0].find(cont, cell)
                    code = commission.REG_FAIL
                    if src is not None and cont != inventory.EQUIP and price > 0 and _pc is not None \
                            and len(lots) < commission.MAX_LOTS:
                        item = inv[0].item(src)
                        have = inv[0].count32(src) or 1
                        n = max(1, min(n or 1, have))
                        fee = commission.reg_fee(price * n)
                        if item != GOLD and inv[0].gold() >= fee:
                            copy = bytearray(src)
                            rest, got, k = inv[0].remove(cont, cell, n, item)
                            if rest is not None:
                                send(0x06, 0x06, build_putin(player.eid, rest))
                            else:
                                send(0x06, 0x06, build_putout(player.eid, cont, cell, item))
                            r = inv[0].add(GOLD, -fee)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            now = time.time()
                            lot = max([L['lot'] for L in lots] + [_pc.get('lot_seq', 200000)]) + 1
                            _pc['lot_seq'] = lot
                            fair = commission.lot_price_any(loot.ITEMS.get(item, {}))
                            delay = commission.sale_delay(price, fair, random)
                            struct.pack_into('<I', copy, 16, k)
                            L = {'lot': lot, 'item': item, 'count': k, 'price': price, 'rec': bytes(copy).hex(),
                                 't': int(now), 'expire': int(now) + commission.LOT_DAYS * 86400,
                                 'sell_at': (now + delay) if delay is not None else 0}
                            lots.append(L)
                            save_inv()
                            code = commission.REG_OK
                            send(0x06, 0x21, bytes(pl[:24]).ljust(24, b'\0') + struct.pack('>H', code))
                            send(0x06, 0x1f, commission.build_my_lot(commission.MODE_SALE, lot, copy, k, price,
                                                                     player.name, L['expire']))
                            send(0x06, 0x25, bytes(4))
                            jot(f"     лот {lot}: {loot.item_name(item)} x{k} по {price} (рынок {fair}), плата {fee}, "
                                f"продажа {'через %.0f с' % delay if delay is not None else 'нет — дорого'}")
                    if code != commission.REG_OK:
                        send(0x06, 0x21, bytes(pl[:24]).ljust(24, b'\0') + struct.pack('>H', code))

                elif (cat, sub) == (0x06, 0x22) and player and inv[0]:   # комиссионка: снять лот
                    pl = bytes(f[6:]) + bytes(14)
                    a_, p1, p2 = struct.unpack_from('>3I', pl, 0)
                    lots, _pc = lots_of()
                    L = next((x for x in lots if x['lot'] in (p1, p2) and not x.get('sold')), None)
                    code = commission.REG_FAIL
                    if L is not None:
                        it = L['item']
                        gear = loot.ITEMS.get(it, {}).get('kind') == 1
                        stackable = it == GOLD or loot.ITEMS.get(it, {}).get('stack', 1) > 1
                        r = inv[0].put_stack(bytes.fromhex(L['rec']), stackable,
                                             inv[0].gear_container() if gear else inventory.BAG)
                        if r is not None:
                            lots.remove(L)
                            save_inv()
                            for r_ in r:
                                send(0x06, 0x06, build_putin(player.eid, r_))
                            send(0x06, 0x20, commission.build_removed(commission.MODE_SALE, [L['lot']]))
                            code = commission.REG_OK
                        else:
                            sys_msg('Нет места в сумке.')
                    send(0x06, 0x22, struct.pack('>IIH', a_, p1, code))
                    jot(f"     06/22 снять лот {p1}/{p2}: код {code:#x}")

                elif (cat, sub) == (0x06, 0x23) and player and inv[0]:   # комиссионка: расчёт
                    lots, _pc = lots_of()
                    sold = [L for L in lots if L.get('sold')]
                    total = sum(L['price'] * L['count'] for L in sold)
                    got = int(total * (1 - commission.SETTLE_FEE))
                    send(0x06, 0x23, struct.pack('>H', commission.REG_OK))
                    if sold:
                        r = inv[0].add(GOLD, got)
                        if r is not None:
                            send(0x06, 0x06, build_putin(player.eid, r))
                        for L in sold:
                            lots.remove(L)
                        save_inv()
                        send(0x06, 0x20, commission.build_removed(commission.MODE_SOLD, [L['lot'] for L in sold]))
                    jot(f"     06/23 расчёт: {len(sold)} лотов на {total}, получено {got}")

                elif (cat, sub) == (0x06, 0x42) and player and COMMISSION:   # комиссионка: купить
                    pl = bytearray(f[6:])
                    jot(f"     06/42 покупка с комиссионки: {pl.hex()}")
                    iid = commission.find_lot(bytes(pl[4:]), loot.ITEMS)
                    it = loot.ITEMS.get(iid, {})
                    n = 10 if it.get('stack', 1) > 1 else 1
                    cost = commission.lot_price(it) * n if iid else 0
                    ok = bool(iid) and inv[0] is not None and inv[0].gold() >= cost \
                        and give_item(iid, n)
                    if ok:
                        give_item(GOLD, -cost, notice=False)
                        save_inv()
                    pl += bytes(max(0, 10 - len(pl)))
                    struct.pack_into('>H', pl, 8, commission.OK if ok else 0x225)
                    send(0x06, 0x42, bytes(pl))

                elif (cat, sub) == (0x06, 0x08) and player:        # переложить/обменять ячейки
                    # C->S (лог): +0 eid, +4 из контейнера, +5 из ячейки, +6 item BE32,
                    # +10 в контейнер, +11 в ячейку
                    pl = f[6:]
                    send(0x06, 0x08, pl)
                    if len(pl) >= 12 and inv[0]:
                        if inv[0].move(pl[4], pl[5], pl[10], pl[11]):
                            save_inv()
                            # эхо 06/08 у клиента правит только быстрые слоты — сами
                            # ячейки подтверждаем записями 06/06 (иначе вещь в сумку
                            # на 48 «не клалась»)
                            for c, sl in ((pl[10], pl[11]), (pl[4], pl[5])):
                                rr = inv[0].find(c, sl)
                                send(0x06, 0x06, build_putin(player.eid,
                                                             rr if rr is not None else empty_rec(c, sl)))
                        jot(f"     06/08 [{pl[4]}][{pl[5]}] -> [{pl[10]}][{pl[11]}]")

                elif (cat, sub) == (0x06, 0x39) and player:        # кэш-шоп: открыть / «Пополнить»
                    # Кнопка GXP (AMo пропатчен, tools/patch_amo_shop.py) и «Пополнить» шлют
                    # C 06/39; ответ S 06/39 открывает окно 16034 с балансом — караты (gxpshop.py).
                    # +12 u16: 2 — кнопка GXP (патч), 1 — «Отмена»/X в окне (окно уже закрыто)
                    pl = f[6:]
                    if len(pl) >= 14 and struct.unpack_from('>H', pl, 12)[0] == 2:
                        send(0x06, 0x39, gxpshop.build_open(player.eid, inv[0].gold() if inv[0] else 0))
                        jot(f"     06/39 магазин: {len(gxpshop.GOODS)} товаров, караты {inv[0].gold() if inv[0] else 0}")

                elif (cat, sub) == (0x06, 0x31) and player:        # кэш-шоп: купить за караты
                    pl = f[6:]
                    sid = gxpshop.parse_buy(pl)
                    g = gxpshop.GOODS.get(sid)
                    code = gxpshop.NOT_FOR_SALE
                    if g and inv[0]:
                        got = gxpshop.roll(g)
                        if inv[0].gold() < g['price']:
                            code = gxpshop.NO_MONEY
                        elif give_item(*got[0]):
                            for it, n in got[1:]:
                                if not give_item(it, n):
                                    jot(f"     магазин: не влезло {loot.item_name(it)} x{n}")
                            give_item(GOLD, -g['price'], notice=False)
                            save_inv()
                            code = gxpshop.OK
                            jot(f"     магазин: выдано {[(loot.item_name(i), n) for i, n in got]}")
                        else:
                            code = gxpshop.BAG_FULL
                    send(0x06, 0x31, gxpshop.build_buy(player.eid, sid, code,
                                                        inv[0].gold() if inv[0] else 0))
                    jot(f"     06/31 магазин: товар {sid} {g and g['name']} код {code:#x}; "
                        f"караты {inv[0].gold() if inv[0] else 0}; {pl.hex()}")

                elif (cat, sub) == (0x06, 0x16) and player:        # крафт у NPC (craft.py)
                    pl = f[6:]
                    rid = craft.find_recipe(pl, (8,))
                    npc_eid = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                    code = craft_make(rid) if rid else craft.ERROR
                    send(0x06, 0x16, craft.build_npc(player.eid, npc_eid, rid or 0, code))
                    jot(f"     06/16 крафт у NPC: рецепт {rid} код {code:#x}; {pl.hex()}")

                elif (cat, sub) == (0x06, 0x3f) and player:        # крафт своими силами
                    pl = f[6:]
                    rid = craft.find_recipe(pl, (12,))
                    a = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                    b = struct.unpack_from('>I', pl, 8)[0] if len(pl) >= 12 else 0
                    req = struct.unpack_from('>H', pl, 16)[0] if len(pl) >= 18 else craft.PC_START
                    jot(f"     06/3f крафт: рецепт {rid} запрос {req:#x}; {pl.hex()}")
                    if craft_job[0]:
                        craft_job[0].cancel()
                        craft_job[0] = None
                    if req == craft.PC_CANCEL:
                        send(0x06, 0x3f, craft.build_pc(player.eid, a, b, rid or 0, craft.PC_CANCEL))
                    else:
                        rec = craft.RECIPES.get(rid) if rid else None
                        code = craft.PC_START
                        if not rec or not inv[0]:
                            code = craft.ERROR
                        elif craft.missing(inv[0], rec):
                            code = craft.NO_MATS
                        elif inv[0].gold() < rec['cost']:
                            code = craft.NO_MONEY
                        send(0x06, 0x3f, craft.build_pc(player.eid, a, b, rid or 0, code))
                        if code == craft.PC_START:
                            def _finish(rid=rid, a=a, b=b):
                                with op_lock:
                                    if craft_job[0] is not threading.current_thread():
                                        return       # прервали, пока таймер ждал замка
                                    craft_job[0] = None
                                    c = craft_make(rid)
                                    send(0x06, 0x3f, craft.build_pc(
                                        player.eid, a, b, rid, craft.PC_OK if c == craft.OK else c))
                            t = threading.Timer(max(0.5, rec['time'] or 0.5), _finish)
                            t.daemon = True
                            craft_job[0] = t
                            t.start()

                elif (cat, sub) == (0x06, 0x56) and player:        # разборка предмета
                    pl = f[6:]
                    jot(f"     06/56 разборка: {pl.hex()}")
                    code, got, n = craft.DIS_CANT, 0, 0
                    cont, cell = (pl[4], pl[5]) if len(pl) >= 6 else (0, 0)
                    item = struct.unpack_from('>I', pl, 6)[0] if len(pl) >= 10 else 0
                    r = inv[0].find(cont, cell) if inv[0] else None
                    if r is not None and inv[0].item(r) == item:
                        info = loot.ITEMS.get(item, {})
                        rule = craft.dismantle_rule(item, info.get('kind'), info.get('lvl'))
                        if rule and inv[0].gold() < rule['cost']:
                            code = craft.DIS_MONEY
                        elif rule:
                            res = craft.dismantle_roll(rule)
                            # материал — до удаления вещи: нет места — вещь остаётся (раньше пропадала)
                            if res is None or give_item(res[0], res[1], notice=False):
                                inv[0].remove(cont, cell, item=item)
                                send(0x06, 0x06, build_putout(player.eid, cont, cell, item))
                                if rule['cost']:
                                    give_item(GOLD, -rule['cost'], notice=False)
                                code = craft.DIS_OK if res else craft.DIS_FAIL
                                if res:
                                    got, n = res
                            save_inv()
                            jot(f"     разборка {loot.item_name(item)} (правило {rule['id']}): "
                                f"{(loot.item_name(got), n) if got else 'неудача'}")
                    send(0x06, 0x56, craft.build_dismantle(player.eid, cont, cell, item, got, n, code))

                elif (cat, sub) == (0x06, 0x5a) and player and inv[0]:   # свиток трансформации
                    r = transform.parse(f[6:])
                    jot(f"     06/5a превращение: {f[6:].hex()}")
                    if r['code'] == transform.CANCEL:
                        send(0x06, 0x5a, transform.build(r, transform.CANCEL, form=0, item=0,
                                                         cont=0, cell=0))
                    elif r['item'] not in transform.SCROLLS:
                        send(0x06, 0x5a, transform.build(r, transform.NO_TARGET))
                    elif not r['form'] or r['form'] == r['item']:
                        # первый запрос из рюкзака — открыть окно выбора существа
                        send(0x06, 0x5a, transform.build(r, transform.OPEN, form=r['item']))
                    else:
                        fm = transform.check(r['form'], r['item'], player.level)
                        held = inv[0].find(r['cont'], r['cell'])
                        if not fm or held is None or Inventory.item(held) != r['item']:
                            send(0x06, 0x5a, transform.build(r, transform.NO_TARGET))
                            jot(f"     превращение {r['form']}: нельзя")
                        else:
                            rec, left = inv[0].use(r['item'], r['cell'], r['cont'])
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, r['cont'], r['cell'], r['item']))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            untransform('(новое)')
                            player.form = r['form']
                            send(0x06, 0x5a, transform.build(r, transform.USE))
                            send(0x08, 0x10, transform.build_char(player.eid, r['form']))
                            sk = fm.get('skill')                   # навык-баф существа (skill_effects)
                            if sk and getattr(player, 'buffs', None):
                                player.buffs.active[sk] = (1, time.time() + fm['secs'], {})
                                send(0x05, 0x09, buff_list([(sk, 1, fm['secs'])]))
                                restat()
                            t = threading.Timer(fm['secs'], untransform, args=('(время вышло)',))
                            t.daemon = True
                            tf_job[0] = t
                            t.start()
                            jot(f"     превращение {r['form']} в {fm['npc']} на {fm['secs']} с")

                elif (cat, sub) == (0x06, 0x47) and player and inv[0]:   # переработка в Дух воина
                    _e, cont, cell, item = craft.parse_recycle(f[6:])
                    jot(f"     06/47 переработка: {f[6:].hex()}")
                    rule = craft.RECYCLE.get(item)
                    r = inv[0].find(cont, cell)
                    code, got, n = craft.RC_NO_MAT, 0, 0
                    if rule and r is not None and inv[0].item(r) == item:
                        mats = rule['mats']
                        if mats and inv[0].count_item(mats[0][0]) < mats[0][1]:
                            code = craft.RC_NO_MAT
                        elif len(mats) > 1 and inv[0].count_item(mats[1][0]) < mats[1][1]:
                            code = craft.RC_NO_EXTRA
                        elif inv[0].gold() < rule['cost']:
                            code = craft.RC_MONEY
                        else:
                            inv[0].remove(cont, cell, item=item)
                            send(0x06, 0x06, build_putout(player.eid, cont, cell, item))
                            if give_item(rule['out'], rule['n'], notice=False):
                                take_items(mats, f"переработка {loot.item_name(item)}")
                                if rule['cost']:
                                    give_item(GOLD, -rule['cost'], notice=False)
                                code, got, n = craft.RC_OK, rule['out'], rule['n']
                            else:                                   # вернуть вещь
                                rec = inv[0].add(item, 1, stack=False, cont=cont)
                                if rec is not None:
                                    send(0x06, 0x06, build_putin(player.eid, rec))
                                code = craft.RC_FULL
                            save_inv()
                    send(0x06, 0x47, craft.build_recycle(player.eid, cont, cell, item, code, got, n))
                    jot(f"     переработка {loot.item_name(item)}: код {code:#x} -> {loot.item_name(got) if got else '-'} x{n}")

                elif cat == 0x10 and sub in (0x01, 0x02, 0x05) and player:   # почта (postbox.py)
                    pl = f[6:]
                    _pc = ACCOUNT.get(player.eid) or {}
                    mails = _pc.setdefault('mail', [])
                    jot(f"     {cat:02x}/{sub:02x} почта: {pl.hex()}")
                    if sub == 0x02:
                        send(0x10, 0x02, postbox.build_list(mails))
                    else:
                        mid = postbox.parse_id(pl)
                        m = next((x for x in mails if x['id'] == mid), None)
                        if m and sub == 0x01:
                            m['read'] = 1
                            send(0x10, 0x01, postbox.build_read(m))
                        elif m and sub == 0x05 and inv[0]:
                            left = []
                            for it, n in m['items']:
                                if not give_item(it, n):
                                    left.append([it, n])
                            if m['gold']:
                                give_item(GOLD, m['gold'])
                            if m.get('exp'):
                                gain_exp(m['exp'])
                            m['items'], m['gold'], m['exp'] = left, 0, 0
                            if not left:
                                mails.remove(m)
                            save_inv()
                            send(0x10, 0x08, postbox.build_taken(m))
                            jot(f"     письмо {mid}: вложения забраны, не влезло {left}")
                    ACCOUNT.save()
                    send(0x10, 0x04, postbox.build_count(mails))

                elif (cat, sub) == (0x05, 0x0e) and player:        # супер-навык: вложить флетту
                    _e, sid, pts, _x = superskill.parse_req(f[6:])
                    ent = super_entries()
                    have = getattr(player, 'fleta', 0)
                    res = None
                    if 0 < pts <= have and sid in superskill.group_skills(player.cls):
                        res = superskill.invest(ent, sid, pts)
                    if res is None:
                        cur = next((e[1] for e in ent if e[0] == sid), 0)
                        send(0x05, 0x0e, superskill.build_reply(player.eid, sid, pts, cur,
                                                                superskill.FAIL, superskill.SPENT))
                        jot(f"     05/0e супер-навык {sid}: отказ (очков {pts}, есть {have})")
                    else:
                        player.fleta = have - pts
                        send(0x05, 0x0e, superskill.build_reply(player.eid, sid, pts, res[0],
                                                                superskill.OK, res[1]))
                        send(0x05, 0x0c, superskill.build_list(player.eid, ent))
                        send(0x08, 0x01, build_hero_gage(player))
                        save_state()
                        if res[1] != superskill.SPENT:
                            restat()                     # пассивные супер-навыки -> 08/02
                        jot(f"     05/0e супер-навык {sid}: +{pts} флетты -> ур.{res[0]}, режим {res[1]}")

                elif (cat, sub) in ((0x05, 0x0d), (0x05, 0x0f)) and player and inv[0]:   # камни супер-навыка
                    pl = f[6:]
                    ent = super_entries()
                    jot(f"     {cat:02x}/{sub:02x} камень супер-навыка: {pl.hex()}")
                    if sub == 0x0d:
                        sid, stone, cont, cell = superskill.parse_equip(pl)
                        e = next((x for x in ent if x[0] == sid and x[1] > 0), None)
                        held = inv[0].find(cont, cell)
                        price = superskill.PRICE_REPLACE if e and e[2] else superskill.PRICE_APPLY
                        fits = superskill.stone_fits(stone, statcalc.skill_kind(sid) == statcalc.PASSIVE)
                        if e is None:
                            code = superskill.ERROR
                        elif fits is None or held is None or Inventory.item(held) != stone:
                            code = superskill.ONLY_STONE
                        elif not fits:
                            code = superskill.WRONG_STONE
                        elif inv[0].gold() < price:
                            code = superskill.ERROR
                        elif e[2] and not give_item(e[2], 1, notice=False):
                            code = superskill.BAG_FULL         # старый камень — в рюкзак
                        else:
                            code = superskill.REPLACED if e[2] else superskill.APPLIED
                            rec, left = inv[0].use(stone, cell, cont)
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, cont, cell, stone))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            give_item(GOLD, -price, notice=False)
                            e[2] = stone
                            save_inv()
                        send(0x05, 0x0d, superskill.build_equip(player.eid, sid, stone, cont, cell, code))
                    else:
                        sid = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                        e = next((x for x in ent if x[0] == sid and x[2]), None)
                        if e is None or inv[0].gold() < superskill.PRICE_REMOVE:
                            code = superskill.REMOVE_FAIL
                        elif not give_item(e[2], 1, notice=False):
                            code = superskill.BAG_FULL
                        else:
                            give_item(GOLD, -superskill.PRICE_REMOVE, notice=False)
                            e[2] = 0
                            code = superskill.REMOVED
                            save_inv()
                        send(0x05, 0x0f, superskill.build_putout(player.eid, sid, code))
                    if code in (superskill.APPLIED, superskill.REPLACED, superskill.REMOVED):
                        send(0x05, 0x0c, superskill.build_list(player.eid, ent))
                        save_state()
                        restat()
                    jot(f"     камень супер-навыка: код {code:#x}")

                elif (cat, sub) == (0x06, 0x5d) and player and inv[0]:   # смена супер-навыка (купон)
                    a, b, cont, cell = superskill.parse_change(f[6:])
                    held = inv[0].find(cont, cell)
                    coupon = Inventory.item(held) if held is not None else 0
                    ent = super_entries()
                    if loot.ITEMS.get(coupon, {}).get('cat') != superskill.COUPON_CAT:
                        code = superskill.CH_ERROR
                    else:
                        code = superskill.change(ent, player.cls, a, b)
                    if code == superskill.CH_OK:
                        rec, left = inv[0].use(coupon, cell, cont)
                        if left == 0:
                            send(0x06, 0x06, build_putout(player.eid, cont, cell, coupon))
                        elif rec is not None:
                            send(0x06, 0x06, build_putin(player.eid, rec))
                        save_inv()
                    send(0x06, 0x5d, superskill.build_change(a, b, cont, cell, code))
                    if code == superskill.CH_OK:
                        send(0x05, 0x0c, superskill.build_list(player.eid, ent))
                        save_state()
                        restat()
                    jot(f"     06/5d смена супер-навыка {a} -> {b}: код {code:#x}; {f[6:].hex()}")

                elif cat == 0x0a and sub in (0x0a, 0x0b, 0x0d) and player:   # дневник событий
                    _pc = ACCOUNT.get(player.eid)
                    if _pc is None:
                        _pc = {}
                    att = _pc.setdefault('attend', {})
                    diary = _pc.setdefault('diary', {'done': [], 'claimed': []})
                    if sub == 0x0a:                          # открыть: календарь и задания
                        send(0x0a, 0x0a, eventdiary.build_open(att))
                        send(0x0a, 0x0c, eventdiary.build_list(diary))
                    elif sub == 0x0b:                        # отметиться сегодня -> награды почтой
                        got = postbox.attend(att)
                        if got:
                            eventdiary.mark_day(att)
                            for _a in got:
                                _pc.setdefault('mail', []).append(postbox.attend_mail(_a))
                                jot(f"     посещение: {_a['text'][:40]} -> почта")
                            send(0x0a, 0x0b, eventdiary.build_attend(att))
                            send(0x10, 0x04, postbox.build_count(_pc.get('mail', [])))
                        ACCOUNT.save()
                    else:                                    # задание: выполнено / забрать награду
                        mid, state = eventdiary.parse_progress(f[6:])
                        jot(f"     0a/0d задание {mid} -> {state}; {f[6:].hex()}")
                        if mid in eventdiary.MISSIONS and mid not in diary['claimed']:
                            if state == eventdiary.DONE and mid not in diary['done']:
                                diary['done'].append(mid)
                                send(0x0a, 0x0c, eventdiary.build_list(diary))
                                send(0x0a, 0x0d, eventdiary.build_progress(mid, eventdiary.DONE))
                            elif state == eventdiary.CLAIM and mid in diary['done'] and inv[0]:
                                r = postbox.REWARDS.get(mid, {})
                                for it, n in r.get('items', []):
                                    if not give_item(it, n):
                                        _pc.setdefault('mail', []).append(postbox.new_mail(
                                            'Награда дневника', 'Не поместилось в рюкзак.', [(it, n)]))
                                if r.get('gold'):
                                    give_item(GOLD, r['gold'])
                                if r.get('exp'):
                                    gain_exp(r['exp'])
                                diary['done'].remove(mid)
                                diary['claimed'].append(mid)
                                save_inv()
                                send(0x0a, 0x0c, eventdiary.build_list(diary))
                                send(0x0a, 0x0d, eventdiary.build_progress(mid, eventdiary.CLAIM))
                                jot(f"     награда дневника {mid}: {r}")
                        ACCOUNT.save()

                elif (cat, sub) == (0x06, 0x09) and player and inv[0]:   # объединить стопки
                    # C 06/09 (сборщик 0x004c1f56): +0 eid, +4 запись-источник (147 байт: сумка,
                    # ячейка, предмет …, +16 кол-во), +151 запись-цель, +298 u16. Genesis отвечает эхом.
                    pl = bytes(f[6:])
                    if len(pl) >= 4 + 147 * 2:
                        a_c, a_s, b_c, b_s = pl[4], pl[5], pl[151], pl[152]
                        ra, rb = inv[0].find(a_c, a_s), inv[0].find(b_c, b_s)
                        if ra is not None and rb is not None and ra is not rb                                 and Inventory.item(ra) == Inventory.item(rb):
                            item = Inventory.item(ra)
                            cap = max(1, loot.ITEMS.get(item, {}).get('stack', 1))
                            na, nb = Inventory.count32(ra) or 1, Inventory.count32(rb) or 1
                            moved = max(0, min(na, cap - nb))
                            if moved:
                                struct.pack_into('<I', rb, 16, nb + moved)
                                if moved >= na:
                                    inv[0].recs.remove(ra)
                                    send(0x06, 0x06, build_putout(player.eid, a_c, a_s, item))
                                else:
                                    struct.pack_into('<I', ra, 16, na - moved)
                                    send(0x06, 0x06, build_putin(player.eid, bytearray(ra)))
                                send(0x06, 0x06, build_putin(player.eid, bytearray(rb)))
                                save_inv()
                            jot(f"     06/09 стопки {loot.item_name(item)}: {na}+{nb} -> перенесено {moved}")
                    send(0x06, 0x09, pl)

                elif (cat, sub) == (0x06, 0x19) and player and inv[0]:   # вставить череп/руну/камень
                    # C 06/19 (окно CGuiCompound): +0 eid, +4/+8/+12 сумка, ячейка, предмет вставки
                    # (u32), +16/+20/+24 сумка, ячейка, вещь, +28 u32, +32 u16 0x7d. Ответ (0x00655bc6) —
                    # эхо с кодом: 0x7d успех, 0x7e недопустимая комбинация, 0x76 больше нельзя,
                    # 0x77 не для этой вещи, 0xa9 мал уровень. Вставки — запись вещи +24..+44 (6 × u32),
                    # у игроков оригинала: оружие и броня — до 4, аксессуары — до 2 (слепок комиссионки);
                    # оружие — черепа и камни, броня — руны и камни, аксессуары — камни (itemCombAttr).
                    pl = bytearray(f[6:]) + bytearray(max(0, 34 - len(f[6:])))
                    mc, ms, mi, tc, ts, ti = struct.unpack_from('>6I', pl, 4)
                    mat, gear = inv[0].find(mc, ms), inv[0].find(tc, ts)
                    sock = itemroll.SOCKETS.get(mi)
                    gi = loot.ITEMS.get(ti, {})
                    allow = {1: (2, 1), 2: (3, 1), 3: (1,)}.get(gi.get('cat'), ())
                    limit = {1: 4, 2: 4, 3: 2}.get(gi.get('cat'), 0)
                    code = 0x7e
                    if mat is None or gear is None or Inventory.item(mat) != mi or Inventory.item(gear) != ti or not sock:
                        code = 0x7e
                    elif sock[0] not in allow:
                        code = 0x77
                    elif player.level < loot.ITEMS.get(mi, {}).get('lvl', 0):
                        code = 0xa9
                    else:
                        slots = list(struct.unpack_from('<6I', gear, itemroll.GEM_OFF))
                        used = sum(1 for g in slots if g)
                        if used >= limit:
                            code = 0x76
                        else:
                            i = slots.index(0)
                            struct.pack_into('<I', gear, itemroll.GEM_OFF + 4 * i, mi)
                            rec, left = inv[0].use(mi, ms, mc)
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, mc, ms, mi))
                            elif rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            send(0x06, 0x06, build_putin(player.eid, bytearray(gear)))
                            save_inv()
                            code = 0x7d
                            if tc == 0:
                                restat()
                    struct.pack_into('>H', pl, 32, code)
                    send(0x06, 0x19, bytes(pl[:34]))
                    jot(f"     06/19 вставка {loot.item_name(mi)} -> {loot.item_name(ti)}: код {code:#x}")

                elif (cat, sub) == (0x06, 0x0d) and player:        # покупка у торговца
                    # C->S: +0 eid, +4 eid торговца, +8 item BE32, +12 код BE16, +14 кол-во
                    # (8 байт, FF..FF = 1). Ответ (обработчик 0x00653ae0): та же раскладка,
                    # код 0x2C — «Вы приобрели …»; прочие коды -> сообщение об ошибке (эхо
                    # с 0x09 давало «Отсутствует предмет», хотя предмет выдавался).
                    pl = bytearray(f[6:])
                    jot(f"     06/0d покупка: {pl.hex()}")
                    ok = False
                    if len(pl) >= 14 and inv[0]:
                        item = struct.unpack_from('>I', pl, 8)[0]
                        raw = struct.unpack_from('>q', pl, 14)[0] if len(pl) >= 22 else -1
                        n = raw if 0 < raw <= 1000 else 1     # пули продаются и по 1000 (целая стопка)
                        cost = loot.ITEMS.get(item, {}).get('price', 0) * n
                        if inv[0].gold() >= cost and give_item(item, n, notice=False):
                            if cost:
                                give_item(GOLD, -cost, notice=False)
                            save_inv()
                            ok = True
                            jot(f"     куплено {item} x{n} за {cost}; золото {inv[0].gold()}")
                    pl += bytes(max(0, 22 - len(pl)))
                    struct.pack_into('>H', pl, 12, 0x2C if ok else 0x0A)
                    send(0x06, 0x0d, bytes(pl))

                elif (cat, sub) in ((0x06, 0x1a), (0x06, 0x1b), (0x06, 0x29), (0x06, 0x2a),
                                    (0x06, 0x1c), (0x06, 0x2b), (0x06, 0x2e), (0x06, 0x1d),
                                    (0x06, 0x2c), (0x06, 0x2d)) and player:
                    # хранилище (server/stash.py): 1a/1b/1c/1d/2c/2e — личное, 29/2a/2b/2d — общее
                    pl = f[6:]
                    jot(f"     {cat:02x}/{sub:02x} хранилище: {pl.hex()}")
                    _pc = ACCOUNT.get(player.eid)
                    if _pc is None or not inv[0]:
                        send(cat, sub, pl)
                        continue
                    acc = sub in (0x29, 0x2a, 0x2b, 0x2d)
                    srecs = stash.load(ACCOUNT.stash if acc else _pc.get('stash'), inventory.DURABILITY)
                    level = int(_pc.get('stash_level', 0))
                    cap = stash.ACCOUNT_CAP if acc else stash.capacity(level)
                    if stash.legacy(ACCOUNT.stash if acc else _pc.get('stash')):
                        if acc:                                       # старый формат [item, кол-во]
                            ACCOUNT.stash = stash.dump(srecs)          # -> полные записи (uid один раз)
                        else:
                            _pc['stash'] = stash.dump(srecs)
                        save_inv()

                    def _store():
                        if acc:
                            ACCOUNT.stash = stash.dump(srecs)
                        else:
                            _pc['stash'] = stash.dump(srecs)
                        save_inv()

                    def _stackable(it):
                        return it == GOLD or loot.ITEMS.get(it, {}).get('stack', 1) > 1

                    if sub == 0x2e:                                   # уровни (разговор с NPC)
                        npc = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                        send(0x06, 0x2e, stash.build_levels(player.eid, npc, level))
                    elif sub in (0x1c, 0x2b):                         # список
                        if sub == 0x1c:
                            send(0x06, 0x1c, stash.build_list(player.eid, srecs, level, cap,
                                                              with_items=False))
                        send(cat, sub, stash.build_list(player.eid, srecs, level, cap, account=acc))
                        jot(f"     список хранилища: {len(srecs)} вещей, вместимость {cap}")
                    elif sub == 0x1d:                                 # расширение
                        npc = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                        price = stash.EXTEND_PRICE.get(level)
                        if price is None:
                            code = stash.IGNORE
                        elif inv[0].gold() < price:
                            code = stash.NO_MONEY
                        else:
                            r = inv[0].add(GOLD, -price)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            level += 1
                            _pc['stash_level'] = level
                            save_inv()
                            code = stash.OK
                        send(0x06, 0x1d, stash.build_extend(player.eid, npc, code, level))
                        jot(f"     расширение хранилища: код {code:#x}, уровень {level}")
                    elif sub in (0x1a, 0x29):                         # положить
                        npc, cont, cell, item, n, sslot = stash.parse_put(pl)
                        fee = stash.FEE_ACCOUNT if acc else stash.FEE_PERSONAL
                        loc = inv[0].locate(cont, cell, item)
                        src = inv[0].find(*loc) if loc else None
                        have = inv[0].count32(src) if src is not None else 0
                        n = max(1, min(n or 1, have or 1))
                        cur = srecs.get(sslot)
                        code = stash.OK
                        if src is None or loc[0] == inventory.EQUIP:
                            code = stash.IGNORE
                        elif inv[0].gold() < fee + (n if item == GOLD else 0):
                            code = stash.NO_MONEY
                        elif not (0 <= sslot < cap) or (cur is not None and (
                                stash.item_of(cur) != item or not _stackable(item))):
                            code = stash.IGNORE
                        if code == stash.OK:
                            copy = bytearray(src)
                            rest, got, k = inv[0].remove(loc[0], loc[1], n, item)
                            stash.put(srecs, sslot, copy, k, cap, _stackable(item))
                            if rest is not None:
                                send(0x06, 0x06, build_putin(player.eid, rest))
                            else:
                                send(0x06, 0x06, build_putout(player.eid, loc[0], loc[1], got))
                            r = inv[0].add(GOLD, -fee)
                            if r is not None:
                                send(0x06, 0x06, build_putin(player.eid, r))
                            _store()
                            jot(f"     в хранилище [{sslot}] {loot.item_name(item)} x{k}, плата {fee}")
                        send(cat, sub, stash.with_code(pl, 32, code, 34))
                    elif sub in (0x1b, 0x2a):                         # забрать
                        sslot, n = stash.parse_take(pl)
                        cur = srecs.get(sslot)
                        code = stash.IGNORE
                        if cur is not None:
                            it = stash.item_of(cur)
                            gear = loot.ITEMS.get(it, {}).get('kind') == 1
                            have = stash.count_of(cur) or 1
                            got = bytearray(cur)                       # проба: место в сумке есть?
                            stash.set_count(got, have if n is None else max(1, min(have, n)))
                            r = inv[0].put_stack(got, _stackable(it),
                                                 inv[0].gear_container() if gear else inventory.BAG)
                            if r is not None:
                                stash.take(srecs, sslot, n)
                                for r_ in r:
                                    send(0x06, 0x06, build_putin(player.eid, r_))
                                _store()
                                code = stash.OK
                                jot(f"     из хранилища [{sslot}] {loot.item_name(it)} x{stash.count_of(got)}")
                            else:
                                sys_msg('Нет места в сумке.')
                        send(cat, sub, stash.with_code(pl, 20, code, 22))
                    elif sub in (0x2c, 0x2d):                         # переложить внутри хранилища
                        a_, b_ = stash.parse_swap(pl)
                        ok = stash.swap(srecs, a_, b_, cap)
                        if ok:
                            _store()
                        code = (stash.ACC_SWAP_OK if acc else stash.SWAP_OK) if ok else stash.IGNORE
                        send(cat, sub, stash.with_code(pl, 44, code, 46))
                        jot(f"     хранилище: {a_} -> {b_}: {'ok' if ok else 'нет'}")

                elif (cat, sub) == (0x04, 0x07) and player:        # телепорт у NPC
                    # C->S (лог): +0 u32 1, +4 точка mapWarpTargetPos BE32,
                    # +8 eid телепортёра, +12 код BE16 0x123 (ответ — эхо)
                    pl = f[6:]
                    tid = struct.unpack_from('>I', pl, 4)[0] if len(pl) >= 8 else 0
                    price = WARPS.get('prices', {}).get(str(tid), 0)
                    jot(f"     04/07 телепорт {tid}, цена {price}: {pl.hex()}")
                    send(0x04, 0x07, pl)
                    if coral_gate(tid):
                        if inv[0] and price and inv[0].gold() >= price:
                            give_item(GOLD, -price, notice=False)
                            save_inv()
                        do_warp(tid)

                elif (cat, sub) == (0x06, 0x02):                  # использовать предмет
                    pl = f[6:]
                    jot(f"     06/02 запрос: {pl.hex()}")
                    consumables.init()
                    _it6 = struct.unpack_from('>I', pl, 6)[0] if len(pl) >= 10 else None
                    item, at = find_potion(pl)
                    if _it6 in consumables.HEAL or _it6 in consumables.HOT:
                        item = None
                    if player and inv[0] and _it6 in consumables.HEAL:
                        rec, left = inv[0].use(_it6, pl[5], pl[4])
                        if rec is not None:
                            hp_, mp_ = consumables.HEAL[_it6]
                            player.hp = min(player.maxhp, player.hp + hp_)
                            player.mp = min(player.maxmp, player.mp + mp_)
                            send(0x06, 0x02, build_item_use(player.eid, _it6))
                            send(0x08, 0x00, build_player_hp(G0800, player))
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], _it6))
                            else:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            jot(f"     зелье {_it6}: +{hp_} HP +{mp_} MP -> {player.hp}/{player.maxhp}, "
                                f"{player.mp}/{player.maxmp}")
                        else:
                            send(0x06, 0x02, pl)
                    elif player and inv[0] and _it6 in consumables.HOT:
                        rec, left = inv[0].use(_it6, pl[5], pl[4])
                        if rec is not None:
                            what, amt, pct, step, dur = consumables.HOT[_it6]
                            now_ = time.time()
                            hot_state[_it6] = [what, amt, pct, step, now_ + dur, now_ + step]
                            send(0x06, 0x02, build_item_use(player.eid, _it6))
                            send(0x05, 0x09, buff_list([(_it6, 1, dur)]))
                            if left == 0:
                                send(0x06, 0x06, build_putout(player.eid, pl[4], pl[5], _it6))
                            else:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            jot(f"     восстановление {_it6}: {what} {amt}{'%' if pct else ''} каждые {step} с, {dur} с")
                        else:
                            send(0x06, 0x02, pl)
                    elif item and player:
                        kind, amount = POTIONS[item]
                        if kind == 'hp':
                            player.hp = min(player.maxhp, player.hp + amount)
                        else:
                            player.mp = min(player.maxmp, player.mp + amount)
                        jot(f"     зелье {item} (найдено @{at}): {kind} +{amount} -> "
                            f"HP {player.hp}/{player.maxhp} MP {player.mp}/{player.maxmp}")
                        send(0x06, 0x02, build_item_use(player.eid, item))
                        send(0x08, 0x00, build_player_hp(G0800, player))
                        # запрос: +8 контейнер, +9 ячейка; число в сумке — через 06/06
                        if inv[0]:
                            cell = pl[9] if len(pl) > 9 else None
                            rec, left = inv[0].use(item, cell, pl[8] if len(pl) > 8 else None)
                            if rec is not None:
                                send(0x06, 0x06, build_putin(player.eid, rec))
                                save_inv()
                                jot(f"     {item}: осталось {left}")
                    elif player and inv[0] and use_special(pl):
                        pass
                    else:
                        send(0x06, 0x02, pl)     # неизвестный предмет — как раньше, эхо
                        if len(pl) >= 10:
                            jot(f"     06/02 предмет не поддержан: {struct.unpack_from('>I', pl, 6)[0]}")

                elif (cat, sub) == (0x03, 0x00) and player:        # чат
                    # C 03/00 (сборщик 0x0056accf) и S 03/00 (0x0064cda9) одной раскладки: +0 eid,
                    # +4 канал BE32, +8 u8, имя\0, текст\0. Клиент своё сообщение сам не выводит —
                    # показывает только пришедшее от сервера (и облачко над говорящим), поэтому
                    # без ответа реплики игрока в чате не появлялись. Отвечаем тем же от персонажа.
                    pl = bytes(f[6:])
                    if len(pl) >= 10:
                        parts = pl[9:].split(b'\0')
                        text = parts[1] if len(parts) > 1 else b''
                        if text:
                            send(0x03, 0x00, struct.pack('>I', player.eid) + pl[4:9]
                                 + player.name.encode('utf-8') + b'\0' + text + b'\0')
                            jot(f"     чат (канал {struct.unpack_from('>I', pl, 4)[0]}): "
                                f"{text.decode('utf-8', 'replace')[:80]}")

                elif (cat, sub) == (0x0b, 0x00):                  # heartbeat
                    send(0x0b, 0x00, f[6:])

                elif (cat, sub) == (0x08, 0x09):                  # автоохота: настройки
                    # 08/09 CCharInfoHelpHuntSetting: +0 eid, +4 флаги (01 01 01 … — включена).
                    # Оригинал (orig_1): при включении — 08/0a CCharInfoHelpHuntGage (+0 eid, +4 осталось
                    # BE, +8 максимум BE: 55000 / 110000) и эхо; при выключении — 08/0f 00000000 и эхо.
                    # Клиент (0x00659ddc) при остатке < 1 выключает автоохоту — без 08/0a автобой
                    # не работал. Локально шкала всегда полная.
                    _hp9 = f[6:]
                    if len(_hp9) >= 5 and _hp9[4] == 1 and player:
                        send(0x08, 0x0a, struct.pack('>III', player.eid, HUNT_GAGE, HUNT_GAGE))
                        jot("     автоохота включена")
                    else:
                        t80f = WTPL.get((0x08, 0x0f))
                        if t80f:
                            send(0x08, 0x0f, t80f)
                    send(0x08, 0x09, _hp9)

                elif cat == 0x13 and sub in (0x00, 0x01, 0x02) and player:      # событийные подземелья EID
                    purge_passes_live()                  # истёкший билет во вход не годится
                    if sub == 0x00:                      # окно событий у Аски: список по уровню
                        send(0x13, 0x00, eidmod.list_for(player.level))
                    elif len(f) >= 12:
                        _code, _ev = struct.unpack_from('>HI', f, 6)
                        _tk = inv[0].count_item(eidmod.EVENTS.get(_ev, {}).get('ticket', 0)) if inv[0] else 0
                        _ok = eidmod.check(_ev, player.level, _tk, DEV.get('eid_anytime'))
                        if sub == 0x01:                  # заявка: отряд из одного — сразу «жребий выигран»
                            send(0x13, 0x01, eidmod.body(_ok, _ev))
                            if _ok == eidmod.OK_FORMED:
                                eid_state['pending'] = _ev
                                send(0x13, 0x01, eidmod.body(eidmod.OK_WON, _ev))
                            jot(f"     EID заявка {_ev}: код {_ok:#x}")
                        elif _ok != eidmod.OK_FORMED:    # уровень / билет / время — код как на заявку
                            send(0x13, 0x02, eidmod.body(_ok, _ev))
                            jot(f"     EID вход {_ev}: отказ, код {_ok:#x}")
                        else:                            # вход: билет списан, перенос к точке команды 1
                            # одиночная игра: заявка (13/01) не обязательна — «Войти» сразу, если
                            # проходят уровень, билет и время (раньше без заявки — 0x210 «нельзя войти»)
                            _tid = eidmod.EVENTS[_ev].get('ticket')
                            for cont, cell, rec in (inv[0].take_item(_tid, 1) if _tid else []):
                                if rec is None:
                                    send(0x06, 0x06, build_putout(player.eid, cont, cell, _tid))
                                else:
                                    send(0x06, 0x06, build_putin(player.eid, rec))
                            save_inv()
                            send(0x13, 0x02, eidmod.body(eidmod.OK_ENTER, _ev))
                            eid_state['pending'] = None
                            eid_state['run'] = eidmod.Run(_ev)
                            jot(f"     EID вход {_ev}: билет списан, перенос")
                            do_warp(eid_state['run'].entry_target())

                elif (cat, sub) == (0x0a, 0x01) and player and len(f) >= 14:   # триггер подземелья
                    _mid, _tid = struct.unpack_from('>II', f, 6)
                    _dg = getattr(world, 'dungeon', None) if world else None
                    if _dg is None or _mid != _dg.map_id:
                        send(cat, sub, f[6:])            # не подземелье — эхо, как раньше
                    else:
                        _ok, _b, _a = _dg.trigger(_tid, player.x, player.y, player.z)
                        jot(f"     триггер подземелья {_tid}: {'да' if _ok else 'закрыт (этап не пройден)'}")
                        if _ok:
                            send(cat, sub, f[6:])        # оригинал: эхо, затем события
                            dungeon_apply(_b, _a)

                elif (cat, sub) == (0x06, 0x51) and player:      # кнопка «сортировка» сумки (CItemAutoSortPacket)
                    # C: +0 eid, +4 u32 n, +8 u16 0x22a, n × (сумка, ячейка) — что клиент считает сдвинутым;
                    # раскладку считает сервер. Ответ — первым: он снимает ожидание клиента (0x0061b196),
                    # а пока оно стоит, 06/06 не обновляет быстрые слоты. Раньше было только эхо.
                    send(0x06, 0x51, f[6:])
                    if inv[0]:
                        _r51 = bag_sort()
                        if _r51.get('error'):
                            sys_msg('Сортировка: ' + _r51['error'] + '.')

                elif (cat, sub) in ((0x08, 0x12), (0x06, 0x5c), (0x05, 0x04)):
                    send(cat, sub, f[6:])            # оригинал отвечает эхом

                elif (cat, sub) == (0x16, 0x01) and player:        # GXP / VIP-статус
                    # C->S 4 байта (00000001) при открытии GXP-окна; оригинал отвечает тем же
                    # 28-байтным пакетом, что и при входе (+4 ранг, +12 очки, +16/+20/+24
                    # пороги). Вылет при нажатии на магазин был не отсюда, а в заглушке №7
                    # weberforclntv2.dll (стек; см. tools/patch_weber.py).
                    send(0x16, 0x01, raw_of(player, '16/01') or WTPL.get((0x16, 0x01))
                         or bytes.fromhex('00000001000000000000000000000000650000002900'
                                          '00003b000000'))

                elif (cat, sub) == (0x02, 0x01):                  # ВЫХОД В МЕНЮ
                    # оригинал: 02/0b (второй пароль), затем карточки (дамп play1)
                    ai_stop[0].set()
                    save_state()                 # позиция/уровень — и при выходе в меню
                    if '020b' in GAME:
                        send(0x02, 0x0b, bytes.fromhex(GAME['020b']))
                    send_cards(send)
                    jot("     выход в меню выбора персонажа")

                else:
                    jot(f"     !!! НЕ ОБРАБОТАН {cat:#04x}/{sub:#04x}")
                    send(cat, sub, f[6:])  # <-- ФИКС: заглушка, чтобы клиент не застревал в T-позе
    except (ConnectionResetError, BrokenPipeError):
        pass
    finally:
        try:
            save_state()             # координаты и состояние — при любом выходе
        except Exception as e:
            print(f"     !!! сохранение при выходе: {e!r}", flush=True)
        ai_stop[0].set()
        if player:
            devtools.unregister(player.eid)
        op_lock.release()
        conn.close()
        print(f"[-] {addr[0]}:{addr[1]} ({stage})", flush=True)


def listen_on(port):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    opt = getattr(socket, 'SO_EXCLUSIVEADDRUSE', socket.SO_REUSEADDR)
    srv.setsockopt(socket.SOL_SOCKET, opt, 1)
    try:
        srv.bind(('0.0.0.0', port)); srv.listen(5)
    except OSError as e:
        print(f"порт {port}: {e}", flush=True); return
    print(f"слушаю {port}", flush=True)
    while True:
        try:
            conn, addr = srv.accept()
        except OSError:
            break
        threading.Thread(target=handle, args=(conn, addr, port), daemon=True).start()


def main():
    ports = [int(x) for x in sys.argv[1:]] or [10001, 10110, 10101]
    st = CONTENT.stats()
    print(f"КОНТЕНТ: {st['total_spawns']} спавнов, {st['npc_types']} типов NPC, "
          f"{st['maps']} карт, {st['warps']} варпов\n")
    for p in ports:
        threading.Thread(target=listen_on, args=(p,), daemon=True).start()
    devtools.WARPS[:] = sorted(
        ({'id': int(k), 'name': t['name'], 'map': t['map'], 'map_name': MAP_NAMES.get(t['map'], '')}
         for k, t in WARPS['targets'].items() if t.get('map') in MAP_NAMES and t.get('name')),
        key=lambda w: (w['map'], w['name']))
    devtools.ACCOUNTS = {'list': account_ids, 'get': lambda: ACCOUNT.id, 'set': set_account}
    devtools.serve(int(os.environ.get('KAROS_DEVPORT', devtools.PORT)))
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nостановлен")


def _preload():
    """Разбор описаний предметов (зелья, бафы, камни души) заранее — иначе первое применение
    предмета ждало ~2 с (тестовый клиент успевал отключиться)."""
    try:
        consumables.init()
        soulstone.init()
        buffs._item_descs()
        buffs.info()
    except Exception as e:          # не мешаем запуску
        print('предзагрузка:', e, flush=True)


if __name__ == '__main__':
    threading.Thread(target=_preload, daemon=True).start()
    main()
