"""Бафы (навыки на себя / отряд с длительностью).

Клиент: 05/09 CAttackSkillBuffListPacket (обработчик 0x006618ff, разбор 0x00660012):
  payload +0 тип сущности (0 игрок), +1 eid BE32, +5 режим (0 — снять, 1 — наложить),
          +6 число записей BE16, затем записи по 18 байт:
          id навыка BE32, уровень u8, уровень наложившего u8, предмет-источник BE32 (0 — навык),
          оставшееся время BE32 (сек; 0 — бессрочно), ? BE32.
  Записи оригинала (remain3, паладин ANGEL ур.60): 3005 05 3c 00000000 00000000 — аура;
  3902 05 3c 00000000 00000258 — 600 с; бафы предметов — номер предмета в поле источника.
  Наложение (FUN_005d7d16): иконка бафа + эффект; если присланное время равно полной
  длительности из skillLevel (double +140), проигрывается эффект наложения. Иконка берётся
  по предмету-источнику, если он задан, — раньше там был eid персонажа, и у бафов-навыков
  значков не было.
Ауры (вид 25, длительность +140 = 0 — 3005, 3903, 3904, 3905): бессрочные (в 05/09 остаток 0);
  их эффект — у навыка id×100+1 (3005 -> 300501), который оригинал «пульсирует» с периодом
  skillLevel +148 (3 с; у 3908 — 4 с): 05/09 снять + наложить с остатком 4 (запись remain3:
  300501 в 55.3, 58.6, 61.8, 64.9 с). У 3903 такого навыка нет — в оригинале 08/02 после неё
  не меняется (аура защиты статов не дала).

skillLevel.lod (режим 0): записи переменной длины, u32 id, u32 уровень, 0, 1, …
  +140 double — длительность (сек), текст описания — последняя длинная строка.
Числа силы бафа в skillLevel нет (их считал сервер оригинала) — прибавку выводим
из описания: атака / защита / скорость атаки / скорость бега, с ростом от уровня.
"""
import os, re, struct, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'skillLevel.lod_rus')

# базовые прибавки (доля) на 1 уровне навыка; +10% от базы за каждый следующий уровень
AURA_SECONDS = 600                 # аура без вида в таблицах (только описание) — держим 10 минут
FOREVER = float('inf')             # бессрочная аура: истекает «никогда», в 05/09 — остаток 0
AURA = 25
BASE = {'atk': 0.10, 'def': 0.15, 'aspd': 0.15, 'move': 0.20}
_INFO = None


def _load():
    from lod_decode import decode
    L = decode(open(SRC, 'rb').read(), 0)
    starts, p = [], 8
    while p < len(L) - 260:
        sid, lv, z, one = struct.unpack_from('<4I', L, p)
        # навыки существ (облики трансформации 81xxx, 94000xxx) — с 0 на +12
        creature = (80000 <= sid <= 99999 or 94000000 <= sid <= 94999999) and one == 0             and struct.unpack_from('<d', L, p + 164)[0] == 1.0
        # у части навыков классов +12 == 0, +8 — требуемый уровень (6806, 6811, 16002…): по метке +248
        marked = one == 0 and z <= 200 and 1000 <= sid <= 40000             and struct.unpack_from('<I', L, p + 248)[0] == 0x40590000
        if 1 <= lv <= 60 and ((z == 0 and ((1000 <= sid <= 99999 and one == 1) or creature)) or marked):
            starts.append((p, sid, lv))
            p += 300
            continue
        p += 1
    info = {}
    for i, (p, sid, lv) in enumerate(starts):
        r = L[p:starts[i + 1][0] if i + 1 < len(starts) else len(L)]
        dur = struct.unpack_from('<d', r, 140)[0]
        per = struct.unpack_from('<d', r, 148)[0] if len(r) >= 156 else 0.0
        texts = re.findall(rb'[\x20-\xff]{12,}', r)
        desc = texts[-1].decode('cp1251', 'replace') if texts else ''
        info[(sid, lv)] = (dur, desc, per if 0 < per < 60 else 0.0)
    return info


def period(sid, lv):
    """Период «пульса» ауры (skillLevel +148, с) или 0."""
    rec = info().get((sid, lv)) or info().get((sid, 1))
    return rec[2] if rec and len(rec) > 2 else 0.0


def pulse_child(sid, lv):
    """Навык-эффект ауры (id×100+1), который шлётся пульсом, или None."""
    try:
        import statcalc
    except ImportError:
        return None
    child = sid * 100 + 1
    if period(sid, lv) and statcalc.skill_fx(child, lv):
        return child
    return None


def info():
    global _INFO
    if _INFO is None:
        try:
            _INFO = _load()
        except OSError:
            _INFO = {}
    return _INFO


def effects(desc):
    """Описание -> {'atk'|'def'|'aspd'|'move': знак}. Пусто — не баф."""
    d = desc.lower()
    if re.search(r'врага|противник|враж', d) and not re.search(r'снимая враж', d):
        return {}                                   # дебаф на цель
    up = re.search(r'повыш|увелич|ускор|освящ|усилен|благослов', d)
    if not up:
        return {}
    e = {}
    if 'скорост' in d and 'атак' in d:
        e['aspd'] = 1
    if 'скорост' in d and re.search(r'движ|передвиж', d):
        e['move'] = -1 if re.search(r'(замедл|сниж|уменьш)[а-я]*\s+(скорост|движ)|скорост[а-я]*\s+движ[а-я]*\s+(сниж|уменьш)', d) else 1
    if re.search(r'сил[аыу]?\s+(физической\s+|магической\s+)?атак|усилени[ея]\s+атак|атаки\s+увелич|сила\s+атаки', d):
        e['atk'] = 1
    if 'защит' in d:
        e['def'] = -1 if re.search(r'ослабл[а-я]* защит', d) else 1
    return e


def lookup(sid, lv):
    """-> (длительность, {эффект: доля}) или None, если навык — не баф.
    Сила бафа — эффекты навыка из таблиц клиента (statcalc: skillLevel +264 -> skillData);
    разбор описания ниже — только запасной путь для навыков без эффектов в таблице."""
    rec = info().get((sid, lv)) or info().get((sid, 1))
    try:
        import statcalc
        k = statcalc.skill_kind(sid)
        if k == AURA:                   # аура: срок из +140 (0 — бессрочно), эффект — только у id×100+1
            dur = rec[0] if rec else 0
            return (dur if dur and dur > 0 else 0), {}
        if k == 23 and statcalc.skill_fx(sid, lv):
            dur = rec[0] if rec else 0
            return (dur if dur and dur > 0 else AURA_SECONDS), {}
    except ImportError:
        pass
    if not rec:
        return None
    e = effects(rec[1])
    if not e:
        return None
    if rec[0] <= 0:                     # ауры без срока — держим 10 минут
        if 'аур' not in rec[1].lower():
            return None
        rec = (AURA_SECONDS, rec[1])
    k = 1 + 0.1 * (max(1, lv) - 1)
    return rec[0], {name: sign * BASE[name] * k for name, sign in e.items()}


class Buffs:
    """Бафы одного персонажа: {sid: (уровень, истекает, эффекты)}."""

    def __init__(self):
        self.active = {}

    def add(self, sid, lv, now=None):
        """-> длительность (0 — бессрочная аура) или None, если навык — не баф."""
        r = lookup(sid, lv)
        if not r:
            return None
        dur, eff = r
        self.active[sid] = (lv, (now or time.time()) + dur if dur else FOREVER, eff)
        return dur

    def expired(self, now=None):
        now = now or time.time()
        gone = [sid for sid, (_, t, _) in self.active.items() if t <= now]
        for sid in gone:
            del self.active[sid]
        return gone

    def mult(self, name):
        return 1.0 + sum(eff.get(name, 0) for _, _, eff in self.active.values())

    def remaining(self, now=None):
        """[(sid, уровень, секунд)]; бессрочная аура — 0 (как у оригинала)."""
        now = now or time.time()
        return [(sid, lv, 0 if t == FOREVER else max(1, int(t - now))) for sid, (lv, t, _) in self.active.items()]


def build_list(eid, entries, add=True, caster=0, level=0):
    """05/09: entries — [(sid, уровень, оставшиеся секунды)]; caster — предмет-источник
    (бафы предметов), у навыков 0; level — уровень наложившего."""
    out = bytearray(struct.pack('>BIBH', 0, eid, 1 if add else 0, len(entries)))
    for sid, lv, sec in entries:
        out += struct.pack('>IBBIII', sid, lv & 0xff, level & 0xff, caster, int(sec), 0)
    return bytes(out)


# ---- бафы от предметов (зелья, «Дух воина», «Зелье ветра») ----
# Число и срок — из описания предмета (itemBase_Name): «Увеличивает скорость
# передвижения на 60% на 5 минут»; нет числа/срока — значения по умолчанию.
ITEM_DEFAULT = {'move': 0.30, 'aspd': 0.20, 'atk': 0.15, 'def': 0.15}
ITEM_SECONDS = 600
_ITEM_DESC = None


def _item_descs():
    global _ITEM_DESC
    if _ITEM_DESC is None:
        _ITEM_DESC = {}
        try:
            from boxes import records, decode as _dec, SRC as _src
            for iid, name, desc in records(_dec(open(_src, 'rb').read(), 0)):
                if re.search(r'увелич|повыш|повыс|бонус|уменьшает время|усилени', desc.lower()):
                    _ITEM_DESC[iid] = (name, desc)
        except OSError:
            pass
    return _ITEM_DESC


def item_buff(item):
    """-> (секунды, {эффект: доля}) или None — предмет не баф."""
    rec = _item_descs().get(item)
    if not rec:
        return None
    name, desc = rec
    full = ' '.join(desc.lower().split())
    d = full.split('время восстановления')[0]
    eff = {}
    # «Уменьшает время восстановления всех навыков на 50% на 7 дней» (100140022) -> 08/02 +248
    m = re.search(r'уменьшает время восстановления[а-я ]*на\s*(\d+)\s*%', full)
    if m:
        eff['cd'] = int(m.group(1)) / 100
    # «Дает бонус 25% к получаемым очкам опыта» (зелья опыта) -> 08/02 +228
    m = re.search(r'бонус\s*(\d+)\s*%\s*к получаемым[а-я ]*опыт', d)
    if m:
        eff['exp'] = int(m.group(1)) / 100
    # «Повышает максимальное число здоровья на 1000» / «повысит количество здоровья на 1000»
    m = re.search(r'(?:максимальн[а-я]* (?:число|запас) здоровья|количество здоровья) на (\d+)', d)
    if m:
        eff['maxhp'] = int(m.group(1))
    m = re.search(r'максимальн[а-я]* (?:число|запас) маны на (\d+)', d)
    if m:
        eff['maxmp'] = int(m.group(1))
    # «Усиление крита на 1 на 10 минут» (54620) -> шанс крита +1
    m = re.search(r'(?:усилени|увеличени)[а-я]*\s+крит[а-я]*\s+на\s+(\d+)', d)
    if m:
        eff['crit'] = int(m.group(1))
    # «Дает бонус 30% к получаемой энергии флетты» (140002) -> флетта за убийство ×1.3
    m = re.search(r'бонус\s*(\d+)\s*%\s*к получаем[а-я]* энерги[а-я]* флетт', d)
    if m:
        eff['fleta'] = int(m.group(1)) / 100
    if not eff and re.search(r'моментально|восстанавливает|опыт|флетт|похищ|супер-навык|аватар|навсегда', d):
        return None
    pats = {'move': r'скорост[а-я]*\s+(?:передвиж|движ|перемещ)[а-я]*',
            'aspd': r'скорост[а-я]*\s+атак[а-я]*',
            'atk': r'(?:сил[а-я]*\s+атак[а-я]*|(?:физическ|магическ)[а-я]*\s+(?:и\s+[а-я]+\s+)?атак[а-я]*)',
            'def': r'защит[а-я]*'}
    for k, p in pats.items():
        if eff.get(k) is not None:
            continue
        m = re.search(p, d)
        if not m:
            continue
        num = re.search(r'на\s*(\d+)\s*%', d[m.end():m.end() + 40]) or \
            re.search(r'(\d+)\s*%', d[m.end():m.end() + 60])
        eff[k] = int(num.group(1)) / 100 if num else ITEM_DEFAULT[k]
    if not eff:
        return None
    lv = re.search(r'ур\.\s*(\d+)', name.lower())
    if lv and not re.search(r'\d+\s*%', d):
        eff = {k: v * int(lv.group(1)) for k, v in eff.items()}    # «Дух воина ур.2»
    sec = ITEM_SECONDS
    m = re.search(r'(\d+)\s*(секунд|сек|минут|мин|час|дн|день|дня)', full) or \
        re.search(r'(\d+)\s*(час|дн|день|дня)', name.lower())        # «(3 часа)», «(7 дней)»
    if m:
        sec = int(m.group(1)) * {'с': 1, 'м': 60, 'ч': 3600, 'д': 86400}[m.group(2)[0]]
    return sec, eff


try:   # предмет -> навык-эффект (tools/item_skills.py, itemAttr +84)
    import json as _json
    ITEM_SKILLS = {int(k): v for k, v in _json.load(open(os.path.join(ROOT, 'data', 'item_skills.json'))).items()}
except OSError:
    ITEM_SKILLS = {}


# Сроки бафов предметов, которых нет в skillLevel +140 (записи Genesis / оригинала, 05/09):
# белая печенька 800039 — 180 с; VIP — по сроку статуса (999900001 — 3 дн., 999900003 — 30 дн.).
SKILL_SECONDS = {800039: 180, 800041: 180}
# VIP-статус (06/02 -> 05/09 в записи Genesis): предмет -> навык статуса (+10% здоровья и маны, вид 29)
VIP = {999900010: 999900001, 999900012: 999900003}


def skill_buff(item):
    """Предмет без чисел в описании, но со своим навыком-бафом (itemAttr +84, вид 23/29):
    «Цветок удачи» 99992 -> 30318, «Суперускоритель» 200012 -> 31111, белая печенька -> 800039.
    -> (навык, секунды) или None."""
    from statcalc import skill_kind
    sid = VIP.get(item) or ITEM_SKILLS.get(item)
    if not sid or skill_kind(sid) not in (23, 29):
        return None
    sec = info().get((sid, 1), (0,))[0] or SKILL_SECONDS.get(sid)
    if item in VIP:
        rec = _item_descs().get(item)
        m = re.search(r'(\d+)\s*дн', (rec or ('', ''))[0]) if rec else None
        from loot import ITEMS
        m = m or re.search(r'(\d+)\s*дн', ITEMS.get(item, {}).get('name', ''))
        sec = int(m.group(1)) * 86400 if m else sec
    return (sid, int(sec)) if sec and sec > 0 else None


def add_item(buffs_obj, item, now=None):
    """Наложить баф предмета. -> (ключ, секунды): ключ — id навыка-эффекта (05/09 рисует
    иконку, как в оригинале), без навыка — -id предмета (без иконки)."""
    r = item_buff(item)
    if not r:
        return None, None
    sec, eff = r
    sid = ITEM_SKILLS.get(item)
    if sid:
        dur = info().get((sid, 1), (0,))[0]
        if dur and dur > 0:
            sec = int(dur)                  # срок — у навыка (skillLevel +140)
    key = sid or -item
    buffs_obj.active[key] = (1, (now or time.time()) + sec, eff)
    return key, sec
