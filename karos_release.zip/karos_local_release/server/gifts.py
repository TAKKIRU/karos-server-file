"""Подарки новичка: содержимое коробок.

В клиенте содержимого коробок нет (его выдавал сервер оригинала), поэтому набор
свой, но из настоящих предметов itemBase:
  * снаряжение своего класса на уровень подарка (оружие + 4 части брони, лучшее
    с требуемым уровнем от N+1 до N+5, где N — уровень подарка);
  * зелья HP/MP по 20 шт.;
  * золото N×100;
  * следующий подарок той же серии (ур.5 -> ур.10 -> …) — открывается, когда
    персонаж до него дорастёт (уровень проверяет и клиент, и сервер).
"""
import loot

ITEMS = loot.ITEMS
GOLD = loot.GOLD


def _series():
    """Серии «Подарок новичка (ур.N)» -> {id: (N, следующий id или None)}."""
    groups = {}
    for iid, it in ITEMS.items():
        if it.get('name', '').lower().startswith('подарок новичка'):
            groups.setdefault(iid // 1000, []).append((it.get('lvl', 0), iid))
    out = {}
    for lst in groups.values():
        lst.sort()
        for i, (lvl, iid) in enumerate(lst):
            out[iid] = (lvl, lst[i + 1][1] if i + 1 < len(lst) else None)
    return out


GIFTS = _series()
SLOTS = (7, 1, 2, 3, 4)          # оружие, торс, ноги, руки, ботинки


def _gear_for(cls, lvl):
    base = (int(cls) // 100) * 100
    lo, hi = lvl + 1, lvl + 5
    best = {}
    for iid, it in ITEMS.items():
        if iid >= 100000 or it.get('kind') != 1 or it.get('cat') not in (1, 2):
            continue
        if it.get('slot') not in SLOTS or (it.get('cls', 0) // 100) * 100 != base:
            continue
        if not lo <= it.get('lvl', 0) <= hi:
            continue
        cur = best.get(it['slot'])
        if cur is None or ITEMS[cur]['lvl'] < it['lvl']:
            best[it['slot']] = iid
    return [best[s] for s in SLOTS if s in best]


def open_gift(item, player):
    """-> [(item, count)] — что выпадает из подарка для этого персонажа."""
    lvl, nxt = GIFTS.get(item, (1, None))
    lvl = max(1, lvl)
    out = [(g, 1) for g in _gear_for(getattr(player, 'cls', 100), lvl)]
    out += [(loot.HP_POTION, 20), (loot.MP_POTION, 20), (GOLD, lvl * 100)]
    if nxt:
        out.append((nxt, 1))
    return out


if __name__ == '__main__':
    class P:
        cls = 300
    for g in list(GIFTS)[:4]:
        print(g, ITEMS[g]['name'], [(loot.item_name(i), n) for i, n in open_gift(g, P)])
