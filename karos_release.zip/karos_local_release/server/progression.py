"""Рост персонажа и сила мобов.

Таблиц роста, HP мобов, опыта и золота в клиенте нет (их держал сервер
оригинала), поэтому формулы свои, но опорные точки — из клиента:
  * уровень моба — npcInfo +68 (у «Малого паука» 1001801 это 1; id = вид*100 + уровень);
  * урон оружия и защита брони — itemAttr (data/item_stats.json, tools/item_stats.py):
    [0]/[1] физ. урон, [2]/[3] маг. урон, [6] физ. защита;
  * окно персонажа 1 ур. (шаблон 08/02): HP 150, MP 90, физ. атака 7 (+оружие),
    физ. защита 21, маг. атака 22, маг. защита 19.

08/02 (784 байта, клиент копирует в структуру героя): два блока по 380 байт —
+32.. «база» и +412.. «итог». Известные поля блока (смещение от +32):
  +0 макс. HP  +4 реген HP  +12 макс. MP  +16 реген MP  +52 физ. атака (база,
  клиент сам прибавляет оружие: «9 (+2)»)  +56 скорость атаки  +64 физ. защита
  +80 маг. атака  +88 маг. защита  +96 скорость навыка  +100 урон крита  +132 шанс крита
"""
import functools, json, math, os, random

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
try:
    ITEM_STATS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'item_stats.json'))).items()}
except OSError:
    ITEM_STATS = {}

# прибавка за уровень по базовому классу (100, 200 паладин, 300, 400, 500, 600 ведунья)
# Запись Karos Genesis (паладин ур.7-10, 08/02): HP 549/605/662/718 (+56.3), MP +8,
# физ. атака +0.25, защита 21 + 0.45/ур., маг. атака +0.33, маг. защита +0.15.
# Остальные классы — пропорционально (точных данных нет; ведунья ур.1 — шаблон 08/02).
HP_PER_LVL = {100: 60, 200: 56.33, 300: 46, 400: 42, 500: 36, 600: 34}
MP_PER_LVL = {100: 6, 200: 8, 300: 8, 400: 10, 500: 14, 600: 15}
ATK_PER_LVL = {100: 0.3, 200: 0.25, 300: 0.3, 400: 0.25, 500: 0.15, 600: 0.15}
MATK_PER_LVL = {100: 0.2, 200: 0.33, 300: 0.2, 400: 0.33, 500: 0.6, 600: 0.6}
DEF_PER_LVL, MDEF_PER_LVL = 0.45, 0.15
BASE = {'hp': 150.4, 'mp': 90.0, 'atk': 6.975, 'def': 21.0, 'matk': 22.46, 'mdef': 19.7}
CLASS_BASE = {100: {'hp': 211, 'atk': 11.9}, 200: {'hp': 211, 'atk': 11.9, 'matk': 9.3, 'mdef': 19.1},
              300: {'hp': 180, 'atk': 11.0}}     # паладин ур.1 — из записи Genesis


def base_cls(cls):
    return (int(cls) // 100) * 100 if cls else 600


class PlayerStats:
    """Итоговые характеристики персонажа: уровень + надетое (+ флетта снаружи)."""

    def __init__(self, level=1, cls=600, equipped=None):
        self.recalc(level, cls, equipped or {})

    def recalc(self, level, cls, equipped):
        c = base_cls(cls)
        lv = max(1, int(level)) - 1
        self.level, self.cls = level, cls
        b = dict(BASE, **CLASS_BASE.get(c, {}))
        self.max_hp = b['hp'] + HP_PER_LVL.get(c, 40) * lv
        self.max_mp = b['mp'] + MP_PER_LVL.get(c, 10) * lv
        self.base_atk = b['atk'] + ATK_PER_LVL.get(c, 0.25) * lv
        self.base_matk = b['matk'] + MATK_PER_LVL.get(c, 0.33) * lv
        self.base_def = b['def'] + DEF_PER_LVL * lv
        self.base_mdef = b['mdef'] + MDEF_PER_LVL * lv
        self.wmin = self.wmax = self.mwmin = self.mwmax = self.armor = 0.0
        for slot, item in equipped.items():
            v = ITEM_STATS.get(item)
            if not v:
                continue
            if slot in (7, 8):                      # оружие / щит
                self.wmin += v[0]
                self.wmax += v[1]
                self.mwmin += v[2]
                self.mwmax += v[3]
            self.armor += v[6]
        self.defense = self.base_def + self.armor
        # совместимость со старым кодом (equip.Stats): «attack» — средний физ. урон
        self.attack = self.base_atk + (self.wmin + self.wmax) / 2
        return self

    def roll(self, magic=False, rng=random):
        if magic and self.mwmax > 0:
            lo, hi = self.base_matk * 0.25 + self.mwmin, self.base_matk * 0.25 + self.mwmax
        else:
            lo, hi = self.base_atk + self.wmin, self.base_atk + self.wmax
        return rng.uniform(lo, max(lo, hi))


def mob_level(info_level):
    return max(1, int(info_level or 1))


# HP обычных мобов оригинала по уровню (записи orig_1 / orig_hl: 04/02 мобов)
ORIG_HP = [(1, 50), (2, 57), (3, 64), (14, 268), (15, 312), (16, 319), (17, 326), (20, 387),
           (34, 950), (53, 1597), (54, 1635), (55, 1674), (58, 2370), (59, 2533), (62, 3036),
           (64, 3385), (65, 3564), (66, 3745), (67, 3930), (68, 4117), (69, 4306)]
try:
    MOB_STATS = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'mob_stats.json'))).items()}
except OSError:
    MOB_STATS = {}
# Официальная база GameXP 2018–2019 (tools/wiki_gamexp.py, docs/data_sources.md): 612 видов — опыт, HP, время
# возрождения, состав дропа. Сверено с записями: HP в 04/02 ровно на WIKI_HP_ADD больше поля вики (38 видов из 45),
# опыт за убийство — базовый опыт вики × множитель разницы уровней (exp_gap). Оценка по квестам
# (data/mob_hp_est.json) завышала HP мобов 80+ в 2–7 раз — больше не используется.
WIKI_HP_ADD = 50
try:
    WIKI = {int(k): v for k, v in json.load(open(os.path.join(DATA, 'gamexp_wiki_mobs.json'),
                                                   encoding='utf-8'))['mobs'].items()}
except (OSError, ValueError, KeyError):
    WIKI = {}


def _orig_hp(l):
    for (l0, h0), (l1, h1) in zip(ORIG_HP, ORIG_HP[1:]):
        if l0 <= l <= l1:
            return h0 + (h1 - h0) * (l - l0) / (l1 - l0)
    return None


def _median(v):
    v = sorted(v)
    return (v[len(v) // 2] + v[(len(v) - 1) // 2]) / 2 if v else None


def _prefix(name):
    return next((p for p, _k in HP_PREFIX if (name or '').startswith(p)), None)


WIKI_BOSS_STUB = 150      # у 14 боссов в базе HP 75–146 (у десяти ровно 100) — заглушка выгрузки: Какантерос 20
                          # в базе 75, в записи 1124. Их HP — оценкой (таблица × множитель боссов), опыт — из базы


def wiki_hp(w):
    """HP по базе (поле вики + 50) или None, если в базе заглушка."""
    if not w or not w.get('hp') or (w.get('grade') in BOSS_GRADES and w['hp'] <= WIKI_BOSS_STUB):
        return None
    return w['hp'] + WIKI_HP_ADD


@functools.lru_cache(maxsize=1)
def _wiki_fit():
    """Подгонка по официальной базе — для мобов, которых в ней нет (~10% точек: мобы 106–110, событий):
      hp_band  — [(уровень, медиана HP обычных мобов окна 5 ур.)] выше ORIG_HP;
      xp_band  — [(уровень, медиана опыт/HP обычных мобов)];
      hp_pref / xp_pref — множитель HP к обычному и опыт/HP по приставке ('boss' — боссы по npcInfo +20)."""
    norm = [(v['level'], wiki_hp(v), v['exp']) for v in WIKI.values()
            if wiki_hp(v) and v.get('grade') not in BOSS_GRADES and not _prefix(v['name'])]
    hp_band, xp_band = [], []
    for c in range(2, 111, 5):
        w = [(h, e) for l, h, e in norm if abs(l - c) <= 2]
        if len(w) >= 3:
            hp_band.append((c, _median([h for h, _ in w])))
            xp_band.append((c, _median([e / h for h, e in w])))
    hp_pref, xp_pref = {}, {}
    groups = {}
    for v in WIKI.values():
        if not wiki_hp(v):
            continue
        k = 'boss' if v.get('grade') in BOSS_GRADES else _prefix(v['name'])
        if k:
            groups.setdefault(k, []).append(v)
    for k, vs in groups.items():
        hp_pref[k] = _median([wiki_hp(v) / _table_hp(v['level'], hp_band) for v in vs])
        xp_pref[k] = _median([v['exp'] / wiki_hp(v) for v in vs])
    return hp_band, xp_band, hp_pref, xp_pref


def _interp(band, l):
    if not band:
        return None
    if l <= band[0][0]:
        return band[0][1]
    for (l0, a), (l1, b) in zip(band, band[1:]):
        if l0 <= l <= l1:
            return a + (b - a) * (l - l0) / (l1 - l0)
    return None


def _table_hp(l, hp_band):
    h = _orig_hp(l)
    if h is not None:
        return h
    if l < ORIG_HP[0][0]:
        return ORIG_HP[0][1]
    h = _interp(hp_band, l)
    if h is not None:
        return h
    if hp_band:
        c, last = hp_band[-1]
        if l > c:
            return last * 1.045 ** (l - c)
    l1, h1 = ORIG_HP[-1]
    return h1 * 1.045 ** (l - l1)


def mob_hp(level):
    """HP обычного моба по уровню: до 69 — таблица записей оригинала (ORIG_HP), выше — медианы обычных
    мобов официальной базы (90–99 ур. — 47–100 тыс., 100–109 — 250–350 тыс.), за последней точкой +4.5%/ур."""
    l = max(1, int(level))
    if WIKI:
        return int(round(_table_hp(l, _wiki_fit()[0])))
    h = _orig_hp(l)
    if h is not None:
        return int(round(h))
    l1, h1 = ORIG_HP[-1]
    return int(round(h1 * 1.045 ** (l - l1)))


def mob_mp(level):
    return 10 * max(1, level)


def mob_damage(level, defense, rng=random, giant=False, boss=False):
    """Урон моба по игроку — по записям ОРИГИНАЛА (orig_hl / remain3, 05/02 моб -> игрок, защита из 08/02 +64):
    урон = A × max(4%, 1 − защита / K), разброс ±1% (оригинал: 266/265/269, 390–393).
      K = 0.41·ур.² — защита, при которой остаётся минимум. Кробис-солдат ур.69 при защите 707/916/1166/1612/1853
          бьёт 266/224/168/72/20; A·(1 − d/K) с K = 1942, A = 424 даёт 270/224/169/74/19.
          (Genesis тот же закон с K = 0.8·ур.² — там защита вдвое слабее.)
      A ≈ (4.5·ур. + 45) × 1.15 — сила удара (оригинал: ×0.96–1.37, медиана ~1.1–1.2; ур.59 — 326,
          ур.63 — 340, ур.67 — 391, ур.87 — 546, ур.89 — 599 при почти нулевой защите).
      Минимум ~4% A: мобы ур.53–57 по защите 1433–1853 — 9–12, ур.64–65 — 16–18.
    Гиганты бьют ×2.2, боссы ×1.5 (Genesis: у гигантов наклон вдвое круче)."""
    L = max(1, level)
    a = (4.5 * L + 45) * 1.15 * (2.2 if giant else 1.0) * (1.5 if boss else 1.0)
    k = max(60.0, 0.41 * L * L)
    g = max(0.04, 1.0 - max(0.0, defense) / k)
    return max(1, int(round(a * g * rng.uniform(0.99, 1.01))))


def mob_hit_kind(player_lvl, mob_lvl, evasion, block, rng=random):
    """Исход удара моба по игроку (записи оригинала, вид в 05/02): 4 промах, 5 блок (×0.6), 6 полный блок,
    2 крит (×1.2), 1 обычный. Pers4x ур.62 (уклон. 14, блок 20): мобы ниже на 4–7 — промах 25–41%,
    блок 24–39%; выше на 2–3 — 13–18% и 15–18%; выше на 7 — 0–5%. Бродяга ур.89 (уклон. 30, блок 12):
    мобы ниже на 22–29 — промах 40–58%, блок 23–33%. Персонажи с уклон. 7 — почти без промахов."""
    d = player_lvl - mob_lvl
    miss = min(60.0, max(0.0, 1.6 * evasion - 5 + 1.5 * d))
    blk = min(40.0, max(0.0, 1.2 * block + d))
    r = rng.random() * 100
    if r < miss:
        return 4
    if r < miss + blk:
        return 6 if rng.random() < 0.15 else 5
    if rng.random() < 0.05:
        return 2
    return 1


def player_miss(player_lvl, mob_lvl):
    """% промахов игрока: оригинал Pers4x ур.62 — по мобам ниже и своего уровня 0%, выше на 2 — 5%,
    на 3 — 6%, на 4 — 12%, на 6 — 17% (~3.4% за уровень сверх первого)."""
    return min(60.0, max(0.0, 3.4 * (mob_lvl - player_lvl - 1)))


FLOOR_LEVELS = 7               # настолько выше игрока были мобы в записи канонира


def hit_damage(raw, mob_lvl, player_lvl, floor=0.0):
    """Урон игрока по мобу: слабее по мобам выше уровнем. floor — доля, ниже которой у класса по записи
    оригинала не падает (charstats.above_floor): до +7 уровней держится, дальше записей нет — те же −4%."""
    d = max(0, mob_lvl - player_lvl)
    k = max(0.4, 1.0 - d * 0.04)
    if floor:
        k = max(k, floor * max(0.4, 1.0 - max(0, d - FLOOR_LEVELS) * 0.04))
    return max(1, int(round(raw * k)))


# Доля опыта по тому, насколько игрок выше моба (d = ур. игрока − ур. моба). Записи оригинала сошлись до
# единицы с базовым опытом вики по правилу floor(база × f), затем × (1 + бонус):
#   d ≤ 2  -> 1.0  (Степной пёс 3 игроку 5: 55 -> 60 при бонусе 10%);
#   3–5   -> 0.9  (Совиный медвежонок 2 игроку 5: 31 -> 29; Мстительный Какантерос 58 игроку 62: 107 192);
#   6–8   -> 0.7  (пробуждённые 54–56 игроку 62: 3261, 5480, 5613, 5744);
#   ≥ 22  -> 0.1  (Зелёный Легалус 67 игроку 89: 14 509; мобы 60–64 — 829 … 1220).
# 9–21 — записей нет: та же лестница по 3 уровня (0.5, 0.3), с 15 — 0.1 (допущение). Моб выше игрока — 1.0.
EXP_GAP = ((2, 1.0), (5, 0.9), (8, 0.7), (11, 0.5), (14, 0.3))
EXP_GAP_MIN = 0.1


def exp_gap(d):
    return next((f for top, f in EXP_GAP if d <= top), EXP_GAP_MIN)


def mob_base_exp(npc_id, level, hp=None, info=None):
    """Базовый опыт моба (игроку того же уровня, без бонусов): поле вики «Получаемый опыт»; моба нет в базе —
    HP × медиана опыт/HP по базе (обычные мобы того же уровня или та же приставка / боссы)."""
    w = WIKI.get(npc_id)
    if w and w.get('exp'):
        return w['exp']
    info = info or {}
    _hb, xp_band, _hpp, xp_pref = _wiki_fit() if WIKI else ((), (), {}, {})
    k = 'boss' if is_boss(info) else _prefix(info.get('name'))
    r = xp_pref.get(k) if k else None
    if r is None:
        r = _interp(xp_band, level)
    if r is None:
        r = xp_band[-1][1] if xp_band else 1.2
    return (hp or mob_max_hp(npc_id, info)) * r


def mob_exp(mob_lvl, player_lvl, exp_to_next=None, rate=1, hp=None, npc_id=None, info=None):
    """Опыт за моба: базовый опыт (mob_base_exp) × exp_gap(разница уровней), с округлением вниз, × rate
    (DEV['exp']: по просьбе ×10 к оригиналу). Бонус опыта % (+228, +240) прибавляет server.mob_exp.
    exp_to_next не используется (оставлен для старых вызовов)."""
    base = mob_base_exp(npc_id, mob_lvl, hp, info)
    try:
        from devtools import DEV          # пульт F2 «Штраф за разницу уровней» (как в оригинале — включён)
        gap = exp_gap(player_lvl - mob_lvl) if DEV.get('exp_gap', True) else 1.0
    except ImportError:
        gap = exp_gap(player_lvl - mob_lvl)
    return max(1, int(math.floor(base * gap + 1e-9) * rate))


def mob_exp_old(mob_lvl, player_lvl, exp_to_next, rate=1):
    """Опыт за моба — постоянный для пары уровней (без случайности):
    база = (опыт до след. уровня моба) / (6 + 1.2×ур.), т.е. ~7 мобов своего
    уровня на ур.1 и ~18 на ур.10; множитель от разницы уровней 0.1..1.5."""
    base = exp_to_next(mob_lvl) / (6 + 1.2 * mob_lvl)
    diff = mob_lvl - player_lvl
    k = 1.0 + 0.1 * diff if diff >= 0 else max(0.1, 1.0 + 0.15 * diff)
    return max(1, int(round(base * min(1.5, k) * rate)))


def mob_gold(level, npc_id):
    """Золото с моба — фиксированное для вида моба."""
    try:
        from devtools import DEV          # пульт F2 меняет на лету
        rate = DEV.get('gold', GOLD_RATE)
    except ImportError:
        rate = GOLD_RATE
    return max(1, int(round(rate * (3 * max(1, level) + (int(npc_id) // 100) % 5))))


GOLD_RATE = 15   # по просьбе: караты ×15


# ---- гиганты и боссы (по просьбе: гигантов ×3 на точке, боссов по 5) ----
BOSS_GRADES = set(range(90, 98)) | {1013, 1014, 1016}   # npcInfo +20 (content.py)
GIANT_MULT = 3            # гигантских мобов на точке спавна — втрое больше
BOSS_COUNT = 5            # боссов на точке
GIANT_LOOT_ROLLS = 2      # с гигантов — вдвое больше предметов

# Время возрождения: как в оригинале — из официальной базы (обычные мобы чаще всего 56 с – 2 мин, боссы
# 30 мин – 24 ч). Пульт F2 «Возрождение 30 с» (DEV['respawn_fast']) возвращает прежнее: 30 с, боссы 60 с.
# В базе «долго» или пусто — обычным 30 с, боссам 1 ч (числа нет).
FAST_RESPAWN = 30.0
BOSS_RESPAWN = 60.0
UNKNOWN_BOSS_RESPAWN = 3600.0


def respawn_delay(mob):
    try:
        from devtools import DEV
        fast = DEV.get('respawn_fast', False)
    except ImportError:
        fast = False
    boss = getattr(mob, 'is_boss', False)
    if fast:
        return BOSS_RESPAWN if boss else FAST_RESPAWN
    w = WIKI.get(getattr(mob, 'npc_id', None))
    if w and w.get('respawn_s'):
        return float(w['respawn_s'])
    return UNKNOWN_BOSS_RESPAWN if boss else FAST_RESPAWN


def is_boss(info):
    return (info or {}).get('grade') in BOSS_GRADES


# HP мобов, которых нет ни в записях, ни в официальной базе, — множитель к обычному мобу того же уровня по
# приставке. С базой — медианы по ней (_wiki_fit: Гигантский ×8, Пробуждённый ×1,3, Разъярённый ×2,1 …).
# Числа ниже — прежние оценки, только если файла базы нет.
HP_PREFIX = (('Гигантск', 9.0), ('Пробужденн', 17.0), ('Мутировавш', 9.0), ('Элитн', 2.75),
             ('Разъяренн', 1.5), ('Яростн', 2.3))
BOSS_HP = 7.0
BIG_RATIO = 5.0           # HP ≥ ×5 обычного — «моб для прокачки»: на точке втрое больше (GIANT_MULT)
MOB_MULT = 2              # обычных мобов на точке — вдвое больше, чем в оригинале (по просьбе)


def hp_mult(info):
    info = info or {}
    k = 'boss' if is_boss(info) else _prefix(info.get('name'))
    if not k:
        return 1.0
    m = _wiki_fit()[2].get(k) if WIKI else None
    if m:
        return m
    return BOSS_HP if k == 'boss' else dict(HP_PREFIX)[k]


def mob_max_hp(npc_id, info):
    """HP моба: запись оригинала (MOB_STATS) -> официальная база (поле вики + 50) -> таблица по уровню ×
    приставка. Виды, усиленные после снимка вики (гигантский сквила-рабочий 89, элитные скелеты 64), есть
    в записях — берётся запись."""
    st = MOB_STATS.get(npc_id)
    if st:
        return st['hp']
    h = wiki_hp(WIKI.get(npc_id))
    if h:
        return h
    return int(round(mob_hp(mob_level((info or {}).get('level'))) * hp_mult(info)))


GIANT_PREFIX = ('Гигантск', 'Мутировавш')


def is_giant(info):
    """Моб для прокачки: «Гигантский …», «Мутировавший …» или HP ≥ ×5 обычного моба того же уровня."""
    info = info or {}
    if not info.get('name') or is_boss(info):
        return False
    if info['name'].startswith(GIANT_PREFIX):
        return True
    lv = mob_level(info.get('level'))
    return mob_max_hp(info.get('id'), info) >= BIG_RATIO * mob_hp(lv)
