@echo off
cd /d "%~dp0"
rem Один раз: правки клиента под локальный сервер (игра закрыта)
python -X utf8 tools\setup_client.py
pause
