# Опкоды категории 06 (предметы)

Из таблицы описаний пакетов клиента: адрес 0x823b2c + 4*sub (порядок = подопкод,
проверено на 9 известных: 06/00…06/0e). Пусто — класс не определён.

> **Внимание (2026-11-09):** таблица ниже не совпадает с номерами этой версии клиента. По
> сборщикам исходящих пакетов (`push 6; call 0x422b24; mov byte [ebp-4], sub`) и обработчикам
> входящих (CClientNet +0x16c+4*sub, RTTI vtable пакета): 06/16 — CItemCombinationPacket
> (крафт у NPC), 06/1d — CItemStashExtendPacket, 06/3f — CItemPCCombinationPacket,
> 06/56 — CItemDismantlePacket, 06/47 — CItemCombiReinforcingPacket, 06/4f/50/5e —
> совмещение/разделение снаряжения, 06/31 — покупка в кэш-шопе, 06/39 — открыть кэш-шоп.
> Форматы крафта и разборки — в `server/crafting.py`.

| Опкод | Класс |
|---|---|
| 06/00 | CItemWearPacket |
| 06/01 | CItemPutoffPacket |
| 06/02 | CItemUsePacket |
| 06/03 | CItemPickupPacket |
| 06/04 | CItemDropPacket |
| 06/05 | CItemInvenListPacket |
| 06/06 | CItemInvenPutinPacket |
| 06/07 | CItemInvenPutoutPacket |
| 06/08 | CItemInvenSwapPacket |
| 06/09 | CItemInvenTogetherPacket |
| 06/0a | CItemInvenSeparatePacket |
| 06/0b | CItemQuickSlotAddPacket |
| 06/0c | CItemQuickSlotDelPacket |
| 06/0d | CItemShopBuyPacket |
| 06/0e | CItemShopSellPacket |
| 06/0f | CItemRepurItemListPacket |
| 06/10 | CItemRepurchaserBuyPacket |
| 06/11 | CItemPersonalTradePacket |
| 06/12 |  |
| 06/13 | CItemPersonalTradeCheckPacket |
| 06/14 | CItemPersonalTradeCompletePacket |
| 06/15 | CItemPersonalTradeCancelPacket |
| 06/16 | CItemGamblePacket |
| 06/17 |  |
| 06/18 |  |
| 06/19 |  |
| 06/1a |  |
| 06/1b |  |
| 06/1c |  |
| 06/1d | CItemCombinationPacket |
| 06/1e | CItemEnchantPacket |
| 06/1f | CItemFletaEnchantPacket |
| 06/20 | CItemCombAttrPacket |
| 06/21 | CItemCombAttrRemovePacket |
| 06/22 | CItemCombEquiPacket |
| 06/23 | CItemCombEquiSeparatePacket |
| 06/24 |  |
| 06/25 | CSetCostumePacket |
| 06/26 | CGetCashItemPacket |
| 06/27 | CItemStashPutinPacket |
| 06/28 | CItemStashPutoutPacket |
| 06/29 | CItemStashListPacket |
| 06/2a | CItemStashExtendPacket |
| 06/2b | CItemStashOpenLevelListPacket |
| 06/2c | CCoolTimeListPacket |
| 06/2d | CItemPCCombinationPacket |
| 06/2e | CItemAutoSortPacket |
| 06/2f | CItemQuickSlotInfoPacket |
| 06/30 | CItemDismantlePacket |
| 06/31 |  |
| 06/32 | CCoolTimeSkillListPacket |
| 06/33 | CItemStashSwapPacket |
| 06/34 | CItemAccountStashSwapPacket |
| 06/35 | CGuildStashSwapPacket |
| 06/36 | CGuildLevelUPPacket |
| 06/37 | CGuildFletaPointPacket |
| 06/38 | CGuildChatSharePacket |
| 06/39 | CItemAccountStashPutinPacket |
| 06/3a | CItemAccountStashPutOutPacket |
| 06/3b | CItemAccountStashListPacket |
| 06/3c |  |
| 06/3d |  |
| 06/3e | CItemSellAgencyItemDelPacket |
| 06/3f | CItemSellAgencyRegisterPacket |
| 06/40 | CItemSellAgencyUnRegisterPacket |
| 06/41 | CItemSellAgencySettlementPacket |
| 06/42 | CItemSellAgencyBuyPacket |
| 06/43 | CItemSellAgencyRegCommissionPacket |
| 06/44 | CItemReturnSlotSavePacket |
| 06/45 | CItemEquipslotStatePacket |
| 06/46 | CItemCashShopBuyPacket |
| 06/47 | CItemCashShopItemUsePacket |
| 06/48 | CItemCashShopOpenPacket |
| 06/49 | CLimitCashShopListPacket |
| 06/4a | CLimitCashShopUpdatePacket |
| 06/4b |  |
| 06/4c |  |
| 06/4d | CItemAccountStashGiveItemPacket |
| 06/4e | CItemSelfShopSellArticleRegisterOpenPacket |
| 06/4f | CItemSelfShopSellArticleRegisterStopPacket |
| 06/50 | CItemSelfShopSellArticleSellPacket |
| 06/51 | CItemSelfShopSellArticleBuyPacket |
| 06/52 | CItemSelfShopSellArticleCancelPacket |
| 06/53 | CItemSelfShopSellArticleListPacket |
| 06/54 | CItemCashCharRecallPacket |
| 06/55 | CItemTrashPacket |
| 06/56 |  |
| 06/57 |  |
| 06/58 |  |
| 06/59 | CItemPartyMemberCallPacket |
| 06/5a | CItemMixedReinforcePacket |
| 06/5b | CItemMixedReinforceRemovePacket |
| 06/5c | CItemUniqueEnchantPacket |
| 06/5d | CItemOptionExtractPacket |
| 06/5e | CItemTranformUseItemPacket |
| 06/5f | CItemHairColorPacket |
| 06/60 |  |
| 06/61 | CSuperSkillChange |
| 06/62 | CSystemPingPacket |
| 06/63 |  |
| 06/64 |  |
| 06/65 |  |
| 06/66 |  |
| 06/67 |  |
| 06/68 | CXigncodeCheckPacket |
| 06/69 |  |
| 06/6a |  |
| 06/6b | CChannelWaitLoginPacket |
| 06/6c |  |
| 06/6d | CGuildMemberInfoPacket |
| 06/6e |  |
| 06/6f |  |

Также: 08/07 CFishingStressPoint, 08/08 CFishingEventTime (база категории 08 — 0x8239d0), 09/00 CQuestStart (база 0x823a20).
