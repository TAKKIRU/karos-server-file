# Каталог таблиц клиента (.lod)

Сгенерировано `tools/lod_catalog.py`. Расшифрованные байты — `data/lod/<имя>.bin`.
Записи часто переменной длины (строки внутри), «байт/запись» — среднее.

| Таблица | Файл | Режим | Записей | Байт/запись | Пример текста |
|---|---|---|---|---|---|
| CashShop | CashShop.lod_rus | 0 | ? | — | eh36 |
| CombiReinforcingAgent | CombiReinforcingAgent.lod_rus | 0 | ? | — | Д.Оа; ваЁЛ; s6mh |
| EIDCondition | EIDCondition.lod_rus | 0 | ? | — | ЗпМэ; ьъФнц; щыюо |
| EIDElement | EIDElement.lod_rus | 0 | ? | — | ФмЬББ; МЩБжфТ; d9q6 |
| EIDMain | EIDMain.lod_rus | 0 | ? | — | эзЭф; L1ol; y8zn |
| EIDString | EIDString.lod_rus | 0 | ? | — | QPHf; ЧпъЛ; rUg3de |
| EIDWarp | EIDWarp.lod_rus | 0 | ? | — | ТЮЮФьл; wBrB; АгрВ |
| EventInform | EventInform.lod_rus | 1 | 126 | 1344 | Парящий остров; Чтобы попасть на Парящий остров, вам пон; божественных перьев. |
| IE_CharFiltering | IE_CharFiltering.lod_rus | — | — | — | не расшифровано |
| IE_GuildNameFiltering | IE_GuildNameFiltering.lod_rus | 1 | ? | — | T2J8; LCM4I; EO.K |
| IE_Maplist | IE_Maplist.lod_rus | 0 | ? | — | еПФдъ; ЛфЁААщ; ЫЛцч |
| IE_NameFiltering | IE_NameFiltering.lod_rus | 1 | ? | — | хЬЖВЕт; чциОБ; еЫяИ |
| IE_TextFiltering | IE_TextFiltering.lod_rus | 0 | ? | — | ЧемФ; zrSRr; МлбЫ |
| ItemCombEqui | ItemCombEqui.lod_rus | 0 | ? | — | Ut1u; ЖОфм,П; ЬЩЗш |
| ItemEnchant | ItemEnchant.lod_rus | 1 | 65 | 34 | ffffff; НМММММь; НММММ |
| SellAgencyCommission | SellAgencyCommission.lod_rus | 0 | ? | — | GrN\; ДХМм |
| SkillTree_100 | SkillTree_100.lod | 0 | 6 | 85 | яяяяяяяяй; яяяяяяяям |
| SkillTree_110 | SkillTree_110.lod | 0 | 13 | 72 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_111 | SkillTree_111.lod | 0 | 19 | 74 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_112 | SkillTree_112.lod | 0 | 19 | 74 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_120 | SkillTree_120.lod | 0 | 13 | 71 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_121 | SkillTree_121.lod | 0 | 19 | 70 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_122 | SkillTree_122.lod | 0 | 19 | 70 | яяяяяяяяй; яяяяяяяям; яяяяяяяян |
| SkillTree_200 | SkillTree_200.lod | 1 | ? | — | bA_LZ; KQ7vC |
| SkillTree_210 | SkillTree_210.lod | 1 | ? | — | жл-тм; KYdHw; бЮКдЫ |
| SkillTree_211 | SkillTree_211.lod | 1 | ? | — | ЯЭрЁ; D Ua; чхУЭ |
| SkillTree_212 | SkillTree_212.lod | 1 | ? | — | ТаИК; ЖузнАе; Bmt4 |
| SkillTree_220 | SkillTree_220.lod | 1 | ? | — | хчлэ; hWv1; фьЕи |
| SkillTree_221 | SkillTree_221.lod | 1 | ? | — | мЫТКМ; ТэчС; нЕ-ДжЮйСЧТВсс |
| SkillTree_222 | SkillTree_222.lod | 1 | ? | — | w4Vi; КвуОЭу; ЩЕСХ |
| SkillTree_300 | SkillTree_300.lod | 1 | ? | — | ЪГ,ыИ; ИфсбЮ; zMPSy |
| SkillTree_310 | SkillTree_310.lod | 1 | ? | — | WMEQ2; mxMn4; R_zZZ |
| SkillTree_311 | SkillTree_311.lod | 0 | 19 | 72 | яяяяяяяян; яяяяо; яяяяяяяяп |
| SkillTree_312 | SkillTree_312.lod | 0 | 19 | 71 | яяяяяяяян; яяяяо; яяяяяяяяп |
| SkillTree_320 | SkillTree_320.lod | 1 | ? | — | wwDQ; jn15; o_ d |
| SkillTree_321 | SkillTree_321.lod | 1 | ? | — | ищгЖж; ZCV7rwVkz; рчЪС |
| SkillTree_322 | SkillTree_322.lod | 1 | ? | — | QNyQ; ceRKb; FytX |
| SkillTree_400 | SkillTree_400.lod | 1 | ? | — | Мэбж; ЖСЖъ |
| SkillTree_410 | SkillTree_410.lod | 1 | ? | — | чшХб; СЯ У; ИнЦФ |
| SkillTree_411 | SkillTree_411.lod | 1 | ? | — | рГЙпьБ; Ф,БЬ; bfJI |
| SkillTree_412 | SkillTree_412.lod | 1 | ? | — | i6N0m; ЕЛМЕе; ТзБТ |
| SkillTree_420 | SkillTree_420.lod | 1 | ? | — | ХЖкл; сьчЗЯ; тЕжЖ |
| SkillTree_421 | SkillTree_421.lod | 0 | 19 | 72 | яяяяяяяяЭ; яяяяяяяяЮ; яяяяЯ |
| SkillTree_422 | SkillTree_422.lod | 0 | 19 | 73 | яяяяяяяяЭ; яяяяяяяяЮ; яяяяЯ |
| SkillTree_500 | SkillTree_500.lod | 1 | ? | — | бгВРаыж |
| SkillTree_510 | SkillTree_510.lod | 1 | ? | — | ЖёЧ.; ау Ц; tfNi |
| SkillTree_511 | SkillTree_511.lod | 0 | 19 | 71 | яяяяяяяя.; Идгй |
| SkillTree_512 | SkillTree_512.lod | 1 | ? | — | Ehlc; ЫЫЁы; H2cv |
| SkillTree_520 | SkillTree_520.lod | 1 | ? | — | ЧхДЧ; ЩЪ-шН; ШЦтц |
| SkillTree_521 | SkillTree_521.lod | 1 | ? | — | rfO9; УЯУЁ; ирфЛ |
| SkillTree_522 | SkillTree_522.lod | 0 | 19 | 74 | яяяяяяяя,; яяяяяяяяН; яяяяяяяяС |
| SkillTree_600 | SkillTree_600.lod | 1 | ? | — | Q2cble; OvV5tS; T36c |
| SkillTree_610 | SkillTree_610.lod | 0 | 13 | 70 | яяяяяяяящ; яяяяяяяяы; яяяяяяяяь |
| SkillTree_611 | SkillTree_611.lod | 0 | 19 | 74 | яяяяяяяящ; яяяяяяяяы; яяяяяяяяь |
| SkillTree_612 | SkillTree_612.lod | 0 | 19 | 73 | яяяяяяяящ; яяяяяяяяы; яяяяяяяяь |
| SkillTree_620 | SkillTree_620.lod | 0 | 13 | 72 | яяяяяяяящ; яяяяяяяяь; яяяяяяяяъ |
| SkillTree_621 | SkillTree_621.lod | 0 | 19 | 74 | яяяяяяяящ; яяяяяяяяь; яяяяяяяяъ |
| SkillTree_622 | SkillTree_622.lod | 0 | 19 | 74 | яяяяяяяящ; яяяяяяяяь; яяяяяяяяъ |
| SkillTree_800 | SkillTree_800.lod | 1 | ? | — | О ЙЧ; ЗэЗф; вВЯпп |
| SkillTree_810 | SkillTree_810.lod | 1 | ? | — | frCq; ъГЪд; фДФд |
| SkillTree_811 | SkillTree_811.lod | 1 | ? | — | UlzK36; фпыН; йткй |
| SkillTree_812 | SkillTree_812.lod | 1 | ? | — | ЛобУйХ; еЭчШ; l0s5 |
| SkillTree_820 | SkillTree_820.lod | 1 | ? | — | ънДу; ЕЕИЬ; фЕёМф |
| SkillTree_821 | SkillTree_821.lod | 1 | ? | — | чЯХЫС; бЩяб; фээЩ |
| SkillTree_822 | SkillTree_822.lod | 1 | ? | — | ЧЭщн.; РлДЮ; PxG. |
| arenaBase | arenaBase.lod_rus | 0 | ? | — | EFoE |
| arenaLadder | arenaLadder.lod_rus | 0 | ? | — | Нршфи |
| arenaPoint | arenaPoint.lod_rus | 0 | ? | — | cPVz\ |
| blessingEnchant | blessingEnchant.lod_rus | 1 | ? | — | ЧсРн |
| classChange | classChange.lod_rus | 0 | ? | — | б ЕЩь; ЧузЙ; J_8tO |
| classInfo | classInfo.lod_rus | 1 | 56 | 1203 | Мечник; Двуручный меч; Воины, мастерски владеющие двуручным меч |
| classRace | classRace.lod_rus | 1 | 9 | 89 | Человек; Тень; Сероин |
| combination | combination.lod_rus | 1 | 1253 | 303 | Двуручный меч; Утяжеленный меч; Полуторный меч |
| combinationNPC | combinationNPC.lod_rus | 0 | ? | — | нкьз; чЯСя; B6HN |
| combinationPC | combinationPC.lod_rus | 0 | ? | — | hDwva; оиВТ; ГЦЬэжБ |
| eventDiary | eventDiary.lod_rus | 1 | 30 | 1239 | Упорядочить предметы в рюкзаке; Вы можете рассортировать предметы в свое; Щелкните по значку |
| eventDiary_attendance | eventDiary_attendance.lod_rus | 1 | 14 | 152 | Заходите в игру каждый день и забирайте ; Будет отправлена на почту; Войдите в игру |
| eventDiary_reward | eventDiary_reward.lod_rus | 0 | ? | — | rSkM; ЁЯ.ФК; ъзыуБВЁ |
| fletaAttr | fletaAttr.lod_rus | 0 | ? | — | й ЙОфАь; атНц; нмХг |
| fletaHonor | fletaHonor.lod_rus | 0 | ? | — | ЕНэБ; g8xl; п-ьн |
| fletaItemEnchant | fletaItemEnchant.lod_rus | 0 | ? | — | ИС .; k05_; eOMm |
| gambleGacha | gambleGacha.lod_rus | 0 | ? | — | юН Ц; go0rsk; ДиШьг |
| gambleGoldFish | gambleGoldFish.lod_rus | 1 | 2 | 168 | Осколок флетты |
| gambleRandom | gambleRandom.lod_rus | 1 | 1 | 288 | Случайный обмен |
| guildLevel | guildLevel.lod_rus | 0 | ? | — | П.,Ъ; Фндъ |
| guildMark | guildMark.lod_rus | 1 | 108 | 80 | KarosGuild_Mark_frame.dds; KarosGuild_Mark_symbol.dds; u32a |
| helpHunt | helpHunt.lod_rus | 0 | ? | — | e8s67B; _wrG |
| helpSystem | helpSystem.lod_rus | 1 | 47 | 1338 | Интерфейс; Интерфейс игры; KarosUI_Help_01.dds |
| itemAttr | itemAttr.lod_rus | 0 | 34395 | 126 | HAM_BLADE_11._EF; HAM_BLADE_12._EF; HAM_BLADE_13._EF |
| itemBase | itemBase.lod_rus | 0 | 20787 | 321 | Большой меч; KarosUI_ItemIcon_06.dds; HAM_SET_01_BLADE._OB |
| itemBase_Name | itemBase_Name.lod_rus | 0 | 20787 | 81 | Большой меч; Кованый железный большой меч.к; Утяжеленный меч |
| itemCombAttr | itemCombAttr.lod_rus | 0 | ? | — | d7jL; ьтшЧ; GT0u |
| itemDismantal | itemDismantal.lod_rus | 0 | ? | — | зЩЦИ; WabO; шзГЁ |
| itemInvokeSkill | itemInvokeSkill.lod_rus | 0 | ? | — | Й-ДТЩ; Ws6W; VDY1 |
| itemLinkMap | itemLinkMap.lod_rus | 1 | ? | — | ДлнЧ; ТПыН; ЩеиА |
| itemMixedExchangeOption | itemMixedExchangeOption.lod_rus | 0 | ? | — | оийц; уОЬЖи; ШлПж |
| itemMixedGrade | itemMixedGrade.lod_rus | 0 | ? | — | ьЮяъ; яоыГу; ЫаЯз |
| itemMixedMatchBuyDecision | itemMixedMatchBuyDecision.lod_rus | 1 | 3528 | 128 | NHN-700153001; NHN-700153002; NHN-700153011 |
| itemMixedOption | itemMixedOption.lod_rus | 0 | ? | — | ЙеуУё; вэыш; ojit |
| itemMixedPeriod | itemMixedPeriod.lod_rus | 0 | ? | — | WwNt; HuuR; BSxP |
| itemMixedSetEffect | itemMixedSetEffect.lod_rus | 0 | ? | — | Qdj4; УРЦт; ЪКщЗ |
| itemMixedType | itemMixedType.lod_rus | 0 | ? | — | еийШ; Вжбпз; quER |
| itemOptionExtract | itemOptionExtract.lod_rus | 0 | ? | — | ДЪЛ-АП; ЁюОфр; F2Clk |
| itemOptionExtractMaterial | itemOptionExtractMaterial.lod_rus | 0 | ? | — | щ-гх; ЫФрЩ; Яхыив |
| itemTransCustom | itemTransCustom.lod_rus | 0 | ? | — | ыЫвЮ; ыЕЖаЮс; Om6m |
| itemUnique | itemUnique.lod_rus | 0 | ? | — | йЮЯЯ; ugVW; g Ta |
| launcherString | launcherString.lod_rus | 0 | ? | — | o2TB; иГяЙ; xLcG |
| mapOccupation | mapOccupation.lod_rus | 1 | 2 | 228 | Люпинельский рудник; Застава |
| mapOccupationNpc | mapOccupationNpc.lod_rus | 0 | ? | — | гЁсШ; СББу; Hq0i |
| mapWarp | mapWarp.lod_rus | 0 | ? | — | КЁКЕ; A7.Uq; тЙАт |
| mapWarpGate | mapWarpGate.lod_rus | 0 | ? | — | ФЛжЪУ; ЫхОЩу; щЭж. |
| mapWarpStat | mapWarpStat.lod_rus | 0 | ? | — | rXLxn; ЯЧизЪ; йдэж |
| mapWarpTargetPos | mapWarpTargetPos.lod_rus | 0 | ? | — | I15Ds; ёъФц; Щсяч |
| npcDialogue | npcDialogue.lod_rus | 1 | 1671 | 1032 | Добро пожаловать в игру; Karos; Вскоре вы сделаете первый шаг на пути к  |
| npcEvent | npcEvent.lod_rus | 0 | ? | — | I\f2; иух,; ДЧдг |
| npcEventName | npcEventName.lod_rus | 1 | ? | — | сиАЕ-С; ОСыыХ |
| npcGMSummon | npcGMSummon.lod_rus | 1 | 2 | 198 | M_LittleSpider._OB; M_GsidaeLittle._OB; Rolf |
| npcInfo | npcInfo.lod_rus | 1 | 1227 | 234 | Золотое священное животное; Серебряное священное животное; Ключевая точка |
| npcPosition | npcPosition.lod_rus | 1 | 122 | 71 | Атакующий; Защитник; Лидер отряда |
| npcShop | npcShop.lod_rus | 1 | 282 | 138 | Управление питомцем; KarosUI_ShopIcon_01.dds; Комиссионка |
| npcShopItem | npcShopItem.lod_rus | 0 | ? | — | L0ym-; йыРШ; FTrtf |
| pcbang | pcbang.lod_rus | 0 | ? | — | нКлц |
| petBase | petBase.lod_rus | 1 | 76 | 340 | karos_pet_icon01.dds; Приобретаемая капсула с питомцем мрака. ; Приобретаемая капсула с милашкой-хряком. |
| petLevel | petLevel.lod_rus | 0 | ? | — | gCRO; TNTy; FN 9 |
| pkField | pkField.lod_rus | 0 | ? | — | (только числа) |
| pkMoral | pkMoral.lod_rus | 0 | ? | — | zJ4HJ; LTX_; ПАЗё |
| quest | quest.lod_rus | 1 | 723 | 6336 | Ты меня выслушаешь; Поговорить с Килиасом; Никогда бы не подумал, что ты так быстро |
| rvrBalanceSkill | rvrBalanceSkill.lod_rus | 0 | ? | — | литЧ; BZqp.p; аКВл |
| rvrBase | rvrBase.lod_rus | 1 | 2 | 152 | Хеллас; KarosUIrvrMainIcon.dds; Крета |
| rvrDrop | rvrDrop.lod_rus | 0 | ? | — | mUUjm; энкС; kLKrFH |
| rvrGrade | rvrGrade.lod_rus | 1 | 46 | 96 | Новичок Хелласа; Солдат Хелласа ур.; Младший офицер Хелласа ур. |
| rvrReward | rvrReward.lod_rus | 0 | ? | — | qCIE; ДРшб; ътЬУ |
| rvrShop | rvrShop.lod_rus | 0 | ? | — | еЗяж; МошА; XKN- |
| rvrStart | rvrStart.lod_rus | 0 | ? | — | wv4-; gaLC; n.fjz |
| rvrStone | rvrStone.lod_rus | 0 | ? | — | нЕаЧ; зШБмЯ; F0Sg |
| rvrStoneRinkNpc | rvrStoneRinkNpc.lod_rus | 0 | ? | — | (только числа) |
| skillBase | skillBase.lod_rus | 1 | 2711 | 280 | Атака; KarosUI_Action.dds; Трофей |
| skillData | skillData.lod_rus | 1 | ? | — | yx.P; лщщф; йВъКЁ |
| skillEnchant | skillEnchant.lod_rus | 0 | ? | — | ТядТея; цюлЗ; ZOV1b |
| skillFireEffect | skillFireEffect.lod_rus | 0 | 75 | 52 | Arrow._OB; CHR_FLETA._OB; EFF_FireBall._OB |
| skillLevel | skillLevel.lod_rus | 0 | 4624 | 420 | Атака выбранной цели; Поднять предмет; Выбрать следующего ближайшего монстра |
| skillLevel_Name | skillLevel_Name.lod_rus | 0 | 4657 | 52 | Атака выбранной цели; Поднять предмет; Выбрать следующего ближайшего монстра |
| skillOperationConstant | skillOperationConstant.lod_rus | 0 | ? | — | (только числа) |
| skillOptionMaxValue | skillOptionMaxValue.lod_rus | 0 | ? | — | (только числа) |
| skillTreeSuper | skillTreeSuper.lod_rus | 0 | ? | — | u9S9; Олих; J7lI6 |
| string | string.lod_rus | 0 | ? | — | OHPB; НхЩЗ; аУ Ц |
| transformBase | transformBase.lod_rus | 1 | 238 | 209 | MOB_UND_Skeleton002_ARCHER._OB; M_SkelArcher_WP01._OB; M_SkelArcher_WP02._OB |
| transformSkill | transformSkill.lod_rus | 0 | ? | — | GHcY; DNAR; Dj-J |
| uniqueOptionDrop | uniqueOptionDrop.lod_rus | 0 | ? | — | ЬЦУЖ; схВЙ; лЙуаь |
| uniqueOptionType | uniqueOptionType.lod_rus | 0 | ? | — | E8pB; ГибхЦЗл; ПИсс |
| warCastle | warCastle.lod_rus | 1 | 6 | 134 | Бент; Бернео; Сайрус |
| warCastleRegen | warCastleRegen.lod_rus | 0 | ? | — | ldmy |
| warCastleTarritory | warCastleTarritory.lod_rus | 0 | ? | — | z3R8c |
| warCastleTax | warCastleTax.lod_rus | 0 | ? | — | _utb; j3KR |
| worldMap | worldMap.lod_rus | 1 | 55 | 287 | World_Map.dds; Карта мира; ASMARA_MAP.dds |
