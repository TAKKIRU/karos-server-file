@echo off
cd /d "%~dp0"
rem Локальный сервер Karos (порты 10001, 10101, 10110; пульт 10199)
python -X utf8 server\server.py
pause
