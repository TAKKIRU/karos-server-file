@echo off
cd /d "%~dp0"
rem Сервер + пульт разработчика (F2 — показать/спрятать окно пульта)
start "Karos dev panel" pythonw tools\devpanel.py
python -X utf8 server\server.py
pause
