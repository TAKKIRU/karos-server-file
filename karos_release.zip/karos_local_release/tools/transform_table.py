"""Свитки трансформации: transformBase.lod_rus -> data/transform.json.

Режим 1: int число (238), записи по 209 байт:
  +0 номер превращения, +4 вид (1 — обычный, 2 — благословенный; клиент принимает только
  1 и 2, 3 — служебные), +16 свиток (item), +20 ступень, +24 уровень персонажа,
  +40 существо (npcInfo), +44 навык-баф существа (skillLevel: 300 с), дальше модели _OB.
Пакеты — server/transform.py. Длительность — skillLevel +140 навыка (+44), обычно 300 с.

transformSkill.lod_rus (режим 1): u32 число (66), записи по 48 байт: +0 номер превращения,
+4 u32 1, +8 5 × u32 особые навыки облика (атаки 81192…, бафы 81292…, дебафы 81391…; урон и
мана — skillLevel, tools/skill_damage.py, tools/skill_mp.py), +28 5 × u32 (1001…1011, 101, 102 —
назначение не выяснено). Есть у 66 обликов из 238 -> поле 'skills'.

Запуск: python tools/transform_table.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                   # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'transform.json')
R = 209


def skill_durations(ids):
    L = decode(open(os.path.join(LOD, 'skillLevel.lod_rus'), 'rb').read(), 0)
    out = {}
    for sid in ids:
        m = re.search(re.escape(struct.pack('<II', sid, 1)), L)
        if m:
            d = struct.unpack_from('<d', L, m.start() + 140)[0]
            if 0 < d < 100000:
                out[sid] = d
    return out


def main():
    p = decode(open(os.path.join(LOD, 'transformBase.lod_rus'), 'rb').read(), 1)
    recs = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        r = p[4 + R * k:4 + R * (k + 1)]
        f = struct.unpack_from('<12i', r, 0)
        if f[1] not in (1, 2):
            continue
        recs[f[0]] = {'type': f[1], 'scroll': f[4], 'tier': f[5], 'lvl': f[6],
                      'npc': f[10], 'skill': f[11]}
    ts = decode(open(os.path.join(LOD, 'transformSkill.lod_rus'), 'rb').read(), 1)
    for k in range(struct.unpack_from('<I', ts, 0)[0]):
        fid, _one, *sk = struct.unpack_from('<7I', ts, 4 + 48 * k)
        if fid in recs:
            recs[fid]['skills'] = [x for x in sk if x]
    dur = skill_durations({v['skill'] for v in recs.values()})
    for v in recs.values():
        v['secs'] = int(dur.get(v['skill'], 300))
    json.dump(recs, open(OUT, 'w', encoding='utf-8'), separators=(',', ':'))
    scrolls = sorted({v['scroll'] for v in recs.values()})
    print(f'{sum(1 for v in recs.values() if v.get("skills"))} с особыми навыками')
    print(f'{len(recs)} превращений, свитки {scrolls}, длительность '
          f'{sorted({v["secs"] for v in recs.values()})} с -> {OUT}')


if __name__ == '__main__':
    main()
