"""Официальная база мобов из вики GameXP (раздел «ОфициальнаяБаза», 2018–2019) через Wayback Machine.

Вики (gamexp.com/ru/wiki/karos) сейчас не отвечает, но её страницы мобов сохранены в архиве.
На странице моба: уровень, агрессия, опыт за убийство, здоровье, мана, время возрождения и состав дропа
(без шансов). Страницы предметов — цены покупки/продажи и продавцы (сверено: равны itemBase).

  python -X utf8 tools/wiki_gamexp.py cdx      список сохранённых страниц (ru, en, es)  -> tools/wiki_cache/
  python -X utf8 tools/wiki_gamexp.py crawl    скачать страницы мобов, пауза 7 с        -> tools/wiki_cache/pages/
  python -X utf8 tools/wiki_gamexp.py build    разобрать и связать с npcInfo и items    -> data/gamexp_wiki_mobs.json
  python -X utf8 tools/wiki_gamexp.py articles статьи и прочая официальная база (задания, NPC, коробки,
                                               магазины), важные первыми             -> tools/wiki_cache/articles/
  python -X utf8 tools/wiki_gamexp.py text <подстрока>   текст скачанных статей с этой подстрокой в названии

Архив ограничивает частоту: при отказе скрипт ждёт 3 минуты и повторяет, не чаще одного запроса в 7 с.
Кэш (tools/wiki_cache/) в git и релиз не попадает.
"""
import collections
import html
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CACHE = os.path.join(HERE, 'wiki_cache')
PAGES = os.path.join(CACHE, 'pages')
OUT = os.path.join(ROOT, 'data', 'gamexp_wiki_mobs.json')
LANGS = ('ru', 'en', 'es')            # en и es — копии той же русской базы, закрывают пропуски архива
UA = {'User-Agent': 'Mozilla/5.0 (research script; low rate)'}
PAUSE = 7
MOB = re.compile(r'^(.*?) \(ур\. (\d+)\):ОфициальнаяБаза$')


def get(url):
    for _ in range(5):
        try:
            raw = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90).read().decode('utf-8', 'replace')
        except Exception as e:  # noqa: BLE001 — сеть/архив: подождать и повторить
            raw = 'ERR %s' % e
        if raw.startswith('ERR') or 'flagged it as suspected abusive' in raw:
            print('  архив отказал, ждём 3 мин:', raw[:70].replace('\n', ' '), flush=True)
            time.sleep(180)
            continue
        return raw
    return ''


def cdx():
    os.makedirs(CACHE, exist_ok=True)
    for lang in LANGS:
        url = ('http://web.archive.org/cdx/search/cdx?url=gamexp.com/%s/wiki/karos/*&fl=original,timestamp,statuscode'
               '&collapse=urlkey&filter=statuscode:200&limit=20000' % lang)
        open(os.path.join(CACHE, 'cdx_%s.txt' % lang), 'w', encoding='utf-8').write(get(url))
        time.sleep(PAUSE)
        print(lang, 'готово', flush=True)


def mob_pages():
    """название -> [(адрес, снимок, язык), …]: русская вики первой, внутри языка — ранний снимок первым.

    collapse=urlkey в cdx даёт по одному (самому раннему) снимку на адрес; он ближе всего к клиенту 2019 года.
    Страницы мобов 90–97 ур. («Месть Аргмара», конец 2018) в ранних снимках бывают пустыми — тогда берётся
    следующий кандидат (en/es 2023–2024, та же база)."""
    cand = collections.defaultdict(list)
    for lang in LANGS:
        p = os.path.join(CACHE, 'cdx_%s.txt' % lang)
        if not os.path.exists(p):
            continue
        for line in open(p, encoding='utf-8'):
            f = line.split()
            if len(f) < 3 or f[2] != '200':
                continue
            title = urllib.parse.unquote(f[0]).split('/wiki/karos/', 1)[-1].replace('_', ' ')
            if MOB.match(title):
                cand[title].append((f[0], f[1], lang))
    for v in cand.values():
        v.sort(key=lambda x: (LANGS.index(x[2]), x[1]))
    return cand


def page_file(title):
    return os.path.join(PAGES, re.sub(r'[^\w.()-]+', '_', title)[:150] + '.html')


INDEX = os.path.join(PAGES, 'index.json')       # название -> [снимок, язык] сохранённой страницы


def load_index():
    return json.load(open(INDEX, encoding='utf-8')) if os.path.exists(INDEX) else {}


def crawl():
    os.makedirs(PAGES, exist_ok=True)
    idx = load_index()
    todo = [(t, c) for t, c in sorted(mob_pages().items()) if not os.path.exists(page_file(t))]
    print('страниц мобов к скачиванию:', len(todo), flush=True)
    for i, (t, cands) in enumerate(todo, 1):
        for u, ts, lang in cands:
            raw = get('http://web.archive.org/web/%sid_/%s' % (ts, u))
            time.sleep(PAUSE)
            if 'Получаемый опыт' in raw:
                open(page_file(t), 'w', encoding='utf-8').write(raw)
                idx[t] = [ts, lang]
                json.dump(idx, open(INDEX, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
                break
        else:
            print('  нет снимка с данными:', t, flush=True)
        if i % 25 == 0:
            print('  ', i, flush=True)


def page_text(raw):
    m = re.search(r'id="mw-content-text"(.*?)(?:<div class="printfooter"|<!-- NewPP|id="catlinks")', raw, re.S)
    body = re.sub(r'<script.*?</script>|<style.*?</style>', ' ', m.group(1) if m else raw, flags=re.S)
    body = re.sub(r'<br\s*/?>|</(?:p|div|tr|li|h\d)>', '\n', body)
    body = re.sub(r'</t[dh]>', '\t', body)
    t = html.unescape(re.sub(r'<[^>]+>', '', body))
    return '\n'.join(x.strip() for x in t.splitlines() if x.strip())


def parse(t):
    r = {}
    for k, pat in (('level', r'Уровень\s*:?\s*\t?\s*(\d+)'), ('exp', r'Получаемый опыт[^\n\t]*\t\s*(\d+)'),
                   ('hp', r'Очки здоровья[^\n\t]*\t\s*(\d+)'), ('mp', r'Очки маны[^\n\t]*\t\s*(\d+)'),
                   ('aggro', r'Агрессия\s*:?\s*\t?\s*(\S+)'), ('respawn', r'Повторное возрождение\s*:?\t([^\n]*)')):
        m = re.search(pat, t)
        if m:
            r[k] = m.group(1).strip()
    m = re.search(r'Из этого монстра выпадает[^\n]*\n(.*)', t, re.S)
    r['drops'] = [x for x in (m.group(1).split('\n') if m else []) if x and len(x) < 120]
    return r


def respawn_seconds(s):
    """«1 мин. 20 сек.» -> 80, «56 сек.» -> 56, «8 час.» -> 28800, «долго» и пусто -> None."""
    parts = [(re.search(r'(\d+)\s*' + u, s), k) for u, k in (('час', 3600), ('мин', 60), ('сек', 1))]
    if not any(m for m, _ in parts):
        return None
    return sum(int(m.group(1)) * k for m, k in parts if m)


NOTES = ('hp — поле вики «Очки здоровья»; в записях оригинала 2019 года 04/02 даёт ровно на 50 больше '
         '(38 видов из 45 точно, 3 — на 49). Исключения — виды, усиленные после снимка вики: Гигантский '
         'сквила-рабочий 89 (91351 против 48636), Элитные скелеты 64 (×1,61), Какантерос подземелья 20. '
         'exp — базовый опыт: в записях игрок на 6–8 ур. выше моба получает ровно 0,7 от него, на 25 и больше — 0,1 '
         '(с округлением вниз и затем бонусом опыта). drops — состав без шансов; общий дроп (Божественное перо, '
         'свитки чарования, праздничные предметы) в списках мобов не указан.')


def build():
    sys.path.insert(0, os.path.join(ROOT, 'server'))
    import content
    npc = content._npcinfo_lod()
    by_name = collections.defaultdict(list)
    for nid, i in npc.items():
        by_name[(i['name'].strip().lower(), i['level'])].append(nid)
    items = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
    by_item = collections.defaultdict(list)
    for iid, it in items.items():
        by_item[it['name'].strip().lower()].append(int(iid))
    out, nomatch = {}, []
    idx = load_index()
    for title, cands in sorted(mob_pages().items()):
        p = page_file(title)
        if not os.path.exists(p):
            continue
        ts, lang = idx.get(title) or cands[0][1:]
        r = parse(page_text(open(p, encoding='utf-8').read()))
        if not r.get('exp'):
            continue
        name, lvl = MOB.match(title).group(1).strip(), int(MOB.match(title).group(2))
        drops, unknown = [], []
        for d in r['drops']:
            nm = re.sub(r'^\d+\s*-\s*', '', d).strip()      # «7 - …» — часть заголовка страницы вики
            cnt = 1
            mm = re.match(r'^(.*?)\s+(\d+)\s*шт\.?$', nm)
            if mm:
                nm, cnt = mm.group(1), int(mm.group(2))
            cand = sorted(by_item.get(nm.lower(), []), key=lambda i: (i >= 900000000, items[str(i)]['price'] <= 0, i))
            if cand:
                drops.append([cand[0], cnt])
            else:
                unknown.append(d)
        rs = respawn_seconds(r.get('respawn') or '')
        rec = dict(name=name, level=lvl, exp=int(r['exp']), hp=int(r.get('hp') or 0), mp=int(r.get('mp') or 0),
                   aggro=r.get('aggro') == 'да', respawn_s=rs, respawn_text=(r.get('respawn') or '').strip(),
                   drops=drops, drops_unknown=unknown, snapshot=ts[:8], wiki=lang)
        ids = by_name.get((name.lower(), lvl), [])
        if not ids:
            nomatch.append(rec)
        for nid in ids:
            out[str(nid)] = dict(rec, grade=npc[nid].get('grade'))     # grade — npcInfo +20 (боссы 90–97 …)
    json.dump(dict(source='gamexp.com/ru/wiki/karos ОфициальнаяБаза (Wayback Machine), tools/wiki_gamexp.py',
                   notes=NOTES, mobs=out, not_in_npcinfo=nomatch),
              open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print('видов npcInfo с данными вики:', len(out), '| страниц без пары в npcInfo:', len(nomatch))


ARTICLES = os.path.join(CACHE, 'articles')
# порядок скачивания: сначала то, что нужно серверу сейчас
FIRST = ('Флетт', 'Флетто', 'флетт', 'Прокачка_стихии', 'Крафт', 'Создание', 'Ремесло', 'крафт', 'Таблица_исп',
         'Питом', 'питом', 'Задани', 'Ежедневн', 'Ивент', 'Боссы', 'Полубоссы', 'парящего', 'Демоническ',
         'Подземел', 'Эристум', 'Перенос_характ', 'Характеристики', 'Типы_характ', 'Атрибуты', 'Чарован',
         'чарован', 'Улучшение', 'Супер-навыки', 'Камни_супер', 'Счастливый_куб', 'Мастер-ученик', 'Опыт')
SKIP = ('api.php', 'load.php', 'Index.php', 'Скриншоты', 'Рисунки', 'Видео', 'Поэзия', 'Проза', 'Конкурсы')


def article_pages():
    """название -> [(адрес, снимок, язык), …] для статей и не-мобов официальной базы, в порядке важности."""
    cand = collections.defaultdict(list)
    for lang in LANGS:
        p = os.path.join(CACHE, 'cdx_%s.txt' % lang)
        if not os.path.exists(p):
            continue
        for line in open(p, encoding='utf-8'):
            f = line.split()
            if len(f) < 3 or f[2] != '200':
                continue
            title = urllib.parse.unquote(f[0]).split('/wiki/karos/', 1)[-1]
            if not title or '?' in title or 'index.php' in title or title.startswith(SKIP) or MOB.match(title.replace('_', ' ')):
                continue
            base = title.endswith(':ОфициальнаяБаза')
            if ':' in title and not base:
                continue
            name = title[:-len(':ОфициальнаяБаза')] if base else title
            if base and not ('(задание)' in name or re.search(r'_\([А-ЯЁ][^)]*\)$', name)
                             or name.startswith(('Коробка', 'Ящик', 'Сундук', 'Мешок', 'Шкатулка', 'Магазин'))):
                continue                       # снаряжение и материалы: цены уже сверены с itemBase
            cand[title].append((f[0], f[1], lang))

    def rank(t):
        name = t.split(':')[0]
        if any(k in name for k in FIRST):
            return 0
        if '(задание)' in name:
            return 1
        if name.startswith(('Коробка', 'Ящик', 'Сундук', 'Мешок', 'Шкатулка', 'Магазин')):
            return 2
        return 3 if t.endswith(':ОфициальнаяБаза') else 4
    for v in cand.values():
        v.sort(key=lambda x: (LANGS.index(x[2]), x[1]))
    return dict(sorted(cand.items(), key=lambda kv: (rank(kv[0]), kv[0])))


def article_file(title):
    return os.path.join(ARTICLES, re.sub(r'[^\w.()-]+', '_', title)[:150] + '.html')


def articles():
    os.makedirs(ARTICLES, exist_ok=True)
    idx_path = os.path.join(ARTICLES, 'index.json')
    idx = json.load(open(idx_path, encoding='utf-8')) if os.path.exists(idx_path) else {}
    todo = [(t, c) for t, c in article_pages().items() if not os.path.exists(article_file(t))]
    print('статей к скачиванию:', len(todo), flush=True)
    for i, (t, cands) in enumerate(todo, 1):
        for u, ts, lang in cands:
            raw = get('http://web.archive.org/web/%sid_/%s' % (ts, u))
            time.sleep(PAUSE)
            if len(page_text(raw)) > 300:          # пустой снимок — взять следующий
                open(article_file(t), 'w', encoding='utf-8').write(raw)
                idx[t] = [ts, lang]
                json.dump(idx, open(idx_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
                break
        else:
            print('  нет снимка с текстом:', t, flush=True)
        if i % 25 == 0:
            print('  ', i, 'из', len(todo), flush=True)


def text(sub):
    for t in article_pages():
        p = article_file(t)
        if sub.lower() in t.lower() and os.path.exists(p):
            print('=====', t)
            print(page_text(open(p, encoding='utf-8').read()))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'build'
    if cmd == 'text':
        text(sys.argv[2])
    else:
        {'cdx': cdx, 'crawl': crawl, 'build': build, 'articles': articles}[cmd]()
