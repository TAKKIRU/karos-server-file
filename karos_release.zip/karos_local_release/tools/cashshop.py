"""Внутриигровой магазин (кэш-шоп CGuiCashShop, окно 16034) с товарами GXP-магазина за караты.

Пишет:
  ResUnpak/Interface/IE_Lod/CashShop.lod_rus — таблица товаров клиента (в русском клиенте пустая);
  data/cashshop.json — то же для сервера: номер товара -> предмет, кол-во, цена в каратах;
  ResUnpak/Interface/IE_Lod/string.lod_rus — строка 20678 «… за %d GXP.» -> «… за %d карат.»
(исходные файлы сохраняются рядом с суффиксом .orig).

CashShop.lod (загрузчик AMo 0x0067fa88, шифр режима 1): int32 число записей, затем записи по
0x34c байт. Поля, которые читает окно:
  +0x00 номер товара  +0x04 цена  +0x10 вкладка (0 события, 1 ездовые, 2 расходники,
  3 ограниченные, 4 костюмы, 5 питомцы, 6 купоны — не во «Всех»)  +0x14 предмет  +0x18 кол-во
  («[N шт.]» при N>1)  +0x1c строка / +0x20 столбец иконки (клетки 32×32 в атласе 512×512)
  +0x24 группа (порядок во «Всех»)  +0x28 имя (64 байта cp1251)  +0x68 подсказка (512 байт)
  +0x268 файл атласа иконок.
Иконка, описание — из itemBase (поля [26] строка, [27] столбец, строка *.dds после имени).
Товары и цены — каталог сайта data/gxp_catalog.tsv (tools/gxp_match.py сопоставляет названия с
предметами клиента), цена = GXP × KARAT_PER_GXP. Наборы: блоки выдачи (A — всё, O — один из).
Без файла каталога — запасной список (что лежало в GXP-рюкзаках, коробки костюмов и крыльев).

Запуск: python tools/cashshop.py
"""
import json, os, re, shutil, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, 'server'))
from lod_decode import decode, encode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
REC = 0x34c
KARAT_PER_GXP = 10000          # караты за 1 GXP
EV, MOUNT, USE, LIMIT, COSTUME, PET = 0, 1, 2, 3, 4, 5

# семейство (имя без срока) -> (вкладка, цена в GXP по сроку: {срок_в_днях|None: GXP})
FAMILIES = {
    'VIP-статус': (EV, {3: 150, 7: 300, 30: 900}),
    'Счастливый день': (EV, {'2ч': 15, 1: 40, 7: 200}),
    'Платиновый ангел-хранитель': (USE, {None: 50}),
    'Защитная капсула': (USE, {None: 30}),
    'Зелье активности': (USE, {None: 20}),
    'Надгробная табличка': (USE, {None: 10}),
    'Книга призыва': (USE, {None: 10}),
    'Счастливый камень': (USE, {None: 30}),
    'Призвать отряд': (USE, {None: 20}),
    'Превосходное зелье силы': (USE, {None: 10}),
    'Зелье быстрого восстановления': (USE, {'1ч': 10, '12ч': 60}),
    'Зелье опыта': (USE, {'2ч': 20, 1: 60}),
    'Платиновое зелье опыта': (USE, {'1ч': 25, '3ч': 50}),
    'Платиновое зелье концентрации': (USE, {'1ч': 25, 1: 80, 7: 300}),
    'Бустер флетты': (USE, {1: 60}),
    'Платиновый бустер флетты': (USE, {'1ч': 25, '3ч': 50}),
    'Малое зелье увеличения здоровья и маны': (USE, {1: 30, 3: 70, 7: 150}),
    'Ожерелье жизни': (LIMIT, {1: 30, 7: 150, 30: 450}),
    'Кольцо опыта': (LIMIT, {1: 30, 7: 150, 14: 250, 30: 450}),
    'Счастливые серьги': (LIMIT, {1: 30, 7: 150, 30: 450}),
    'Счастливая кирка': (LIMIT, {7: 100, 14: 180, 30: 300}),
    'Суперускоритель': (PET, {None: 20}),
    'Стоп-голод': (PET, {None: 20}),
    'Зелье живучести игрового помощника': (PET, {None: 15}),
}
PREFER = (910, 400, 100, 999, 200, 500)        # из одинаковых предметов разных регионов
COSTUME_BOX_GXP = 1500
WING_BOX_GXP = 1200
TOKEN_GXP = 10
RENAME = {}                    # коробка костюма -> подпись в магазине (у всех имя «Коробка с костюмом»)


def term(name):
    """Срок из имени: «(7 дней)» -> 7, «(3 часа)» -> '3ч', без срока -> None."""
    m = re.search(r'\((\d+)\s*(дн[а-я.]*|день|час[а-я]*)\)\s*$', name)
    if not m:
        return None
    return int(m.group(1)) if m.group(2).startswith('д') else f'{m.group(1)}ч'


def family(name):
    return re.sub(r'\s*\(\d+\s*(дн[а-я.]*|день|час[а-я]*)\)\s*$', '', name).strip()


def item_base():
    """id -> (атлас, строка, столбец, описание) из itemBase."""
    d = decode(open(os.path.join(LOD, 'itemBase.lod_rus'), 'rb').read(), 0)
    out = {}
    q = 0
    while True:
        q = d.find(b'\x01\x00\x00\x00', q + 1)
        if q < 0 or q + 400 > len(d):
            break
        p = q - 4
        f = struct.unpack_from('<40i', d, p)
        if not (0 < f[0] < 2_000_000_000 and f[3] == 0 and 1 <= f[4] <= 9 and 1 <= f[14] <= 100000
                and 0 < f[39] < 200) or f[0] in out:
            continue
        tail = d[p + 160 + f[39]:p + 1400]
        strs = [m.group().decode('cp1251') for m in re.finditer(rb'[\x20-\x7e\xa8\xb8\xc0-\xff\r\n]{3,}', tail)]
        icon = next((s for s in strs if s.lower().endswith('.dds')), '')
        desc = next((s for s in strs if not re.search(r'\.(dds|_ob|ob|tga|bmp)$', s.lower()) and len(s) > 8), '')
        out[f[0]] = (icon, f[26], f[27], desc)
    return out


def catalog(items, gxp_ids):
    import costume, gacha
    picks = {}
    for iid, it in items.items():
        fam = family(it['name'])
        if fam not in FAMILIES:
            continue
        tab, prices = FAMILIES[fam]
        t = term(it['name'])
        if t not in prices:
            continue
        key = (fam, t)
        rank = (0 if iid in gxp_ids else 1, PREFER.index(iid // 1000000) if iid // 1000000 in PREFER else 9, iid)
        if key not in picks or rank < picks[key][0]:
            picks[key] = (rank, iid, tab, prices[t])
    goods = [(tab, iid, 1, gxp) for (_r, iid, tab, gxp) in picks.values()]
    goods.append((EV, gacha.TOKEN, 10, TOKEN_GXP * 10))
    costume.init(items)
    best = {}                     # костюм -> (срок: 0 вечный лучше всех, коробка)
    for box, cps in sorted(costume.BOX.items()):
        name = items.get(box, {}).get('name', '')
        if not name:
            continue
        if cps and cps[0] in costume.COUPON:
            cname, _part, per = costume.COUPON[cps[0]]
            per = per or 0
            rank = (0 if per == 0 else 1, -per)
            if cname not in best or rank < best[cname][0]:
                best[cname] = (rank, box, per)
        elif '(' not in name:     # коробка с самими крыльями, вечная
            goods.append((MOUNT, box, 1, WING_BOX_GXP))
    for cname, (_r, box, per) in best.items():
        gxp = {0: COSTUME_BOX_GXP, 2592000: 500, 1209600: 300, 604800: 200}.get(per, 200)
        title = 'Коробка: ' + cname[:1].upper() + cname[1:]
        title += '' if per == 0 else f' ({per // 86400} дн.)'
        RENAME[box] = title
        goods.append((COSTUME, box, 1, gxp))
    order = {EV: 0, USE: 1, LIMIT: 2, PET: 3, MOUNT: 4, COSTUME: 5}
    goods.sort(key=lambda g: (order[g[0]], family(RENAME.get(g[1]) or items[g[1]]['name']), g[3]))
    return goods


def cp(s, n):
    b = s.encode('cp1251', 'replace')[:n - 1]
    return b + bytes(n - len(b))


def _fmt(n):
    return f'{n:,}'.replace(',', ' ')


def build_lod(goods, items, ib):
    """goods: dict(name, gxp, old, tab, blocks=[{mode A|O, items:[[id, min, max]]}])."""
    recs = bytearray(struct.pack('<i', len(goods)))
    table = {}
    for k, g in enumerate(goods, 1):
        sid = 1000 + k
        price = max(1, int(round(g['gxp'] * KARAT_PER_GXP)))
        first = g['blocks'][0]['items'][0]
        iid = first[0]
        single = len(g['blocks']) == 1 and g['blocks'][0]['mode'] == 'A' and len(g['blocks'][0]['items']) == 1
        cnt = first[1] if single and first[1] == first[2] else 1
        icon, row, col, desc = ib.get(iid, ('', 0, 0, ''))
        r = bytearray(REC)
        struct.pack_into('<IIII', r, 0, sid, price, 0, 0)
        # +0x14 нужен клиенту только для проверки «снаряжение?» и «Обзор»: у категорий 56/57/58/68
        # (костюмы, аватары оружия, крылья) «Купить» открывает окно выбора уровня/срока/опций
        # (таблицы itemMixed*, AMo 0x004cfcf3) — у аватаров оно пустое и купить нельзя. Для них 0:
        # обычное «Купить?», цена в списке видна; что выдать, сервер знает по номеру товара.
        shown = 0 if items.get(iid, {}).get('cat') in (56, 57, 58, 68) else iid
        struct.pack_into('<IIIIII', r, 0x10, g['tab'], shown, cnt, row, col, g['tab'])
        r[0x28:0x68] = cp(g['name'], 0x40)
        lines = []
        if single:
            lines.append(desc)
        else:
            for blk in g['blocks']:
                lines.append('Вы получите все предметы:' if blk['mode'] == 'A' else 'Вы получите один из предметов:')
                for i, a, z in blk['items']:
                    lines.append(f"- {items[i]['name']}" + (f' x{a}' if a == z and a > 1 else f' x{a}-{z}' if a != z else ''))
        lines.append('')
        lines.append(f'Цена: {_fmt(price)} карат' + (f' (было {_fmt(int(round(g["old"] * KARAT_PER_GXP)))})' if g.get('old') else ''))
        r[0x68:0x268] = cp(chr(10).join(x for x in lines if x is not None), 0x200)
        r[0x268:0x34c] = cp(icon, 0xe4)
        recs += r
        table[sid] = {'name': g['name'], 'price': price, 'tab': g['tab'], 'pid': g.get('pid'),
                      'item': iid, 'count': cnt, 'blocks': g['blocks']}
    return bytes(recs), table


def patch_strings():
    path = os.path.join(LOD, 'string.lod_rus')
    orig = path + '.orig'
    if not os.path.exists(orig):
        shutil.copy2(path, orig)
    raw = open(orig, 'rb').read()
    d = bytearray(decode(raw, 1))
    old = 'Вы приобрели %s за %d GXP.'.encode('cp1251')
    new = 'Вы приобрели %s за %d карат.'.encode('cp1251')
    i = d.find(old)
    if i < 0:
        return False
    # строка в записи фиксированной длины (1028 байт), хвост — нули: пишем поверх, без сдвига
    assert not any(d[i + len(old):i + len(new) + 1])
    n = len(d)
    d[i:i + len(new)] = new
    assert len(d) == n
    open(path, 'wb').write(encode(bytes(d), raw, 1))
    return True


def _ten(raw, enc):
    """CheckFileListW.ten (AMo 0x00720fba, ключ 0x42): расшифровка out = in - k, k += out;
    зашифровка обратная (in = out + k)."""
    k, out = 0x42, bytearray()
    for c in raw:
        if enc:
            out.append((c + k) & 0xFF)
            k = (k + c) & 0xFF
        else:
            o = (c - k) & 0xFF
            out.append(o)
            k = (k + o) & 0xFF
    return bytes(out)


def update_checklist():
    """Клиент при запуске сверяет MD5 файлов IE_Lod со списком CheckFileListW.ten
    (AMo 0x00429c11 читает строки «путь<TAB>md5», 0x0042536c сверяет) и пишет «Обнаружен
    измененный файл» (строка 19004). Пересчитать суммы изменённых файлов -> список исправленных."""
    import hashlib
    path = os.path.join(ROOT, 'CheckFileListW.ten')
    if not os.path.exists(path + '.orig'):
        shutil.copy2(path, path + '.orig')
    lines = _ten(open(path, 'rb').read(), False).decode('cp1251').split('\r\n')
    fixed = []
    for n, l in enumerate(lines):
        if '\t' not in l:
            continue
        rel, h = l.split('\t', 1)
        f = os.path.join(ROOT, rel.lstrip('/'))
        if os.path.exists(f):
            md = hashlib.md5(open(f, 'rb').read()).hexdigest()
            if md != h.strip().lower():
                lines[n] = rel + '\t' + md
                fixed.append(rel)
    if fixed:
        open(path, 'wb').write(_ten('\r\n'.join(lines).encode('cp1251'), True))
    return fixed


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    items = {int(k): v for k, v in json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8')).items()}
    _ap = os.path.join(ROOT, 'server', 'accounts.json')
    acc = json.load(open(_ap, encoding='utf-8')) if os.path.exists(_ap) else {}   # чистая установка: нет
    ib = item_base()
    import gxp_match
    if os.path.exists(gxp_match.TSV):          # настоящий каталог сайта (снят из браузера)
        goods, skipped = gxp_match.load(items)
        print(f'каталог сайта: {len(goods)} товаров, нет в клиенте: {len(set(skipped))} названий')
    else:                                      # запасной: что было в GXP-рюкзаках + коробки
        gxp_ids = {i for chars in acc.values() if isinstance(chars, list)
                   for ch in chars if isinstance(ch, dict) for i, _n in ch.get('gxp', [])}
        goods = [{'name': RENAME.get(iid) or items[iid]['name'], 'gxp': gxp, 'old': None, 'tab': tab,
                  'blocks': [{'mode': 'A', 'items': [[iid, cnt, cnt]]}]}
                 for tab, iid, cnt, gxp in catalog(items, gxp_ids)]
        for g in goods:
            g['gxp'] /= 100.0                  # оценки были в «GXP×100»
    plain, table = build_lod(goods, items, ib)
    path = os.path.join(LOD, 'CashShop.lod_rus')
    if not os.path.exists(path + '.orig'):
        shutil.copy2(path, path + '.orig')
    like = open(path + '.orig', 'rb').read()
    enc = encode(plain, like, 1)
    assert decode(enc, 1) == plain
    open(path, 'wb').write(enc)
    json.dump(table, open(os.path.join(ROOT, 'data', 'cashshop.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    s = patch_strings()
    print('CheckFileListW.ten: пересчитаны суммы', update_checklist())
    tabs = {}
    for g in goods:
        tabs[g['tab']] = tabs.get(g['tab'], 0) + 1
    print(f'{len(goods)} товаров (по вкладкам {tabs}) -> {path}; строка покупки: {"исправлена" if s else "не найдена"}')
    no_icon = [g['name'] for g in goods if not ib.get(g['blocks'][0]['items'][0][0], ('',))[0]]
    print('без иконки:', len(no_icon), no_icon[:5])


if __name__ == '__main__':
    main()
