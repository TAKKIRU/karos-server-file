"""Характеристики предметов из itemAttr.lod_rus -> data/item_stats.json.

Запись (124/125 байт, выравнивания нет — ищем перебором): u32 id, u32 уровень
заточки, u32 ?, затем 14 double:
  [0] физ. урон мин  [1] физ. урон макс  [2] маг. урон мин  [3] маг. урон макс
  [4] скорость оружия (меч 1.1, кинжал 1.57)  [5] 10 (у оружия)  [6] физ. защита
  [7..13] прочее (не снято)
Окно персонажа: «Физ. атака 9 (+2) / 15 (+8)» = база + [0]/[1] Малого меча (2.68/8.08);
«Защита: 12» у Ботинок богомольца = [6].
Пишем только заточку 0: {id: [14 чисел]}.

Запуск: python tools/item_stats.py
"""
import json, math, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemAttr.lod_rus')
OUT = os.path.join(ROOT, 'data', 'item_stats.json')


def scan(d, ids):
    out = {}
    unp = struct.Struct('<3I').unpack_from
    for o in range(8, len(d) - 124):
        iid, lv, x = unp(d, o)
        if lv != 0 or x > 64 or iid not in ids or iid in out:
            continue
        v = struct.unpack_from('<14d', d, o + 12)
        if all(math.isfinite(a) and abs(a) < 1e7 for a in v) and any(v):
            out[iid] = [round(a, 3) for a in v]
    return out


def scan_enchant(d, ids):
    """{id: {заточка: [14 чисел]}} — все уровни заточки (снаряжение)."""
    out = {}
    unp = struct.Struct('<3I').unpack_from
    for o in range(8, len(d) - 124):
        iid, lv, x = unp(d, o)
        if lv > 20 or x > 64 or iid not in ids or lv in out.get(iid, {}):
            continue
        v = struct.unpack_from('<14d', d, o + 12)
        if all(math.isfinite(a) and abs(a) < 1e7 for a in v) and any(v):
            out.setdefault(iid, {})[lv] = [round(a, 3) for a in v]
    return out


if __name__ == '__main__':
    items = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
    raw = decode(open(SRC, 'rb').read(), 0)
    gear = {int(k) for k, v in items.items() if v.get('kind') == 1}
    ench = scan_enchant(raw, gear)
    json.dump({str(k): {str(a): b for a, b in sorted(v.items())} for k, v in sorted(ench.items())},
              open(os.path.join(ROOT, 'data', 'item_stats_enchant.json'), 'w'), separators=(',', ':'))
    print(f'заточка: {len(ench)} предметов -> data/item_stats_enchant.json')
    fx = json.load(open(os.path.join(ROOT, 'data', 'skill_effects.json')))
    esk = {}
    unp = struct.Struct('<3I').unpack_from
    for o in range(8, len(raw) - 124):
        iid, lv, x = unp(raw, o)
        if lv > 20 or x > 64 or iid not in ench or lv not in ench[iid]:
            continue
        sk = struct.unpack_from('<I', raw, o + 84)[0]
        if sk and str(sk) in fx and str(lv) not in esk.get(str(iid), {}):
            esk.setdefault(str(iid), {})[str(lv)] = sk
    json.dump(esk, open(os.path.join(ROOT, 'data', 'item_equip_skill.json'), 'w'), separators=(',', ':'))
    print(f'навыки снаряжения: {len(esk)} предметов; крылья 999900058: {esk.get("999900058")}')
    res = scan(raw, {int(k) for k in items})
    json.dump({str(k): v for k, v in sorted(res.items())}, open(OUT, 'w'), separators=(',', ':'))
    print(f'{len(res)} предметов -> {OUT}')
