"""Точки мобов интерьерных карт (подземелья, лаборатории, корабль…) из файлов объектов .mo.

У карт из одного меша (Map/<карта>/Map/*.m) нет файлов .npc: мобы стоят в объектах карты
Map/<карта>/Object/<имя>.mo. Запись объекта (151 байт у мобов):
  u32 тип (7 — точка моба), u32 номер точки (1001, 1002 … — его клиент ждёт в 04/02 +0x44),
  …, 3×f32 позиция (x, высота, z) @+84, …, u32 1, строка модели _OB (u32 длина), u32 вид моба.
Проверено: N_laboratory_exp.mo — Чёрный маг 1060009 в точке 1001 (2776.8, 206.7, 2930.9);
мобы подземелий в записях оригинала приходят с такими же номерами точек.

Несколько .mo у одной карты (лаборатория: обычная и «другого мира»; Extreme/T_darkcliff/
катакомбы по уровням) — файл для номера карты выбирается в FILE_FOR (сверено с квестами и
записями), иначе — основной файл <карта>.mo.

Выход: data/spawns_mo.json {номер карты: [{model, id, x, y, z, tile: 0, uidx}]}
(формат spawns.json; сервер берёт его для карт без своих точек спавна).
Запуск: python tools/mo_spawns.py
"""
import glob, json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, 'data', 'spawns_mo.json')

# номер карты -> файл .mo, если у карты их несколько
FILE_FOR = {
    19012: 'N_laboratory_exp.mo',      # маги (квесты «Некромант»: 1060009–1060011, королева)
    19013: 'N_laboratory_exp2.mo',     # големы (квесты «Другой мир»: 1060017–1060022, король)
}


def file_for(mid, name):
    """Вариант .mo по номеру карты. Сверено с записями оригинала (номера точек и виды мобов):
    29014 -> catacomb02event.mo, 29614 -> _60LV, 29516 -> catacombBelltower_50LV.
    Катакомбы/колокольня 29L14, 29L16: L — десятки уровня (0 — основной файл).
    Extreme 100AA0BB, T_darkcliff 200AA0BB: AA — нижний уровень (Extreme_20 … _90;
    у T_darkcliff 50 — основной файл)."""
    if mid in FILE_FOR:
        return FILE_FOR[mid]
    if name in ('catacomb02event', 'catacombBelltower') and 29000 <= mid < 30000:
        lv = (mid // 100) % 10
        return f'{name}_{lv}0LV.mo' if lv else f'{name}.mo'
    if name == 'Extreme' and mid >= 1000000:
        return f'Extreme_{(mid // 100) % 1000}.mo'
    if name == 'T_darkcliff' and mid >= 2000000:
        lo = (mid // 100) % 1000
        return 'T_darkcliff.mo' if lo == 50 else f'T_darkcliff_{lo}.mo'
    return name + '.mo'


def parse_mo(path):
    d = open(path, 'rb').read()
    out = []
    for m in re.finditer(rb'\x07\x00\x00\x00', d):
        p = m.start()
        if p + 140 > len(d):
            break
        uidx = struct.unpack_from('<I', d, p + 4)[0]
        if not 1 <= uidx <= 100000:
            continue
        x, h, z = struct.unpack_from('<3f', d, p + 84)
        if not (0 < x < 100000 and 0 < z < 100000 and -20000 < h < 20000):
            continue
        if struct.unpack_from('<I', d, p + 112)[0] != 1:
            continue
        n = struct.unpack_from('<I', d, p + 116)[0]
        if not 4 < n < 64:
            continue
        model = d[p + 120:p + 120 + n].rstrip(b'\0').decode('latin1')
        if not model.lower().endswith('._ob'):
            continue
        nid = struct.unpack_from('<I', d, p + 120 + n)[0]
        if not 1000 <= nid <= 99999999:
            continue
        out.append({'model': model[:-4], 'id': nid, 'x': round(x, 1), 'y': round(h, 1),
                    'z': round(z, 1), 'tile': 0, 'uidx': uidx})
    return out


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    maps = json.load(open(os.path.join(ROOT, 'data', 'maplist.json'), encoding='utf-8'))
    res = {}
    for v in maps:
        name, mid = v['name'], v['head'][1]
        if not glob.glob(os.path.join(ROOT, 'ResUnpak', 'Map', name, 'Map', '*.m')):
            continue                                    # карта из тайлов — точки в .npc
        odir = os.path.join(ROOT, 'ResUnpak', 'Map', name, 'Object')
        files = {os.path.basename(f).lower(): f for f in glob.glob(os.path.join(odir, '*.mo'))}
        want = file_for(mid, name).lower()
        f = files.get(want) or (next(iter(files.values())) if len(files) == 1 else None)
        if not f:
            print(f'{mid} {name}: нет {want}')
            continue
        pts = parse_mo(f)
        if pts:
            res[str(mid)] = pts
        kinds = {}
        for s in pts:
            kinds[s['id']] = kinds.get(s['id'], 0) + 1
        print(f'{mid} {name} <- {os.path.basename(f)}: {len(pts)} точек, видов {len(kinds)}')
    json.dump(res, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print('->', OUT)


if __name__ == '__main__':
    main()
