"""Слепок комиссионки из записи (06/1e S->C) -> data/commission_snapshot.json.

Лот: см. parse_lots (сверено с записью оригинала, все числа BE).
Запуск: python tools/cap_commission.py data/captures/orig_1.jsonl
"""
import json, struct, sys


def parse_lots(p, start=52):
    """Лот (запись оригинала): u32 лот, u32 предмет, u32 заточка, u32 время выставления,
    u32 id продавца, u32 0, u32 кол-во, 6×u32 вставки/опции, u64 цена, продавец\0,
    u32 срок (unix), затем 95 байт (нули/служебное)."""
    out, o = [], start
    n = struct.unpack_from('>I', p, 42)[0]
    for _ in range(n):
        lot, item, ench, reg, sid, _z, cnt = struct.unpack_from('>7I', p, o)
        opts = list(struct.unpack_from('>6I', p, o + 28))
        price = struct.unpack_from('>Q', p, o + 52)[0]
        e = p.index(bytes(1), o + 60)
        raw = p[o + 60:e]
        try:
            seller = raw.decode('utf-8')
        except UnicodeDecodeError:
            seller = raw.decode('cp1251', 'replace')
        exp = struct.unpack_from('>I', p, e + 1)[0]
        tail = p[e + 5:e + 1 + 95]            # 91 байт; последние 23 = запись предмета +124..+146
        o = e + 1 + 12 + 8 + 8 + 36 + 8 + 1 + 22
        out.append({'lot': lot, 'item': item, 'enchant': ench, 'count': cnt, 'price': price,
                    'seller': seller, 'registered': reg, 'expire': exp, 'opts': opts,
                    'tail': tail.hex()})
    return out, o


def main(*paths):
    items = json.load(open('data/items.json', encoding='utf-8'))
    lots, totals = {}, {}
    for l in (line for path in paths for line in open(path)):
        x = json.loads(l)
        if x['op'] == '06/1e' and x['dir'] == 'S':
            p = bytes.fromhex(x['hex'])
            cat = struct.unpack_from('>I', p, 8)[0]
            got, end = parse_lots(p)
            totals[cat] = struct.unpack_from('>I', p, 46)[0]
            for g in got:
                g['cat'] = cat
                g['name'] = items.get(str(g['item']), {}).get('name')
                lots[g['lot']] = g
    json.dump(list(lots.values()), open('data/commission_snapshot.json', 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    import collections
    by = collections.Counter(g['cat'] for g in lots.values())
    for c in sorted(totals):
        print(f'категория {c}: снято {by[c]} из {totals[c]} лотов')
    print('всего лотов', len(lots), 'неизвестных клиенту', sum(1 for g in lots.values() if not g['name']))


if __name__ == '__main__':
    main(*sys.argv[1:])
