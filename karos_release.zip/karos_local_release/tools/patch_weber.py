"""Вылет при нажатии на GXP-магазин: заглушка IsValidWindow (№7) в weberforclntv2.dll.

weberforclntv2.dll — наш перехватчик connect (-> 127.0.0.1), подложенный вместо DLL GameXP.
AMo импортирует из неё по номерам только №4 (Term) и №7 (IsValidWindow). У GameXP №7
двойная (Karos Genesis/WeberForClntV2_real.dll):
  eax != 0 — IsValidWindow(hwnd) из WeberForClientNHN, stdcall, 1 аргумент (AMo 0x4210e7);
  eax == 0 — открыть веб-магазин: (0, 0xc, 0, url) -> shop_api_v2!shopAPIneedOpenGameShop(url),
             снимает 4 аргумента (AMo 0x481cd9: push url,0,0xc,0; xor eax,eax; call [№7]; ret 4).
Наша заглушка была «xor eax,eax; ret» без очистки стека: после неё `ret 4` клиента брал
адрес возврата из запушенного 0 — переход на адрес 0 (WER: fault offset 0x00000000).

Патч: test eax,eax / jnz +5 / xor eax,eax / ret 10h / xor eax,eax / ret 4.
Магазин локально ничего не открывает (сайт GameXP без настоящей сессии бесполезен).

Запуск (игра должна быть закрыта): python tools/patch_weber.py
"""
import os, shutil, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DLL = os.path.join(ROOT, 'weberforclntv2.dll')
OFF = 0x880                        # RVA 0x1480: экспорт №7 (и №8 IsValidWindow@0)
OLD = bytes.fromhex('5589e531c05dc3')
NEW = bytes.fromhex('85c0' '7505' '31c0' 'c21000' '31c0' 'c20400' '9090')


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = bytearray(open(DLL, 'rb').read())
    cur = bytes(data[OFF:OFF + len(NEW)])
    if cur == NEW:
        print('уже исправлено')
        return 0
    if cur[:len(OLD)] != OLD:
        print('неизвестные байты по 0x880:', cur.hex(' '))
        return 1
    bak = DLL + '.bak'
    if not os.path.exists(bak):
        shutil.copy2(DLL, bak)
    data[OFF:OFF + len(NEW)] = NEW
    open(DLL, 'wb').write(data)
    print('исправлено, копия:', bak)
    return 0


if __name__ == '__main__':
    sys.exit(main())
