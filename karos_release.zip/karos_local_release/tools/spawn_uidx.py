"""Номер точки спавна (UniqIndex) для каждого моба -> поле 'uidx' в data/spawns.json.

Клиент создаёт моба из пакета 04/02 НЕ по id шаблона: он клонирует объект точки
спавна, загруженный вместе с картой (обработчик 0x00667a45: payload+0x44 ->
поиск сущности с этим номером -> клон). Номер — порядковый, с 1, при обходе
файлов ResUnpak/Map/<карта>/Map/<карта><тайл>.npc по возрастанию номера тайла.
Проверено по дампу: на berneo точка 460 = малый паук (1001801), как в шаблоне.

Формат .npc: u32 число ячеек; ячейка = 'CPNT', u32 версия, u32 число записей;
запись = 3 строки (u32 длина + байты: путь .mdl, имя _OB, имя), u32 id шаблона,
3×f32 позиция (x, высота, z), остальное до 68 байт после строк.

Запуск: python tools/spawn_uidx.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MAPS = os.path.join(ROOT, 'ResUnpak', 'Map')
SPAWNS = os.path.join(ROOT, 'data', 'spawns.json')
FIXED = {5: 40, 6: 68}   # байт после трёх строк, по версии ячейки


def _lstr(d, o):
    n = struct.unpack_from('<I', d, o)[0]
    return d[o + 4:o + 4 + n].rstrip(b'\0').decode('latin1'), o + 4 + n


def parse_npc(path):
    d = open(path, 'rb').read()
    o, out = 4, []
    for _ in range(struct.unpack_from('<I', d, 0)[0]):
        if d[o:o + 4] != b'CPNT':
            raise ValueError(f'{path}: нет CPNT @{o}')
        ver, n = struct.unpack_from('<II', d, o + 4)
        if n and ver not in FIXED:
            raise ValueError(f'{path}: версия {ver} не поддержана')
        o += 12
        for _ in range(n):
            _, o = _lstr(d, o)
            _, o = _lstr(d, o)
            nm, o = _lstr(d, o)
            nid = struct.unpack_from('<I', d, o)[0]
            x, h, z = struct.unpack_from('<3f', d, o + 4)
            out.append((nid, nm, x, h, z))
            o += FIXED[ver]
    return out


def map_points(name):
    """[(uidx, tile, id, x, z)] в порядке клиента."""
    mdir = os.path.join(MAPS, name, 'Map')
    if not os.path.isdir(mdir):
        return []
    tiles = []
    for fn in os.listdir(mdir):
        m = re.fullmatch(re.escape(name) + r'(\d+)\.npc', fn, re.I)
        if m:
            tiles.append((int(m.group(1)), os.path.join(mdir, fn)))
    pts, k = [], 0
    for tile, path in sorted(tiles):
        for nid, nm, x, h, z in parse_npc(path):
            k += 1
            pts.append((k, tile, nid, x, z))
    return pts


def main():
    spawns = json.load(open(SPAWNS, encoding='utf-8'))
    total = hit = 0
    for name, lst in spawns.items():
        try:
            pts = map_points(name)
        except ValueError as e:
            print('  пропуск', name, '-', e)
            pts = []
        index = {}
        for k, tile, nid, x, z in pts:
            index.setdefault((tile, nid, round(x, 1), round(z, 1)), k)
        for s in lst:
            total += 1
            k = index.get((s.get('tile', 0), s['id'], round(s['x'], 1), round(s['z'], 1)))
            if k:
                s['uidx'] = k
                hit += 1
            else:
                s.pop('uidx', None)
    json.dump(spawns, open(SPAWNS, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'uidx: {hit}/{total} точек сопоставлено')


if __name__ == '__main__':
    main()
