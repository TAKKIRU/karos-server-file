"""Таблица расхода маны навыков из skillLevel.lod -> data/skill_mp.json.

Запись skillLevel (переменной длины, ~427 байт): u32 id, u32 уровень, ...,
u32 @+12 == 1 (у навыков существ 81xxx / 94000xxx — 0), double @+40 = расход MP (растёт с уровнем: 11001 -> 2,3,3,4,4;
3001 -> 6,8,8,9,11). Поле +104 похоже на дальность (165 у стрелков, 20 у
ближнего боя), +80 — на перезарядку в секундах.

Запуск: python tools/skill_mp.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'skillLevel.lod_en')
OUT = os.path.join(ROOT, 'data', 'skill_mp.json')


# Метка записи: double 100.0 на +244 (u32 0x40590000 на +248). У части навыков классов +12 == 0, а +8 —
# требуемый уровень (10…40): 2003…, 2800…, 6806 «замедление» (6 с), 6811 (30 с), 16002 (3 с) — длительности
# совпадают с 05/09 записей оригинала (remain3_persons, orig_hl_Pers4x); их берём по метке.
MARK = 0x40590000


def creature(sid):
    """Навыки существ (облики свитков трансформации 81xxx, 94000xxx; transformSkill.lod)."""
    return 80000 <= sid <= 99999 or 94000000 <= sid <= 94999999


def scan(L):
    mp = {}
    p = 4
    while p < len(L) - 260:
        sid, lv = struct.unpack_from('<II', L, p)
        f12 = struct.unpack_from('<I', L, p + 12)[0]
        f8 = struct.unpack_from('<I', L, p + 8)[0]
        marked = struct.unpack_from('<I', L, p + 248)[0] == MARK
        if 1 <= lv <= 60 and ((1000 <= sid <= 40000 and (f12 == 1 or (f12 == 0 and f8 <= 200 and marked)))
                              or (creature(sid) and f12 in (0, 1)
                                  and struct.unpack_from('<d', L, p + 164)[0] == 1.0)):
            c = struct.unpack_from('<d', L, p + 40)[0]
            if 0 <= c <= 5000 and c == int(c):
                mp.setdefault(str(sid), {})[str(lv)] = int(c)
                p += 300
                continue
        p += 1
    return mp


if __name__ == '__main__':
    mp = scan(decode(open(SRC, 'rb').read(), 0))
    json.dump(mp, open(OUT, 'w', encoding='utf-8'), indent=0, sort_keys=True)
    print(f'{len(mp)} skills -> {OUT}')
