"""Порталы между картами -> data/warp_gates.json.

mapWarpGate.lod_rus (режим 1): u32 число, записи по 1093 байта:
  +0 id ворот  +4 карта  +8..+40 4×double: прямоугольник x1,z1,x2,z2
  +60 id точки назначения  +68 название (cp1251)
mapWarpTargetPos.lod_rus (режим 1), запись (1065 байт) от id точки:
  +0 id (= карта*100 + n)  +4 карта  +8 double x  +16 double z  +40 название
Клиент, войдя в прямоугольник ворот, шлёт 04/06: +0 id ворот BE32, +4 код BE16.

Запуск: python tools/warps.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'warp_gates.json')
GATE_REC = 1093
TARGET_REC = 1065


def _ids(d):
    """Позиции записей: u32 id, u32 карта, где id = карта*100+n или карта*10+n
    (телепорты NPC: 190021 = Люпинель на карте 19002)."""
    out = []
    for i in range(4, len(d) - 48):
        a, b = struct.unpack_from('<II', d, i)
        if 10_000 <= b <= 99_999 and (a // 100 == b or a // 10 == b):
            out.append(i)
    return out


def _name(d, o):
    return d[o:o + 100].split(b'\0')[0].decode('cp1251', 'replace').strip()


def main():
    g = decode(open(os.path.join(LOD, 'mapWarpGate.lod_rus'), 'rb').read(), 1)
    t = decode(open(os.path.join(LOD, 'mapWarpTargetPos.lod_rus'), 'rb').read(), 1)
    targets = {}
    # записи подряд по 1065 байт с +4 (раньше искали по шаблону id = карта*100+n
    # и теряли точки вроде 2970200 «караульная башня» на карте 29502)
    for k in range(struct.unpack_from('<I', t, 0)[0]):
        i = 4 + k * TARGET_REC
        if i + 48 > len(t):
            break
        tid, m = struct.unpack_from('<II', t, i)
        x, z = struct.unpack_from('<2d', t, i + 8)
        if tid and 10_000 <= m <= 99_999:
            targets.setdefault(tid, {'map': m, 'x': x, 'z': z, 'name': _name(t, i + 40)})
    for i in _ids(t):                                   # на всякий случай — и старым способом
        tid, m = struct.unpack_from('<II', t, i)
        x, z = struct.unpack_from('<2d', t, i + 8)
        targets.setdefault(tid, {'map': m, 'x': x, 'z': z, 'name': _name(t, i + 40)})
    gates = {}
    for k in range(struct.unpack_from('<I', g, 0)[0]):     # записи по 1093 байта с +4
        i = 4 + k * GATE_REC
        if i + GATE_REC > len(g):
            break
        gid, m = struct.unpack_from('<II', g, i)
        box = [round(v, 1) for v in struct.unpack_from('<4d', g, i + 8)]
        tgt = struct.unpack_from('<I', g, i + 60)[0]
        if tgt in targets:
            gates.setdefault(gid, {'map': m, 'box': box, 'target': tgt, 'name': _name(g, i + 68)})
    # mapWarp (режим 1): u32 число; записи [NPC, ?, точка, цена, ?, ...] — меню телепортёра
    w = decode(open(os.path.join(LOD, 'mapWarp.lod_rus'), 'rb').read(), 1)
    npc_warps = {}
    for i in range(4, len(w) - 16):
        npc, one, tid, price = struct.unpack_from('<4i', w, i)
        if 9_000_000 <= npc <= 9_999_999 and one == 1 and tid in targets and 0 <= price < 10_000_000:
            npc_warps.setdefault(str(tid), price)
    json.dump({'gates': gates, 'targets': targets, 'prices': npc_warps},
              open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'направлений у телепортёров: {len(npc_warps)}')
    print(f'ворот {len(gates)}, точек {len(targets)} -> {OUT}')
    for k in list(gates)[:3] + [1900306]:
        v = gates.get(k)
        if v:
            print(' ', k, v, '->', targets[v['target']])


if __name__ == '__main__':
    main()
