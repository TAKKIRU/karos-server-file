"""Высоты рельефа открытых карт из файлов .ter -> сервер (server/terrain.py читает их сам).

Map/<карта>/Map/<карта><тайл>.ter: 'CEST', u32 1, затем сетка 129×129 f32 высот (строки по z,
шаг 40 = 5120/128 — тайл 5120×5120), дальше прочие данные (нормали, текстуры). Тайл t —
мировое смещение ((t % 64) * 5120, (t // 64) * 5120), как у точек спавна в .npc.
Проверено: высоты точек спавна (.npc) совпадают с билинейной интерполяцией сетки (см. main).

Запуск (проверка): python tools/terrain_check.py
"""
import json, os, statistics, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, 'server'))
import terrain as T                                          # noqa: E402


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sp = json.load(open(os.path.join(ROOT, 'data', 'spawns.json'), encoding='utf-8'))
    for name, pts in sorted(sp.items()):
        err = []
        for s in pts:
            t = s.get('tile', 0)
            h = T.height(name, s['x'] + (t % 64) * 5120, s['z'] + (t // 64) * 5120)
            if h is not None:
                err.append(abs(h - s['y']))
        if err:
            err.sort()
            print(f'{name}: {len(err)}/{len(pts)} точек, ошибка медиана {statistics.median(err):.1f}, '
                  f'90% {err[int(len(err) * .9)]:.1f}')
        else:
            print(f'{name}: нет .ter')


if __name__ == '__main__':
    main()
