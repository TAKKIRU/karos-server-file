"""Супер-навыки: skillTreeSuper.lod_rus + цены уровней из skillLevel -> data/super_skills.json.

skillTreeSuper (режим 1): число (84), записи по 9 байт: u16 группа классов (100 … 800),
  u8 ряд (0..2), u32 навык, u16 ветка (1/2 — «1-я/2-я профессия»; пассивный ли навык — по
  skill_effects 'k'). По 12 навыков на группу.
skillLevel (режим 0): запись (u32 навык, u32 уровень, u32 очки флетты на этот уровень, …):
  6801: ур.1 — 1, ур.2 — 865, ур.3 — 5530, ур.4 — 7350, ур.5 — 8650.
skillEnchant (режим 1): число (173), записи по 39 байт: +0 камень (предмет 600101…631105, он же
  номер опции в 05/0c), +4 u8 вид (5 — пассивный камень, 6 — для активного навыка), +5 u8 ряд,
  +6 u8 ступень (малый…легендарный). Эффект камня — skillData с тем же номером
  (600101: характеристика 1 +2; 600602: тип 7 +20) — tools/skill_effects.skill_data.
  У камней «Атака» (6301xx…6311xx: шок, замедление, снижение защиты…) эффекта в skillData нет —
  число берётся из описания предмета («шок на 3 с», «уменьшение защиты на 30%»,
  «перезарядка снижена на 5 с»): поле 'n'.
Пакеты — server/superskill.py.

Запуск: python tools/super_table.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                    # noqa: E402
import skill_effects                                            # noqa: E402
import items as I                                               # noqa: E402


def descriptions(ids):
    """{камень: первое число из описания предмета (itemBase, cp1251)}."""
    d = decode(open(I.SRC, 'rb').read(), 0)
    out = {}
    for sid in ids:
        m = re.search(re.escape(struct.pack('<iI', sid, 1)), d)
        if not m:
            continue
        txt = [x.decode('cp1251', 'replace')
               for x in re.findall(rb'[\xc0-\xff][\x20-\xff]{10,}', d[m.start() + 64:m.start() + 1500])]
        desc = next((t for t in txt if 'При ' in t), '')
        n = re.search(r'(\d+(?:,\d+)?)\s*(%|с\.)', desc)
        if n:
            out[sid] = float(n.group(1).replace(',', '.'))
    return out


LOD =os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'super_skills.json')


def main():
    p = decode(open(os.path.join(LOD, 'skillTreeSuper.lod_rus'), 'rb').read(), 1)
    tree = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        grp, row, sid, kind = struct.unpack_from('<HBIH', p, 4 + 9 * k)
        tree.setdefault(str(grp), []).append([row, sid, kind])
    L = decode(open(os.path.join(LOD, 'skillLevel.lod_rus'), 'rb').read(), 0)
    cost = {}
    for rows in tree.values():
        for _row, sid, _k in rows:
            c = {}
            for lv in range(1, 31):
                m = re.search(re.escape(struct.pack('<II', sid, lv)), L)
                if not m:
                    break
                c[str(lv)] = struct.unpack_from('<I', L, m.start() + 8)[0]
            cost[str(sid)] = c
    p = decode(open(os.path.join(LOD, 'skillEnchant.lod_rus'), 'rb').read(), 1)
    data = skill_effects.skill_data(decode(open(os.path.join(LOD, 'skillData.lod_rus'), 'rb').read(), 0))
    items = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
    stones = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        sid, kind, row, tier = struct.unpack_from('<IBBB', p, 4 + 39 * k)
        if kind in (5, 6) and str(sid) in items:
            stones[str(sid)] = {'kind': kind, 'tier': tier,
                                'eff': [list(data[sid])] if sid in data else []}
    nums = descriptions([int(k) for k in stones])
    for k, v in stones.items():
        if int(k) in nums:
            v['n'] = nums[int(k)]
    json.dump({'tree': tree, 'cost': cost, 'stones': stones}, open(OUT, 'w', encoding='utf-8'),
              separators=(',', ':'))
    print(f'{len(stones)} камней супер-навыков, с эффектом {sum(1 for v in stones.values() if v["eff"])}')
    print(f'{sum(len(v) for v in tree.values())} супер-навыков в {len(tree)} группах -> {OUT}')
    for sid in ('2001', '6801', '16001'):
        print(' ', sid, cost.get(sid))


if __name__ == '__main__':
    main()
