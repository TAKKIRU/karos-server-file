"""Событийные подземелья в одиночку: EIDMain.lod_rus — режим события 0 вместо «отряд».

Клиент сам проверяет заявку на «Парящий остров» / «Демоническую башню» до отправки C 13/01 (AMo 0x0068aad0):
при режиме 1 (EIDMain поле 6 = 1) нужно быть лидером отряда и иметь рядом (радиус поле 9 × 10) не меньше
поле 8 игроков (остров 3, башня 2) — одному игроку окно отказывает и пакет не уходит. При режиме, отличном
от 1 и 2, остаётся только проверка билета (поле 7, «Билет на соревнование» 63057). Сервер (server/eid.py)
игроков не считает: одиночная команда.

Что делает: поле 6 всех записей EIDMain -> 0 (копия EIDMain.lod_rus.orig рядом), пересчитывает MD5 в
CheckFileListW.ten (иначе «Обнаружен измененный файл»). Повторный запуск ничего не портит.
Откат: вернуть EIDMain.lod_rus.orig и CheckFileListW.ten.orig.

Запуск: python -X utf8 tools/patch_eid_solo.py
"""
import os, shutil, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode, encode                              # noqa: E402

PATH = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'EIDMain.lod_rus')
REC, MODE = 0xd4, 6 * 4


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    if not os.path.exists(PATH):
        print('нет', PATH)
        return 1
    if not os.path.exists(PATH + '.orig'):
        shutil.copy2(PATH, PATH + '.orig')
    like = open(PATH + '.orig', 'rb').read()
    d = bytearray(decode(like, 1))
    n = struct.unpack_from('<I', d, 0)[0]
    changed = 0
    for i in range(n):
        o = 4 + i * REC + MODE
        if struct.unpack_from('<i', d, o)[0] in (1, 2):
            struct.pack_into('<i', d, o, 0)
            changed += 1
    enc = encode(bytes(d), like, 1)
    assert decode(enc, 1) == bytes(d), 'шифр: обратное преобразование не сошлось'
    open(PATH, 'wb').write(enc)
    import cashshop
    fixed = cashshop.update_checklist()
    print(f'EIDMain: режим «отряд» снят у {changed} из {n} событий; CheckFileListW.ten: {fixed or "без изменений"}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
