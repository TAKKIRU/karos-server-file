"""Классы и расы из клиента -> data/class_info.json.

classRace.lod (режим 1): u32 число, записи переменной длины: u32 раса, u32 0, 5 × u32 стартовые
атрибуты (сила, ловкость, живучесть, интеллект, мудрость), имя (cp1251). Человек 7/5/7/6/5,
Тень 4/8/5/7/6, Сероин 5/7/5/7/6, Ванисиец 7/4/7/6/6 …
classInfo.lod (режим 1, записи переменной длины; якорь — пара float 65.0, 10.0 после 13 × u32):
+0 класс, +4 раса, +8 номер базового класса, +12 0, +16 5 × u32 прибавка атрибутов класса, …,
после пары float: +0 ?, +4 класс-родитель, …; дальше название и оружие.

Проверено записями оригинала (08/02 +6 — своя база атрибутов):
  паладин 200 ур.5 (orig_1): Человек + 200 = 9/7/10/7/7;
  221 ур.60 (remain3): Человек + 200 + 3 × 220 + 221 = 21/12/18/11/18;
  612 ур.60 (remain3): Сероин + 600 + 3 × 610 + 612 = 10/15/10/23/22;
  811 ур.62 (Pers4x): Ванисиец + 800 + 3 × 810 + 811 = 19/16/17/11/17;
  311 ур.89 (remain3): Тень + 300 + 3 × 310 + 3 × 311 = 19/29/15/14/23.
То есть прибавка класса начисляется при каждой ступени classChange: смена класса (ур.10 и 45) и
повышение ранга (25/40 и 60/75) — прибавкой того класса, в который перешли.

Запуск: python tools/class_table.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'class_info.json')


def races():
    d = decode(open(os.path.join(LOD, 'classRace.lod_rus'), 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    out = {}
    for m in re.finditer(rb'[\xc0-\xff][\xc0-\xff \-]{2,}\x00', d):
        o = m.start()
        rid, z, *attrs = struct.unpack_from('<7I', d, o - 28)
        if 1 <= rid <= n and z == 0 and all(1 <= a <= 20 for a in attrs):
            out[rid] = {'name': m.group()[:-1].decode('cp1251'), 'attrs': attrs}
    return out


def classes():
    d = decode(open(os.path.join(LOD, 'classInfo.lod_rus'), 'rb').read(), 1)
    pat = struct.pack('<2f', 65.0, 10.0)
    out = {}
    o = d.find(pat)
    while o >= 0:
        cls, race, base, z, *rest = struct.unpack_from('<13I', d, o - 52)
        bonus = rest[:5]
        parent = struct.unpack_from('<I', d, o + 12)[0]
        names = [m.group().decode('cp1251') for m in
                 re.finditer(rb'[\xc0-\xff][\xc0-\xff \-]{2,}', d[o + 8:o + 400])][:2]
        if 100 <= cls <= 900 and z == 0:
            out[cls] = {'race': race, 'bonus': bonus, 'parent': parent,
                        'name': names[0] if names else '', 'weapon': names[1] if len(names) > 1 else ''}
        o = d.find(pat, o + 1)
    return out


if __name__ == '__main__':
    R, C = races(), classes()
    json.dump({'races': R, 'classes': C}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'{len(R)} рас, {len(C)} классов -> {OUT}')
    for c in (100, 200, 300, 400, 500, 600, 700, 800):
        v = C.get(c)
        if v:
            r = R.get(v['race'], {})
            print(' ', c, v['name'], r.get('name'), [a + b for a, b in zip(r.get('attrs', [0] * 5), v['bonus'])])
