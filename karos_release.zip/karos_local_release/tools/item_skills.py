"""Предмет -> навык, который он накладывает (баф зелья, «Дух воина» и т.п.) -> data/item_skills.json.

itemAttr.lod_rus (режим 0): запись предмета u32 id, u32 заточка, u32 ?, ..., +84 u32 — id
навыка-эффекта (сверено с записью Karos Genesis: «Зелье ветра» 999900032 -> 30332,
«Дух земли ур.1» 63055 -> 30329, «Цветок удачи» 99992 -> 30318, «Платиновое зелье
опыта» 140005 -> 6000004; зелья восстановления — навык с id самого предмета).
Длительность — у навыка (skillLevel +140).

Запуск: python tools/item_skills.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemAttr.lod_rus')
SKL = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'skillLevel.lod_rus')
OUT = os.path.join(ROOT, 'data', 'item_skills.json')
OFF = 84


def skill_ids():
    L = decode(open(SKL, 'rb').read(), 0)
    out, p = set(), 8
    while p < len(L) - 200:
        sid, lv, z, one = struct.unpack_from('<4I', L, p)
        if 1000 <= sid <= 99_999_999 and 1 <= lv <= 60 and z == 0 and one == 1:
            out.add(sid)
            p += 300
            continue
        p += 1
    return out


def main():
    # только расходники (зелья, бафы, камни): у снаряжения на +84 лежит половина double
    items = {int(k) for k, v in json.load(open(os.path.join(ROOT, 'data', 'items.json'),
                                               encoding='utf-8')).items() if v.get('kind') in (2, 8, 9)}
    d = decode(open(SRC, 'rb').read(), 0)
    out = {}
    unp = struct.Struct('<3I').unpack_from
    for o in range(8, len(d) - OFF - 4):
        iid, lv, x = unp(d, o)
        if lv != 0 or x > 64 or iid not in items or iid in out:
            continue
        sk = struct.unpack_from('<I', d, o + OFF)[0]
        if 1000 <= sk < 100_000_000:
            out[iid] = sk
    json.dump({str(k): v for k, v in sorted(out.items())}, open(OUT, 'w'), separators=(',', ':'))
    print(f'{len(out)} предметов с навыком -> {OUT}')
    for k in (999900032, 63055, 99992, 140005, 54616, 54208):
        print(' ', k, out.get(k))


if __name__ == '__main__':
    main()
