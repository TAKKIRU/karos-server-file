"""Шансы заточки из ItemEnchant.lod_rus -> data/enchant.json.

Режим 1: int число (65), записи по 32 байта:
  +0 u32 вид свитка (0 обычный, 1 — свиток Маркуса: в itemBase у него [28] = 2),
  +4 u32 уровень, на который точим (1..13), +8 u32 тип предмета (itemBase [5]: 1 оружие,
  2 броня, 25 крылья), +12 f64 шанс успеха, %, +20 f64 шанс неудачи без потерь, %,
  +28 u32 (растёт с уровнем 1..23; назначение не выяснено).
Остаток (100 − успех − «без потерь») — предмет уничтожается (если нет защиты).
Пример: обычный свиток, оружие, +4: 60% / 30% / 10% уничтожение; +13: 0.6% / 24% / 75.4%.

Запуск: python tools/enchant_table.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                    # noqa: E402

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'ItemEnchant.lod_rus')
OUT = os.path.join(ROOT, 'data', 'enchant.json')


def main():
    p = decode(open(SRC, 'rb').read(), 1)
    out = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        grade, lv, typ, ok, keep, x = struct.unpack_from('<3I2dI', p, 4 + 32 * k)
        out.setdefault(str(grade), {}).setdefault(str(typ), {})[str(lv)] = [ok, keep, x]
    json.dump(out, open(OUT, 'w', encoding='utf-8'), separators=(',', ':'))
    print(f'{sum(len(t) for g in out.values() for t in g.values())} строк -> {OUT}')


if __name__ == '__main__':
    main()
