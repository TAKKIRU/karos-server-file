"""Событийные подземелья (EID: «Парящий остров», «Демоническая башня») — таблицы клиента -> data/eid.json.

Клиент (AMo.exe) читает IE_LOD\\EIDMain/EIDCondition/EIDElement/EIDWarp/EIDString.lod (загрузчик 0x0068a846,
режим 1, размеры записей из кода 0x0068a54c…0x0068a64f: 0xd4, 0x2c, 0x16, 0x1c, 0xe0).

EIDMain (212 байт = 53 × i32), смысл полей — по коду клиента (проверка заявки 0x0068aad0, сообщения 0x00687ed6,
итоги 0x0068ba27) и по совпадению с EventInform (расписание):
  [0] номер события = карта (1002030 … Extreme, 2005060 … T_darkcliff), [1] карта, [2] NPC (9300291 Аска),
  [4]/[5] уровни, [6] режим (1 — отряд: клиент требует лидерство, людей рядом; 2 — гильдия; иначе — только билет),
  [7] билет (63057), [8] минимум игроков (3 остров, 2 башня), [9] радиус сбора ×10, [10] число команд (2/1),
  [11] дни недели, [12] час первого старта (14 / 13), [13] 600, [14] запись до старта, с (300),
  [15] отсчёт перед стартом, с (10; строка «Начало через %d сек.»), [16]/[34] ворота команд A/B (9900804/805),
  [21+i] условие этапа i (основной этап — 0), [36] условие финального этапа (индекс 4 в S 13/05),
  [38] период стартов, с (10800 = 3 ч), [39] окно стартов от первого, с (46800),
  [40]/[41] точка возврата (mapWarpTargetPos 190031 — Бернео), [45] награда победителю, [46] проигравшему.
  Проверка: старты 14,17,20,23,2 ч (остров) и 13,16,19,22,1 ч (башня), запись за 5 мин — ровно EventInform
  (13:55, 16:55 … и 12:55, 15:55 …).
EIDCondition (44 байта = 11 × i32): [0] условие, [2] вид, [4] время этапа, с, [5] нужен моб, [6] этот моб
  (NPC), [7]/[9] показывать два числа в табло, [10] нужные очки (50000 — башня; 9999999 — без порога).
EIDElement (22 байта): u32 событие, u32 условие, u8, u32 NPC, u8, u32 очки за убийство, u32 100.
EIDWarp (28 байт = 7 × i32): [2] событие, [3] строка названия, [4] карта, [5] команда (1/2), [6] точка
  mapWarpTargetPos входа команды (10020301/10020302; у башни 20050601, 20050602 — к боссу).
EIDString (224 байта): номера строк сообщений (35001… — см. docs/protocol.md, 13/xx).

Сценарий карты (events[*].script) — из скрипта клиента Map/<карта>/map/<карта>.me (у всех вариантов
острова и башни одинаковый): u32 n типов по 8 байт; u32 n таймлайнов (u32 id, f32 начало, f32 конец,
u32 кадров: f32 время, u32 n, действия); u32 n триггеров (u16 id, u16 режим, u32 n, действия);
действие = u16 вид (0 — дверь/эффект, 36 — вернуть, 46 — включить объект, 47 — выключить), u16 цель, u32.
Кто запускает триггер режима 2, в файле не записано — восстановлено по содержимому (записей нет):
  * триггер, включающий волну и один пассивный объект-«ключ» (на острове «Монстр с 1-м/2-м ключом»,
    в башне кристалл «Ключевой предмет»), — убийство ближайшего к ключу стартера (siege_symbol_normal:
    «1-й стартер» / «Начальная башня», у модели есть анимация гибели AN099_BDED);
  * триггер, выключающий эту волну (остаток), — убийство ключа (двери дальше, 0 N);
  * в башне номер триггера = номер убитого объекта (301–307 стартеры, 411–417 ключи, 957 полубосс) —
    совпадает с правилом выше. Режим 1 — триггеры, которые шлёт клиент (C 0a/01).
Остров: стартер 101 -> 200 (дверь 1 за спиной, волна 501–536 + ключ 201), ключ 201 -> 201 (двери 2, 3),
стартер 102 -> 204, ключ 202 -> 205 (дверь 5 к центру); команда B — 103/203 -> 206/207, 104/204 -> 208/209.

Запуск: python -X utf8 tools/eid_tables.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                     # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'eid.json')


def table(name, size):
    p = os.path.join(LOD, name + '.lod_rus')
    if os.path.exists(p + '.orig'):           # EIDMain правит tools/patch_eid_solo.py — данные берём из оригинала
        p += '.orig'
    d = decode(open(p, 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    return [d[4 + i * size:4 + (i + 1) * size] for i in range(n)]


def ints(r):
    return [struct.unpack_from('<i', r, j)[0] for j in range(0, len(r) - 3, 4)]


MAPDIR = os.path.join(ROOT, 'ResUnpak', 'Map')
ME = {1: os.path.join(MAPDIR, 'Extreme', 'map', 'Extreme.me'),          # события 10xxxxx — остров
      2: os.path.join(MAPDIR, 'T_darkcliff', 'map', 'T_darkcliff.me')}  # 20xxxxx — башня


def parse_me(path):
    """-> [(триггер, режим, [(вид, цель, параметр)])] (таймлайны пропускаем)."""
    d = open(path, 'rb').read()
    o = 4 + 8 * struct.unpack_from('<I', d, 0)[0]
    n_tl = struct.unpack_from('<I', d, o)[0]
    o += 4
    for _ in range(n_tl):                                           # таймлайны: id, начало, конец, кадры
        nf = struct.unpack_from('<I', d, o + 12)[0]
        o += 16
        for _f in range(nf):                                        # кадр: время, n, действия
            o += 8 + 8 * struct.unpack_from('<I', d, o + 4)[0]
    n_tr = struct.unpack_from('<I', d, o)[0]
    o += 4
    out = []
    for _ in range(n_tr):
        tid, mode, n = struct.unpack_from('<HHI', d, o)
        o += 8
        out.append((tid, mode, [struct.unpack_from('<HHI', d, o + 8 * i) for i in range(n)]))
        o += 8 * n
    assert o == len(d), path
    return out


def script(trs, spawns, npc):
    """Сценарий одного события: kill_events (номер убитого объекта -> события 0a/00), triggers (режим 1),
    attackable (стартеры и ключи — бьются, но стоят на месте)."""
    pos = {s['uidx']: (s['x'], s['z']) for s in spawns}
    nid = {s['uidx']: s['id'] for s in spawns}
    starters = [s['uidx'] for s in spawns if s['model'].lower().startswith('siege_symbol')]

    def passive(r):
        return not (npc.get(nid.get(r)) or {}).get('aggro')

    def evs(acts, param):
        return [[k, t, param, -1] for k, t, _p in acts]

    by = {t: (m, a) for t, m, a in trs}
    fire, keys = {}, {}
    for tid, (_m, acts) in sorted(by.items()):
        on = [t for k, t, _p in acts if k == 46 and t in pos]
        ks = [t for t in on if passive(t)]
        if len(ks) == 1 and starters:
            k = ks[0]
            st = min(starters, key=lambda r: (pos[r][0] - pos[k][0]) ** 2 + (pos[r][1] - pos[k][1]) ** 2)
            fire.setdefault(st, tid)
            keys[k] = set(on) - {k}
    for tid, (_m, acts) in sorted(by.items()):
        off = {t for k, t, _p in acts if k == 47}
        for k, wave in keys.items():
            if wave and wave <= off:
                fire.setdefault(k, tid)
    for tid in by:                                     # башня: 957 (полубосс) -> триггер 957
        if tid in pos and tid not in fire and tid not in fire.values():
            fire[tid] = tid
    used = set(fire.values())
    return {'kill_events': {str(r): evs(by[t][1], 2) for r, t in sorted(fire.items())},
            'triggers': {str(t): {'events': evs(a, 1)} for t, (m, a) in sorted(by.items())
                         if m == 1 and t not in used},
            'attackable': sorted(set(starters) | set(keys)),
            'fired_by': {str(r): t for r, t in sorted(fire.items())}}


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    events = {}
    for r in table('EIDMain', 0xd4):
        f = ints(r)
        if not f[1]:
            continue                                   # 1900300 — «вечеринка» без карты (не событие EID)
        events[str(f[0])] = {
            'map': f[1], 'npc': f[2], 'lo': f[4], 'hi': f[5], 'mode': f[6], 'ticket': f[7],
            'min_players': f[8], 'teams': f[10], 'days': f[11], 'first_hour': f[12],
            'reg_before': f[14], 'countdown': f[15], 'doors': [f[16], f[34]],
            'stages': {'0': f[21], '4': f[36]}, 'period': f[38], 'window': f[39],
            'return_warp': f[40], 'reward_win': f[45], 'reward_lose': f[46], 'raw': f}
    conds = {}
    for r in table('EIDCondition', 0x2c):
        f = ints(r)
        conds[str(f[0])] = {'kind': f[2], 'seconds': f[4], 'need_npc': f[6] if f[5] else 0,
                            'show': [f[7], f[9]], 'score': f[10], 'raw': f}
    points = {}
    for r in table('EIDElement', 0x16):
        ev, cond = struct.unpack_from('<II', r, 0)
        npc, = struct.unpack_from('<I', r, 9)
        pts, = struct.unpack_from('<I', r, 14)
        points.setdefault(str(cond), {})[str(npc)] = pts
    warps = {}
    for r in table('EIDWarp', 0x1c):
        f = ints(r)
        if f[2] and f[4]:
            warps.setdefault(str(f[2]), {})[str(f[5])] = f[6]
    sys.path.insert(0, os.path.join(ROOT, 'server'))
    import content                                                # noqa: E402
    npc = content.Content().npc
    spawns = json.load(open(os.path.join(ROOT, 'data', 'dungeon_spawns.json'), encoding='utf-8'))
    me = {k: parse_me(p) for k, p in ME.items() if os.path.exists(p)}
    for k, e in events.items():
        e['warps'] = warps.get(k, {})
        kind = int(k) // 1000000
        if kind in me and k in spawns:
            e['script'] = script(me[kind], spawns[k], npc)
        for c in e['stages'].values():
            if str(c) in conds:
                conds[str(c)]['points'] = points.get(str(c), {})
    json.dump({'events': events, 'conditions': conds}, open(OUT, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('событий', len(events), 'условий', len(conds), '->', OUT)
    for k, e in events.items():
        st = [(e['first_hour'] * 3600 + i * e['period']) % 86400 for i in range(e['window'] // e['period'] + 1)
              if i * e['period'] < e['window']]
        print(k, 'ур.', e['lo'], '-', e['hi'], 'старты', ['%02d:%02d' % (s // 3600, s // 60 % 60) for s in st],
              'входы', e['warps'], 'сценарий', (e.get('script') or {}).get('fired_by'))


if __name__ == '__main__':
    main()
