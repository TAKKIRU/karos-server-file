"""Золотая рыбка и случайный обмен -> data/gamble.json.

gambleGoldFish.lod (режим 1, записи 110 байт): +0 вариант (его клиент шлёт в 06/14 +9), +4 NPC,
+8/+16/+24 три пары (предмет, кол-во) — что отдать, +32 три u8 — вероятности исходов (%),
+35/+43/+51 три пары (предмет, кол-во) — исходы, +59 название (cp1251).
  1 «Осколок флетты A»: Золотая рыбка -> 30% Осколок флеттоцвета, 70% Кости золотой рыбки, 0% —;
  2 «Осколок флетты B»: Золотая рыбка + Кости -> 45% Осколок, 50% Ракушка ×10, 5% —.
Третий исход — «предмет 1» (такого предмета нет): неудача, клиент пишет «Неудача.» (код 0x6c).
gambleRandom.lod (записи 207 байт): +0 вариант, +4 NPC, +8 что отдать (Ракушка ×10), +92 три u32
вероятности (2/90/8) — призов в таблице нет (их выбирал сервер), поэтому обмен не подключён.

Запуск: python tools/gamble_table.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'gamble.json')


def goldfish():
    d = decode(open(os.path.join(LOD, 'gambleGoldFish.lod_rus'), 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    out = {}
    for k in range(n):
        r = d[4 + 110 * k:4 + 110 * (k + 1)]
        vid, npc = struct.unpack_from('<II', r, 0)
        give = [list(struct.unpack_from('<II', r, 8 + 8 * i)) for i in range(3)]
        probs = list(r[32:35])
        outs = [list(struct.unpack_from('<II', r, 35 + 8 * i)) for i in range(3)]
        name = r[59:].split(b'\0')[0].decode('cp1251', 'replace')
        out[vid] = {'npc': npc, 'name': name,
                    'give': [g for g in give if g[0] and g[1]],
                    'outcomes': [[p, it if it > 1 else 0, c] for p, (it, c) in zip(probs, outs)]}
    return out


if __name__ == '__main__':
    g = goldfish()
    json.dump({'goldfish': g}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'{len(g)} вариантов рыбки -> {OUT}')
    for k, v in g.items():
        print(' ', k, v)
