"""Сверка навыков с записью: расход MP (05/01 -> 08/00), перезарядка, урон по мобам.

Для каждого удара навыком (C 05/01, +5 == 1, +6 навык) берётся ближайший S 08/00 своего персонажа
(+1 eid, +17 MP) и предыдущее MP — разница = расход (реген в этот миг почти не мешает: берётся мода).
Уровень навыка — по S 05/06 (изучен, ур.1) и S 05/07 (+8 новый уровень). Сравнение —
с data/skill_mp.json. Перезарядка — минимальный интервал между ударами одним навыком.

Запуск: python tools/cap_skill_check.py data/captures/huge_genesis_pack_2.jsonl
"""
import collections, json, os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(path):
    mp_tab = json.load(open(os.path.join(ROOT, 'data', 'skill_mp.json')))
    me = None
    lv = {}
    last_mp = None
    pending = []                      # [(t, sid, lv)]
    drops = collections.defaultdict(list)
    uses = collections.defaultdict(list)
    for line in open(path, encoding='utf-8'):
        if '"05/0' not in line and '"08/00"' not in line:
            continue
        j = json.loads(line)
        p = bytes.fromhex(j['hex'])
        op, d, t = j['op'], j['dir'], j['t']
        if d == 'C' and op == '05/01' and len(p) >= 10:
            me = me or p[1:5]
            if p[5] == 1:
                sid = struct.unpack_from('>I', p, 6)[0]
                pending.append((t, sid, lv.get(sid, 1)))
                uses[sid].append(t)
        elif d == 'S' and op in ('05/06', '05/07') and len(p) >= 12 and (me is None or p[:4] == me):
            sid = struct.unpack_from('>I', p, 4)[0]
            lv[sid] = 1 if op == '05/06' else struct.unpack_from('>I', p, 8)[0]
        elif d == 'S' and op == '08/00' and len(p) >= 25 and me is not None and p[1:5] == me:
            mp = struct.unpack_from('<I', p, 17)[0]
            while pending and t - pending[0][0] > 1.5:
                pending.pop(0)
            if pending and last_mp is not None and mp < last_mp:
                t0, sid, l = pending.pop(0)
                drops[(sid, l)].append(last_mp - mp)
            last_mp = mp
    print('навык ур | расход в записи (мода, n) | skill_mp.json | откат, с')
    bad = 0
    for (sid, l), v in sorted(drops.items()):
        mode, n = collections.Counter(v).most_common(1)[0]
        tab = mp_tab.get(str(sid), {})
        want = tab.get(str(l)) or tab.get('1')
        ts = sorted(uses[sid])
        cd = min((b - a for a, b in zip(ts, ts[1:]) if b - a > 0.3), default=None)
        flag = '' if want == mode else '  <-- расхождение'
        bad += bool(flag)
        print(f'{sid:>6} {l:>2} | {mode:>4} ({n}) | {want} | {cd and round(cd, 1)}{flag}')
    print('расхождений:', bad)


if __name__ == '__main__':
    main(sys.argv[1])
