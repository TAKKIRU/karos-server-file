"""Срабатывание навыка от вещи (itemInvokeSkill.lod_rus) -> data/item_procs.json.

Режим 1: u32 число (26), записи по 14 байт: u32 навык вещи (9 000 000 + номер вещи: «Большой меч
Властелина» 1228 -> 9001228), u32 вызываемый навык, u16 когда (2 — при ударе, 3 — при ударе (лечение),
4 — при получении удара), u32 шанс /10000 (500 = 5%).
Что делает вызываемый навык — skill_effects (statcalc): вид 11 с эффектами 13/27 — замедление цели,
вид 11 без эффектов — дополнительный удар, вид 23 — баф на себя, вид 21 — лечение.
Выход: {вещь: [навык, когда, шанс/10000]}. Запуск: python tools/proc_table.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                     # noqa: E402


def main():
    p = decode(open(os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemInvokeSkill.lod_rus'), 'rb').read(), 1)
    out = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        own, skill, when, chance = struct.unpack_from('<IIHI', p, 4 + 14 * k)
        out[str(own - 9000000)] = [skill, when, chance]
    json.dump(out, open(os.path.join(ROOT, 'data', 'item_procs.json'), 'w'), separators=(',', ':'))
    print(f'{len(out)} вещей со срабатыванием -> data/item_procs.json')


if __name__ == '__main__':
    main()
