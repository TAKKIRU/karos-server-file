"""Состав коробок из описаний предметов (itemBase_Name.lod_rus) -> data/boxes.json.

itemBase_Name (режим 0): заголовок [20101118][кол-во], затем записи подряд:
u32 id, u32 длина, имя (cp1251), u32 длина, описание (cp1251).

Описание коробки содержит блок
    [Состав]
    Подарок новичка (ур.10): 1
    Коробка с маленькими зельями здоровья: 1
— это и есть содержимое (клиент показывает его в подсказке). Имя -> id: среди
предметов с таким именем берём ближайший по номеру к самой коробке (у серии
999000xxx свои копии зелий и коробок).

Коробки без [Состав], но с «Есть шанс получить <что-то>» пишем в 'chance' —
их содержимое сервер подбирает по ключевым словам.

Запуск: python tools/boxes.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemBase_Name.lod_rus')
OUT = os.path.join(ROOT, 'data', 'boxes.json')
LINE = re.compile(r'^\s*(.+?)\s*[:：]\s*(\d+)\s*$')
# коробки без [Состав] («Есть шанс получить …») — что в них, видно по соседним id
MANUAL = {
    999900029: [[999900030, 1]],   # -> «Уровневый образец флетта-брони (3 часа)»
    999900041: [[999900042, 1]],   # «Коробка с флетта-оружием уровня C» -> уровневое (15 дней)
    999900043: [[999900044, 1]],
}


def stem(name):
    """«Небольшие зелья здоровья» ~ «Небольшое зелье здоровья»: основы слов."""
    words = re.findall(r'[\w-]+', name.lower())
    return ' '.join(w[:max(3, len(w) - 3)] for w in words)


def base(name):
    return stem(re.sub(r'\(.*?\)', ' ', name))


def records(d):
    o, count = 8, struct.unpack_from('<I', d, 4)[0]
    for _ in range(count):                  # после записей — служебный хвост
        iid, n = struct.unpack_from('<II', d, o)
        name = d[o + 8:o + 8 + n].decode('cp1251', 'replace').rstrip('\0')
        o += 8 + n
        m = struct.unpack_from('<I', d, o)[0]
        desc = d[o + 4:o + 4 + m].decode('cp1251', 'replace').rstrip('\0')
        o += 4 + m
        yield iid, name, desc


def main():
    d = decode(open(SRC, 'rb').read(), 0)
    recs = list(records(d))
    by_name, by_stem, by_base = {}, {}, {}
    names = {iid: name for iid, name, _ in recs}
    for iid, name, _ in recs:
        by_name.setdefault(name.strip().lower(), []).append(iid)
        by_stem.setdefault(stem(name), []).append(iid)
        by_base.setdefault(base(name), []).append(iid)
    boxes, chance, missing = {}, {}, set()
    for iid, name, desc in recs:
        text = desc.replace('\r', '')
        if '[Состав]' in text:
            out = []
            for ln in text.split('[Состав]', 1)[1].split('\n'):
                m = LINE.match(ln)
                if not m:
                    if out and ln.strip():
                        break
                    continue
                nm, cnt = m.group(1), int(m.group(2))
                ids = (by_name.get(nm.strip().lower()) or by_stem.get(stem(nm))
                       or by_base.get(base(nm)))
                if not ids:
                    missing.add(nm)
                    continue
                out.append([min(ids, key=lambda x: abs(x - iid)), cnt])
            if out:
                boxes[iid] = out
        elif name.lower().startswith(('коробка с ', 'коробка со ')) or 'Содержит ' in text:
            # «Коробка с маленьким зельем здоровья» / «Содержит 50 маленьких зелий здоровья.»
            m = re.search(r'Содержит\s+(\d+)\s+([^.\n]+)', text)
            cnt = int(m.group(1)) if m else 1
            what = m.group(2) if m else re.sub(r'^коробка\s+со?\s+', '', name.strip(), flags=re.I)
            ids = [i for i in (by_stem.get(stem(what)) or by_base.get(base(what)) or [])
                   if i != iid and not names[i].lower().startswith('коробка')]
            if not ids and m:
                what = re.sub(r'^коробка\s+со?\s+', '', name.strip(), flags=re.I)
                ids = [i for i in (by_stem.get(stem(what)) or by_base.get(base(what)) or [])
                       if i != iid and not names[i].lower().startswith('коробка')]
            if ids:
                boxes[iid] = [[min(ids, key=lambda x: abs(x - iid)), cnt]]
        elif 'шанс получить' in text.lower():
            chance[iid] = {'name': name, 'desc': text}
    for k, v in MANUAL.items():
        boxes[k] = v
        chance.pop(k, None)
    json.dump({'boxes': boxes, 'chance': chance}, open(OUT, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    print(f'коробок с составом: {len(boxes)}, «шанс получить»: {len(chance)}, '
          f'не найдено имён: {len(missing)} -> {OUT}')
    for nm in sorted(missing)[:20]:
        print('   нет предмета:', nm)


if __name__ == '__main__':
    main()
