"""Урон навыков из skillLevel.lod -> data/skill_dmg.json.

Запись skillLevel (как в tools/skill_mp.py): u32 id, u32 уровень, ..., u32 @+12 == 0/1, double @+164 == 1.0.
Поля урона (сверено с записями оригинала, docs/stats.md):
  double @+180 / @+188 — прибавка урона навыка (мин./макс.), напр. 16103 ур.1: 198..220;
  double @+252 — множитель атаки оружия (1.05 = 105%, 0.7 = 70%).
Удар навыком = атака персонажа (как в окне) × множитель + случайное из [мин., макс.].

Выход: {id: {уровень: [множитель, мин., макс.]}}.
Запуск: python tools/skill_damage.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'skillLevel.lod_rus')
OUT = os.path.join(ROOT, 'data', 'skill_dmg.json')


def creature(sid):
    """Навыки существ (облики свитков трансформации 81xxx, 94000xxx; transformSkill.lod)."""
    return 80000 <= sid <= 99999 or 94000000 <= sid <= 94999999


def scan(L):
    out = {}
    p = 4
    while p < len(L) - 260:
        sid, lv = struct.unpack_from('<II', L, p)
        if ((1000 <= sid <= 40000 or creature(sid)) and 1 <= lv <= 60 and struct.unpack_from('<I', L, p + 12)[0] in (0, 1)
                and struct.unpack_from('<d', L, p + 164)[0] == 1.0):
            lo, hi = struct.unpack_from('<2d', L, p + 180)
            mult = struct.unpack_from('<d', L, p + 252)[0]
            if 0 <= lo <= 1e6 and 0 <= hi <= 1e6 and 0 <= mult <= 50 and (mult or hi):
                out.setdefault(str(sid), {})[str(lv)] = [round(mult, 4), round(lo, 2), round(hi, 2)]
            p += 300
            continue
        p += 1
    return out


if __name__ == '__main__':
    d = scan(decode(open(SRC, 'rb').read(), 0))
    json.dump(d, open(OUT, 'w', encoding='utf-8'), indent=0, sort_keys=True)
    print(f'{len(d)} skills -> {OUT}')
    for s in ('16103', '15103', '15101', '5104', '6104', '6813'):
        print(' ', s, d.get(s))
