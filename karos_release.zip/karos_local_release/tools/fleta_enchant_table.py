"""Чарование изделий из флеттоцветов: fletaItemEnchant.lod_rus -> data/fleta_enchant.json.

Режим 1: u32 число (10), записи по 276 байт (загрузчик — как у прочих таблиц, окно 0x0049ebde):
  +0 u32 ступень, на которую чаруем (2..6), +4 u32 вид (4 — «Оружие из флеттоцветов» 53001,
  5 — «Доспехи из флеттоцветов» 53501; так же их выбирает обработчик ответа 0x00655e73),
  +8 u32 цена в каратах, +12 f64 шанс успеха %, +20 f64 шанс неудачи без потери вещей %,
  +28 20 × u32 вещи, +108 20 × u32 ступень вещи (для изделия; 0 — не важно), +188 20 × u32 кол-во,
  +268 u32 (1, 2, 5, 7, 10 — назначение не выяснено).
Пример: ступень 2 — 2 изделия ступени 1 и 10 «Красного латиума», 20 000 карат, 25% / 30%;
ступень 6 — изделия ступеней 4 и 5, 40 / 50 / 70 латиума и руды, 200 000 карат, 1% / 5%.
Остаток (100 − успех − «без потерь») — все вещи исчезают (код 0x7b, строка 0x4f26).

Запуск: python tools/fleta_enchant_table.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                    # noqa: E402

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'fletaItemEnchant.lod_rus')
OUT = os.path.join(ROOT, 'data', 'fleta_enchant.json')
REC = 276


def main():
    p = decode(open(SRC, 'rb').read(), 1)
    out = []
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        r = p[4 + REC * k:4 + REC * (k + 1)]
        grade, kind, cost = struct.unpack_from('<3I', r, 0)
        ok, keep = struct.unpack_from('<2d', r, 12)
        items = struct.unpack_from('<20I', r, 28)
        grades = struct.unpack_from('<20I', r, 108)
        counts = struct.unpack_from('<20I', r, 188)
        need = [[items[i], grades[i], counts[i]] for i in range(20) if items[i]]
        out.append({'grade': grade, 'kind': kind, 'cost': cost, 'ok': ok, 'keep': keep, 'need': need,
                    'x': struct.unpack_from('<I', r, 268)[0]})
    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'{len(out)} записей -> {OUT}')


if __name__ == '__main__':
    main()
