"""Каталог клиентских таблиц .lod: расшифровка, режим, число записей.

Для каждой таблицы IE_Lod (*.lod_rus, иначе *.lod_en, иначе *.lod) пробует
режимы 0 и 1, выбирает тот, где после версии 20101118 идёт правдоподобное
число записей, и пишет:
  data/lod/<имя>.bin       — расшифрованные байты (для разбора)
  docs/lod_catalog.md      — таблица: файл, режим, записей, байт/запись, пример текста

Запуск: python tools/lod_catalog.py
"""
import os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'lod')
DOC = os.path.join(ROOT, 'docs', 'lod_catalog.md')
VERSION = 20101118


def pick_files():
    by = {}
    for fn in os.listdir(SRC):
        m = re.match(r'(.+?)\.lod(?:_(rus|en))?$', fn, re.I)
        if not m:
            continue
        name, lang = m.group(1), (m.group(2) or '').lower()
        rank = {'rus': 0, 'en': 1, '': 2}[lang]
        if name not in by or rank < by[name][0]:
            by[name] = (rank, fn)
    return sorted((n, f) for n, (_, f) in by.items())


WORD = re.compile(rb'(?:[A-Za-z_][A-Za-z0-9_ .\\-]{3,}|[\xc0-\xff\xa8\xb8][\xc0-\xff\xa8\xb8 ,.\-]{3,})')


def score(d):
    """Сколько байт в начале похожи на осмысленный текст (имена, пути .dds)."""
    head = d[:65536]
    return sum(len(m) for m in WORD.findall(head) if not re.fullmatch(rb'[\xff ]+', m))


def best_decode(raw):
    """-> (mode, bytes, count). Шапка бывает двух видов: [20101118][count] или
    сразу [count]; режим выбираем по количеству читаемого текста."""
    best = None
    for mode in (0, 1):
        try:
            d = decode(raw, mode)
        except Exception:
            continue
        if len(d) < 8:
            continue
        a, b = struct.unpack_from('<2I', d, 0)
        n = b if a == VERSION else a
        if not (0 < n < 2_000_000 and n * 2 <= len(d)):
            n = None
        sc = (score(d), a == VERSION)
        if best is None or sc > best[0]:
            best = (sc, mode, d, n)
    return best


def sample_text(d, limit=3):
    out = []
    for t in WORD.findall(d[8:65536]):
        if re.fullmatch(rb'[\xff ]+', t):
            continue
        s = t.decode('cp1251', 'replace').strip()
        if len(s) >= 4 and s not in out:
            out.append(s[:40])
        if len(out) >= limit:
            break
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    for name, fn in pick_files():
        raw = open(os.path.join(SRC, fn), 'rb').read()
        b = best_decode(raw)
        if b is None:
            rows.append((name, fn, '—', '—', '—', ['не расшифровано']))
            continue
        (sc, _), mode, d, n = b
        open(os.path.join(OUT, name + '.bin'), 'wb').write(d)
        per = f'{(len(d) - 8) / n:.0f}' if n else '—'
        txt = sample_text(d) if sc else ['(только числа)']
        rows.append((name, fn, mode, n if n else '?', per, txt))
    with open(DOC, 'w', encoding='utf-8') as f:
        f.write('# Каталог таблиц клиента (.lod)\n\n'
                'Сгенерировано `tools/lod_catalog.py`. Расшифрованные байты — `data/lod/<имя>.bin`.\n'
                'Записи часто переменной длины (строки внутри), «байт/запись» — среднее.\n\n'
                '| Таблица | Файл | Режим | Записей | Байт/запись | Пример текста |\n'
                '|---|---|---|---|---|---|\n')
        for name, fn, mode, n, per, txt in rows:
            f.write(f'| {name} | {fn} | {mode} | {n} | {per} | {"; ".join(txt).replace("|", "/")} |\n')
    ok = sum(1 for r in rows if r[2] != '—')
    print(f'{ok}/{len(rows)} таблиц расшифровано -> {OUT}, {DOC}')


if __name__ == '__main__':
    main()
