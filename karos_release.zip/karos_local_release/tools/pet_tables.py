"""Рост питомцев: petBase.lod_rus и petLevel.lod_rus -> data/pets.json.

petBase (режим 1): u32 число (76), записи по 339 байт:
  +0 u32 шаблон питомца (10001..10076; поле +4 записи питомца), +4 u32 NPC (npcInfo 11000001..),
  +8 u32 предмет-капсула (только у первой стадии; 0 у следующих), +12 u32 шаблон следующей стадии
  (0 — последняя), +16 u32 1, +20 u32 лист значков, +24 u32 номер значка, +28 u32 1 у стадий 2–3,
  +32 char[51] файл значка, +83 char[256] описание (cp1251).
  У каждого вида три стадии: 10074 Мирик -> 10075 -> 10076 (записи оригинала: Мирик ур.5 — 10075,
  Мяут-вор ур.6 — 10020, оба — вторая стадия).

petLevel (режим 1): u32 число (11), записи по 74 байта, уровни 0..10:
  +0 u32 таблица (1; поле +65 записи питомца), +4 u16 уровень, +6 u32 (50..410, +40 за уровень) —
  опыт питомцу за убийство (оригинал: ур.5 — 249 при 250), +10 u32 опыт до следующего уровня (0 у ур.10), +14 u32 (1 у ур.10),
  +18 u32 (0 / 400 / 800 / 1200 — по стадиям: ур.0, 1–3, 4–9, 10; берём как предел сытости),
  +22 u32 общий навык уровня (ур.1 — 900001, ур.4 — 6), +38 / +50 / +62 u32 навык типа
  1 «чарователь» / 2 «счастливчик» / 3 «помощник» (тип — поле +18 записи питомца; у обоих
  питомцев записей тип 2 и навык 900010 / 900011 из второго столбца).
Клиент (AMo 0x0055eb33, 0x0055ebb0): на ур.3, 6, 9 опыт копится до порога, дальше нужна
тренировка (11/11) за 1 000 / 10 000 / 100 000 карат; на ур.0 — «готов к высиживанию».

Запуск: python tools/pet_tables.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                    # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'pets.json')


def base():
    d = decode(open(os.path.join(LOD, 'petBase.lod_rus'), 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    out = {}
    for k in range(n):
        o = 4 + 339 * k
        tid, npc, capsule, nxt, _one, sheet, icon, later = struct.unpack_from('<8I', d, o)
        desc = d[o + 83:o + 339].split(b'\0')[0].decode('cp1251', 'replace')
        out[tid] = {'npc': npc, 'capsule': capsule, 'next': nxt, 'later': later, 'desc': desc}
    return out


def levels():
    d = decode(open(os.path.join(LOD, 'petLevel.lod_rus'), 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    out = []
    for k in range(n):
        o = 4 + 74 * k
        table, lv = struct.unpack_from('<IH', d, o)
        x, exp, last, sat, common = struct.unpack_from('<5I', d, o + 6)
        types = [struct.unpack_from('<I', d, o + off)[0] for off in (38, 50, 62)]
        out.append({'level': lv, 'table': table, 'x': x, 'exp': exp, 'last': last, 'sat': sat,
                    'skill': common, 'types': types})
    return out


def main():
    b, lv = base(), levels()
    json.dump({'base': b, 'levels': lv}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(f'{len(b)} шаблонов, {len(lv)} уровней -> {OUT}')


if __name__ == '__main__':
    main()
