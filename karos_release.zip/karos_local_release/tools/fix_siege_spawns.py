"""Расстановка карт осады (Siege_001, Siege_002) в data/spawns.json.

При выгрузке файлы Map/Siege_00N/Map/Siege_00N<тайл>.npc разобрались как карта «Siege_» с тайлом «00N<тайл>»
(цифры имени слиплись с номером тайла): 10–12, 164–166, 1128–1130 — Siege_001, 20–22, 264–266, 2128–2130 —
Siege_002. Сервер искал Siege_001/Siege_002 и не находил ничего: карта пустая, NPC без имён и некликабельны.
Скрипт делит «Siege_» на две карты с настоящими тайлами; номера точек (uidx) — потом tools/spawn_uidx.py.
Запуск: python -X utf8 tools/fix_siege_spawns.py && python -X utf8 tools/spawn_uidx.py
"""
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPAWNS = os.path.join(ROOT, 'data', 'spawns.json')


def main():
    sp = json.load(open(SPAWNS, encoding='utf-8'))
    bad = sp.pop('Siege_', None)
    if not bad:
        print('Siege_ нет — уже исправлено')
        return
    out = {'Siege_001': [], 'Siege_002': []}
    for s in bad:
        t = str(int(s.get('tile', 0)))
        name = 'Siege_00' + t[0]
        out.setdefault(name, []).append(dict(s, tile=int(t[1:])))
    for k, v in out.items():
        sp[k] = v
        print(k, len(v), 'точек, тайлы', sorted({s['tile'] for s in v}))
    json.dump(sp, open(SPAWNS, 'w', encoding='utf-8'), ensure_ascii=False)


if __name__ == '__main__':
    main()
