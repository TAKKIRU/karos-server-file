"""Пульт разработчика Karos (временный инструмент для тестов).

F2 (в любой программе, в том числе в игре) — показать / спрятать окно.
Окно всегда поверх игры. Говорит с сервером по http://127.0.0.1:10199
(server/devtools.py) — сервер должен быть запущен.

Что умеет:
  * скорость бега, множители опыта/карат/урона/HP/атаки/защиты, режим бога,
    убийство с одного удара, «мобы не отвечают»;
  * уровень (поставить / +1 / +5 / +10), опыт, караты, очки флетты и навыков;
  * выдать предмет (поиск по имени в data/items.json);
  * телепорт: по списку точек (mapWarpTargetPos), по координатам миникарты,
    к ближайшим мобам нужного уровня; убить всех мобов вокруг;
  * лечение, сохранение;
  * «Сумка» — сортировка; отметить несколько предметов и продать / разобрать / в хранилище / уничтожить;
  * «Крафт» — «Изготовить всё»: на сколько хватает материалов, карат и места;
  * «Питомец» — автокормление, что подбирать при сборе трофеев, тип способности.

Запуск: python tools/devpanel.py   (или start_dev.bat)
"""
import ctypes, ctypes.wintypes as wt, json, os, queue, threading, urllib.request
import tkinter as tk
from tkinter import messagebox, ttk

API = os.environ.get('KAROS_DEVURL', 'http://127.0.0.1:10199')
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOTKEY_VK = 0x71          # F2
WM_HOTKEY = 0x0312


def call(path, data=None):
    req = urllib.request.Request(API + path, method='POST' if data is not None else 'GET',
                                 data=json.dumps(data).encode() if data is not None else None,
                                 headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=3) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception as e:          # noqa: BLE001
        return {'ok': False, 'error': f'сервер недоступен: {e}'}


def hotkey_thread(q):
    """Глобальная F2: RegisterHotKey + свой цикл сообщений."""
    user32 = ctypes.windll.user32
    if not user32.RegisterHotKey(None, 1, 0x4000, HOTKEY_VK):     # MOD_NOREPEAT
        q.put(('error', 'F2 занята другой программой — окно открыто без горячей клавиши'))
        return
    msg = wt.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        if msg.message == WM_HOTKEY:
            q.put(('toggle', None))


class Panel:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Karos — пульт разработчика (F2)')
        self.root.attributes('-topmost', True)
        self.root.geometry('560x720+40+40')
        self.root.protocol('WM_DELETE_WINDOW', self.hide)
        self.q = queue.Queue()
        self.items = self._load_items()
        self.warps = []
        self.dev = {}
        self._build()
        threading.Thread(target=hotkey_thread, args=(self.q,), daemon=True).start()
        self.root.after(200, self._poll_queue)
        self.root.after(300, self.refresh)

    # ---------- данные ----------
    @staticmethod
    def _load_items():
        try:
            it = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
            return sorted(((int(k), v.get('name', '')) for k, v in it.items()
                           if v.get('name') and not v['name'].endswith('.dds')), key=lambda x: x[0])
        except OSError:
            return []

    # ---------- окно ----------
    def _build(self):
        r = self.root
        pad = {'padx': 4, 'pady': 2}
        self.status = tk.StringVar(value='…')
        ttk.Label(r, textvariable=self.status, font=('Segoe UI', 10, 'bold'),
                  wraplength=540).pack(fill='x', **pad)
        self.msg = tk.StringVar()
        ttk.Label(r, textvariable=self.msg, foreground='#a33', wraplength=540).pack(fill='x', **pad)

        nb = ttk.Notebook(r)
        nb.pack(fill='both', expand=True, **pad)
        t1, t2, t3, t4, t5 = ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb)
        nb.add(t1, text='Персонаж')
        nb.add(t2, text='Перемещение')
        nb.add(t3, text='Предметы')
        nb.add(t4, text='Сумка')
        t6 = ttk.Frame(nb)
        nb.add(t6, text='Крафт')
        nb.add(t5, text='Питомец')
        t7 = ttk.Frame(nb)
        nb.add(t7, text='Внешность')
        t8 = ttk.Frame(nb)
        nb.add(t8, text='Задания')
        self._build_quests(t8, pad)
        self._build_craft(t6, pad)
        self._build_bag(t4, pad)
        self._build_pet(t5, pad)
        self._build_hair(t7, pad)

        # --- аккаунт ---
        fa = ttk.LabelFrame(t1, text='Аккаунт (персонажи в окне выбора; применится при выходе в выбор)')
        fa.pack(fill='x', **pad)
        self.accv = tk.StringVar()
        self.accbox = ttk.Combobox(fa, textvariable=self.accv, state='readonly', width=20)
        self.accbox.pack(side='left', **pad)
        ttk.Button(fa, text='Выбрать', command=self.set_account).pack(side='left', **pad)

        # --- множители ---
        f = ttk.LabelFrame(t1, text='Множители (сразу применяются)')
        f.pack(fill='x', **pad)
        self.vars = {}
        rows = [('move', 'Скорость бега ×'), ('exp', 'Опыт с мобов ×'), ('gold', 'Караты ×'),
                ('dmg', 'Урон по мобам ×'), ('hp', 'HP/MP ×'), ('atk', 'Атака ×'), ('def', 'Защита ×')]
        for i, (k, label) in enumerate(rows):
            ttk.Label(f, text=label).grid(row=i, column=0, sticky='w', **pad)
            v = tk.StringVar()
            self.vars[k] = v
            e = ttk.Entry(f, textvariable=v, width=8)
            e.grid(row=i, column=1, **pad)
            e.bind('<Return>', lambda _e, k=k: self.set_dev(k))
            for j, q in enumerate((1, 2, 5, 10)):
                ttk.Button(f, text=f'×{q}', width=4,
                           command=lambda k=k, q=q: self.set_dev(k, q)).grid(row=i, column=2 + j)
        fl = ttk.Frame(t1)
        fl.pack(fill='x', **pad)
        self.flags = {}
        for i, (k, label) in enumerate((('god', 'Бессмертие'), ('one_hit', 'Убийство с 1 удара'),
                                        ('aggro', 'Мобы отвечают на удар'),
                                        ('eid_anytime', 'Остров/башня в любое время'),
                                        ('safe_enchant', 'Заточка без поломки'),
                                        ('respawn_fast', 'Возрождение 30 с (боссы 60 с)'),
                                        ('exp_gap', 'Штраф опыта за разницу уровней'))):
            v = tk.BooleanVar()
            self.flags[k] = v
            ttk.Checkbutton(fl, text=label, variable=v, command=lambda k=k: self.set_flag(k)
                            ).grid(row=i // 3, column=i % 3, sticky='w', **pad)   # 2 ряда — влезает в окно

        # --- уровень и прочее ---
        f = ttk.LabelFrame(t1, text='Уровень, опыт, караты')
        f.pack(fill='x', **pad)
        self.lvl = tk.StringVar()
        ttk.Label(f, text='Уровень').grid(row=0, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.lvl, width=6).grid(row=0, column=1, **pad)
        ttk.Button(f, text='Поставить', command=lambda: self.cmd('level', value=self.lvl.get())
                   ).grid(row=0, column=2, **pad)
        for j, d in enumerate((1, 5, 10)):
            ttk.Button(f, text=f'+{d}', width=4, command=lambda d=d: self.add_level(d)
                       ).grid(row=0, column=3 + j)
        self.expv = tk.StringVar(value='1000')
        ttk.Label(f, text='Опыт').grid(row=1, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.expv, width=10).grid(row=1, column=1, **pad)
        ttk.Button(f, text='Добавить', command=lambda: self.cmd('exp', value=self.expv.get())
                   ).grid(row=1, column=2, **pad)
        ttk.Label(f, text='Караты').grid(row=2, column=0, sticky='w', **pad)
        for j, g in enumerate((10000, 100000, 1000000)):
            ttk.Button(f, text=f'+{g:,}'.replace(',', ' '),
                       command=lambda g=g: self.cmd('gold', value=g)).grid(row=2, column=1 + j, **pad)
        self.fletav, self.spv = tk.StringVar(value='10'), tk.StringVar(value='10')
        ttk.Label(f, text='Очки флетты').grid(row=3, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.fletav, width=6).grid(row=3, column=1, **pad)
        ttk.Button(f, text='Поставить', command=lambda: self.cmd('fleta', value=self.fletav.get())
                   ).grid(row=3, column=2, **pad)
        ttk.Label(f, text='Очки навыков').grid(row=4, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.spv, width=6).grid(row=4, column=1, **pad)
        ttk.Button(f, text='Поставить', command=lambda: self.cmd('skillpts', value=self.spv.get())
                   ).grid(row=4, column=2, **pad)
        self.petv = tk.StringVar(value='100000')
        ttk.Label(f, text='Опыт питомцу').grid(row=5, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.petv, width=10).grid(row=5, column=1, **pad)
        ttk.Button(f, text='Добавить', command=lambda: self.cmd('petexp', value=self.petv.get())
                   ).grid(row=5, column=2, **pad)
        self.satv = tk.StringVar(value='800')
        ttk.Label(f, text='Сытость питомца (0 — смерть)').grid(row=6, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.satv, width=10).grid(row=6, column=1, **pad)
        ttk.Button(f, text='Поставить', command=lambda: self.cmd('petsat', value=self.satv.get())
                   ).grid(row=6, column=2, **pad)
        ttk.Label(f, text='Высиживание питомца').grid(row=7, column=0, sticky='w', **pad)
        ttk.Button(f, text='Завершить сразу', command=lambda: self.cmd('pethatch')
                   ).grid(row=7, column=2, **pad)
        fb = ttk.Frame(t1)
        fb.pack(fill='x', **pad)
        ttk.Button(fb, text='Вылечить', command=lambda: self.cmd('heal')).pack(side='left', **pad)
        ttk.Button(fb, text='Сохранить', command=lambda: self.cmd('save')).pack(side='left', **pad)
        ttk.Label(t1, text='Новый уровень/статы видны сразу; после смены уровня клиенту иногда\n'
                           'нужно перезайти, чтобы обновить окно навыков.',
                  foreground='#666').pack(fill='x', **pad)

        # --- перемещение ---
        f = ttk.LabelFrame(t2, text='Мобы')
        f.pack(fill='x', **pad)
        self.huntv, self.radv = tk.StringVar(value='1'), tk.StringVar(value='1500')
        ttk.Label(f, text='К мобам уровня').grid(row=0, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.huntv, width=5).grid(row=0, column=1, **pad)
        ttk.Button(f, text='Перенестись', command=lambda: self.cmd('hunt', level=self.huntv.get())
                   ).grid(row=0, column=2, **pad)
        ttk.Button(f, text='Список мобов карты', command=self.show_mobs).grid(row=0, column=3, **pad)
        ttk.Label(f, text='Убить вокруг, радиус').grid(row=1, column=0, sticky='w', **pad)
        ttk.Entry(f, textvariable=self.radv, width=6).grid(row=1, column=1, **pad)
        ttk.Button(f, text='Убить', command=lambda: self.cmd('kill', radius=self.radv.get())
                   ).grid(row=1, column=2, **pad)

        f = ttk.LabelFrame(t2, text='Координаты (как на миникарте: 83.7 99.6 — или полные)')
        f.pack(fill='x', **pad)
        self.gx, self.gy = tk.StringVar(), tk.StringVar()
        ttk.Entry(f, textvariable=self.gx, width=8).pack(side='left', **pad)
        ttk.Entry(f, textvariable=self.gy, width=8).pack(side='left', **pad)
        ttk.Button(f, text='Перенестись (эта карта)', command=self.goto).pack(side='left', **pad)

        f = ttk.LabelFrame(t2, text='Точки телепорта (другая карта — через переподключение)')
        f.pack(fill='both', expand=True, **pad)
        self.wfilter = tk.StringVar()
        self.wfilter.trace_add('write', lambda *_: self.fill_warps())
        ttk.Entry(f, textvariable=self.wfilter).pack(fill='x', **pad)
        self.wlist = tk.Listbox(f, height=14)
        self.wlist.pack(fill='both', expand=True, **pad)
        self.wlist.bind('<Double-Button-1>', lambda _e: self.teleport())
        ttk.Button(f, text='Телепорт', command=self.teleport).pack(**pad)

        # --- предметы ---
        f = ttk.LabelFrame(t3, text='Выдать предмет (поиск по имени или id)')
        f.pack(fill='both', expand=True, **pad)
        self.ifilter, self.icount = tk.StringVar(), tk.StringVar(value='1')
        self.ifilter.trace_add('write', lambda *_: self.fill_items())
        ttk.Entry(f, textvariable=self.ifilter).pack(fill='x', **pad)
        self.ilist = tk.Listbox(f, height=20)
        self.ilist.pack(fill='both', expand=True, **pad)
        self.ilist.bind('<Double-Button-1>', lambda _e: self.give())
        fc = ttk.Frame(f)
        fc.pack(fill='x', **pad)
        ttk.Label(fc, text='Количество').pack(side='left', **pad)
        ttk.Entry(fc, textvariable=self.icount, width=6).pack(side='left', **pad)
        ttk.Button(fc, text='Выдать', command=self.give).pack(side='left', **pad)
        self.fill_items()

    def _build_bag(self, t, pad):
        """Массовые действия с сумкой (как «отметьте предметы и нажмите…» в Karos Unity)."""
        f = ttk.LabelFrame(t, text='Отметьте предметы (Ctrl/Shift — несколько) и выберите действие')
        f.pack(fill='both', expand=True, **pad)
        self.bfilter = tk.StringVar()
        self.bfilter.trace_add('write', lambda *_: self.fill_bag())
        ttk.Entry(f, textvariable=self.bfilter).pack(fill='x', **pad)
        self.blist = tk.Listbox(f, height=18, selectmode='extended')
        self.blist.pack(fill='both', expand=True, **pad)
        self.bag_items = []
        fs = ttk.Frame(f)
        fs.pack(fill='x', **pad)
        ttk.Button(fs, text='Обновить', command=self.load_bag).pack(side='left', **pad)
        ttk.Button(fs, text='Сортировать', command=self.bag_sort).pack(side='left', **pad)
        ttk.Button(fs, text='Отметить всё', command=lambda: self.blist.select_set(0, 'end')).pack(side='left', **pad)
        ttk.Button(fs, text='Всё снаряжение', command=lambda: self.select_bag(lambda x: x['kind'] == 1 and not x['improved'])
                   ).pack(side='left', **pad)
        ttk.Button(fs, text='Части/материалы', command=lambda: self.select_bag(lambda x: x['kind'] == 3)
                   ).pack(side='left', **pad)
        fa = ttk.Frame(f)
        fa.pack(fill='x', **pad)
        for text, act in (('Продать', 'sell'), ('Разобрать', 'dismantle'), ('В хранилище', 'stash'),
                          ('Уничтожить', 'destroy')):
            ttk.Button(fa, text=text, command=lambda a=act: self.bag_act(a)).pack(side='left', **pad)
        ttk.Label(t, text='Продажа — по цене торговца (проданное можно выкупить у торговца), разборка — по\n'
                          'правилам клиента (стоимость и шанс), хранилище — личное, 10 карат за вещь.\n'
                          'Надетое не показывается. «Всё снаряжение» не отмечает улучшенные вещи.\n'
                          'Перед сортировкой закройте в игре окна торговли, заточки, крафта и хранилища.',
                  foreground='#666').pack(fill='x', **pad)

    def _build_craft(self, t, pad):
        """«Изготовить всё» (в Karos Unity — «столько, сколько хватает материалов и денег»)."""
        f = ttk.LabelFrame(t, text='Рецепты, на которые сейчас хватает материалов')
        f.pack(fill='both', expand=True, **pad)
        self.cfilter = tk.StringVar()
        self.cfilter.trace_add('write', lambda *_: self.fill_craft())
        ttk.Entry(f, textvariable=self.cfilter).pack(fill='x', **pad)
        self.clist = tk.Listbox(f, height=12, exportselection=False)
        self.clist.pack(fill='both', expand=True, **pad)
        self.clist.bind('<<ListboxSelect>>', lambda _e: self.craft_select())
        self.recipes, self.craft_view = [], []
        self.cinfo = tk.StringVar(value='Нажмите «Обновить»')
        ttk.Label(f, textvariable=self.cinfo, wraplength=520, justify='left').pack(fill='x', **pad)
        fb = ttk.Frame(f)
        fb.pack(fill='x', **pad)
        ttk.Button(fb, text='Обновить', command=self.load_craft).pack(side='left', **pad)
        ttk.Button(fb, text='Изготовить всё', command=self.craft_all).pack(side='left', **pad)
        ttk.Label(t, text='Шанс, цена и материалы — рецепта; не больше 1000 попыток за раз. Останавливается\n'
                          'на нехватке или полной сумке. Улучшенное снаряжение в материалы не идёт.\n'
                          'Навык ремесла и ремесленник рядом не требуются.', foreground='#666').pack(fill='x', **pad)

    def _build_pet(self, t, pad):
        f = ttk.LabelFrame(t, text='Питомец')
        f.pack(fill='x', **pad)
        self.petinfo = tk.StringVar(value='—')
        ttk.Label(f, textvariable=self.petinfo, wraplength=500).pack(fill='x', **pad)
        f = ttk.LabelFrame(t, text='Автокормление (корм его стадии из сумки)')
        f.pack(fill='x', **pad)
        self.autofeed, self.feedbelow = tk.BooleanVar(), tk.StringVar(value='40')
        ttk.Checkbutton(f, text='Кормить, когда сытость ниже, %', variable=self.autofeed).pack(side='left', **pad)
        ttk.Entry(f, textvariable=self.feedbelow, width=5).pack(side='left', **pad)
        f = ttk.LabelFrame(t, text='Сбор трофеев питомцем — что подбирать (без отметок — всё)')
        f.pack(fill='x', **pad)
        self.lootv = {}
        for i, (k, label) in enumerate((('gold', 'Караты'), ('gear', 'Снаряжение'), ('use', 'Расходники'),
                                        ('mat', 'Материалы'), ('other', 'Прочее'))):
            v = tk.BooleanVar()
            self.lootv[k] = v
            ttk.Checkbutton(f, text=label, variable=v).grid(row=i // 3, column=i % 3, sticky='w', **pad)
        f = ttk.LabelFrame(t, text='Тип способности (в клиенте — один раз, здесь можно сменить)')
        f.pack(fill='x', **pad)
        self.ptype = tk.IntVar(value=0)
        for k, label in ((1, 'Чарование (атака)'), (2, 'Удача (добыча, крит)'), (3, 'Помощь (продажа вещей)')):
            ttk.Radiobutton(f, text=label, value=k, variable=self.ptype).pack(side='left', **pad)
        fb = ttk.Frame(t)
        fb.pack(fill='x', **pad)
        ttk.Button(fb, text='Применить', command=self.pet_apply).pack(side='left', **pad)
        ttk.Button(fb, text='Обновить', command=lambda: self.pet_apply(read_only=True)).pack(side='left', **pad)
        ttk.Label(t, text='Сбор трофеев работает, когда у питомца есть способность сбора (клиент сам\n'
                          'посылает подбор). Автокормление срабатывает при голоде (раз в 30 мин призыва)\n'
                          'и сразу при «Применить».', foreground='#666').pack(fill='x', **pad)

    # ---------- действия ----------
    def load_bag(self):
        r = call('/cmd', {'op': 'bag', 'act': 'list'})
        if not r.get('ok'):
            self.say(r.get('error', 'ошибка'))
            return
        self.bag_items = (r.get('result') or {}).get('items', [])
        self.fill_bag()

    def fill_bag(self):
        q = self.bfilter.get().strip().lower()
        self.bag_view = [x for x in self.bag_items if not q or q in x['name'].lower() or q == str(x['item'])]
        self.blist.delete(0, 'end')
        for x in self.bag_view:
            extra = ((' · улучшено' if x['improved'] else '') + (' · продажа %d' % x['sell'] if x['sell'] else '')
                     + (' · разбирается' if x['dismantle'] else ''))
            self.blist.insert('end', f"[{x['cont']}:{x['cell']:>2}] {x['name']} ×{x['n']}{extra}")

    def select_bag(self, pred):
        self.blist.select_clear(0, 'end')
        for i, x in enumerate(getattr(self, 'bag_view', [])):
            if pred(x):
                self.blist.select_set(i)

    def bag_act(self, act):
        sel = [self.bag_view[i] for i in self.blist.curselection()]
        if not sel:
            self.say('Ничего не отмечено')
            return
        verb = {'sell': 'Продать', 'dismantle': 'Разобрать', 'destroy': 'Уничтожить', 'stash': 'В хранилище'}[act]
        if act != 'stash':
            lines = [f"{x['name']} ×{x['n']}{' (улучшено)' if x['improved'] else ''}" for x in sel]
            better = sum(1 for x in sel if x['improved'])
            text = (f'{verb}: {len(sel)}' + (f', из них улучшенных: {better}' if better else '') + '\n\n'
                    + '\n'.join(lines[:15]) + ('\n…' if len(lines) > 15 else ''))
            if not messagebox.askyesno('Сумка', text, default='no', parent=self.root):
                return
        r = call('/cmd', {'op': 'bag', 'act': act, 'cells': [x['ref'] for x in sel]})
        res = r.get('result') or {}
        stale = res.get('stale', 0)
        self.say(f"{verb}: {len(res.get('done', []))} из {len(sel)}; караты {res.get('gold_delta', 0):+}"
                 + (f'; изменились в игре и не тронуты: {stale}' if stale else '')
                 if r.get('ok') else r.get('error', 'ошибка'))
        self.load_bag()

    def bag_sort(self):
        r = call('/cmd', {'op': 'bag', 'act': 'sort'})
        res = r.get('result') or {}
        if not r.get('ok') or res.get('error'):
            self.say(res.get('error') or r.get('error', 'ошибка'))
            return
        self.say(f"Сортировка: переложено {res.get('moved', 0)}, стопок объединено {res.get('merged', 0)}"
                 + (f"; пропущены сумки {res['skipped']}" if res.get('skipped') else ''))
        self.load_bag()

    def load_craft(self):
        r = call('/cmd', {'op': 'craft', 'act': 'list'})
        if not r.get('ok'):
            self.say(r.get('error', 'ошибка'))
            return
        self.recipes = (r.get('result') or {}).get('recipes', [])
        self.fill_craft()

    def fill_craft(self):
        q = self.cfilter.get().strip().lower()
        self.craft_view = [x for x in self.recipes if not q or q in x['name'].lower() or q in x['group'].lower()]
        self.clist.delete(0, 'end')
        self.cinfo.set('' if self.craft_view else 'Нет рецептов, на которые хватает материалов и карат')
        for x in self.craft_view:
            chance = '' if x['chance'] >= 100 else f" · шанс {x['chance']:g}%"
            self.clist.insert('end', f"{x['name']} — попыток {x['count']}{chance}  [{x['group']}]")

    def craft_text(self, x):
        n = x['count']
        out = [f"{x['name']}: попыток {n}, шанс каждой {x['chance']:g}%", 'Уйдёт, если хватит места:']
        out += [f'  {name} ×{per * n}' for name, per in x['mats']]
        if x['cost']:
            out.append(f"  караты {x['cost'] * n}")
        if x['kept']:
            out.append(f"Улучшенные вещи не берутся: {x['kept']}")
        return '\n'.join(out)

    def craft_select(self):
        sel = self.clist.curselection()
        if sel:
            self.cinfo.set(self.craft_text(self.craft_view[sel[0]]))

    def craft_all(self):
        sel = self.clist.curselection()
        if not sel:
            self.say('Не выбран рецепт')
            return
        x = self.craft_view[sel[0]]
        if not messagebox.askyesno('Изготовить всё', self.craft_text(x), default='no', parent=self.root):
            return
        r = call('/cmd', {'op': 'craft', 'act': 'make', 'rid': x['rid'], 'count': x['count']})
        res = r.get('result') or {}
        if not r.get('ok') or res.get('error'):
            self.say(res.get('error') or r.get('error', 'ошибка'))
        else:
            self.say(f"{x['name']}: изготовлено {res['made']}, неудач {res['failed']} — {res['stop']}")
        self.load_craft()

    def pet_apply(self, read_only=False):
        args = {'op': 'pet'}
        if not read_only:
            try:
                below = int(self.feedbelow.get())
            except ValueError:
                below = 40
            args.update(autofeed=self.autofeed.get(), feed_below=below,
                        loot_cats=[k for k, v in self.lootv.items() if v.get()])
            if self.ptype.get():
                args['ptype'] = self.ptype.get()
        r = call('/cmd', args)
        if not r.get('ok'):
            self.say(r.get('error', 'ошибка'))
            return
        res = r.get('result') or {}
        cfg, pet = res.get('cfg') or {}, res.get('pet')
        self.autofeed.set(cfg.get('autofeed', False))
        self.feedbelow.set(str(cfg.get('feed_below', 40)))
        for k, v in self.lootv.items():
            v.set(k in cfg.get('loot', []))
        self.petinfo.set(f"{pet['name']} ур.{pet['level']}, тип: {pet['type']}, сытость {pet['satiety']}/{pet['cap']}"
                         f"{', призван' if pet['out'] else ''}" if pet else 'Питомец не выбран')
        self.say('питомец: ' + ('настройки сохранены' if not read_only else 'обновлено'))

    def _build_quests(self, t, pad):
        """Автозадания (как в Karos Unity): принять все доступные по уровню, сдать готовые без похода к NPC."""
        f = ttk.Frame(t)
        f.pack(fill='x', **pad)
        ttk.Button(f, text='Обновить', command=lambda: self.quests_show('list')).pack(side='left', **pad)
        ttk.Button(f, text='Принять доступные', command=lambda: self.quests_show('accept')).pack(side='left', **pad)
        ttk.Button(f, text='Сдать готовые', command=lambda: self.quests_show('turn_in')).pack(side='left', **pad)
        ttk.Label(t, text='Принимаются квесты по уровню с выполненным предыдущим (не больше 20 активных). '
                          'Сдаются те, где выполнены все цели; «поговорить» и «отнести» — у NPC в игре.',
                  wraplength=540).pack(fill='x', **pad)
        self.qlist = tk.Listbox(t, height=14)
        self.qlist.pack(fill='both', expand=True, **pad)

    def quests_show(self, act):
        r = call('/cmd', dict(op='quests', act=act))
        res = r.get('result') if r.get('ok') else None
        if not res or 'error' in res:
            return self.say((res or {}).get('error') or r.get('error', 'нет персонажа в игре'))
        self.qlist.delete(0, 'end')
        for q in sorted(res['active'], key=lambda q: (not q['ready'], q['level'] or 0)):
            self.qlist.insert('end', '%s ур.%s  %s  [%s]%s' % ('✔' if q['ready'] else '·', q['level'], q['title'],
                                                               ' '.join(q['progress']),
                                                               '  — готов к сдаче' if q['ready'] else ''))
        what = {'accept': 'принято', 'turn_in': 'сдано'}.get(act)
        self.say((f'{what}: {len(res["done"])}. ' if what else '') + f'доступно ещё: {res["available"]}')

    def _build_hair(self, t, pad):
        """Причёски своего класса (вещь в сумку, надеть в игре) и цвет волос (сразу, S 06/5b)."""
        f = ttk.LabelFrame(t, text='Причёска (вещь на 30 дней — в сумку, наденьте её в игре)')
        f.pack(fill='x', **pad)
        self.hairv = tk.StringVar()
        self.hairbox = ttk.Combobox(f, textvariable=self.hairv, state='readonly', width=40)
        self.hairbox.pack(side='left', **pad)
        ttk.Button(f, text='Обновить', command=self.hair_load).pack(side='left', **pad)
        ttk.Button(f, text='Выдать', command=self.hair_give).pack(side='left', **pad)
        self.hair_ids = []
        fc = ttk.LabelFrame(t, text='Цвет волос (меняется сразу; «свой» — цвет персонажа)')
        fc.pack(fill='x', **pad)
        self.hair_colors = ttk.Frame(fc)
        self.hair_colors.pack(fill='x', **pad)

    def hair_load(self):
        r = call('/cmd', dict(op='hair', act='list'))
        res = r.get('result') if r.get('ok') else None
        if not res:
            return self.say(r.get('error', 'нет персонажа в игре'))
        self.hair_ids = [s['id'] for s in res['styles']]
        self.hairbox['values'] = [s['name'] for s in res['styles']]
        if self.hair_ids:
            self.hairbox.current(0)
        for w in self.hair_colors.winfo_children():
            w.destroy()
        for i, c in enumerate(res['palette']):
            ttk.Button(self.hair_colors, text=c['name'], width=11,
                       command=lambda i=i: self.cmd('hair', act='color', color=i)
                       ).grid(row=i // 5, column=i % 5, padx=2, pady=2)
        self.say('цвет сейчас: %s' % res['color'])

    def hair_give(self):
        i = self.hairbox.current()
        if 0 <= i < len(self.hair_ids):
            self.cmd('hair', act='style', id=self.hair_ids[i])

    def say(self, text):
        self.msg.set(text)

    def cmd(self, op, **args):
        r = call('/cmd', dict(op=op, **args))
        if not r.get('ok'):
            self.say(r.get('error', 'ошибка'))
        else:
            res = r.get('result')
            self.say(f'{op}: готово' + (f' ({res})' if isinstance(res, (int, bool)) and op == 'kill' else ''))
        self.refresh(force=True)
        return r

    def set_dev(self, key, value=None):
        if value is None:
            try:
                value = float(self.vars[key].get().replace(',', '.'))
            except ValueError:
                return self.say('нужно число')
        r = call('/dev', {key: value})
        self.say('' if r.get('ok') else r.get('error', 'ошибка'))
        self.refresh(force=True)

    def set_account(self):
        r = call('/account', {'id': self.accv.get()})
        self.say(f"аккаунт: {r.get('active')} — выйдите в выбор персонажа" if r.get('ok') else r.get('error', ''))

    def set_flag(self, key):
        call('/dev', {key: self.flags[key].get()})

    def add_level(self, d):
        st = call('/state')
        pl = (st.get('players') or [{}])[0]
        self.cmd('level', value=int(pl.get('level', 1)) + d)

    def goto(self):
        try:
            x, y = float(self.gx.get().replace(',', '.')), float(self.gy.get().replace(',', '.'))
        except ValueError:
            return self.say('координаты — числа')
        if x < 1000 and y < 1000:          # как на миникарте (×100)
            x, y = x * 100, y * 100
        self.cmd('goto', x=x, y=y)

    def show_mobs(self):
        r = call('/cmd', {'op': 'mobs'})
        if not r.get('ok'):
            return self.say(r.get('error', ''))
        lines = [f"ур.{g['level']:>3}: {g['count']:>3} шт., ближайший {g['dist']} "
                 f"({g['x'] / 100:.1f} {g['y'] / 100:.1f})" for g in r['result']]
        w = tk.Toplevel(self.root)
        w.title('Мобы карты')
        w.attributes('-topmost', True)
        lb = tk.Listbox(w, width=60, height=25)
        lb.pack(fill='both', expand=True)
        for ln in lines:
            lb.insert('end', ln)
        lb.bind('<Double-Button-1>', lambda _e: (self.cmd('hunt', level=r['result'][lb.curselection()[0]]['level'])
                                                 if lb.curselection() else None))

    def fill_warps(self):
        flt = self.wfilter.get().lower()
        self.wshown = [w for w in self.warps
                       if not flt or flt in w['name'].lower() or flt in w['map_name'].lower()]
        self.wlist.delete(0, 'end')
        for w in self.wshown:
            self.wlist.insert('end', f"{w['name']}  [{w['map_name']}]  #{w['id']}")

    def teleport(self):
        sel = self.wlist.curselection()
        if sel:
            self.cmd('teleport', target=self.wshown[sel[0]]['id'])

    def fill_items(self):
        flt = self.ifilter.get().strip().lower()
        if flt.isdigit():
            shown = [x for x in self.items if str(x[0]).startswith(flt)]
        else:
            shown = [x for x in self.items if flt in x[1].lower()] if flt else self.items[:300]
        self.ishown = shown[:500]
        self.ilist.delete(0, 'end')
        for iid, name in self.ishown:
            self.ilist.insert('end', f'{iid}  {name}')

    def give(self):
        sel = self.ilist.curselection()
        if sel:
            self.cmd('item', id=self.ishown[sel[0]][0], count=self.icount.get() or 1)

    # ---------- обновление ----------
    def refresh(self, force=False):
        if self.root.state() != 'withdrawn' or force:
            st = call('/state')
            if 'dev' in st:
                if st['dev'] != self.dev:
                    self.dev = st['dev']
                    for k, v in self.vars.items():
                        v.set(f"{self.dev.get(k, 1):g}")
                    for k, v in self.flags.items():
                        v.set(bool(self.dev.get(k)))
                acc = st.get('accounts') or {}
                if acc.get('list'):
                    self.accbox['values'] = acc['list']
                    if self.root.focus_get() is not self.accbox:
                        self.accv.set(acc.get('active', ''))
                if st.get('warps') and not self.warps:
                    self.warps = st['warps']
                    self.fill_warps()
                pls = st.get('players') or []
                if pls:
                    p = pls[0]
                    self.status.set(
                        f"{p['name']}  ур.{p['level']}  опыт {p['exp']}/{p['exp_next']}  "
                        f"HP {p['hp']}/{p['maxhp']}  MP {p['mp']}/{p['maxmp']}\n"
                        f"{p['map_name']} ({p['x'] / 100:.1f} {p['y'] / 100:.1f})  караты {p['gold']:,}  "
                        f"флетта {p['fleta']}  очки навыков {p['sp']}".replace(',', ' '))
                    if not self.lvl.get():
                        self.lvl.set(str(p['level']))
                else:
                    self.status.set('Сервер работает, персонаж не в игре')
            else:
                self.status.set(st.get('error', 'нет связи с сервером'))
        if not force:
            self.root.after(1000, self.refresh)

    def _poll_queue(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == 'toggle':
                    self.toggle()
                elif kind == 'error':
                    self.say(val)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_queue)

    def hide(self):
        self.root.withdraw()

    def toggle(self):
        if self.root.state() == 'withdrawn':
            self.root.deiconify()
            self.root.attributes('-topmost', True)
            self.root.lift()
            self.root.focus_force()
            self.refresh(force=True)
        else:
            self.hide()

    def run(self):
        self.root.mainloop()


if __name__ == '__main__':
    Panel().run()
