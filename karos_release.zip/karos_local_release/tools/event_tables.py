"""Посещение и дневник событий: eventDiary*.lod_rus -> data/events.json.

eventDiary_attendance (режим 1): число (14), записи по 148 байт:
  +0 номер, +4 вид (1 — каждый день, 2 — N входов за месяц), +8 N, +12 награда
  (eventDiary_reward), +16 1, +20 текст (cp1251).
eventDiary_reward: число (134), записи по 20 байт: награда, порядковый, вид
  (0 — опыт, 1 — караты, 2 — предмет), значение (опыт/караты/предмет), количество.
  Пример: 10001 (каждый день) — 60 опыта, 100 карат, «Дух воина ур.2» — ровно это пришло
  в почте «Награда за посещение» в записи оригинала (orig_1: 100 карат + 54617).
eventDiary: 30 заданий дневника (записи ~1239 байт: номер, …, название, описание) —
  награды 1001…1030 в eventDiary_reward.

Запуск: python tools/event_tables.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                     # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'events.json')


def lod(n):
    return decode(open(os.path.join(LOD, n + '.lod_rus'), 'rb').read(), 1)


def main():
    p = lod('eventDiary_reward')
    rewards = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        rid, _i, kind, val, cnt = struct.unpack_from('<5I', p, 4 + 20 * k)
        r = rewards.setdefault(rid, {'exp': 0, 'gold': 0, 'items': []})
        if kind == 0:
            r['exp'] += val
        elif kind == 1:
            r['gold'] += val
        elif kind == 2:
            r['items'].append([val, max(1, cnt)])
    p = lod('eventDiary_attendance')
    att = []
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        o = 4 + 148 * k
        aid, kind, n, rid, _one = struct.unpack_from('<5I', p, o)
        text = p[o + 20:o + 148].split(b'\0')[0].decode('cp1251', 'replace').strip()
        att.append({'id': aid, 'kind': kind, 'n': n, 'reward': rid, 'text': text})
    json.dump({'attendance': att, 'rewards': rewards}, open(OUT, 'w', encoding='utf-8'),
              ensure_ascii=False, separators=(',', ':'))
    print(f'{len(att)} наград за посещение, {len(rewards)} наборов наград -> {OUT}')
    for a in att:
        print(' ', a['kind'], a['n'], rewards.get(a['reward']), a['text'][:50])


if __name__ == '__main__':
    main()
