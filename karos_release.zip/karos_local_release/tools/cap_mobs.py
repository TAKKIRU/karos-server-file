"""Мобы из записи трафика (data/captures/*.jsonl, tools/pcap_frames.py):
уровень, HP (04/02), урон игрока (05/02), опыт за убийство (08/01 +63), добыча.

Раскладка (как у нашего сервера, сверено с записью Karos Genesis):
  04/02: +1 вид (1 — NPC/моб), +2 id LE32, +6 x,y,z, +22 HP, +26 макс. HP, +30 MP, +34 макс. MP,
         +50 уровень u16, +0x40 тип NPC (npcInfo id)
  05/02: +0 тип атакующего, +1 id, +15.. записи по 30 байт (тип, id LE32, урон i32)
  08/06: +0 тип, +1 id LE32 ..., текущее HP
  08/01: +37 уровень, +63 опыт u64, +71 опыт до уровня u64

Запуск: python tools/cap_mobs.py data/captures/genesis_1.jsonl
"""
import collections, datetime, json, struct, sys


def main(path):
    F = [json.loads(l) for l in open(path)]
    spawn = {}
    for x in F:
        if x['dir'] == 'S' and x['op'] == '04/02':
            p = bytes.fromhex(x['hex'])
            if len(p) >= 0x44 and p[1] == 1:
                mid = struct.unpack_from('<I', p, 2)[0]
                spawn[mid] = {'npc': struct.unpack_from('<I', p, 0x40)[0],
                              'lvl': struct.unpack_from('<H', p, 50)[0],
                              'maxhp': struct.unpack_from('<I', p, 26)[0],
                              'hp': struct.unpack_from('<I', p, 22)[0]}
    # кто я: eid из 02/05
    me = None
    for x in F:
        if x['op'] == '02/05' and x['dir'] == 'S':
            me = struct.unpack_from('>I', bytes.fromhex(x['hex']), 0)[0]
            break
    exp = None
    kills, dmg = [], collections.defaultdict(list)
    last_exp, lvl = None, None
    pending = {}
    for x in F:
        p = bytes.fromhex(x['hex'])
        if x['dir'] == 'S' and x['op'] == '05/02' and len(p) >= 15 + 9:
            n = (len(p) - 15) // 30
            for i in range(n):
                o = 15 + i * 30
                tid = struct.unpack_from('<I', p, o + 1)[0]
                d = struct.unpack_from('<i', p, o + 6)[0]
                if tid in spawn:
                    dmg[tid].append(d)
        if x['dir'] == 'S' and x['op'] == '08/06' and len(p) >= 9:
            tid = struct.unpack_from('>I', p, 1)[0]          # 08/06: тип, id BE, ?, HP BE, MP BE, кто
            hp = struct.unpack_from('>I', p, 9)[0] if len(p) >= 13 else None
            if tid in spawn and hp == 0 and tid not in pending:
                pending[tid] = x['t']
        if x['dir'] == 'S' and x['op'] == '08/01' and len(p) >= 79:
            e = struct.unpack_from('<Q', p, 63)[0]
            lv = struct.unpack_from('<I', p, 37)[0] & 0xffff
            if last_exp is not None and pending:
                gain = e - last_exp if lv == lvl else None
                for tid, t in list(pending.items()):
                    if x['t'] - t < 3:
                        kills.append((t, tid, gain, lv))
                        gain = 0
                    del pending[tid]
            last_exp, lvl = e, lv
    print('я', me, 'мобов в 04/02:', len(spawn), 'убийств:', len(kills))
    by = collections.defaultdict(list)
    for t, tid, gain, lv in kills:
        s = spawn[tid]
        by[(s['npc'], s['lvl'], s['maxhp'])].append((gain, lv, sum(dmg[tid]), len(dmg[tid])))
        print(datetime.datetime.fromtimestamp(t).strftime('%H:%M:%S'), 'npc', s['npc'], 'ур', s['lvl'],
              'HP', s['maxhp'], 'урон', sum(dmg[tid]), 'ударов', len(dmg[tid]), 'опыт', gain, 'игрок ур', lv)
    return spawn, kills


if __name__ == '__main__':
    main(sys.argv[1])
