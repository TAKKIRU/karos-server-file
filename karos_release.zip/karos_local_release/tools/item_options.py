"""Справочник особых характеристик предметов -> data/item_options.json.

Цепочка клиента (подсказка 0x00638817 -> 0x0063870f):
  номер опции (u16 в записи предмета: белые +125.., жёлтые +135..) ->
  uniqueOptionType.lod (режим 1: u32 число, записи 10 байт: u16 номер, u32 навык, u32 ?) ->
  skillLevel (навык, ур.1): +264 5 × u32 id эффектов ->
  skillData.lod (режим 0): запись эффекта — +0 id, +4 тип характеристики, +0x18 значение
  (double, «+3.00»), +0x20 процент (double, «+5.00%»).
Название типа — switch 0x006076cb (тип -> строка string.lod).
Выход: {номер: {"skill": id, "flag": x, "effects": [[тип, значение, процент, "название"], ...]}}

Плюс вставки -> data/socket_attrs.json (itemCombAttr.lod).

Запуск: python tools/item_options.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
TYPE_STR = {1: 0x526f, 0x51: 0x526f, 2: 0x5271, 100: 0x5271, 3: 0x5270, 4: 0x5273, 0x66: 0x5273,
            5: 0x5272, 0x65: 0x5272, 6: 0x5274, 7: 0x7a88, 8: 0x5276, 9: 0x7a89, 10: 0x5279,
            0xb: 0x5297, 0xc: 0x7a8a, 0xd: 0x7a8b, 0xe: 0x7a8c, 0xf: 0x7a8d, 0x10: 0x527f,
            0x11: 0x5275, 0x12: 0x7a8e, 0x13: 0x5277, 0x14: 0x7a8f, 0x15: 0x527a, 0x16: 0x5280,
            0x17: 0x7a90, 0x18: 0x7a91, 0x19: 0x7a92, 0x1b: 0x7a93, 0x1c: 0x528a, 0x1d: 0x528b,
            0x1e: 0x7a94, 0x1f: 0x7a95, 0x20: 0x7a96, 0x21: 0x7a97, 0x69: 0x7a97, 0x22: 0x7a98,
            0x23: 0x7a98, 0x24: 0x7a99, 0x2e: 0x7adf, 0x2f: 0x7ae0, 0x30: 0x7ae1, 0x31: 0x7ae2,
            0x32: 0x7ae3, 0x33: 0x7ae4, 0x34: 0x7ae5, 0x35: 0x7ae6, 0x36: 0x7ae7, 0x37: 0x7ae8,
            0x38: 0x7ae9, 0x39: 0x7aea, 0x3a: 0x5283, 0x3b: 0x521f, 0x3c: 0x521f, 0x3e: 0x521f,
            0x52: 0x521f, 0x3f: 0x7b32, 0x40: 0x7b36, 0x41: 0x7b34, 0x47: 0x7b33, 0x48: 0x7b35,
            0x49: 0x560a, 0x4a: 0x560b, 0x50: 0x90d6, 0x53: 0x90d7, 0x54: 0x90d9, 0x55: 0x90eb,
            0x56: 0x90ec, 0x57: 0x90ed, 0x60: 0x7b3a, 0x61: 0x7b3b, 0x62: 0x7b3c, 99: 0x7b3d,
            0x67: 0x90da, 0x6c: 0x90d5}


def strings():
    d = decode(open(os.path.join(LOD, 'string.lod_rus'), 'rb').read(), 1)

    def get(i):
        o = d.find(struct.pack('<I', i))
        while o >= 0:
            t = d[o + 4:o + 200].split(b'\0')[0]
            if len(t) > 2:
                return t.decode('cp1251', 'replace')
            o = d.find(struct.pack('<I', i), o + 1)
        return ''
    return get


def main():
    d = decode(open(os.path.join(LOD, 'uniqueOptionType.lod_rus'), 'rb').read(), 1)
    n = struct.unpack_from('<I', d, 0)[0]
    opts = {}
    for k in range(n):
        i, s, x = struct.unpack_from('<HII', d, 4 + 10 * k)
        opts[i] = (s, x)
    L = decode(open(os.path.join(LOD, 'skillLevel.lod_rus'), 'rb').read(), 0)
    SD = decode(open(os.path.join(LOD, 'skillData.lod_rus'), 'rb').read(), 0)
    name = strings()
    out = {}
    for i, (s, x) in sorted(opts.items()):
        effs = []
        m = re.search(re.escape(struct.pack('<II', s, 1)), L)
        ids = struct.unpack_from('<5I', L, m.start() + 264) if m else (s,)
        for e in ids:
            if not e:
                continue
            o = SD.find(struct.pack('<I', e))
            while o >= 0:
                typ = struct.unpack_from('<I', SD, o + 4)[0]
                val, pct = struct.unpack_from('<2d', SD, o + 0x18)
                if 0 < typ < 200 and abs(val) < 1e7 and abs(pct) < 1e4:
                    effs.append([typ, round(val, 3), round(pct, 3), name(TYPE_STR.get(typ, 0))])
                    break
                o = SD.find(struct.pack('<I', e), o + 1)
        out[i] = {'skill': s, 'flag': x, 'effects': effs}
    json.dump(out, open(os.path.join(ROOT, 'data', 'item_options.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    # вставки (камни/черепа/руны): itemCombAttr.lod (режим 1: u32 число, записи 72 байта:
    # +0 предмет, +4 группа 1 аксессуары / 2 оружие / 3 броня, +8 тип характеристики,
    # +28 значение double, +36 процент double, +44 навык)
    c = decode(open(os.path.join(LOD, 'itemCombAttr.lod_rus'), 'rb').read(), 1)
    sock = {}
    for k in range(struct.unpack_from('<I', c, 0)[0]):
        r = c[4 + 72 * k:4 + 72 * (k + 1)]
        gem, grp, typ = struct.unpack_from('<3I', r, 0)
        val, pct = struct.unpack_from('<2d', r, 28)
        sock[gem] = [grp, typ, round(val, 3), round(pct, 3), name(TYPE_STR.get(typ, 0))]
    json.dump(sock, open(os.path.join(ROOT, 'data', 'socket_attrs.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    print(f'{len(sock)} вставок -> data/socket_attrs.json; 55111:', sock.get(55111))
    print(f'{len(out)} опций -> data/item_options.json')
    for i in (13, 38, 49, 51, 83, 87, 91):
        print(' ', i, out.get(i))


if __name__ == '__main__':
    main()
