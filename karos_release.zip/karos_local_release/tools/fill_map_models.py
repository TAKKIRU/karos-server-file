"""Недостающие модели объектов карт -> копировать из соседних клиентов.

Клиент грузит объекты карты из Map/<карта>/Object/<карта>.mo. Если модели (._OB) нет ни в
одной папке ResUnpak, игра падает: «MOB_DVL_RIPPER201_LEGALLUSS._OB File Not Found»
(Гипогей Миродской капеллы, карта bs). Модели есть в arena_open / el_origen
(ResUnpak/Map/Npc, тот же формат «OBJECT TYPE … 5.02.22»).

Скрипт: собирает имена ._OB из всех .mo наших карт, ищет их у нас (без учёта регистра),
недостающие копирует из донора в тот же относительный путь вместе с ._RC и текстурами
с тем же началом имени.

Запуск: python tools/fill_map_models.py [--dry]
"""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUR = os.path.join(ROOT, 'ResUnpak')
DONORS = [os.path.join(os.path.dirname(ROOT), d, 'ResUnpak') for d in ('arena_open', 'el_origen')]


def index(base):
    out = {}
    for dp, _dn, fn in os.walk(base):
        for f in fn:
            out.setdefault(f.lower(), os.path.join(dp, f))
    return out


def main(dry=False):
    ours = index(OUR)
    donors = [index(d) for d in DONORS if os.path.isdir(d)]
    need = {}
    for dp, _dn, fn in os.walk(os.path.join(OUR, 'Map')):
        for f in fn:
            if f.lower().endswith('.mo'):
                data = open(os.path.join(dp, f), 'rb').read()
                for m in set(re.findall(rb'[A-Za-z0-9_\-]+\._OB', data)):
                    name = m.decode('ascii', 'replace')
                    if name.lower() not in ours:
                        need.setdefault(name, set()).add(os.path.relpath(os.path.join(dp, f), OUR))
    copied, missing = 0, []
    for name, maps in sorted(need.items()):
        src = None
        for di, d in zip(DONORS, donors):
            if name.lower() in d:
                src = (di, d[name.lower()])
                break
        if not src:
            missing.append((name, sorted(maps)))
            continue
        base, path = src
        stem = name.lower()[:-4]
        folder = os.path.dirname(path)
        for f in os.listdir(folder):
            fl = f.lower()
            if fl.startswith(stem) and fl not in ours:
                rel = os.path.relpath(os.path.join(folder, f), base)
                dst = os.path.join(OUR, rel)
                print(('[dry] ' if dry else '') + 'копия', rel, '<-', os.path.basename(os.path.dirname(base)))
                if not dry:
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(os.path.join(folder, f), dst)
                ours[fl] = dst
                copied += 1
    print(f'нужно моделей: {len(need)}, скопировано файлов: {copied}, не найдено: {len(missing)}')
    for name, maps in missing:
        print('  нет нигде:', name, maps)


if __name__ == '__main__':
    main('--dry' in sys.argv)
