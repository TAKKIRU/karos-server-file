"""Магазины NPC: «Метка входа на Коралловый остров» у торговцев пристаней островов Зерона.

npcShop.lod_rus (режим 1): u32 число (282), записи по 138 байт: +0 NPC, +4 карта, +8 номер списка
  товаров, +12/+20 double коэффициенты цен, дальше название и иконка.
npcShopItem.lod_rus (режим 1): u32 число (1022), записи по 12 байт: список, предмет, порядок.
Списки 301 (оружие, Далтон) и 302 (одежда и ткани) у пристаней Зерона (карты 19007/19008/19009)
общие с Пельтроком (19005), поэтому торговцам Зерона даются свои списки 308/309: копия прежних +
метка 64005 (цена — из itemBase, 50 000 карат). Сервер сам проверяет уровень 70 и метку при переходе
на Коралловый остров (server.py, CORAL_*).

Правит файлы клиента в ResUnpak/Interface/IE_Lod (копии *.orig рядом) и пересчитывает
CheckFileListW.ten (tools/cashshop.update_checklist), иначе клиент пишет «Обнаружен измененный файл».
Повторный запуск безопасен: всегда собирается заново из *.orig.
Запуск (игра закрыта): python tools/patch_shops.py
"""
import os, shutil, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode, encode                            # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
SHOP, ITEMS = os.path.join(LOD, 'npcShop.lod_rus'), os.path.join(LOD, 'npcShopItem.lod_rus')
ZERON = (19007, 19008, 19009)
PASS = 64005                                      # «Метка входа на Коралловый остров»
NEW_LIST = {301: 308, 302: 309}                   # прежний список -> свой список Зерона
SHOP_REC, ITEM_REC = 138, 12


def _orig(path):
    if not os.path.exists(path + '.orig'):
        shutil.copy2(path, path + '.orig')
    return open(path + '.orig', 'rb').read()


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    raw_s, raw_i = _orig(SHOP), _orig(ITEMS)
    s, it = bytearray(decode(raw_s, 1)), decode(raw_i, 1)
    n = struct.unpack_from('<I', s, 0)[0]
    changed = 0
    for k in range(n):
        o = 4 + SHOP_REC * k
        npc, mp, lst = struct.unpack_from('<III', s, o)
        if mp in ZERON and lst in NEW_LIST:
            struct.pack_into('<I', s, o + 8, NEW_LIST[lst])
            changed += 1
    m = struct.unpack_from('<I', it, 0)[0]
    recs = [struct.unpack_from('<3I', it, 4 + ITEM_REC * k) for k in range(m)]
    tail = it[4 + ITEM_REC * m:]
    add = []
    for old, new in NEW_LIST.items():
        rows = sorted((o, i) for l, i, o in recs if l == old)
        add += [(new, i, o) for o, i in rows]
        add.append((new, PASS, (rows[-1][0] if rows else 0) + 1))
    recs = [r for r in recs if r[0] not in NEW_LIST.values()] + add
    out_i = struct.pack('<I', len(recs)) + b''.join(struct.pack('<3I', *r) for r in recs) + tail
    open(SHOP, 'wb').write(encode(bytes(s), raw_s, 1))
    open(ITEMS, 'wb').write(encode(out_i, raw_i, 1))
    assert decode(open(ITEMS, 'rb').read(), 1)[:len(out_i)] == out_i
    import cashshop
    fixed = cashshop.update_checklist()
    print(f'торговцев Зерона со своими списками: {changed}; товаров в списках {sorted(NEW_LIST.values())}: '
          f'{len(add)}; контрольные суммы обновлены: {fixed}')


if __name__ == '__main__':
    main()
