"""Подготовка чистого клиента Karos к локальному серверу (запускать один раз, игра закрыта).

Что делает (всё обратимо: рядом остаются копии *.orig / *.bak):
  1. AMo.exe — кнопка GXP открывает внутриигровой магазин за караты (tools/patch_amo_shop.py).
  2. CashShop.lod_rus + строка покупки «… за %d карат.» — товары магазина GameXP за караты
     (tools/cashshop.py, каталог data/gxp_catalog.tsv).
  3. npcShop/npcShopItem — «Метка входа на Коралловый остров» у торговцев пристаней Зерона
     (tools/patch_shops.py).
  4. EIDMain.lod_rus — «Парящий остров» и «Демоническая башня» без отряда (tools/patch_eid_solo.py).
  5. itemBase.lod_rus — стопки предметов по 999 (tools/patch_stacks.py).
  6. CheckFileListW.ten — пересчёт контрольных сумм изменённых файлов (иначе клиент пишет
     «Обнаружен измененный файл»).
weberforclntv2.dll (перехват соединения на 127.0.0.1 + исправление вылета GXP) уже лежит в сборке
готовым; если в клиенте старая версия — tools/patch_weber.py её исправит.

Запуск: setup_client.bat (или python -X utf8 tools/setup_client.py) из папки клиента.
Нужен только Python 3.8+ (сторонние модули не нужны).
"""
import os, sys, traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)


def step(name, fn):
    print(f'\n== {name}')
    try:
        r = fn()
        return r in (None, 0)
    except SystemExit as e:
        return e.code in (None, 0)
    except Exception:                                   # noqa: BLE001
        traceback.print_exc()
        return False


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    need = ['AMo.exe', 'CheckFileListW.ten', os.path.join('ResUnpak', 'Interface', 'IE_Lod', 'CashShop.lod_rus')]
    miss = [n for n in need if not os.path.exists(os.path.join(ROOT, n))]
    if miss:
        print('Это не папка клиента Karos (нет: ' + ', '.join(miss) + ').')
        print('Скопируйте сборку в корень клиента (рядом с AMo.exe) и запустите снова.')
        return 1
    import patch_amo_shop, patch_weber, cashshop, patch_shops, patch_eid_solo, patch_stacks
    ok = [step('AMo.exe: кнопка GXP -> магазин за караты', patch_amo_shop.main),
          step('weberforclntv2.dll: вылет на GXP', patch_weber.main),
          step('CashShop.lod_rus и строка покупки', cashshop.main),
          step('Магазины Зерона: метка Кораллового острова', patch_shops.main),
          step('EIDMain: Парящий остров и Демоническая башня в одиночку', patch_eid_solo.main),
          step('itemBase: стопки предметов по 999', patch_stacks.main)]
    print('\nГотово.' if all(ok) else '\nЕсть ошибки — см. выше (остальные шаги выполнены).')
    print('Дальше: start.bat (сервер), затем AMo-local.cmd (игра).')
    return 0 if all(ok) else 1


if __name__ == '__main__':
    sys.exit(main())
