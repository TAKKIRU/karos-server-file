// For every AMOPacket::* class: vftable entries, constructors (functions writing
// the vftable), and the functions that call those constructors (factory/registry).
// Writes packets.txt (summary) and ctors.c / factories.c (decompiled code).
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.program.model.mem.*;
import ghidra.app.decompiler.*;
import java.io.*;
import java.util.*;

public class PacketMap extends GhidraScript {
    DecompInterface dec;
    Map<Address, String> cache = new HashMap<>();

    String decomp(Function f) {
        if (cache.containsKey(f.getEntryPoint())) return cache.get(f.getEntryPoint());
        DecompileResults r = dec.decompileFunction(f, 60, monitor);
        String c = (r != null && r.decompileCompleted()) ? r.getDecompiledFunction().getC() : "// decompile failed\n";
        cache.put(f.getEntryPoint(), c);
        return c;
    }

    @Override
    public void run() throws Exception {
        String dir = getScriptArgs()[0];
        dec = new DecompInterface(); dec.openProgram(currentProgram);
        SymbolTable st = currentProgram.getSymbolTable();
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        Memory mem = currentProgram.getMemory();
        PrintWriter sum = new PrintWriter(new FileWriter(dir + "/packets.txt"));
        PrintWriter ctors = new PrintWriter(new FileWriter(dir + "/ctors.c"));
        PrintWriter vf = new PrintWriter(new FileWriter(dir + "/vfuncs.c"));
        Map<Address, Set<String>> factoryUse = new TreeMap<>();

        List<Symbol> vts = new ArrayList<>();
        for (Symbol s : st.getAllSymbols(true)) {
            if (s.getName().equals("vftable") && s.getParentNamespace() != null) {
                String ns = s.getParentNamespace().getName(true);
                if (ns.startsWith("AMOPacket::")) vts.add(s);
            }
        }
        sum.println("packet classes: " + vts.size());
        for (Symbol s : vts) {
            String cls = s.getParentNamespace().getName(true).replace("AMOPacket::", "");
            Address vt = s.getAddress();
            // vftable entries
            List<String> ents = new ArrayList<>();
            for (int i = 0; i < 24; i++) {
                Address slot = vt.add(i * 4);
                int p;
                try { p = mem.getInt(slot); } catch (Exception e) { break; }
                Address fa = vt.getNewAddress(p & 0xffffffffL);
                Function f = fm.getFunctionAt(fa);
                if (f == null) break;
                if (i > 0 && st.getPrimarySymbol(slot) != null && st.getPrimarySymbol(slot).getName().contains("meta")) break;
                ents.add(i + ":" + f.getEntryPoint());
                // decompile small virtuals (likely the handlers/serializers), skip shared base ones later via dedupe
                if (i >= 1 && i <= 6 && f.getBody().getNumAddresses() < 6000) {
                    vf.println("// ===== " + cls + " vslot " + i + " @" + f.getEntryPoint());
                    vf.println(decomp(f));
                }
            }
            // constructors: functions referencing the vftable address
            Set<Function> cs = new LinkedHashSet<>();
            for (Reference r : rm.getReferencesTo(vt)) {
                Function f = fm.getFunctionContaining(r.getFromAddress());
                if (f != null) cs.add(f);
            }
            StringBuilder cinfo = new StringBuilder();
            for (Function c : cs) {
                cinfo.append(c.getEntryPoint()).append(' ');
                ctors.println("// ===== " + cls + " ctor/dtor @" + c.getEntryPoint());
                String code = decomp(c);
                ctors.println(code.length() > 4000 ? code.substring(0, 4000) + "\n// ...truncated\n" : code);
                for (Reference r : rm.getReferencesTo(c.getEntryPoint())) {
                    Function caller = fm.getFunctionContaining(r.getFromAddress());
                    if (caller != null && !cs.contains(caller))
                        factoryUse.computeIfAbsent(caller.getEntryPoint(), k -> new TreeSet<>()).add(cls);
                }
            }
            sum.println(cls + " | vft " + vt + " | entries " + ents + " | ctor/dtor " + cinfo);
        }
        sum.println("\n== functions calling packet ctors (factory candidates), most classes first");
        List<Map.Entry<Address, Set<String>>> fl = new ArrayList<>(factoryUse.entrySet());
        fl.sort((a, b) -> b.getValue().size() - a.getValue().size());
        PrintWriter fac = new PrintWriter(new FileWriter(dir + "/factories.c"));
        int n = 0;
        for (Map.Entry<Address, Set<String>> e : fl) {
            Function f = fm.getFunctionAt(e.getKey());
            sum.println(e.getValue().size() + " classes  " + e.getKey() + " " + (f != null ? f.getName() : "") + "  " + (e.getValue().size() < 8 ? e.getValue() : ""));
            if (n++ < 6 && f != null) {
                fac.println("// ===== factory candidate @" + e.getKey() + " (" + e.getValue().size() + " classes)");
                fac.println(decomp(f));
            }
        }
        sum.close(); ctors.close(); vf.close(); fac.close();
    }
}
