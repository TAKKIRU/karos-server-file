import re, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
D = sys.argv[1]
txt = open(D + r'\vfuncs.c', encoding='utf-8', errors='replace').read()
blocks = re.split(r'// ===== (\S+) vslot (\d+) @([0-9a-f]+)\n', txt)
def ch(s):
    s = s.strip("'")
    if s.startswith('\\x'): return int(s[2:], 16)
    if s.startswith('\\'): return {'\\0': 0, '\\a': 7, '\\b': 8, '\\t': 9, '\\n': 10, '\\v': 11, '\\f': 12, '\\r': 13}.get(s, None)
    return ord(s)
rows = {}
for i in range(1, len(blocks), 4):
    cls, slot, addr, code = blocks[i], int(blocks[i+1]), blocks[i+2], blocks[i+3]
    if slot != 1: continue
    pairs = re.findall(r"\*\w+ == '((?:\\x[0-9a-f]{2}|\\.|.))'\)? && \(\w+\[1\] == '((?:\\x[0-9a-f]{2}|\\.|.))'", code)
    lens = re.findall(r'(0x[0-9a-f]+|\d+) < \*\(uint \*\)\(\w+ \+ 0x10\)', code)
    if not pairs:
        pairs2 = re.findall(r"== '((?:\\x[0-9a-f]{2}|\\.|.))'", code)
        pairs = [tuple(pairs2[:2])] if len(pairs2) >= 2 else []
    ops = sorted(set((ch(a), ch(b)) for a, b in pairs))
    ml = int(lens[0], 0) + 1 if lens else None
    rows[cls] = (ops, ml, addr)
bycat = collections.defaultdict(list)
for cls, (ops, ml, addr) in rows.items():
    if not ops: bycat['??'].append(f'{cls} (slot1 @{addr})'); continue
    for c, s in ops:
        bycat[c].append((s, cls, ml, addr))
out = []
for c in sorted(k for k in bycat if k != '??'):
    out.append(f'\n## {c:02x}')
    for s, cls, ml, addr in sorted(bycat[c]):
        out.append(f'{c:02x}/{s:02x}  {cls:45} minlen={ml}  parse@{addr}')
if '??' in bycat:
    out.append('\n## unresolved'); out += bycat['??']
open(D + r'\optable.txt', 'w', encoding='utf-8').write('\n'.join(out))
print('\n'.join(out))
