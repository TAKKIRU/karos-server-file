// Recon for Karos AMo.exe: network imports + callers, interesting RTTI classes,
// functions with switch tables whose cases look like packet categories.
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.program.model.lang.OperandType;
import ghidra.program.model.scalar.Scalar;
import ghidra.app.decompiler.*;
import java.io.*;
import java.util.*;

public class Recon extends GhidraScript {
    PrintWriter out;

    @Override
    public void run() throws Exception {
        String dir = getScriptArgs()[0];
        out = new PrintWriter(new FileWriter(dir + "/recon.txt"));
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        SymbolTable st = currentProgram.getSymbolTable();
        out.println("functions: " + fm.getFunctionCount());

        // 1. network imports and their callers
        String[] net = {"recv", "WSARecv", "send", "WSASend", "connect", "WSAConnect", "select", "WSAEventSelect", "WSAAsyncSelect", "closesocket", "ntohl", "ntohs", "htonl", "htons"};
        out.println("\n== network imports -> calling functions");
        for (String n : net) {
            for (Symbol s : st.getSymbols(n)) {
                Set<String> callers = new TreeSet<>();
                for (Reference r : rm.getReferencesTo(s.getAddress())) {
                    Function f = fm.getFunctionContaining(r.getFromAddress());
                    if (f != null) callers.add(f.getName() + "@" + f.getEntryPoint());
                    // thunk / IAT pointer: follow refs to the pointer too
                    for (Reference r2 : rm.getReferencesTo(r.getFromAddress())) {
                        Function f2 = fm.getFunctionContaining(r2.getFromAddress());
                        if (f2 != null) callers.add(f2.getName() + "@" + f2.getEntryPoint());
                    }
                }
                if (!callers.isEmpty()) out.println(n + " [" + s.getAddress() + "]: " + callers);
            }
        }

        // 2. RTTI / class names of interest
        out.println("\n== interesting class / symbol names");
        String[] kw = {"Packet", "Pkt", "Msg", "Net", "Session", "Socket", "Proc", "Recv", "Send", "Protocol", "Handler", "Dispatch", "Mob", "Npc", "Skill", "Attack", "Damage"};
        TreeSet<String> names = new TreeSet<>();
        for (Symbol s : st.getAllSymbols(true)) {
            String nm = s.getName(true);
            for (String k : kw) if (nm.contains(k)) { names.add(nm); break; }
            if (names.size() > 3000) break;
        }
        for (String nm : names) out.println(nm);

        // 3. strings of interest
        out.println("\n== strings of interest");
        String[] skw = {"packet", "Packet", "PACKET", "recv", "Recv", "opcode", "Opcode", "protocol", "Protocol", "unknown", "Unknown", "%02x", "%02X", "cmd", "Cmd"};
        DataIterator di = currentProgram.getListing().getDefinedData(true);
        int sc = 0;
        while (di.hasNext() && sc < 600) {
            Data d = di.next();
            if (!d.hasStringValue()) continue;
            String v = String.valueOf(d.getValue());
            for (String k : skw) if (v.contains(k)) {
                Set<String> users = new TreeSet<>();
                for (Reference r : rm.getReferencesTo(d.getAddress())) {
                    Function f = fm.getFunctionContaining(r.getFromAddress());
                    if (f != null) users.add(f.getEntryPoint().toString());
                }
                out.println(d.getAddress() + " " + v.replace("\n", "\\n") + "  <- " + users);
                sc++; break;
            }
        }

        // 4. functions with computed jumps (switch tables) -> decompile, score by packet-category cases
        out.println("\n== switch functions scored by packet-like cases");
        DecompInterface dec = new DecompInterface();
        dec.openProgram(currentProgram);
        List<String> rows = new ArrayList<>();
        int checked = 0;
        for (Function f : fm.getFunctions(true)) {
            if (monitor.isCancelled()) break;
            boolean sw = false;
            for (Instruction ins : currentProgram.getListing().getInstructions(f.getBody(), true)) {
                if (ins.getFlowType().isComputed() && ins.getFlowType().isJump()) { sw = true; break; }
            }
            if (!sw) continue;
            checked++;
            DecompileResults res = dec.decompileFunction(f, 30, monitor);
            if (res == null || !res.decompileCompleted()) continue;
            String c = res.getDecompiledFunction().getC();
            int cases = 0; Set<Integer> vals = new TreeSet<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("case (0x[0-9a-f]+|\\d+):").matcher(c);
            while (m.find()) {
                cases++;
                String t = m.group(1);
                vals.add(t.startsWith("0x") ? Integer.parseInt(t.substring(2), 16) : Integer.parseInt(t));
            }
            int[] cats = {2, 4, 5, 6, 8, 9, 0xa, 0xb, 0xf, 0x16};
            int hit = 0; for (int x : cats) if (vals.contains(x)) hit++;
            if (hit >= 6 || cases >= 25)
                rows.add(String.format("hit=%d cases=%d %s@%s size=%d vals=%s", hit, cases, f.getName(), f.getEntryPoint(), f.getBody().getNumAddresses(), vals.size() > 60 ? vals.size() + " values" : vals.toString()));
        }
        rows.sort(Comparator.reverseOrder());
        for (String r : rows) out.println(r);
        out.println("switch functions checked: " + checked);
        out.close();
    }
}
