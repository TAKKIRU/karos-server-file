// args: outdir outname hexAddr... -> ensure a function exists containing each address
// (create one starting right after the previous function / padding), then decompile it.
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.app.decompiler.*;
import java.io.*;
import java.util.*;

public class MakeFn extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        PrintWriter out = new PrintWriter(new FileWriter(a[0] + "/" + a[1]));
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        Listing L = currentProgram.getListing();
        AddressSpace sp = currentProgram.getAddressFactory().getDefaultAddressSpace();
        DecompInterface dec = new DecompInterface(); dec.openProgram(currentProgram);
        for (int i = 2; i < a.length; i++) {
            Address t = sp.getAddress(Long.parseLong(a[i], 16));
            Function f = fm.getFunctionContaining(t);
            if (f == null) {
                if (L.getInstructionAt(t) == null && L.getInstructionContaining(t) == null) disassemble(t);
                Function prev = getFunctionBefore(t);
                Address s = prev != null ? prev.getBody().getMaxAddress().next() : t;
                // skip padding (CC / 90) and non-instructions
                while (s.compareTo(t) < 0) {
                    byte b = getByte(s);
                    if (b == (byte) 0xCC || b == (byte) 0x90) { s = s.next(); continue; }
                    break;
                }
                if (L.getInstructionAt(s) == null) disassemble(s);
                f = createFunction(s, null);
                if (f == null) f = fm.getFunctionContaining(t);
                out.println("// created function at " + s + " for " + t + " -> " + (f != null ? f.getBody().getMinAddress() + ".." + f.getBody().getMaxAddress() : "FAILED"));
            }
            if (f == null) continue;
            Set<String> up = new TreeSet<>();
            for (Reference r : rm.getReferencesTo(f.getEntryPoint())) {
                Function g = fm.getFunctionContaining(r.getFromAddress());
                up.add(g != null ? g.getEntryPoint().toString() : "d:" + r.getFromAddress());
            }
            out.println("\n// ===== for " + t + ": " + f.getName() + " @" + f.getEntryPoint() + " size=" + f.getBody().getNumAddresses() + " calledBy=" + up);
            DecompileResults res = dec.decompileFunction(f, 120, monitor);
            String c = (res != null && res.decompileCompleted()) ? res.getDecompiledFunction().getC() : "// failed: " + (res != null ? res.getErrorMessage() : "") + "\n";
            out.println(c.length() > 40000 ? c.substring(0, 40000) + "\n// ...truncated\n" : c);
        }
        out.close();
    }
}
