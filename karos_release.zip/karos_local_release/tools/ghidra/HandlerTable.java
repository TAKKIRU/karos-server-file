// Dump the receive-handler table around a known slot: for each pointer slot,
// the function and which AMOPacket classes it references; who references the table.
// args: outdir startHex endHex
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.program.model.mem.*;
import java.io.*;
import java.util.*;

public class HandlerTable extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        PrintWriter out = new PrintWriter(new FileWriter(a[0] + "/handlers.txt"));
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        SymbolTable st = currentProgram.getSymbolTable();
        Memory mem = currentProgram.getMemory();
        AddressSpace sp = currentProgram.getAddressFactory().getDefaultAddressSpace();
        // map: vftable address -> class ; parse fn -> class
        Map<Address, String> vtCls = new HashMap<>();
        for (Symbol s : st.getAllSymbols(true))
            if (s.getName().equals("vftable") && s.getParentNamespace() != null && s.getParentNamespace().getName(true).startsWith("AMOPacket::"))
                vtCls.put(s.getAddress(), s.getParentNamespace().getName(true).substring(11));
        long start = Long.parseLong(a[1], 16), end = Long.parseLong(a[2], 16);
        for (long p = start; p < end; p += 4) {
            Address slot = sp.getAddress(p);
            int v = mem.getInt(slot);
            Function f = fm.getFunctionAt(sp.getAddress(v & 0xffffffffL));
            StringBuilder sb = new StringBuilder();
            Symbol ss = st.getPrimarySymbol(slot);
            if (ss != null && rm.getReferenceCountTo(slot) > 0) {
                Set<String> users = new TreeSet<>();
                for (Reference r : rm.getReferencesTo(slot)) {
                    Function u = fm.getFunctionContaining(r.getFromAddress());
                    users.add(u != null ? u.getEntryPoint().toString() : r.getFromAddress().toString());
                }
                sb.append("   <== table referenced by ").append(users);
            }
            if (f == null) { out.println(slot + ": " + Integer.toHexString(v) + " (not a function)" + sb); continue; }
            Set<String> cls = new TreeSet<>();
            for (Address ad : f.getBody().getAddresses(true)) {
                for (Reference r : rm.getReferencesFrom(ad)) {
                    String c = vtCls.get(r.getToAddress());
                    if (c != null) cls.add(c);
                }
            }
            out.println(slot + ": " + f.getEntryPoint() + " size=" + f.getBody().getNumAddresses() + " " + cls + sb);
        }
        out.close();
    }
}
