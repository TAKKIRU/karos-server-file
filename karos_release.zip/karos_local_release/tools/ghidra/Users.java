// args: outdir outname Class1 Class2 ...  -> decompile every function that
// references the class vftable or calls its ctor (the code that USES the packet),
// plus one level of callers' names. Also dumps non-virtual getters called on it.
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.app.decompiler.*;
import java.io.*;
import java.util.*;

public class Users extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        PrintWriter out = new PrintWriter(new FileWriter(a[0] + "/" + a[1]));
        DecompInterface dec = new DecompInterface(); dec.openProgram(currentProgram);
        SymbolTable st = currentProgram.getSymbolTable();
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        Set<Address> done = new HashSet<>();
        for (int i = 2; i < a.length; i++) {
            String cls = a[i];
            Address vt = null;
            for (Symbol s : st.getAllSymbols(true))
                if (s.getName().equals("vftable") && s.getParentNamespace() != null
                        && s.getParentNamespace().getName(true).equals("AMOPacket::" + cls)) { vt = s.getAddress(); break; }
            if (vt == null) { out.println("// no vftable for " + cls); continue; }
            Set<Function> ctors = new LinkedHashSet<>();
            for (Reference r : rm.getReferencesTo(vt)) {
                Function f = fm.getFunctionContaining(r.getFromAddress());
                if (f != null) ctors.add(f);
            }
            Set<Function> users = new LinkedHashSet<>();
            for (Function c : ctors) {
                boolean tiny = c.getBody().getNumAddresses() < 40;
                if (!tiny) users.add(c);   // inlined ctor inside the real handler
                for (Reference r : rm.getReferencesTo(c.getEntryPoint())) {
                    Function f = fm.getFunctionContaining(r.getFromAddress());
                    if (f != null && !ctors.contains(f)) users.add(f);
                }
            }
            out.println("\n//################ " + cls + "  vft=" + vt + "  ctors=" + ctors.size() + "  users=" + users.size());
            for (Function u : users) {
                if (!done.add(u.getEntryPoint())) { out.println("// (already dumped) " + u.getEntryPoint()); continue; }
                Set<String> callers = new TreeSet<>();
                for (Reference r : rm.getReferencesTo(u.getEntryPoint())) {
                    Function f = fm.getFunctionContaining(r.getFromAddress());
                    callers.add(f != null ? f.getEntryPoint().toString() : r.getFromAddress().toString());
                }
                out.println("// ===== user " + u.getName() + " @" + u.getEntryPoint() + " size=" + u.getBody().getNumAddresses() + " callers=" + callers);
                DecompileResults res = dec.decompileFunction(u, 90, monitor);
                String c = (res != null && res.decompileCompleted()) ? res.getDecompiledFunction().getC() : "// failed\n";
                out.println(c.length() > 30000 ? c.substring(0, 30000) + "\n// ...truncated\n" : c);
            }
        }
        out.close();
    }
}
