// args: outdir outname hexAddr...  -> decompile each function that calls/references
// the given addresses (deduped), skipping tiny wrappers; also decompile the target itself.
// Prefix an address with '=' to decompile only that function.
// @category Karos
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.address.*;
import ghidra.app.decompiler.*;
import java.io.*;
import java.util.*;

public class Callers extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        PrintWriter out = new PrintWriter(new FileWriter(a[0] + "/" + a[1]));
        DecompInterface dec = new DecompInterface(); dec.openProgram(currentProgram);
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        AddressSpace sp = currentProgram.getAddressFactory().getDefaultAddressSpace();
        Set<Address> done = new HashSet<>();
        for (int i = 2; i < a.length; i++) {
            boolean only = a[i].startsWith("=");
            Address t = sp.getAddress(Long.parseLong(a[i].replace("=", ""), 16));
            List<Function> fs = new ArrayList<>();
            Function tf = fm.getFunctionContaining(t);
            if (only) { if (tf != null) fs.add(tf); }
            else for (Reference r : rm.getReferencesTo(t)) {
                Function f = fm.getFunctionContaining(r.getFromAddress());
                if (f != null) fs.add(f);
                else out.println("// ref from non-function " + r.getFromAddress());
            }
            out.println("\n//################ target " + t + (only ? " (self)" : " callers=" + fs.size()));
            for (Function f : fs) {
                if (!done.add(f.getEntryPoint())) { out.println("// (dup) " + f.getEntryPoint()); continue; }
                Set<String> up = new TreeSet<>();
                for (Reference r : rm.getReferencesTo(f.getEntryPoint())) {
                    Function g = fm.getFunctionContaining(r.getFromAddress());
                    up.add(g != null ? g.getEntryPoint().toString() : "d:" + r.getFromAddress());
                }
                out.println("// ===== " + f.getName() + " @" + f.getEntryPoint() + " size=" + f.getBody().getNumAddresses() + " calledBy=" + up);
                DecompileResults res = dec.decompileFunction(f, 120, monitor);
                String c = (res != null && res.decompileCompleted()) ? res.getDecompiledFunction().getC() : "// failed\n";
                out.println(c.length() > 40000 ? c.substring(0, 40000) + "\n// ...truncated\n" : c);
            }
        }
        out.close();
    }
}
