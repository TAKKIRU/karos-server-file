"""Каталог GXP-магазина (data/gxp_catalog.tsv) -> товары внутриигрового магазина.

Сопоставление названий сайта с предметами клиента (data/items.json):
  1) точное после нормализации (ё/е, регистр, знаки; «24 часа» = «1 день», «168 часов» = «7 дней»,
     «(Аватар)», «(вечный)», «[НП]» убираются; «восст. ОЗ/ОМ» = «восстановления здоровья/маны»,
     «[Редк.]» = «(Редкое)»; «- 10 шт» в конце — количество);
  2) иначе по словам: совпадение срока обязательно, сходство слов (Жаккар) от 0.85.
Предметов, которых нет в клиенте 2019 года (новые хэллоуинские вещи, «Дары», камни супер-навыков
нового вида…), в магазине нет — они пропускаются.

Товар -> блоки выдачи: A — всё, O/+/k/K — один случайный предмет блока (как «один из» на сайте);
количество «от X до Y» — случайное в этих пределах при покупке.
"""
import collections, json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TSV = os.path.join(ROOT, 'data', 'gxp_catalog.tsv')

# раздел сайта (menu_id) -> вкладка окна: 0 события, 1 ездовые/крылья, 2 расходники,
# 3 ограниченные (украшения, чародейские камни), 4 костюмы и аватары, 5 питомцы
MENU_TAB = {}
for tab, menus in ((5, '583'),
                   (1, '1368 1245 1666'),
                   (4, '1758 1759 1760 1934 1642 1419 2408 1927 1928 2522 1652'),
                   (3, '706 1661 1140 1877 1078 2364'),
                   (2, '707 708 709 2256 2135 1033 1034 2258 541 712 713 539 2295 1150 1660 718 2389'),
                   (0, '2 1 3 5 2416 2306 853 963 1704 2125 1847 1980 1690')):
    for m in menus.split():
        MENU_TAB.setdefault(m, tab)


def _term(s):
    s = s.replace('(24 часа)', '(1 день)').replace('(168 часов)', '(7 дней)')
    s = re.sub(r'\((\d+)\s*дн\.?\)', r'(\1 дней)', s)
    s = s.replace('(1 дней)', '(1 день)').replace('(3 дней)', '(3 дня)').replace('(14 дня)', '(14 дней)')
    return s


def norm(s):
    s = _term(s.lower().replace('ё', 'е'))
    s = re.sub(r'\[нп\]|\(аватар\)|\(вечн[а-я.]*\)|\(вечно\)', ' ', s)
    s = s.replace('[редк.]', '(редкое)').replace('восст.', 'восстановления')
    s = re.sub(r'\bоз/ом\b', 'здоровья и маны', s)
    s = re.sub(r'\bоз\b', 'здоровья', s)
    s = re.sub(r'\bом\b', 'маны', s)
    s = re.sub(r'(\S)\(', r'\1 (', s)
    s = re.sub(r'[^0-9a-zа-я()+%]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def split_qty(name):
    """«Надгробная табличка - 10 шт» -> («Надгробная табличка», 10)."""
    m = re.match(r'(.+?)\s*-?\s*(\d+)\s*шт\.?\s*$', name)
    return (m.group(1), int(m.group(2))) if m else (name, 1)


def term_of(n):
    m = re.search(r'\((\d+ (?:день|дня|дней|час|часа|часов))\)', n)
    return m.group(1) if m else ''


# сайт -> имя в клиенте, где названия различаются
ALIAS = {
    'ангел-хранитель': 'Ангел-хранитель (малый)',
    'белый единорог': 'Единорог',
    'капсула питомца баулебо': 'Капсула баулебо',
    'капсула феи': 'Фея',
    'зелье активности (20 минут)': 'Зелье активности',
    'превосходное зелье силы (1 час)': 'Превосходное зелье силы',
    'призыв отряда': 'Призвать отряд',
    'увеличение времени автокача': 'Зелье живучести игрового помощника',
}
TOKEN_NAMES = ('гача монета',)            # монеты гачи оригинала в клиенте нет -> лотерейный билет


def _costume_key(name):
    """«Коробка с улучшенным Розовым купальным костюмом (30 дней)» -> («уникальный розовый
    купальный костюм», 2592000); обычные -> без «уникальный». None, если это не коробка костюма."""
    n = name.lower().replace('ё', 'е')
    m = re.match(r'(?:коробка|сундук) с (.*?)\s*(\((\d+) дн[а-я]*\)|\(веч[а-я]*\))?\s*$', n)
    if not m or 'костюм' not in m.group(1):
        return None
    body = m.group(1)
    per = int(m.group(3)) * 86400 if m.group(3) else 0
    uniq = bool(re.match(r'(улучшенн|усиленн|уникальн)\w*\s', body))
    body = re.sub(r'^(улучшенн|усиленн|уникальн)\w*\s', '', body)
    words = body.split()
    out = []
    for w in words:                                   # творительный -> именительный
        if w == 'костюмом':
            w = 'костюм'
        elif w.endswith('ым') or w.endswith('им'):
            w = w[:-2] + ('ий' if w.endswith('ким') or w.endswith('ним') else 'ый')
        out.append(w)
    nm = ' '.join(out).replace('"', '')
    if nm == 'костюм на хэллоуин' and uniq:
        nm = 'костюм хэллоуина'
    return ('уникальный ' if uniq else '') + nm, per


class Matcher:
    def __init__(self, items):
        self.items = items
        self.box = {}
        try:
            import sys
            sys.path.insert(0, os.path.join(ROOT, 'server'))
            import costume
            costume.init(items)
            for b, cps in sorted(costume.BOX.items()):
                if cps and cps[0] in costume.COUPON:
                    cname, _p, per = costume.COUPON[cps[0]]
                    self.box.setdefault((cname.replace('ё', 'е').replace('"', ''), per or 0), b)
        except Exception:
            pass
        self.by = collections.defaultdict(list)
        for i, v in items.items():
            self.by[norm(v['name'])].append(i)
        self.words = {k: set(k.replace('(', ' ').replace(')', ' ').split()) for k in self.by}

    def _pick(self, ids, want_box=False):
        # из одинаковых предметов разных регионов: что есть у сервера в таблицах, ближе к оригиналу
        def rank(i):
            v = self.items[i]
            box = 'коробк' in v['name'].lower()
            return (box != want_box, v.get('kind') == 0, -(i // 100000000 in (9, 4, 1)), i)
        return sorted(ids, key=rank)[0]

    def find(self, name):
        low = name.lower().replace('ё', 'е').strip()
        if low in TOKEN_NAMES:
            import gacha
            return gacha.TOKEN
        if low in ALIAS:
            name = ALIAS[low]
        ck = _costume_key(name)
        if ck:
            nm, per = ck
            if (nm, per) in self.box:
                return self.box[(nm, per)]
            alts = sorted((p, b) for (n2, p), b in self.box.items() if n2 == nm)
            alts = [a for a in alts if a[0] == per]   # срок только тот же: вечный не подменяем 7-дневным
            return alts[0][1] if alts else None
        n = norm(name)
        want_box = n.startswith('коробка') or n.startswith('капсула')
        if n in self.by:
            return self._pick(self.by[n], want_box)
        t = term_of(n)
        w = set(n.replace('(', ' ').replace(')', ' ').split())
        best, score = None, 0.0
        for k, kw in self.words.items():
            if term_of(k) != t:
                continue
            j = len(w & kw) / len(w | kw)
            if j > score:
                best, score = k, j
        if best and score >= 0.85:
            return self._pick(self.by[best], want_box)
        if not n.startswith('(редкое)'):              # аватары оружия: в клиенте только «(Редкое) …»
            r = self.find('(Редкое) ' + name)
            if r:
                return r
        if t:                                         # в клиенте предмет без срока
            k = norm(re.sub(r'\s*\(\d+ (?:день|дня|дней|час|часа|часов)\)\s*$', '', n))
            if k in self.by:
                return self._pick(self.by[k], want_box)
        return None


def _qty(q):
    m = re.match(r'от (\d+) до (\d+)', q)
    if m:
        return int(m.group(1)), int(m.group(2))
    m = re.match(r'(\d+)', q)
    n = int(m.group(1)) if m else 1
    return n, n


def load(items):
    """-> список товаров: dict(pid, name, gxp, old, tab, blocks=[{mode, items:[[id, min, max]]}]),
    и список пропущенных названий."""
    mt = Matcher(items)
    goods, skipped = [], []
    for line in open(TSV, encoding='utf-8'):
        if line.startswith('#') or not line.strip():
            continue
        pid, name, gxp, old, menus, give = (line.rstrip('\n').split('|') + [''] * 6)[:6]
        menus = menus.split(',')
        tab = next((MENU_TAB[m] for m in menus if m in MENU_TAB and m not in ('2', '1', '3', '5')),
                   next((MENU_TAB[m] for m in menus if m in MENU_TAB), 2))
        blocks = []
        if give:
            for blk in give.split(' / '):
                mode, body = blk[0], blk[2:]
                its = []
                for part in body.split(';'):
                    nm, q = part.rsplit('*', 1)
                    iid = mt.find(nm)
                    if iid:
                        its.append([iid, *_qty(q)])
                    else:
                        skipped.append(nm)
                if its:
                    blocks.append({'mode': 'A' if mode == 'A' else 'O', 'items': its})
        else:
            iid, n = mt.find(name), 1
            if not iid:
                base, n = split_qty(name)
                iid = mt.find(base)
            if iid:
                blocks.append({'mode': 'A', 'items': [[iid, n, n]]})
            else:
                skipped.append(name)
        if not blocks:
            continue
        goods.append({'pid': int(pid), 'name': name, 'gxp': float(gxp), 'old': float(old) if old else None,
                      'tab': tab, 'blocks': blocks})
    return goods, skipped


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    items = {int(k): v for k, v in json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8')).items()}
    goods, skipped = load(items)
    print(len(goods), 'товаров;', 'пропущено названий:', len(set(skipped)))
    for g in goods[:40]:
        print(g['pid'], g['name'], g['gxp'], g['tab'],
              [(b['mode'], [(items[i]['name'], a, z) for i, a, z in b['items'][:3]]) for b in g['blocks']])
    print('---пропущены---')
    print('\n'.join(sorted(set(skipped))))
