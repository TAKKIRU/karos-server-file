"""Расшифровка .lod файлов клиента Karos (IE_Lod).

Алгоритм восстановлен из AMo.exe (Ghidra): инициализация FUN_0072104a,
чтение FUN_007210d7.

  заголовок: 93 байта H; ключ key[j] = H[1 + 3*j], j = 0..30
  1 байт b; пропустить (b ^ H[92]) байт
  1 байт -> состояние s = (байт + 0x4F) & 0xFF
  далее для каждого байта c (счётчик n с нуля):
      k   = key[n % 31]
      x   = c ^ ((k + s) & 0xFF)
      out = (x - s) & 0xFF
      s   = (k + x + 0x4F) & 0xFF
      если out == 0 и режим 1 — следующий байт файла пропускается
  Таблицы начинаются с int32 даты версии (20101118).

Запуск:
  python tools/lod_decode.py <файл.lod> [выход.bin] [--mode 0|1]
"""
import sys


def decode(data, mode=1):
    pos = 0
    h = data[:93]; pos = 93
    key = [h[1 + 3 * j] for j in range(31)]
    nskip = data[pos] ^ h[92]; pos += 1
    pos += nskip
    s = (data[pos] + 0x4F) & 0xFF; pos += 1
    out = bytearray()
    n = 0
    L = len(data)
    while pos < L:
        c = data[pos]; pos += 1
        k = key[n % 31]
        x = c ^ ((k + s) & 0xFF)
        o = (x - s) & 0xFF
        s = (k + x + 0x4F) & 0xFF
        out.append(o)
        if o == 0 and mode:
            pos += 1
        n += 1
    return bytes(out)


def encode(plain, like, mode=1):
    """Обратное decode: зашифровать plain, взяв заголовок/ключ/пропуск/затравку из файла like
    (любой .lod той же игры). В режиме 1 после каждого нулевого байта пишется байт-заполнитель
    (клиент его пропускает: FUN_007210d7)."""
    h = like[:93]
    key = [h[1 + 3 * j] for j in range(31)]
    nskip = like[93] ^ h[92]
    head = like[:94 + nskip + 1]
    s = (like[94 + nskip] + 0x4F) & 0xFF
    out = bytearray(head)
    for n, o in enumerate(plain):
        k = key[n % 31]
        x = (o + s) & 0xFF
        out.append(x ^ ((k + s) & 0xFF))
        s = (k + x + 0x4F) & 0xFF
        if o == 0 and mode:
            out.append(0x5A)
    return bytes(out)


if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    mode = 1
    if '--mode' in sys.argv:
        mode = int(sys.argv[sys.argv.index('--mode') + 1])
        args = [a for a in args if a != str(mode)]
    src = args[0]
    dst = args[1] if len(args) > 1 else src + '.bin'
    raw = open(src, 'rb').read()
    dec = decode(raw, mode)
    open(dst, 'wb').write(dec)
    import struct
    print(f'{src}: {len(raw)} -> {len(dec)} bytes, first ints: {struct.unpack_from("<4i", dec, 0)}')
