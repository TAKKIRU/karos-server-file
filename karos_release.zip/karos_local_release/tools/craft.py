"""Крафт и разборка: таблицы клиента -> data/craft.json.

combination.lod_rus (режим 1): int число, записи по 303 байта:
  +0 номер рецепта, +4 0, +8 результат (item), +0xc цена в каратах, +0x10 шанс (10000 = 100%;
  у праздничных 70000 — тоже «всегда»), +0x14 double время изготовления (с; у рецептов
  «своими силами» 1.0), +0x1c 20×u32 материалы, +0x6c 20×u32 их количество,
  +0xbc имя раздела (51 байт cp1251), +0xef имя рецепта (64 байта).
combinationNPC.lod_rus: число, пары (вид NPC, рецепт) — что умеет изготавливать NPC.
combinationPC.lod_rus: число, тройки (навык, уровень навыка, рецепт) — крафт своими силами.
itemDismantal.lod_rus: число, записи по 79 байт:
  +0 номер, +4 u8 вид предмета (itemBase [4], 1 — снаряжение), +5 u8 грейд (itemBase +0x94:
  1 обычное изготовленное, 2 «Крепкий», 3 «Большой», 4 «Могучий», 6 «Властелина», 11 таинственные
  аксессуары), +6 u8 ярус 1..12, +7 f32 множитель количества, +0xb u32 цена разборки,
  +0xf 4×(u32 материал, u32 шанс, u32 из скольки (100), u32 0).
Клиент (AMo 0x0062ba75) ищет первую запись с тем же видом и грейдом и берёт из неё цену;
ярус сервер берёт по требуемому уровню предмета (1–10 -> 1, 11–20 -> 2 …).
CombiReinforcingAgent.lod_rus («Дух воина», переработка снаряжения): число, записи по 32 байта:
  +0 предмет, который перерабатывают, +4 что получают, +8 сколько, +12 цена в каратах,
  +16 материал (Рецепт духа воина ур.N), +20 сколько, +24 доп. материал (Кристалл флетты), +28 сколько.

Запуск: python tools/craft.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode                                   # noqa: E402
import items as I                                               # noqa: E402

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
OUT = os.path.join(ROOT, 'data', 'craft.json')
REC = 303
DREC = 79


def lod(name):
    return decode(open(os.path.join(LOD, name + '.lod_rus'), 'rb').read(), 1)


def cstr(b):
    return b.split(b'\0')[0].decode('cp1251', 'replace')


def recipes():
    p = lod('combination')
    out = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        r = p[4 + REC * k:4 + REC * (k + 1)]
        rid, _z, item, cost, chance = struct.unpack_from('<5i', r, 0)
        secs = struct.unpack_from('<d', r, 0x14)[0]
        mats = struct.unpack_from('<20i', r, 0x1c)
        cnt = struct.unpack_from('<20i', r, 0x6c)
        out[rid] = {'item': item, 'cost': cost, 'chance': min(10000, chance), 'time': secs,
                    'mats': [[m, max(1, c)] for m, c in zip(mats, cnt) if m],
                    'group': cstr(r[0xbc:0xef]), 'name': cstr(r[0xef:])}
    return out


def pairs(name, width):
    p = lod(name)
    n = struct.unpack_from('<I', p, 0)[0]
    return [struct.unpack_from(f'<{width}i', p, 4 + 4 * width * k) for k in range(n)]


def dismantle():
    p = lod('itemDismantal')
    out = []
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        o = 4 + DREC * k
        rid, kind, grade, tier = struct.unpack_from('<IBBB', p, o)
        mult, cost = struct.unpack_from('<fI', p, o + 7)
        res = []
        for j in range(4):
            item, ch, of, _ = struct.unpack_from('<4I', p, o + 15 + 16 * j)
            if item and ch:
                res.append([item, ch, of or 100])
        out.append({'id': rid, 'kind': kind, 'grade': grade, 'tier': tier,
                    'mult': round(mult, 3), 'cost': cost, 'out': res})
    return out


def recycle():
    p = lod('CombiReinforcingAgent')
    out = {}
    for k in range(struct.unpack_from('<I', p, 0)[0]):
        it, got, n, cost, mat, mn, ext, en = struct.unpack_from('<8I', p, 4 + 32 * k)
        out[it] = {'out': got, 'n': n, 'cost': cost,
                   'mats': [[m, c] for m, c in ((mat, mn), (ext, en)) if m and c]}
    return out


def grades():
    """{item: грейд} — байт +0x94 записи itemBase (только ненулевые)."""
    d = decode(open(I.SRC, 'rb').read(), 0)
    out, L, q = {}, len(d) - 64, 8
    while True:
        q = d.find(b'\x01\x00\x00\x00', q)
        if q < 0 or q - 4 >= L:
            break
        p = q - 4
        q += 1
        f = struct.unpack_from('<32i', d, p)
        if (f[1] == 1 and 0 < f[0] < 2_000_000_000 and f[3] == 0 and 1 <= f[4] <= 9
                and 0 <= f[5] <= 200 and 0 <= f[9] <= 30 and 0 <= f[11] <= 300
                and 1 <= f[14] <= 100000 and f[2] in range(0, 10000)):
            if f[0] not in out and d[p + 0x94]:
                out[f[0]] = d[p + 0x94]
            q = p + 64
    return out


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    rec = recipes()
    npc = {}
    for n, r in pairs('combinationNPC', 2):
        if r in rec:
            npc.setdefault(n, []).append(r)
    pc = {r: [s, lv] for s, lv, r in pairs('combinationPC', 3) if r in rec}
    dis = dismantle()
    kinds = {(d['kind'], d['grade']) for d in dis}
    gr = {i: g for i, g in grades().items() if (1, g) in kinds}
    rc = recycle()
    json.dump({'recipes': rec, 'npc': npc, 'pc': pc, 'dismantle': dis, 'grade': gr, 'recycle': rc},
              open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(f'{len(rec)} рецептов, {len(npc)} NPC-ремесленников, {len(pc)} рецептов своими силами, '
          f'{len(dis)} правил разборки, {len(gr)} предметов можно разобрать, '
          f'{len(rc)} — переработать в Дух воина -> {OUT}')


if __name__ == '__main__':
    main()
