"""Сегменты TCP (tshark: time, srcport, seq_raw, payload) -> кадры игрового протокола.

Вход (TSV): tshark -r file.pcapng -Y "tcp.stream==N && tcp.len>0" -T fields
            -e frame.time_epoch -e tcp.srcport -e tcp.seq_raw -e tcp.payload
Выход: data/captures/<имя>.jsonl — по строке на кадр:
  {"t": unix-время, "dir": "C"|"S", "op": "06/02", "hex": "<payload без 6 байт заголовка>"}
Кадр: u32 BE длина n (без самих 4 байт), затем n байт: cat, sub, 2 байта, seq BE16, payload.

Запуск: python tools/pcap_frames.py <segments.tsv> <out.jsonl> <клиентский порт>
"""
import json, struct, sys


def main(src, out, client_port):
    streams = {'C': {}, 'S': {}}
    for line in open(src, encoding='utf-8'):
        p = line.rstrip('\n').split('\t')
        if len(p) < 4 or not p[3]:
            continue
        d = 'C' if p[1] == str(client_port) else 'S'
        seq = int(p[2])
        streams[d].setdefault(seq, (float(p[0]), bytes.fromhex(p[3].replace(':', ''))))
    frames = []
    for d, segs in streams.items():
        buf, t0, nxt = b'', None, None
        times = []                       # (смещение в buf, время)
        for seq in sorted(segs):
            t, data = segs[seq]
            if nxt is not None and seq < nxt:            # перекрытие/повтор
                cut = nxt - seq
                if cut >= len(data):
                    continue
                data = data[cut:]
            times.append((len(buf), t))
            buf += data
            nxt = seq + len(segs[seq][1])
        pos, ti = 0, 0
        while pos + 4 <= len(buf):
            n = struct.unpack_from('>I', buf, pos)[0]
            if n < 6 or pos + 4 + n > len(buf):
                break
            while ti + 1 < len(times) and times[ti + 1][0] <= pos:
                ti += 1
            f = buf[pos + 4:pos + 4 + n]          # cat, sub, 0, 0, seq BE16, payload
            frames.append({'t': times[ti][1], 'dir': d, 'op': f'{f[0]:02x}/{f[1]:02x}',
                           'hex': f[6:].hex()})
            pos += 4 + n
        print(d, 'кадров', sum(1 for x in frames if x['dir'] == d), 'остаток', len(buf) - pos)
    frames.sort(key=lambda x: x['t'])
    with open(out, 'w', encoding='utf-8') as fo:
        for x in frames:
            fo.write(json.dumps(x) + '\n')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]))
