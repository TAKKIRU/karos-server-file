"""Высота пола карт без точек спавна (лаборатория, мастерская) — из меша карты.

Сервер не знает рельефа: на обычных картах высоту даёт ближайшая точка спавна, а у
N_Laboratory_exp / N_Workshop_exp спавнов нет. Раньше высоту запоминали по ходьбе клиента, но в
лаборатории это была плоскость ПОД картой (130): комнаты висят выше (пол 200–230), и игрок,
поставленный на 135, проваливался.

Меш Map/<карта>/Map/<имя>.m (формат EZMG): вершины — тройки float (x, высота, z) в тех же
координатах, что точки телепорта (mapWarpTargetPos). Пол комнаты — тысячи вершин на одной
высоте, поэтому в каждой клетке 100×100 берётся самая частая высота (мода, не меньше 20 вершин).
Числа ищутся по всем выравниваниям файла — случайные совпадения отсекает порог.

Выход: data/floor_heights.json {карта: {"cell": 100, "h": {"cx,cz": [[высота, вершин], ...]}}}.
Запуск: python tools/map_floor.py [карта ...]   (по умолчанию — карты без спавнов)
"""
import collections, glob, json, os, sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, 'data', 'floor_heights.json')
CELL = 100
MIN_VERTS = 20
MAPS = ('N_Laboratory_exp', 'N_Workshop_exp')


def mesh_points(path):
    d = open(path, 'rb').read()
    xs, ys, zs = [], [], []
    for off in range(4):
        a = np.frombuffer(d[off:off + (len(d) - off) // 4 * 4], dtype='<f4')
        x, y, z = a[:-2], a[1:-1], a[2:]
        with np.errstate(invalid='ignore'):
            m = ((x > 1) & (x < 10240) & (z > 1) & (z < 10240) & (y > -3000) & (y < 5000)
                 & (np.abs(y) > 0.01) & np.isfinite(y))
        xs.append(x[m]); ys.append(y[m]); zs.append(z[m])
    return np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)


def floor_grid(map_name):
    files = glob.glob(os.path.join(ROOT, 'ResUnpak', 'Map', map_name, 'Map', '*.m'))
    cells = collections.defaultdict(collections.Counter)
    for f in files:
        x, y, z = mesh_points(f)
        cx, cz, h = (x // CELL).astype(int), (z // CELL).astype(int), np.round(y).astype(int)
        for a, b, c in zip(cx.tolist(), cz.tolist(), h.tolist()):
            cells[(a, b)][c] += 1
    out = {}
    for (a, b), cnt in cells.items():
        top = [[h, n] for h, n in cnt.most_common(6) if n >= MIN_VERTS]
        if top:
            out[f'{a},{b}'] = top                 # [[высота, вершин], ...] — частые высоты клетки
    return out


def floor_at(grid, x, z, low=None, high=None):
    """Пол в точке: самая частая высота по клеткам 3×3 вокруг (в пределах low..high)."""
    cell = grid['cell']
    cx, cz = int(x // cell), int(z // cell)
    cnt = collections.Counter()
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            for h, n in grid['h'].get(f'{cx + dx},{cz + dz}', []):
                if (low is None or h >= low) and (high is None or h <= high):
                    cnt[h] += n
    return cnt.most_common(1)[0][0] if cnt else None


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    maps = sys.argv[1:] or MAPS
    data = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {}
    for m in maps:
        g = floor_grid(m)
        data[m] = {'cell': CELL, 'h': g}
        hs = collections.Counter(v[0][0] for v in g.values())
        print(f'{m}: {len(g)} клеток, частые высоты {hs.most_common(6)}')
    json.dump(data, open(OUT, 'w', encoding='utf-8'), separators=(',', ':'))


if __name__ == '__main__':
    main()
