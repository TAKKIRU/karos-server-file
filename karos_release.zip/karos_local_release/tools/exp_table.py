"""Таблица «опыт до следующего уровня» -> data/exp_table.json.

Таблицы в клиенте нет — её присылает сервер (08/01 +71). Источники:
  оригинал (импорт 4 персонажей и orig_1): ур.1 — 48, ур.5 — 1 577, ур.60 — 28 666 463,
    ур.62 — 33 552 308, ур.89 — 516 610 899;
  Karos Genesis — полная кривая ур.1–70 (лучница, huge_genesis_pack_2; ур.19–72 совпадают с
    huge_genesis_pack*): ур.1 — 93, ур.5 — 1 255, ур.60 — 55 306 720 …
Масштаб у Genesis другой (на ур.60 ×1.93), но форма кривой — подробная: ур.10–19 +20% за уровень,
19–29 +10%, 29–50 +22%, 50–60 +12%, 60–69 +7.4%. Модель: ур.1–62 = Genesis × поправка, поправка
(отношение оригинал/Genesis) — линейная в логарифме между точками оригинала (1, 5, 60, 62), так
что они выходят точно; ур.63–88 — геометрически к ур.89; выше 89 — +10% за уровень (как раньше).

Запуск: python tools/exp_table.py [data/captures/huge_genesis_pack_2.jsonl]
"""
import json, math, os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'data', 'exp_table.json')
ORIG = {1: 48, 5: 1577, 60: 28666463, 62: 33552308, 89: 516610899}


def genesis_curve(path):
    """08/01 своего персонажа: +37 уровень, +71 u64 опыт до следующего."""
    me, tn = None, {}
    for line in open(path, encoding='utf-8'):
        if '"08/01"' not in line and '"05/01"' not in line:
            continue
        j = json.loads(line)
        p = bytes.fromhex(j['hex'])
        if j['dir'] == 'C' and j['op'] == '05/01' and me is None and len(p) > 5:
            me = p[1:5]
        elif j['dir'] == 'S' and j['op'] == '08/01' and len(p) >= 79 and (me is None or p[1:5] == me):
            lv = struct.unpack_from('<I', p, 37)[0] & 0xffff
            nxt = struct.unpack_from('<Q', p, 71)[0]
            if nxt and 1 <= lv <= 120:
                tn.setdefault(lv, nxt)
    return tn


def build(gen):
    for lv in range(2, 70):                       # пропуски (ур.2) — геометрически по соседям
        if lv not in gen and lv - 1 in gen and lv + 1 in gen:
            gen[lv] = int(round(math.sqrt(gen[lv - 1] * gen[lv + 1])))
    anchors = sorted((lv, math.log(v / gen[lv])) for lv, v in ORIG.items() if lv in gen)

    def corr(lv):
        for (l0, c0), (l1, c1) in zip(anchors, anchors[1:]):
            if l0 <= lv <= l1:
                return c0 + (c1 - c0) * (lv - l0) / (l1 - l0)
        return anchors[-1][1]
    out = {}
    for lv in range(1, 63):
        out[lv] = ORIG.get(lv) or int(round(gen[lv] * math.exp(corr(lv))))
    l0, l1 = 62, 89
    for lv in range(63, 89):
        out[lv] = int(round(ORIG[l0] * (ORIG[l1] / ORIG[l0]) ** ((lv - l0) / (l1 - l0))))
    out[89] = ORIG[89]
    return out


if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'data', 'captures',
                                                               'huge_genesis_pack_2.jsonl')
    gen = genesis_curve(path)
    tab = build(gen)
    json.dump({str(k): v for k, v in tab.items()}, open(OUT, 'w', encoding='utf-8'), indent=0)
    print(f'{len(tab)} уровней -> {OUT}')
    for lv in (1, 5, 10, 20, 29, 30, 40, 50, 60, 62, 70, 89):
        print(f'  ур.{lv}: {tab.get(lv)}  (Genesis {gen.get(lv)})')
