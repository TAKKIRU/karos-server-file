"""Справочник предметов из itemBase.lod_rus -> data/items.json.

Запись itemBase (переменной длины, ~321 байт): int32 поля
  [0] id  [1] 1  [2] класс (0 любой, 200 паладин, 310 …)  [3] 0  [4] вид (1 снаряжение, 2 расходник…)
  [5] категория (1 оружие, 2 броня, 7 зелья…)  [6] тип оружия  [9] слот экипировки (1 торс … 7 оружие, 8 щит)
  [11] требуемый уровень  [14] размер стака  [16] ячеек у сумки (48 у «Сумки на 48 слотов»)  [29] (+116) задержка атаки оружия
  (посох 55, меч 50, кинжал 30 — чем меньше, тем быстрее)
  [21] (+84) цена у торговца (Флюид 100 — клиент продаёт его за 45; зелье 30)
  [25] (+100) цена продажи торговцу (зелье 15) — клиент сам пишет «продано за N»
  [31] (+124) срок действия в секундах (Малая сумка 2592000 = 30 дней); у такого
       предмета в записи +0x38 (u64) — время истечения, иначе «срок действия истёк»
дальше имя (cp1251) и пути к иконке/модели.

Запуск: python tools/items.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemBase.lod_rus')
if os.path.exists(SRC + '.orig'):          # стопки клиента правит tools/patch_stacks.py — данные из оригинала
    SRC += '.orig'
OUT = os.path.join(ROOT, 'data', 'items.json')
NAME = re.compile(rb'[\xc0-\xff\xa8\xb8A-Za-z0-9"\'(\[][\x20-\x7e\xc0-\xff\xa8\xb8]{2,}')


def scan(d):
    items = {}
    L = len(d) - 64
    q = 8
    while True:
        q = d.find(b'\x01\x00\x00\x00', q)       # поле [1] == 1
        if q < 0 or q - 4 >= L:
            break
        p = q - 4
        q += 1
        if p < 0:
            continue
        f = struct.unpack_from('<32i', d, p)
        if (f[1] == 1 and 0 < f[0] < 2_000_000_000 and f[3] == 0 and 1 <= f[4] <= 9
                and 0 <= f[5] <= 200 and 0 <= f[9] <= 30 and 0 <= f[11] <= 300
                and 1 <= f[14] <= 100000 and f[2] in range(0, 10000)):
            m = NAME.search(d, p + 64, p + 400)
            name = m.group(0).decode('cp1251', 'replace') if m else ''
            name = re.sub(r'^\d+ - ', '', name)          # «1 - Сабля» -> «Сабля»
            delay = struct.unpack_from('<i', d, p + 116)[0]      # задержка атаки оружия
            price = struct.unpack_from('<i', d, p + 84)[0]       # цена у торговца
            per = struct.unpack_from('<i', d, p + 124)[0]        # срок действия, с (сумки 30 дн.)
            dur = struct.unpack_from('<i', d, p + 140)[0]        # [35] прочность
            items.setdefault(f[0], {'name': name, 'cls': f[2], 'kind': f[4], 'cat': f[5],
                                    'wtype': f[6], 'slot': f[9], 'lvl': f[11], 'stack': f[14],
                                    'delay': delay if 0 < delay < 1000 else 0,
                                    'price': price if 0 <= price < 100_000_000 else 0,
                                    'sell': f[25] if 0 <= f[25] < 100_000_000 else 0,
                                    'period': per if 0 < per < 400_000_000 else 0,
                                    'slots': f[16] if 0 < f[16] <= 200 else 0,
                                    # [35] макс. прочность (кирки: 1600/3200/16000); текущая —
                                    # в записи предмета +0x48 (подсказка клиента 0x00638817)
                                    'dur': dur if 0 < dur < 10_000_000 else 0})
            q = p + 64
    return items


if __name__ == '__main__':
    d = decode(open(SRC, 'rb').read(), 0)
    items = scan(d)
    json.dump(items, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'{len(items)} предметов -> {OUT}')
    for i in (5001, 34001, 29001, 54005, 999999):
        print(' ', i, items.get(i))
