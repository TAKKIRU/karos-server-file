"""Стопки предметов по 999: itemBase.lod_rus клиента.

Клиент сам считает лимит стопки (int64 на +56 записи): по нему складывает, покупает и считает ячейки кнопкой
сортировки (AMo 0x0061d616). Сервер держит тот же лимит (server/loot.py STACK_MIN).

Таблица (режим 0): u32 дата, u32 число записей; запись — 156 байт постоянной части и 13 строк (u32 длина,
байты); после записей — 75 байт служебного хвоста. Файл читается целиком по этой раскладке: записи не
сошлись — ничего не пишется (поиском по образцу, как tools/items.py, править файл нельзя).

Что делает: у стопочных (лимит 2…998) лимит -> 999; нестопочные и 1000+ как есть. Копия
itemBase.lod_rus.orig рядом, MD5 в CheckFileListW.ten пересчитывается. Повторный запуск ничего не меняет.
Откат: вернуть itemBase.lod_rus.orig и пересчитать список (python -X utf8 tools/patch_stacks.py --revert).

Запуск (игра закрыта): python -X utf8 tools/patch_stacks.py
"""
import os, shutil, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode, encode                              # noqa: E402

PATH = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'itemBase.lod_rus')
FIXED, STRINGS, TAIL, STACK_AT = 156, 13, 75, 56
STACK = 999


def records(d):
    """Начала записей. Не та раскладка -> ValueError."""
    n = struct.unpack_from('<I', d, 4)[0]
    end = len(d) - TAIL
    p, out = 8, []
    for k in range(n):
        s = p
        p += FIXED
        for _ in range(STRINGS):
            if p + 4 > end:
                raise ValueError(f'запись {k}: файл кончился')
            p += 4 + struct.unpack_from('<I', d, p)[0]
        if p > end or struct.unpack_from('<I', d, s + 4)[0] != 1:
            raise ValueError(f'запись {k}: не та раскладка')
        out.append(s)
    if p != end:
        raise ValueError(f'после записей {end - p} лишних байт')
    return out


def patch(plain):
    d = bytearray(plain)
    changed = 0
    for s in records(plain):
        if 1 < struct.unpack_from('<q', d, s + STACK_AT)[0] < STACK:
            struct.pack_into('<q', d, s + STACK_AT, STACK)
            changed += 1
    return bytes(d), changed


def main(revert=False):
    sys.stdout.reconfigure(encoding='utf-8')
    if not os.path.exists(PATH):
        print('нет', PATH)
        return 1
    orig = PATH + '.orig'
    if revert:
        if not os.path.exists(orig):
            print('нет', orig)
            return 1
        shutil.copy2(orig, PATH)
        changed = 0
    else:
        raw = open(PATH, 'rb').read()
        plain = decode(raw, 0)
        try:
            new, changed = patch(plain)
        except (ValueError, struct.error) as e:
            print('itemBase: другая версия таблицы, не трогаю:', e)
            return 1
        if changed:
            enc = encode(new, raw, 0)
            if decode(enc, 0) != new or len(enc) != len(raw):
                print('itemBase: шифр не сошёлся, не трогаю')
                return 1
            if not os.path.exists(orig):
                shutil.copy2(PATH, orig)
            tmp = PATH + '.tmp'
            with open(tmp, 'wb') as fh:
                fh.write(enc)
            os.replace(tmp, PATH)
    import cashshop
    fixed = cashshop.update_checklist()
    print(f"itemBase: {'возвращён оригинал' if revert else f'лимит {STACK} поставлен у {changed} предметов'}; "
          f"CheckFileListW.ten: {fixed or 'без изменений'}")
    return 0


if __name__ == '__main__':
    sys.exit(main('--revert' in sys.argv))
