"""Опыт за мобов в записях оригинала: каждое убийство -> вид моба, уровень, HP, уровень игрока,
прирост опыта (08/01 +63, u64 в пределах уровня; +37 уровень, +71 до следующего), бонус опыта
% из 08/02 (+228, зелья/кольца/VIP).

Убийство: суммарный урон игрока по мобу (05/02, цели по 30 байт с +15: тип, id LE32, урон i32 LE
@+6) достиг его HP из 04/02 (+22 HP, +26 макс. HP, +50 уровень, +0x40 вид, +2 id LE32), либо моб
исчез (04/03) после удара. Прирост опыта в ближайшие 3 с относится к последнему убитому.

Запуск: python tools/exp_check.py [jsonl ...]  -> таблица и сводка «опыт / HP» по видам.
"""
import collections, glob, json, os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(path):
    F = [json.loads(l) for l in open(path, encoding='utf-8')]
    own = None
    mobs = {}                     # id -> dict(npc, lvl, maxhp, hp, dmg)
    level, exp, nxt = None, None, None
    bonus = 0.0
    dead = collections.deque()    # (t, mob)
    out = []
    for x in F:
        op, d, t = x['op'], bytes.fromhex(x['hex']), x['t']
        if x['dir'] != 'S':
            continue
        if op == '04/02' and len(d) >= 0x48 and d[1] == 1:
            mid = struct.unpack_from('<I', d, 2)[0]
            mobs[mid] = {'npc': struct.unpack_from('<I', d, 0x40)[0], 'lvl': struct.unpack_from('<H', d, 50)[0],
                         'maxhp': struct.unpack_from('<I', d, 26)[0], 'hp': struct.unpack_from('<I', d, 22)[0],
                         'dmg': 0, 'id': mid, 'hit': 0}
        elif op == '08/01' and len(d) >= 79:
            lv = struct.unpack_from('<H', d, 37)[0]
            ex = struct.unpack_from('<Q', d, 63)[0]
            nx = struct.unpack_from('<Q', d, 71)[0]
            if own is None:
                own = d[1:5]
            if d[1:5] != own:
                continue
            if level is not None and (ex != exp or lv != level):
                gain = ex - exp if lv == level else (nxt - exp) + ex if lv == level + 1 else None
                while dead and t - dead[0][0] > 3:
                    dead.popleft()
                if gain and gain > 0:
                    m = dead.popleft()[1] if dead else None
                    out.append((t, level, gain, bonus, m))
            level, exp, nxt = lv, ex, nx
        elif op == '08/02' and len(d) >= 232 and own and d[0:4] == own:
            bonus = struct.unpack_from('<f', d, 228)[0]
        elif op == '05/02' and len(d) >= 15 and d[0] == 0 and own and d[1:5] == own:
            n = d[10]
            for k in range(n):
                e = 15 + 30 * k
                if e + 10 > len(d) or d[e] != 1:
                    continue
                mid = struct.unpack_from('<I', d, e + 1)[0]
                dmg = struct.unpack_from('<i', d, e + 6)[0]
                m = mobs.get(mid)
                if m and dmg > 0:
                    m['dmg'] += dmg
                    m['hit'] = t
                    if m['dmg'] >= m['hp'] and not m.get('dead'):
                        m['dead'] = True
                        dead.append((t, m))
        elif op == '04/03' and len(d) >= 5:
            mid = struct.unpack_from('<I', d, 1)[0]
            m = mobs.get(mid)
            if m and not m.get('dead') and m['hit'] and t - m['hit'] < 5:
                m['dead'] = True
                dead.append((t, m))
    return out


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    paths = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, 'data', 'captures', 'orig*.jsonl')) +
                                   glob.glob(os.path.join(ROOT, 'data', 'captures', 'remain*.jsonl')))
    by = collections.defaultdict(list)
    for p in paths:
        rows = run(p)
        print(f'== {os.path.basename(p)}: {len(rows)} приростов опыта')
        for t, lv, gain, bonus, m in rows:
            if m:
                by[(m['npc'], m['lvl'], m['maxhp'])].append((lv, gain, bonus))
    print('\nвид моба | ур. | макс. HP | ур. игрока | опыт (мин–макс, медиана) | бонус % | опыт/HP')
    for (npc, ml, hp), v in sorted(by.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        g = sorted(x[1] for x in v)
        med = g[len(g) // 2]
        print(f'{npc} | {ml} | {hp} | {sorted(set(x[0] for x in v))} | {g[0]}–{g[-1]}, {med} (n={len(g)}) | '
              f'{sorted(set(round(x[2], 1) for x in v))} | {med / hp:.3f}' if hp else '')


if __name__ == '__main__':
    main()
