"""Расстановка мобов и их HP из записей трафика оригинала.

  python tools/cap_spawns.py data/captures/orig_hl_Pers4x.jsonl [ещё.jsonl ...]

-> data/spawns_capture.json {номер карты: [{model, id, x, y, z, tile, uidx, hp, level}]}
   (x, z — горизонталь, y — высота, как в data/spawns.json; tile = 0, координаты мировые)
-> data/mob_stats.json {npc id: {hp, level}} — точное HP оригинала по виду моба.
Карта — по последнему 04/04 (смена зоны). Мобы — 04/02 вида 1 с npc id 1 000 000..8 999 999
(NPC 9xxxxxxx, стража 44444444, питомцы 11000xxx не берутся). Повторы (возрождение) —
по номеру точки спавна (+0x44) или позиции.
"""
import json, os, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'server'))


def main(paths):
    from content import Content
    names = {k: v['name'] for k, v in Content().maps.items()}
    out = {}
    try:
        stats = {int(k): v for k, v in json.load(open(os.path.join(ROOT, 'data', 'mob_stats.json'))).items()}
    except OSError:
        stats = {}
    for path in paths:
        cur = None
        for line in open(path):
            x = json.loads(line)
            if x['dir'] != 'S':
                continue
            p = bytes.fromhex(x['hex'])
            if x['op'] == '04/04':           # ключ — номер карты: у подземелий разных
                mid = struct.unpack_from('>I', p, 4)[0]   # уровней общие файлы карты
                cur = str(mid) if mid in names else None
            if x['op'] != '04/02' or not cur or len(p) < 0x48 or p[1] != 1:
                continue
            npc = struct.unpack_from('<I', p, 0x40)[0]
            if not 1_000_000 <= npc < 9_000_000:
                continue
            X, Y, Z = struct.unpack_from('<3f', p, 6)
            lvl = struct.unpack_from('<H', p, 50)[0]
            hp = struct.unpack_from('<I', p, 26)[0]
            uidx = struct.unpack_from('<I', p, 0x44)[0]
            stats[npc] = {'hp': hp, 'level': lvl}
            m = out.setdefault(cur, {})
            key = uidx or (round(X / 50), round(Y / 50))
            m.setdefault(key, {'model': 'M_capture', 'id': npc, 'x': round(X, 1), 'y': round(Z, 1),
                               'z': round(Y, 1), 'tile': 0, 'uidx': uidx, 'hp': hp, 'level': lvl})
    res = {k: list(v.values()) for k, v in out.items()}
    old = {}
    if '--append' in sys.argv:
        try:
            old = json.load(open(os.path.join(ROOT, 'data', 'spawns_capture.json'), encoding='utf-8'))
        except OSError:
            pass
    for k, v in res.items():                     # дополнить, не затирая прошлые записи
        seen = {(s['uidx'] or (s['x'], s['z'])) for s in old.get(k, [])}
        old.setdefault(k, []).extend(s for s in v if (s['uidx'] or (s['x'], s['z'])) not in seen)
    json.dump(old, open(os.path.join(ROOT, 'data', 'spawns_capture.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=0)
    json.dump({str(k): v for k, v in sorted(stats.items())},
              open(os.path.join(ROOT, 'data', 'mob_stats.json'), 'w'), indent=0)
    for k, v in old.items():
        print(f'{k} {names.get(int(k))}: {len(v)} мобов')
    print(f'видов мобов с HP: {len(stats)}')


if __name__ == '__main__':
    main([a for a in sys.argv[1:] if not a.startswith('--')])
