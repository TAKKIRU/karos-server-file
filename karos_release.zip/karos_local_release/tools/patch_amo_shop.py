"""Кнопка GXP-магазина -> внутриигровой кэш-шоп (окно 16034, CGuiCashShop) вместо сайта.

AMo 0x0043af61 (thiscall на менеджере окон, аргумент 1 — открыть): GameXP заменил открытие окна
40002 (CGuiWebShop) на переход по ссылке gameshop.gamexp.ru (WeberForClntV2 №7). Вызывается
кнопкой меню 0xa0ce, горячей клавишей и окном 0x004aa423.

Патч ветки «открыть» (0x43af6d…0x43afde, 114 байт): отправить серверу C 06/39 — тот же запрос,
что шлёт кнопка «Пополнить» в самом кэш-шопе (0x004d4241…0x004d42a0):
    пакет 0x422b0a; 0x4aa37f(пакет, eid, 0, 0, 1, 0, 0, ""); 0x5e6dec; [0x8db7ec]+0x7738 -> 0x64458f(пакет); 0x4235a0
Сервер отвечает S 06/39 (обработчик 0x0065855b): +4 BE64 баланс -> клиент открывает окно 16034
и пишет баланс (караты). Товары окна — из Interface/IE_LOD/CashShop.lod_rus (tools/cashshop.py),
покупка — C 06/31, ответ S 06/31 (код 0x2C, +10 BE64 новый баланс).
Ветка «закрыть» (0x43afdf) не тронута.
Кнопки «Отмена» и X кэш-шопа (0x004d4241) шлют тот же C 06/39 с u16 +12 = 1 (окно уже спрятано) —
поэтому кнопка GXP шлёт +12 = 2, и сервер открывает окно только на 2 (иначе окно не закрывалось).

Запуск (игра закрыта): python tools/patch_amo_shop.py   (копия AMo.exe.bak)
"""
import os, shutil, sys

try:                                  # для пересборки патча; для установки не нужны
    import pefile
    from keystone import Ks, KS_ARCH_X86, KS_MODE_32
except ImportError:
    pefile = Ks = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXE = os.path.join(ROOT, 'AMo.exe')
VA, END = 0x43af6d, 0x43afdf
ORIG = bytes.fromhex('bb429c000053e8497201008bf885ffeb2c')   # mov ebx,9c42 / push / call / … / jmp

ASM = """
    sub esp, 0x40
    mov ecx, esp
    call 0x422b0a
    mov edi, dword ptr [0x8db7ec]
    mov ecx, dword ptr [edi + 0x8480]
    call 0x41e29a
    push 0x838053
    push 0
    push 0
    push {flag}
    push 0
    push 0
    push eax
    lea eax, [esp + 0x1c]
    push eax
    call 0x4aa37f
    add esp, 0x20
    mov ecx, dword ptr [edi + 0x8480]
    call 0x5e6dec
    lea ecx, [edi + 0x7738]
    push esp
    call 0x64458f
    mov ecx, esp
    call 0x4235a0
    add esp, 0x40
    jmp 0x43affb
"""


FILE_OFF = 0x3af6d                    # смещение VA 0x43af6d в AMo.exe (секция .text)
# готовые байты (собраны keystone из ASM ниже): установка без сторонних модулей
PREBUILT = {
    2: bytes.fromhex('83ec4089e1e8937bfeff8b3decb78d008b8f80840000e81233feff68538083006a006a006a026a006a00'
                     '508d44241c50e8ddf3060083c4208b8f80840000e83cbe1a008d8f3877000054e8d395200089e1e8dd85'
                     'feff83c440eb33cccccccccccccccccccccccccccccccccccccccccccccc'),
    1: bytes.fromhex('83ec4089e1e8937bfeff8b3decb78d008b8f80840000e81233feff68538083006a006a006a016a006a00'
                     '508d44241c50e8ddf3060083c4208b8f80840000e83cbe1a008d8f3877000054e8d395200089e1e8dd85'
                     'feff83c440eb33cccccccccccccccccccccccccccccccccccccccccccccc'),
}


def build(flag=2):
    if Ks is None:
        return PREBUILT[flag]
    code, _ = Ks(KS_ARCH_X86, KS_MODE_32).asm(ASM.format(flag=flag), VA)
    code = bytes(code)
    assert len(code) <= END - VA, len(code)
    return code + b'\xcc' * (END - VA - len(code))


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    if pefile is not None:
        pe = pefile.PE(EXE, fast_load=True)
        off = pe.get_offset_from_rva(VA - pe.OPTIONAL_HEADER.ImageBase)
        pe.close()
    else:
        off = FILE_OFF
    data = bytearray(open(EXE, 'rb').read())
    new = build()
    cur = bytes(data[off:off + len(new)])
    if cur == new:
        print('уже исправлено')
        return 0
    if cur != build(1) and cur[:len(ORIG)] != ORIG:      # build(1) — первая версия патча
        print('неизвестные байты по', hex(VA), cur[:24].hex(' '))
        return 1
    bak = EXE + '.bak'
    if not os.path.exists(bak):
        shutil.copy2(EXE, bak)
    data[off:off + len(new)] = new
    open(EXE, 'wb').write(data)
    print(f'исправлено ({len(new.rstrip(bytes([0xcc])))} байт), копия: {bak}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
