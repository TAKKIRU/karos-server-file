"""Число мобов в точке спавна и радиус разброса -> поля 'count', 'radius' в data/spawns.json.

Запись точки в .npc (версия 6, после трёх строк): u32 вид, 3×f32 позиция, …, @+28 u32 число мобов,
@+32 f32 радиус. Пример: пустыня Эристума — 245 точек «2 моба, радиус 150», 57 — «5 мобов, 150»;
Темптерон — 514 точек по 2. Сервер раньше ставил по одному мобу на точку.
Точки сопоставляются по номеру (uidx), как в tools/spawn_uidx.py (тот же порядок обхода).

Запуск: python tools/spawn_counts.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import spawn_uidx as SU                                     # noqa: E402

SPAWNS = os.path.join(ROOT, 'data', 'spawns.json')


def point_counts(name):
    """{uidx: (число, радиус)} в порядке клиента."""
    mdir = os.path.join(SU.MAPS, name, 'Map')
    if not os.path.isdir(mdir):
        return {}
    tiles = []
    for fn in os.listdir(mdir):
        m = re.fullmatch(re.escape(name) + r'(\d+)\.npc', fn, re.I)
        if m:
            tiles.append((int(m.group(1)), os.path.join(mdir, fn)))
    out, k = {}, 0
    for _tile, path in sorted(tiles):
        d = open(path, 'rb').read()
        o = 4
        for _ in range(struct.unpack_from('<I', d, 0)[0]):
            ver, n = struct.unpack_from('<II', d, o + 4)
            o += 12
            for _ in range(n):
                for _s in range(3):
                    o += 4 + struct.unpack_from('<I', d, o)[0]
                k += 1
                if ver == 6:
                    cnt = struct.unpack_from('<I', d, o + 28)[0]
                    rad = struct.unpack_from('<f', d, o + 32)[0]
                    out[k] = (cnt, rad)
                o += SU.FIXED[ver]
    return out


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    spawns = json.load(open(SPAWNS, encoding='utf-8'))
    total = more = 0
    for name, lst in spawns.items():
        try:
            pc = point_counts(name)
        except (ValueError, KeyError, struct.error) as e:
            print('  пропуск', name, '-', e)
            continue
        extra = 0
        for s in lst:
            c = pc.get(s.get('uidx'))
            if c and 1 <= c[0] <= 20 and 0 <= c[1] < 5000:
                s['count'], s['radius'] = c[0], round(c[1], 1)
                extra += c[0] - 1
                total += 1
        more += extra
        if extra:
            print(f'  {name}: +{extra} мобов к {len(lst)} точкам')
    json.dump(spawns, open(SPAWNS, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'{total} точек с числом мобов, всего мобов больше на {more}')


if __name__ == '__main__':
    main()
