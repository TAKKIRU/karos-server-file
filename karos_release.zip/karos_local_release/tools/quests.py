"""Справочник квестов из quest.lod_rus -> data/quests.json.

Запись — 6336 байт, с +4 (u32 число записей в начале):
  +0  id квеста          +44 NPC-выдающий       +48 предыдущий квест
  +52 мин. уровень, +56 макс. уровень (сверено с официальной базой GameXP: 486 из 486; раньше мин. уровень
      читался с +12 — там у всех 1)   +64 предмет, выдаваемый при взятии
  +8  вид квеста: 3 — повторяемый (метка «Повтор», строка 21019 — клиент 0x004eef57 / 0x005082d9;
        162 квеста, в т.ч. билет Аски 99990212); 1, 2, 6, 9 — прочие виды
  +84 цели: 20 блоков по 52 байта: [тип, цель, кол-во, ?, моб/NPC, ?, шанс(double) ...]
        тип 1 убить N мобов (цель = id моба)
        тип 3 собрать N предметов (цель = предмет, +16 моб, с которого падает)
        тип 8 поговорить с NPC (цель = NPC)
        тип 9 отнести предмет NPC (цель = предмет, +16 NPC)
  +1128 NPC, принимающий квест
  +1144 тип главной награды: 1 опыт (+1148 сколько), 3 предмет (+1148 id, +1156 кол-во —
        «Метка входа в катакомбы» x3), 2 золото (+1148). Раньше +1148 всегда читался как
        опыт: метки не выдавались, а их id (64003) начислялся опытом
  +1168 награды: 20 блоков по 24 байта: тип 2 золото (+4 int64 сумма), тип 3 предмет
        (+4 id, +12 кол-во); первый блок с другим типом — конец списка
  +1624 текст выдачи   +3160 текст цели   +4696 текст сдачи   +6232 название
Те же 52-байтные блоки целей клиент ждёт в 09/02 (список активных) — поэтому
блоки сохраняются целиком (hex).

Запуск: python tools/quests.py
"""
import json, os, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

SRC = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod', 'quest.lod_rus')
OUT = os.path.join(ROOT, 'data', 'quests.json')
R = 6336
try:
    ITEMS = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
except OSError:
    ITEMS = {}


def text(rec, off, size):
    return rec[off:off + size].split(b'\0')[0].decode('cp1251', 'replace').strip()


def parse(d):
    out = {}
    for k in range(struct.unpack_from('<I', d, 0)[0]):
        rec = d[4 + k * R:4 + (k + 1) * R]
        if len(rec) < R:
            break
        qid = struct.unpack_from('<i', rec, 0)[0]
        objs = []
        for b in range(20):
            o = 84 + b * 52
            t, tg, cnt = struct.unpack_from('<3i', rec, o)
            if t:
                objs.append({'i': b, 'type': t, 'target': tg, 'count': cnt,
                             'aux': struct.unpack_from('<i', rec, o + 16)[0],
                             'block': rec[o:o + 52].hex()})
        rewards = []
        for b in range(20):
            o = 1168 + b * 24
            t = struct.unpack_from('<i', rec, o)[0]
            if t == 2:
                rewards.append({'type': 'gold', 'amount': struct.unpack_from('<q', rec, o + 4)[0]})
            elif t == 3:
                rewards.append({'type': 'item', 'item': struct.unpack_from('<i', rec, o + 4)[0],
                                'count': max(1, struct.unpack_from('<i', rec, o + 12)[0])})
            else:
                break
        mtype, mval = struct.unpack_from('<2i', rec, 1144)
        exp = mval if mtype == 1 else 0
        if mtype == 3 and mval:
            rewards.insert(0, {'type': 'item', 'item': mval,
                               'count': max(1, struct.unpack_from('<i', rec, 1156)[0])})
        elif mtype == 2 and mval:
            rewards.insert(0, {'type': 'gold', 'amount': mval})
        # +64 — предмет, который выдаётся при взятии: письмо/посылка для «отнести» («отнеси это письмо», «вот
        # кирки…»), арендованная кирка/удочка (её же потом сдают — цель «собрать»), «освящённая голова зомби».
        # У части квестов там порядковые числа 1–7 и 2998 — не предметы, не выдаются
        si = struct.unpack_from('<i', rec, 64)[0]
        start_item = si if si > 0 and str(si) in ITEMS else 0
        out[qid] = {
            'id': qid, 'title': text(rec, 6232, 104), 'min_level': struct.unpack_from('<i', rec, 52)[0],
            'max_level': struct.unpack_from('<i', rec, 56)[0],
            'start_item': start_item,
            'kind': struct.unpack_from('<i', rec, 8)[0],
            'start_npc': struct.unpack_from('<i', rec, 44)[0], 'prev': struct.unpack_from('<i', rec, 48)[0],
            'end_npc': struct.unpack_from('<i', rec, 1128)[0], 'exp': exp,
            'objectives': objs, 'rewards': rewards, 'goal': text(rec, 3160, 1536),
        }
    return out


if __name__ == '__main__':
    q = parse(decode(open(SRC, 'rb').read(), 1))
    json.dump(q, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False)
    print(f'{len(q)} квестов -> {OUT}')
    for k in list(q)[:3] + [19003101, 19003103]:
        v = q.get(k)
        if v:
            print(' ', k, v['title'], '| цели', [(o['type'], o['target'], o['count']) for o in v['objectives']],
                  '| опыт', v['exp'], '| награды', v['rewards'])
