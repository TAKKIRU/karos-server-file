"""HP мобов без записей оригинала — по наградам квестов «убить N мобов» (таблицы клиента).

Опыт за моба на сервере = HP × (0.385 + 0.0392·ур.) (docs/exp.md, по записям оригинала). Выше
89 уровня HP мобов в записях нет, и прежняя оценка (+4.5% за уровень от 69-го) давала в пустыне
Эристума 14–17 тыс. HP и ~60 тыс. опыта — а квест «Убить 200 гасторнисов» даёт 131.8 млн.

Связь «опыт квеста на одного моба» / «опыт за убийство» калибруется на мобах с HP из записей
оригинала (Рилик, Пробоклон, Адская тварь, сквилы Посейтуньи… — 0.4–0.6). Для моба с квестом:
опыт за убийство = награда / N / k, HP = опыт / (0.385 + 0.0392·ур.). Отдельные квесты сильно
разнятся (у Талоса 0.1–2.4 млн на моба), поэтому берётся медианный множитель ЗОНЫ к прежней оценке
progression.mob_hp (квесты на 100–300 убийств, без осад) — он сохраняет разницу уровней внутри
зоны. HP из записей оригинала не трогается.

Квесты — Karos Genesis overlay/ui/quests_ru.js (те же таблицы quest.lod, что у клиента).
Выход: data/mob_hp_est.json {вид: HP}. Запуск: python tools/mob_hp_quests.py
"""
import collections, json, os, re, statistics, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, 'server'))
import progression as P                                      # noqa: E402
from content import Content                                  # noqa: E402

QUESTS = os.path.join(os.path.dirname(ROOT), 'Karos Genesis', 'overlay', 'ui', 'quests_ru.js')
OUT = os.path.join(ROOT, 'data', 'mob_hp_est.json')
CAL_N = (20, 600)               # квесты для калибровки k (у мобов с HP оригинала — 20–70)
ZONE_N = (100, 500)             # квесты для множителя зоны: мелкие/огромные N дают выбросы
FROM_LEVEL = 70                 # ниже — таблица HP оригинала (progression.ORIG_HP)


def r(level):
    return 0.385 + 0.0392 * level


def kill_quests(lo, hi):
    """-> {вид моба: [награда опытом на одного моба, …]} по квестам с одной целью."""
    s = open(QUESTS, encoding='utf-8').read()
    out = collections.defaultdict(list)
    for o, rw in re.findall(r'"o":(\[\[.*?\]\]),"r":(\[\[.*?\]\])', s):
        objs = re.findall(r'\[1,\[([\d,]+)\],(\d+),\d+,\d+\]', o)
        exp = re.findall(r'\[1,(\d+),\d+,\d+\]', rw)
        if len(objs) != 1 or not exp:
            continue
        ids, n = [int(x) for x in objs[0][0].split(',')], int(objs[0][1])
        if lo <= n <= hi:
            for i in ids:
                out[i].append(int(exp[0]) / n)
    return out


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    c = Content()
    q = kill_quests(*CAL_N)
    ks = []
    for nid, rs in q.items():                     # калибровка на HP из записей оригинала
        st = P.MOB_STATS.get(nid)
        info = c.npc.get(nid) or {}
        if st and st['hp'] < 20000:               # обычные мобы (не элита/боссы)
            ks.append(statistics.median(rs) / (st['hp'] * r(info.get('level', st['level']))))
    k = statistics.median(ks)
    print(f'калибровка: {len(ks)} мобов с HP оригинала, квест/убийство k = {k:.2f} '
          f'(от {min(ks):.2f} до {max(ks):.2f})')

    est, scale_by_map = {}, collections.defaultdict(list)
    zone_of = {}
    for name, pts in list(c.spawns.items()) + [(str(m), v) for m, v in c.spawns_by_id.items()]:
        for s in pts:
            zone_of.setdefault(s['id'], name)
    for nid, rs in kill_quests(*ZONE_N).items():  # множитель зоны: медиана по её квестам
        info = c.npc.get(nid) or {}
        lv = info.get('level', 0)
        z = zone_of.get(nid)
        if lv < FROM_LEVEL or nid in P.MOB_STATS or not z or z.startswith('Siege'):
            continue
        for rk in rs:
            scale_by_map[z].append(rk / k / r(lv) / P.mob_hp(lv))
    zone_scale = {z: max(1.0, statistics.median(v)) for z, v in scale_by_map.items()}
    for nid, z in zone_of.items():                # все мобы зоны без HP из записей
        info = c.npc.get(nid) or {}
        lv = info.get('level', 0)
        if nid in P.MOB_STATS or lv < FROM_LEVEL or z not in zone_scale:
            continue
        est[nid] = int(round(P.mob_hp(lv) * zone_scale[z]))
    json.dump({str(k_): v for k_, v in sorted(est.items())}, open(OUT, 'w', encoding='utf-8'))
    print(f'{len(est)} мобов -> {OUT}')
    for z, sc in sorted(zone_scale.items(), key=lambda kv: kv[1]):
        print(f'  зона {z}: HP ×{sc:.1f} к прежней оценке')
    for nid in (1050011, 1050008, 1050006, 1050003, 1050002, 1060009, 1060017, 1021289, 1020987):
        info = c.npc.get(nid) or {}
        lv = info.get('level', 0)
        hp = est.get(nid) or (P.MOB_STATS.get(nid) or {}).get('hp')
        print(f'  {nid} {info.get("name")} ур.{lv}: HP {hp} (было {P.mob_hp(lv)}), '
              f'опыт своего уровня ≈ {int(hp * r(lv)) if hp else "-"}')


if __name__ == '__main__':
    main()
