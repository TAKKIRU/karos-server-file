"""Эффекты навыков, вставок и стихий флетты -> data/skill_effects.json, data/fleta.json.

skillLevel.lod (режим 0, записи переменной длины): +0 id, +4 уровень, +244 double 100.0
(метка записи: u32 @+248 == 0x40590000), +264 5 × u32 id эффектов.
skillData.lod (режим 0): +0 id эффекта, +4 тип характеристики, +0x18 значение (double),
+0x20 процент (double). Названия типов — tools/item_options.py TYPE_STR.
skillBase.lod (режим 1): +0 id, +4 вид (0 пассивный, 11 атака, 13 дебаф, 23 баф),
+8 класс, +16 ступень дерева, +32 маска оружия.
itemCombAttr.lod (режим 1, записи 72 байта): +0 вставка, +44 навык вставки — её настоящий
эффект (руна 56103: «+20% коэф. уклонения» И «+20% шанс блока»; поле типа +8 — только одно).
fletaAttr.lod (режим 1, записи 40 байт): группа, стихия, этап, порог очков, навык этапа
(уровень навыка = этап), признак 6-го этапа, …, навык-приём 6-го этапа.

Выход:
  data/skill_effects.json {id: {"k": вид, "c": класс, "lv": {уровень: [[тип, знач., %], ...]}}}
  data/socket_skill.json  {вставка: навык}
  data/fleta.json         {группа: {стихия: [[порог, навык], ... по этапам]}}
Запуск: python tools/skill_effects.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from lod_decode import decode

LOD = os.path.join(ROOT, 'ResUnpak', 'Interface', 'IE_Lod')
MARK = struct.pack('<I', 0x40590000)


def lod(name, mode):
    return decode(open(os.path.join(LOD, name + '.lod_rus'), 'rb').read(), mode)


def skill_data(SD):
    """id эффекта -> (тип, значение, процент): первая правдоподобная запись с этим id."""
    out = {}
    for m in re.finditer(rb'(?s).{4}', SD[:0]):
        pass
    p = 0
    n = len(SD) - 0x28
    while p < n:
        e, typ = struct.unpack_from('<II', SD, p)
        if 1000 <= e <= 2200000000 and 0 < typ < 300 and e not in out:
            val, pct = struct.unpack_from('<2d', SD, p + 0x18)
            if abs(val) < 1e7 and abs(pct) < 1e5 and (val == val) and (pct == pct):
                out[e] = (typ, round(val, 4), round(pct, 4))
        p += 1
    return out


def main():
    L = lod('skillLevel', 0)
    SD = lod('skillData', 0)
    SB = lod('skillBase', 1)
    data = skill_data(SD)
    kinds = {}
    for m in re.finditer(rb'(?s)(.{4})(.{4})', SB[:0]):
        pass
    p = 0
    while p < len(SB) - 40:
        sid, kind, cls, z, tier = struct.unpack_from('<5I', SB, p)
        if (1000 <= sid <= 2200000000 and kind < 64 and (cls == 0 or 100 <= cls <= 822)
                and z == 0 and tier < 20 and sid not in kinds):
            kinds[sid] = (kind, cls)
        p += 1
    skills = {}
    for m in re.finditer(re.escape(MARK), L):
        r = m.start() - 248
        if r < 0:
            continue
        sid, lv = struct.unpack_from('<II', L, r)
        if not (1 <= lv <= 60 and 1000 <= sid <= 2200000000):
            continue
        effs = []
        for e in struct.unpack_from('<5I', L, r + 264):
            if e and e in data:
                effs.append(list(data[e]))
        k, c = kinds.get(sid, (None, None))
        s = skills.setdefault(str(sid), {'k': k, 'c': c, 'lv': {}})
        s['lv'].setdefault(str(lv), effs)
    json.dump(skills, open(os.path.join(ROOT, 'data', 'skill_effects.json'), 'w'), separators=(',', ':'))

    c = lod('itemCombAttr', 1)
    sock = {}
    for k in range(struct.unpack_from('<I', c, 0)[0]):
        r = c[4 + 72 * k:4 + 72 * (k + 1)]
        sock[struct.unpack_from('<I', r, 0)[0]] = struct.unpack_from('<I', r, 44)[0]
    json.dump(sock, open(os.path.join(ROOT, 'data', 'socket_skill.json'), 'w'))

    f = lod('fletaAttr', 1)
    fl = {}
    for k in range(struct.unpack_from('<I', f, 0)[0]):
        g, el, st, cost, sk = struct.unpack_from('<5i', f, 4 + 40 * k)
        fl.setdefault(str(g), {}).setdefault(str(el), []).append([cost, sk])
    json.dump(fl, open(os.path.join(ROOT, 'data', 'fleta.json'), 'w'))
    print(f'{len(skills)} навыков, {len(sock)} вставок, флетта {fl}')
    for s in ('5003', '5103', '6801', '6809', '16001', '4800', '42103', '50021'):
        print(' ', s, skills.get(s))


if __name__ == '__main__':
    main()
