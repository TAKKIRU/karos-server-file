"""Двери, стены и «мосты» подземелий без записанного сценария -> data/dungeon_doors.json (server/dungeon.py).

Записей оригинала по этим картам нет, у NeoAsmara для них нет этапов. Из клиента (Map/<карта>/Object/<карта>.mo —
объекты сцены с номерами, Map/<карта>/Map/<карта>.me — триггеры) собирается:
  open_objects  — номера объектов, которым при входе шлётся S 0a/04 (0, номер, 1): AMo 0x005f4d33 — состояние 1
                  запускает анимацию открытия (0 — закрытия); так оригинал открывал 137 стен логова Гельменко;
  open_events   — события 0a/00 вида 0 (двери/эффекты сцены) из триггеров .me, которые шлются при входе;
  near_triggers — триггеры режима 2 (их запускает сервер; кто — в файле не записано): срабатывают, когда убит моб
                  ближе NEAR к одной из их дверей (вид 0) — «зачистили мобов у двери — дверь открылась».
Карты (по просьбе пользователя 2026-11-23):
  29004 ruin01 (Катакомбы Нава, Родовая гробница Вастиана) — двери при входе открыты, эффекты и коллизии
        («мосты», преграды) включены, волны-боссы 110–170, 201, 202 — по убийству у двери триггера;
  29002 bs (Гипогей) — стены и двери по убийству рядом (триггер 90 — по NeoAsmara, остаётся);
  29011 The_Eternal_Maze, 29012 sewer_01, 29013 Labyrinth_02 — все двери/стены/коллизии открыты при входе
        (в .me у них нет ни одного триггера).
Запуск: python -X utf8 tools/dungeon_doors.py
"""
import json, os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from eid_tables import parse_me                                    # noqa: E402

MAPS = os.path.join(ROOT, 'ResUnpak', 'Map')
OUT = os.path.join(ROOT, 'data', 'dungeon_doors.json')
NEAR = 600.0
CONF = {
    29004: dict(name='ruin01', entry_doors=True, open_models=r'effect_0|col', near=True),
    29002: dict(name='bs', entry_doors=False, open_models=None, near=True),
    29011: dict(name='The_Eternal_Maze', entry_doors=False, open_models=r'door|wall|collision', near=False),
    29012: dict(name='sewer_01', entry_doors=False, open_models=r'door|wall|collision', near=False),
    29013: dict(name='Labyrinth_02', entry_doors=False, open_models=r'door|wall|collision', near=False),
}


def scene_objects(path):
    """{номер: (тип, модель, x, высота, z)} — объекты .mo, кроме точек мобов (тип 7)."""
    d = open(path, 'rb').read()
    out = {}
    for m in re.finditer(rb'(?=([\x00-\x20])\x00\x00\x00(....))', d, re.S):
        p = m.start()
        uidx = struct.unpack_from('<I', d, p + 4)[0]
        if p + 130 >= len(d) or not 0 < uidx < 10000000 or d[p] == 7:
            continue
        x, h, z = struct.unpack_from('<3f', d, p + 84)
        if not (1 < x < 100000 and 1 < z < 100000 and -5000 < h < 20000) or h == 0:
            continue
        s = re.search(rb'([A-Za-z0-9_\-]{3,40})\._?[Oo][Bb]', d[p:p + 200])
        if s:
            out.setdefault(uidx, (d[p], s.group(1).decode(), x, h, z))
    return out


def find(name, ext):
    for root, _dirs, files in os.walk(os.path.join(MAPS, name)):
        for f in files:
            if f.lower() == (name + ext).lower():
                return os.path.join(root, f)
    return None


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    out = {}
    for mid, c in CONF.items():
        objs = scene_objects(find(c['name'], '.mo'))
        me = find(c['name'], '.me')
        trs = parse_me(me) if me else []
        r = {'name': c['name']}
        if c['open_models']:
            r['open_objects'] = sorted(k for k, v in objs.items()
                                       if re.search(c['open_models'], v[1], re.I) and 'warp' not in v[1].lower())
        if c['entry_doors']:
            seen, ev = set(), []
            for _t, _m, acts in trs:
                for k, tgt, _p in acts:
                    if k == 0 and tgt not in seen:
                        seen.add(tgt)
                        ev.append([0, tgt, 1, -1])
            r['open_events'] = ev
        if c['near']:
            nt = {}
            for t, mode, acts in trs:
                if mode != 2:
                    continue
                pos = [[round(objs[tg][2]), round(objs[tg][4])] for k, tg, _p in acts if k == 0 and tg in objs]
                if pos:
                    nt[str(t)] = {'pos': pos, 'events': [[k, tg, 2, -1] for k, tg, _p in acts]}
            r['near_triggers'] = nt
            r['near'] = NEAR
        out[str(mid)] = r
        print(mid, c['name'], {k: len(v) for k, v in r.items() if isinstance(v, (list, dict))})
    json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
