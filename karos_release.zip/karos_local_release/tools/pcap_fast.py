"""Быстрый разбор больших pcapng (сотни МБ) без tshark -> кадры игрового протокола.

Читает pcapng потоково (Enhanced Packet Block, Ethernet/IPv4/TCP), берёт TCP-сегменты с данными
на порт сервера (по умолчанию все порты, где встречается протокол Karos — см. --ports), собирает
потоки по seq и режет на кадры как tools/pcap_frames.py:
  u32 BE длина n, затем n байт: cat, sub, u32 счётчик запросов, payload.
Вход/секретное вырезается: C 01/07 (токен), C 02/00 (логин, токен), C 02/0b (второй пароль) —
payload обнуляется. Кроме того, все строки из этих пакетов (логин, токены, второй пароль — его клиент
шлёт ещё и при покупке на комиссионке, C 06/41) ищутся во ВСЕХ кадрах записи (как байты) и заменяются
нулями. Сами значения нигде не сохраняются и не печатаются.

Выход: data/captures/<имя>.jsonl — {"t", "dir": "C"|"S", "op": "06/02", "hex", "conn": номер потока}.
Запуск: python tools/pcap_fast.py <file.pcapng> <out.jsonl> [--ports 20001,20002]
"""
import json, re, struct, sys, collections

SECRET = {(0x01, 0x07), (0x02, 0x00), (0x02, 0x0b)}


def packets(path):
    """-> (время, bytes кадра канального уровня)."""
    f = open(path, 'rb')
    tsres = {}
    le = '<'
    while True:
        h = f.read(8)
        if len(h) < 8:
            return
        btype, blen = struct.unpack(le + 'II', h)
        if btype == 0x0A0D0D0A:                     # Section Header: порядок байт
            bom = f.read(4)
            le = '<' if bom == b'\x4d\x3c\x2b\x1a' else '>'
            blen = struct.unpack(le + 'I', h[4:])[0]
            f.read(blen - 12)
            continue
        body = f.read(blen - 8)
        if btype == 6:                              # Enhanced Packet Block
            iface, th, tl, cap, _orig = struct.unpack_from(le + 'IIIII', body, 0)
            ts = ((th << 32) | tl) / tsres.get(iface, 1e6)
            yield ts, body[20:20 + cap]
        elif btype == 1:                            # Interface Description: разрешение времени
            n = len(tsres)
            tsres[n] = 1e6
            o = 8
            while o + 4 <= len(body) - 4:
                code, ln = struct.unpack_from(le + 'HH', body, o)
                if code == 0:
                    break
                if code == 9:
                    v = body[o + 4]
                    tsres[n] = (2 ** (v & 0x7f)) if v & 0x80 else 10 ** v
                o += 4 + ((ln + 3) & ~3)


def tcp_segments(path, ports=None):
    for ts, fr in packets(path):
        if len(fr) < 14:
            continue
        et = struct.unpack_from('>H', fr, 12)[0]
        o = 14
        if et == 0x8100:
            et = struct.unpack_from('>H', fr, 16)[0]
            o = 18
        if et != 0x0800:
            continue
        ihl = (fr[o] & 0x0f) * 4
        if fr[o + 9] != 6:
            continue
        tot = struct.unpack_from('>H', fr, o + 2)[0]
        src, dst = fr[o + 12:o + 16], fr[o + 16:o + 20]
        t = o + ihl
        sp, dp, seq = struct.unpack_from('>HHI', fr, t)
        doff = (fr[t + 12] >> 4) * 4
        data = fr[t + doff:o + tot]
        if not data:
            continue
        if ports and sp not in ports and dp not in ports:
            continue
        yield ts, src, sp, dst, dp, seq, data


def main(src, out, ports=None):
    streams = collections.defaultdict(dict)        # (сервер, клиент) -> dir -> {seq: (t, data)}
    for ts, s, sp, d, dp, seq, data in tcp_segments(src, ports):
        if ports:
            server = (s, sp) if sp in ports else (d, dp)
        else:
            server = (s, sp) if sp < dp else (d, dp)
        client = (d, dp) if server == (s, sp) else (s, sp)
        key = (server, client)
        dr = 'S' if (s, sp) == server else 'C'
        streams[key].setdefault(dr, {}).setdefault(seq, (ts, data))
    frames = []
    secret_strings = set()
    for ci, (key, dirs) in enumerate(sorted(streams.items(), key=lambda kv: min(
            t for d in kv[1].values() for t, _ in d.values()))):
        for dr, segs in dirs.items():
            buf, nxt, times = bytearray(), None, []
            for seq in sorted(segs):
                t, data = segs[seq]
                if nxt is not None and seq < nxt:
                    cut = nxt - seq
                    if cut >= len(data):
                        continue
                    data = data[cut:]
                times.append((len(buf), t))
                buf.extend(data)
                nxt = seq + len(segs[seq][1])
            pos, ti = 0, 0
            while pos + 4 <= len(buf):
                n = struct.unpack_from('>I', buf, pos)[0]
                if n < 6 or n > 1 << 22 or pos + 4 + n > len(buf):
                    break
                while ti + 1 < len(times) and times[ti + 1][0] <= pos:
                    ti += 1
                body = bytes(buf[pos + 4:pos + 4 + n])
                op = (body[0], body[1])
                pl = body[6:]
                if dr == 'C' and op in SECRET:
                    for m in re.finditer(rb'[!-~]{4,}', pl):
                        secret_strings.add(m.group(0))
                    pl = bytes(len(pl))
                elif dr == 'C' and op == (0x06, 0x41) and len(pl) > 26:   # уничтожение: хвост — цифры подтверждения из окна
                    for m in re.finditer(rb'[!-~]{4,}', pl[26:]):
                        secret_strings.add(m.group(0))
                    pl = pl[:26] + bytes(len(pl) - 26)
                frames.append({'t': times[ti][1], 'dir': dr, 'op': '%02x/%02x' % op,
                               'hex': pl.hex(), 'conn': ci, 'port': key[0][1]})
                pos += 4 + n
    frames.sort(key=lambda x: x['t'])
    # вычистить строки из пакетов входа во всех кадрах (как hex-подстроку на границе байта)
    secrets = {m for m in secret_strings if len(m) >= 5}
    for x in frames:
        h = x['hex']
        for sec in secrets:
            hs = sec.hex()
            i = h.find(hs)
            while i >= 0:
                if i % 2 == 0:
                    h = h[:i] + '00' * len(sec) + h[i + len(hs):]
                i = h.find(hs, i + 1)
        x['hex'] = h
    with open(out, 'w', encoding='utf-8') as fo:
        for x in frames:
            fo.write(json.dumps(x) + '\n')
    print(f'{len(frames)} кадров, потоков {len(streams)} -> {out}')


if __name__ == '__main__':
    a = sys.argv[1:]
    ports = None
    if '--ports' in a:
        i = a.index('--ports')
        ports = {int(x) for x in a[i + 1].split(',')}
        del a[i:i + 2]
    main(a[0], a[1], ports)
