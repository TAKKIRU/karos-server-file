"""Копия персонажа из записи трафика оригинала -> персонаж нашего аккаунта (accounts.json).

  python tools/import_char.py data/captures/orig_hl_Pers4x.jsonl [--write] [--account orig]
  (все входы персонажей в записи; аккаунт по умолчанию — default)

Берётся из пакетов входа (сервер -> клиент):
  02/01 карточка, 02/05 вход в мир, своё 04/02 (облик, позиция), 04/04 карта,
  08/01 (уровень, опыт, флетта, очки навыков), 08/02 (характеристики — последний при входе,
  уже с надетым), 08/00, 05/05 (навыки), 05/0c, 09/04 (выполненные квесты), 06/28
  (быстрые слоты), 0f/11, 16/01, 0e/0c, 08/05;
  06/05 — инвентарь (записи 147 байт, как у нашего сервера: надетое, сумки 1-4);
  06/1c — обычное хранилище (записи 146 байт = наши 147 без байта контейнера);
  06/48 — GXP-рюкзак (кэш-хранилище: u32 uid, 0, предмет, кол-во, LE).
Сырые пакеты кладутся в 'raw' — сервер шлёт их этому персонажу вместо шаблонов
(внешний вид, экипировка, характеристики, быстрые слоты — как в оригинале).
Логины/пароли из записи не берутся.
"""
import collections, json, os, shutil, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ACC = os.path.join(ROOT, 'server', 'accounts.json')
REC = 147
RAW_OPS = ('02/05', '08/01', '08/02', '08/00', '05/05', '05/0c', '06/28', '0f/11', '16/01',
           '0e/0c', '08/05', '0a/0f')


ACCOUNT_ID = 'default'


def frames(path):
    return [json.loads(l) for l in open(path)]


def main(path, write=False):
    """Все входы персонажей в записи (каждый S 02/05 — свой персонаж)."""
    F = frames(path)
    items = json.load(open(os.path.join(ROOT, 'data', 'items.json'), encoding='utf-8'))
    Sall = [x for x in F if x['dir'] == 'S']
    starts = [i for i, x in enumerate(Sall) if x['op'] == '02/05']
    # повтор 02/05 сразу за первым (оригинал шлёт его дважды) — тот же вход
    starts = [i for k, i in enumerate(starts)
              if k == 0 or Sall[i]['t'] - Sall[starts[k - 1]]['t'] > 10]
    out = []
    for k, i in enumerate(starts):
        seg = Sall[i:starts[k + 1] if k + 1 < len(starts) else len(Sall)]
        out.append(build(seg, Sall, items, path, write))
    return out


def build(S, Sall, items, path, write=False):
    enter = next(bytes.fromhex(x['hex']) for x in S if x['op'] == '02/05')
    eid = struct.unpack_from('>I', enter, 0)[0]
    raw, first = {}, {}
    # «при входе» — до первого действия клиента после 02/04 (+5 с)
    t0 = next(x['t'] for x in S if x['op'] == '02/05')
    for x in S:
        if x['t'] > t0 + 5:
            break
        if x['op'] in RAW_OPS:
            raw[x['op']] = x['hex']                   # последний — уже с надетым
    card = next((x['hex'] for x in Sall if x['op'] == '02/01'
                 and struct.unpack_from('>I', bytes.fromhex(x['hex']), 1)[0] == eid), None)
    raw['02/01'] = card
    me_le = struct.pack('<I', eid)
    own = next((x['hex'] for x in S if x['op'] == '04/02'
                and bytes.fromhex(x['hex'])[1] == 0 and bytes.fromhex(x['hex'])[2:6] == me_le), None)
    raw['04/02'] = own
    zone = next(bytes.fromhex(x['hex']) for x in S if x['op'] == '04/04')
    mp = struct.unpack_from('>I', zone, 4)[0]
    g = bytes.fromhex(raw['08/01'])
    level = struct.unpack_from('<I', g, 37)[0] & 0xffff
    exp = struct.unpack_from('<Q', g, 63)[0]
    fleta = struct.unpack_from('<I', g, 59)[0]
    sp = struct.unpack_from('<I', g, 87)[0]
    cls = struct.unpack_from('<H', enter, 4)[0]
    # имя — из 0c/01 (список гильдии/друзей: запись со своим eid) или из 04/02 +254
    name = None
    if own:
        o = bytes.fromhex(own)
        name = o[254:254 + 32].split(b'\0')[0].decode('utf-8', 'replace') or None
    pos = [0.0, 0.0, 0.0]
    if own:
        pos = list(struct.unpack_from('<3f', bytes.fromhex(own), 6))
    # инвентарь
    inv = next(bytes.fromhex(x['hex']) for x in S if x['op'] == '06/05')
    n = inv[5]
    recs = [inv[6 + i * REC:6 + (i + 1) * REC] for i in range(n)]
    # хранилище (06/1c с записями)
    storage = []
    for x in S:
        if x['op'] == '06/1c' and len(x['hex']) > 200:
            b = bytes.fromhex(x['hex'])
            k = struct.unpack_from('>I', b, 16)[0]
            size = (len(b) - 22) // k if k else 0
            for i in range(k):
                r = b[22 + i * size:22 + (i + 1) * size]
                storage.append(r.hex())
            break
    # GXP-рюкзак
    gxp = collections.OrderedDict()
    for x in S:
        if x['op'] == '06/48':
            b = bytes.fromhex(x['hex'])
            cnt = struct.unpack_from('>I', b, 4)[0]
            for k in range(cnt):
                uid, _z, item, c = struct.unpack_from('<IIII', b, 12 + 16 * k)
                gxp[uid] = [item, c]
    # навыки
    sk = bytes.fromhex(raw['05/05'])
    ns = struct.unpack_from('>H', sk, 4)[0]
    ids = struct.unpack_from(f'<{ns}I', sk, 6)
    lvs = struct.unpack_from(f'<{ns}I', sk, 6 + 4 * ns)
    skills = [[i, l] for i, l in zip(ids, lvs) if i > 1000]
    # выполненные квесты
    done = []
    for x in S:                  # список выполненных: +4 число BE32, затем id LE32 (длина сходится)
        if x['op'] != '09/04':
            continue
        q = bytes.fromhex(x['hex'])
        nq = struct.unpack_from('>I', q, 4)[0] if len(q) >= 8 else -1
        if 8 + 4 * nq == len(q):
            done = list(struct.unpack_from(f'<{nq}I', q, 8))
            break
        nq = nq & 0xffff                         # вариант: +4 u16 страница, +6 u16 число
        if 0 < nq and 8 + 4 * nq <= len(q):
            done = list(struct.unpack_from(f'<{nq}I', q, 8))
            break
    # характеристики оригинала (08/02, блок +32) — основа для расчёта
    st = bytes.fromhex(raw['08/02'])
    f = lambda o: struct.unpack_from('<f', st, 32 + o)[0]
    stat_base = {'level': level, 'hp': f(0), 'mp': f(12), 'atk': f(52), 'def': f(64),
                 'matk': f(80), 'mdef': f(88)}
    # питомцы: список у Мелиссы (S 11/00) и текущий (S 11/01) — сырые записи
    sys.path.insert(0, os.path.join(ROOT, 'server'))
    import pets as _pets
    pet_recs = {}
    for x in S:
        if x['op'] == '11/00':
            for r in _pets.parse_list(bytes.fromhex(x['hex'])):
                pet_recs[struct.unpack_from('<I', r, 0)[0]] = r.hex()
    cur = next((bytes.fromhex(x['hex']) for x in S if x['op'] == '11/01'), None)
    active = None
    if cur and len(cur) > 70 and struct.unpack_from('<I', cur, 0)[0]:
        active = struct.unpack_from('<I', cur, 0)[0]
        pet_recs.setdefault(active, cur[:cur.index(bytes(1), 69) + 1].hex())
    if raw.get('02/01'):                      # ник с настоящего сервера в карточку не берём
        c = bytes.fromhex(raw['02/01'])
        nm = (name or 'Hero')[:20]
        if len(c) > 385:
            raw['02/01'] = (c[:383] + bytes([len(nm), 0]) + b''.join(struct.pack('<I', ord(x)) for x in nm)
                            + c[385 + c[383] * 4:]).hex()
    ch = {'eid': eid, 'pets': list(pet_recs.values()), 'pet_active': active, 'name': name or f'imported_{eid:x}', 'cls': cls, 'level': level, 'exp': exp,
          'map': mp, 'pos': pos, 'angle': 0.0, 'fleta': fleta, 'fleta_attr': {},
          'sp_spent': level - 1 - sp, 'skills': skills,
          'quests': {'active': {}, 'done': done},
          'inv': [r.hex() for r in recs], 'storage': storage,
          'gxp': [v for v in gxp.values()], 'raw': raw, 'stat_base': stat_base,
          'imported_from': os.path.basename(path)}
    # хранилище -> формат нашего сервера {ячейка: [предмет, кол-во]}
    stash = {}
    for h in storage:
        r = bytes.fromhex(h)
        item, cnt = struct.unpack_from('<I', r, 0)[0], struct.unpack_from('<I', r, 14)[0]
        if str(item) in items:
            stash[str(r[4])] = [item, max(1, cnt)]
    ch['stash'] = stash
    known = sum(1 for r in recs if str(struct.unpack_from('<I', r, 2)[0]) in items)
    print(f"{ch['name']} eid {eid:#x} класс {cls} ур.{level} опыт {exp} флетта {fleta} очков навыков {sp}")
    print(f"карта {mp} позиция {[round(v) for v in pos]}; вещей {len(recs)} (известно клиенту {known}), "
          f"хранилище {len(storage)} (известно {len(ch['stash'])}), GXP {len(gxp)}, навыков {len(skills)}, квестов выполнено {len(done)}")
    print('сырые пакеты:', {k: (len(v) // 2 if v else None) for k, v in raw.items()})
    print('питомцы:', [_pets.Pet(bytes.fromhex(h)).name for h in ch['pets']], 'активный', ch['pet_active'])
    print('база характеристик:', {k: round(v, 1) for k, v in stat_base.items()})
    if write:
        shutil.copy(ACC, ACC + '.before_import')
        acc = json.load(open(ACC, encoding='utf-8'))
        chars = acc.setdefault(ACCOUNT_ID, [])
        chars[:] = [c for c in chars if c.get('eid') != eid]
        chars.append(ch)
        json.dump(acc, open(ACC, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'записано в {ACC} (копия прежнего — accounts.json.before_import)')
    return ch


if __name__ == '__main__':
    if '--account' in sys.argv:
        ACCOUNT_ID = sys.argv[sys.argv.index('--account') + 1]
    main(sys.argv[1], '--write' in sys.argv)
