"""Добыча с мобов по записям ОРИГИНАЛА -> сводка (docs/drop_original.md): предметов на убийство, доли по
видам, караты по уровню. Пакеты входа (02/xx) пропускаются и не печатаются.
Запуск: python -X utf8 tools/cap_orig_drops.py data/captures/orig_1.jsonl data/captures/orig_hl_Pers4x.jsonl data/captures/remain3_persons.jsonl
"""
import collections, json, struct, sys
sys.path.insert(0, 'server')
import loot
ITEMS = loot.ITEMS
GOLD = 999999
per_kill = []          # список (npc, lvl, [items], gold)
for path in sys.argv[1:]:
    mobs, counted = {}, {}
    cur = me = None
    for l in open(path):
        x = json.loads(l)
        op = x['op']
        if x['dir'] != 'S' or (op.startswith('02/') and op != '02/05'):
            continue
        p = bytes.fromhex(x['hex'])
        if op == '02/05':                 # свой eid: считать только свои убийства
            me = struct.unpack_from('>I', p, 0)[0]
            continue
        if op == '04/02' and len(p) >= 0x44 and p[1] == 1:
            mobs[struct.unpack_from('<I', p, 2)[0]] = (struct.unpack_from('<I', p, 0x40)[0], struct.unpack_from('<H', p, 50)[0])
        elif op == '08/06' and len(p) >= 18 and p[0] == 1 and struct.unpack_from('>I', p, 10)[0] == 0:
            eid = struct.unpack_from('>I', p, 1)[0]
            if eid in mobs and x['t'] - counted.get(eid, -1e9) > 30:
                counted[eid] = x['t']
                if struct.unpack_from('>I', p, len(p) - 4)[0] != me:
                    cur = None            # чужое убийство — его добыча не наша
                    continue
                cur = {'t': x['t'], 'mob': mobs[eid], 'items': [], 'gold': 0}
                per_kill.append(cur)
        elif op == '06/04' and len(p) >= 40 and cur and x['t'] - cur['t'] < 2.0:
            it = struct.unpack_from('<I', p, 22)[0]
            n = struct.unpack_from('<I', p, 36)[0]
            if it == GOLD:
                cur['gold'] += n
            else:
                cur['items'].append(it)
K = len(per_kill)
print('убийств', K)
cnt = collections.Counter(len(k['items']) for k in per_kill)
print('предметов на убийство (кроме карат):', dict(sorted(cnt.items())), 'в среднем', round(sum(len(k['items']) for k in per_kill) / K, 3))
def cls(i):
    it = ITEMS.get(i)
    if not it: return 'нет в itemBase'
    if it['kind'] == 1: return 'снаряжение'
    if 80000 <= i < 81000: return 'часть монстра 80xxx'
    if it['kind'] == 2: return 'зелье/расходник'
    return f"прочее kind{it['kind']} cat{it['cat']}"
c = collections.Counter(cls(i) for k in per_kill for i in k['items'])
for k_, v in c.most_common(): print(f'  {k_}: {v} ({v / K:.3f} на убийство)')
print('доля убийств со снаряжением', round(sum(1 for k in per_kill if any(cls(i) == "снаряжение" for i in k['items'])) / K, 3))
allit = collections.Counter(i for k in per_kill for i in k['items'])
print('все предметы:', ', '.join(f'{i} {loot.item_name(i)} x{n}' for i, n in allit.most_common(60)))
# караты от уровня
g = collections.defaultdict(list)
for k in per_kill:
    if k['gold']: g[k['mob'][1] // 10 * 10].append(k['gold'])
print('караты по уровням:', {lv: (min(v), round(sum(v) / len(v)), max(v), len(v)) for lv, v in sorted(g.items())})
