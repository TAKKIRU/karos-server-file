"""Кадры записи в окне времени: python tools/cap_window.py <jsonl> HH:MM:SS HH:MM:SS [ops через запятую]"""
import datetime, json, sys
NOISE = {'04/01', '04/03', '0b/01', '08/06', '03/08', '0c/09', '16/0b', '08/0b', '03/00', '02/0b',
         '04/02', '05/09', '06/5c'}
F = [json.loads(l) for l in open(sys.argv[1])]
a, b = sys.argv[2], sys.argv[3]
only = set(sys.argv[4].split(',')) if len(sys.argv) > 4 else None
for x in F:
    tm = datetime.datetime.fromtimestamp(x['t']).strftime('%H:%M:%S.%f')[:-3]
    if not (a <= tm <= b):
        continue
    if only and x['op'] not in only:
        continue
    if not only and x['op'] in NOISE:
        continue
    print(tm, x['dir'], x['op'], len(x['hex']) // 2, x['hex'][:150])
