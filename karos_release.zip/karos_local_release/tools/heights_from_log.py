"""Высоты пола из лога сервера (server/emu_*.log) -> data/heights_learned.json.

Карта — по строкам «КАРТА: <имя> (...)» и «варп -> … (<имя> x,y)»; высота — из 04/01
клиента, когда он идёт (смещение по плоскости, высота «откуда» = «куда»).
Запуск: python tools/heights_from_log.py [лог ...]
"""
import json, os, re, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'data', 'heights_learned.json')
CELL = 200


def main(logs):
    H = json.load(open(OUT, encoding='utf-8')) if os.path.exists(OUT) else {}
    n = 0
    for lg in logs:
        cur = None
        for line in open(lg, encoding='utf-8', errors='replace'):
            if 'КАРТА:' in line:
                m = re.search(r'КАРТА: (\S+)', line)
                cur = m.group(1) if m else cur
            elif 'варп ->' in line:
                m = re.search(r'\((\S+) -?\d+,-?\d+\)\s*$', line)
                cur = m.group(1) if m else cur
            elif cur and '<- 0x04/0x01' in line:
                try:
                    p = bytes.fromhex(line.split()[3])[6:]
                    x0, y0, z0, x, y, z = struct.unpack_from('<6f', p, 6)
                except (ValueError, IndexError, struct.error):
                    continue
                if abs(z0 - z) < 0.5 and abs(x0 - x) + abs(y0 - y) > 1 and 10 < x < 1e5 and 10 < y < 1e5 \
                        and -1e5 < z < 1e5:
                    H.setdefault(cur, {})[f'{int(x // CELL)},{int(y // CELL)}'] = round(z, 1)
                    n += 1
    json.dump(H, open(OUT, 'w', encoding='utf-8'), separators=(',', ':'))
    print(n, 'шагов;', {k: len(v) for k, v in H.items()})


if __name__ == '__main__':
    main(sys.argv[1:] or [os.path.join(ROOT, 'server', 'emu_10101.log')])
